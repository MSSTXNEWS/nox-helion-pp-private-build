# P01: verify publisher-provided contents before any activation. Windows PowerShell 5.1-compatible.
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Root,
  [Parameter(Mandatory=$true)][string]$Manifest
)
$ErrorActionPreference = 'Stop'
function Fail([string]$reason) { throw "P01_PAYLOAD_VERIFY_FAILED: $reason" }
$rootInfo = Get-Item -LiteralPath $Root -ErrorAction Stop
if (-not $rootInfo.PSIsContainer) { Fail 'root is not directory' }
$rootFull = [IO.Path]::GetFullPath($rootInfo.FullName).TrimEnd('\')
function Assert-NoReparseAncestors([string]$Target) {
  $cursor = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Target))
  while ($cursor -and ($cursor -ieq $rootFull -or $cursor.StartsWith($rootFull+'\',[StringComparison]::OrdinalIgnoreCase))) {
    $node = Get-Item -LiteralPath $cursor -Force -ErrorAction Stop
    if (-not $node.PSIsContainer -or (($node.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
      Fail "reparse or non-directory ancestor $cursor"
    }
    if ($cursor -ieq $rootFull) { break }
    $cursor = [IO.Path]::GetDirectoryName($cursor)
  }
}
$manifestFull = [IO.Path]::GetFullPath($Manifest)
if (-not $manifestFull.StartsWith($rootFull+'\', [StringComparison]::OrdinalIgnoreCase)) { Fail 'manifest outside root' }
Assert-NoReparseAncestors $manifestFull
$m = Get-Content -LiteralPath $manifestFull -Raw -Encoding UTF8 | ConvertFrom-Json
if ($m.schema -cne 'NOX_P01_PAYLOAD_SHA256_V1') { Fail 'schema' }
if ($m.entrypoint -cne 'NOX.P01.Shell.exe') { Fail 'entrypoint' }
if ($m.files.Count -lt 1) { Fail 'empty manifest' }
$registered = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach($f in $m.files) {
  $rel = [string]$f.path
  if ([string]::IsNullOrWhiteSpace($rel) -or [IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)' -or $rel -match '[:*?"<>|]') { Fail "invalid path $rel" }
  $rel = $rel.Replace('/','\')
  if (-not $registered.Add($rel)) { Fail "duplicate path $rel" }
  $full = [IO.Path]::GetFullPath((Join-Path $rootFull $rel))
  if (-not $full.StartsWith($rootFull+'\',[StringComparison]::OrdinalIgnoreCase)) { Fail "escape $rel" }
  Assert-NoReparseAncestors $full
  $obj = Get-Item -LiteralPath $full -ErrorAction Stop
  if ($obj.PSIsContainer -or (($obj.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { Fail "not regular file $rel" }
  if ($obj.Length -ne [int64]$f.bytes) { Fail "size mismatch $rel" }
  $actual = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -cne ([string]$f.sha256).ToLowerInvariant()) { Fail "sha mismatch $rel" }
}
# Reject all nested directory reparse points, including empty junctions.
$allDirs = @(Get-ChildItem -LiteralPath $rootFull -Recurse -Force -Directory)
foreach ($dir in $allDirs) {
  if (($dir.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { Fail "reparse directory $($dir.FullName)" }
  Assert-NoReparseAncestors $dir.FullName
}
# Include only regular files the packager approved; prevents hidden extras in the staging area.
$actualFiles = @(Get-ChildItem -LiteralPath $rootFull -Recurse -Force -File)
foreach ($file in $actualFiles) {
  Assert-NoReparseAncestors $file.FullName
  if (($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { Fail "reparse $($file.FullName)" }
  $rel = $file.FullName.Substring($rootFull.Length+1)
  if ($rel -eq 'payload.sha256.json') { continue }
  if (-not $registered.Contains($rel)) { Fail "unexpected file $rel" }
}
if ($actualFiles.Count -ne ($registered.Count + 1)) { Fail 'file count mismatch' }
if (-not (Test-Path -LiteralPath (Join-Path $rootFull 'NOX.P01.Shell.exe') -PathType Leaf)) { Fail 'entrypoint absent' }
'P01_PAYLOAD_SHA256_PASS'
