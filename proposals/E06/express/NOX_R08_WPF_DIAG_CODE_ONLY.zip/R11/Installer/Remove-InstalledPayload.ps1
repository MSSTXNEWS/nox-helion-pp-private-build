# Conservative uninstall: remove only unmodified files listed in payload manifest.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$InstallRoot)
$ErrorActionPreference = 'Stop'
$expected = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs\NOX HELION'))
$root = [IO.Path]::GetFullPath($InstallRoot)
if ($root -ine $expected) { throw 'P01_UNINSTALL_WRONG_ROOT' }
$localRoot = [IO.Path]::GetFullPath($env:LOCALAPPDATA).TrimEnd('\')
$cursor = $root
while ($cursor -and ($cursor -ieq $localRoot -or $cursor.StartsWith($localRoot+'\',[StringComparison]::OrdinalIgnoreCase))) {
  if (Test-Path -LiteralPath $cursor) {
    $node = Get-Item -LiteralPath $cursor -Force
    if (($node.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "P01_UNINSTALL_REPARSE_INSTALL_PARENT:$cursor" }
  }
  if ($cursor -ieq $localRoot) { break }
  $cursor = [IO.Path]::GetDirectoryName($cursor)
}
if (-not (Test-Path -LiteralPath (Join-Path $root 'nox-p01-owned.txt'))) { throw 'P01_UNINSTALL_NO_OWNERSHIP_MARKER' }
if ((Get-Item -LiteralPath $root).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'P01_UNINSTALL_REPARSE_ROOT' }
function Assert-NoReparseAncestors([string]$Target) {
  $cursor = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Target))
  while ($cursor -and ($cursor -ieq $root -or $cursor.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase))) {
    $node = Get-Item -LiteralPath $cursor -Force -ErrorAction Stop
    if (-not $node.PSIsContainer -or (($node.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
      throw "P01_UNINSTALL_REPARSE_ANCESTOR:$cursor"
    }
    if ($cursor -ieq $root) { break }
    $cursor = [IO.Path]::GetDirectoryName($cursor)
  }
}
$manifestPath = Join-Path $root 'payload.sha256.json'
Assert-NoReparseAncestors (Join-Path $root 'payload.sha256.json')
$m = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($m.schema -cne 'NOX_P01_PAYLOAD_SHA256_V1') { throw 'P01_UNINSTALL_BAD_MANIFEST' }
$allowed = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$directories = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$removed = 0
$kept = 0
foreach ($f in $m.files) {
  $relative = [string]$f.path
  if ([string]::IsNullOrWhiteSpace($relative) -or [IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)' -or $relative -match '[:*?"<>|]') { throw 'P01_UNINSTALL_BAD_PATH' }
  $relative = $relative.Replace('/','\')
  if (-not $allowed.Add($relative)) { throw 'P01_UNINSTALL_DUPLICATE_PATH' }
  $path = [IO.Path]::GetFullPath((Join-Path $root $relative))
  if (-not $path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'P01_UNINSTALL_PATH_ESCAPE' }
  Assert-NoReparseAncestors $path
  if (Test-Path -LiteralPath $path -PathType Leaf) {
    $item = Get-Item -LiteralPath $path -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $item.Length -ne [int64]$f.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne ([string]$f.sha256).ToLowerInvariant()) {
      $kept++; continue
    }
    Remove-Item -LiteralPath $path -Force
    $removed++
  }
  $parent = [IO.Path]::GetDirectoryName($path)
  while ($parent -and $parent.Length -gt $root.Length -and $parent.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) {
    [void]$directories.Add($parent)
    $parent = [IO.Path]::GetDirectoryName($parent)
  }
}
foreach ($d in @($directories | Sort-Object Length -Descending)) {
  try { if ((Get-ChildItem -LiteralPath $d -Force | Measure-Object).Count -eq 0) { Remove-Item -LiteralPath $d -Force } } catch { }
}
# Never remove unknown/modified files. Metadata and uninstaller are removed by NSIS only on complete success.
if ($kept -gt 0) { Write-Output "P01_UNINSTALL_PARTIAL kept_modified=$kept removed=$removed"; exit 9 }
Write-Output "P01_UNINSTALL_PAYLOAD_PASS removed=$removed"
