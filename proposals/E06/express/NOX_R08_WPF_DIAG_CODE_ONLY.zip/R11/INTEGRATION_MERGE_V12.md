# Integration merge · Canon V11 · refreshed

RunID: `NOX-EXE-SYNC-V12-CANON-V11-R6-P04-INTENSITY-20261026T192431Z`
Scope: Windows EXE EXPRESS INTEGRATOR only. WEB 540 remains separate.

Current base is the existing integrated V12 candidate from Drive. P03 was refreshed from the latest current Drive revision (115,965 B, SHA `87b8f7d1…`), keeping the one WPF host and P02/P04/P05 integrations. P01–P05 weights remain 20/25/20/25/10; E06/E07 carry zero weight.

Static corrections in this refresh: stable queue operation IDs; unknown transfer measurements remain N/D; STOPPED/PAUSED events wait for owner acknowledgement; local V3 journal writes share a process lock and Windows named mutex; P03 shell actions are included in the common journal.

No Windows build, tests, live chat/pull, actual training, Drive sync from inside EXE or independent same-BuildID/SHA acceptance was run. Accepted product readiness stays N/D; `REPORT_GATE=HOLD` until Google Drive write/readback; `EXE RELEASE=BLOCKED`.

## R6 additive source delta · P04 intensity and thermal guard

RunID `NOX-EXE-SYNC-V12-CANON-V11-R6-P04-INTENSITY-20261026T192431Z`. Added an accessible ECO/BALANCED/INTENSIVE slider to the existing QLoRA card and host allowlist; it saves for the next run and is disabled while a worker is active. The Python worker applies 20/40/60 steps, checks selected NVIDIA temperature by UUID, fails closed on unavailable/timed-out sensor reads, requests a checkpoint at optimizer boundaries, and avoids post-STOP/HOLD GPU evaluation. This is bounded source behavior only; it is not a utilization/power cap.

Verification in this candidate: source regression 20/20 PASS, Python compile PASS, inline JavaScript syntax PASS, HTML parse PASS. Windows/.NET, WebView2, real GPU/training, Drive sync from inside the EXE, and independent same-EXE acceptance remain NOT RUN. Product HOLD; EXE release BLOCKED.


## C6 · Registry provenance correction

Corrected stale legacy I08 adapter-source digest to the active P04 worker source path and SHA. Runtime dependency compatibility remains unresolved; I08 stays SOURCE_ONLY_HOLD.
