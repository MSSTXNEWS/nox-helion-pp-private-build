# NOX HELION EXPRESS INTEGRATOR · CANON V11

Windows .NET 8 WPF/WebView2 installer source candidate, based on the R11 host. See `README_INTEGRATION.md` and `INTEGRATION_MERGE_V12.md` for merged modules and exact release holds.

Build and acceptance scripts are under `Scripts/`. No Windows build or independent release acceptance has been run on this merged source candidate. Do not treat this archive as a released EXE.
