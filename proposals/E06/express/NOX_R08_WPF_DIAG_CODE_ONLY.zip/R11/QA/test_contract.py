import unittest,json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class Integration(unittest.TestCase):
 def test_weights(self):
  d=json.loads((ROOT/'Contracts/events.v3.json').read_text());self.assertEqual(sum(d['packageWeights'][k] for k in ['P01','P02','P03','P04','P05']),100)
 def test_v3_fields_and_states(self):
  d=json.loads((ROOT/'Contracts/events.v3.json').read_text());self.assertIn('run_id',d['requiredEventFields']);self.assertIn('task_id',d['requiredEventFields']);self.assertIn('timestamp_utc',d['requiredEventFields']);self.assertIn('STOPPED',d['allowedStates']);self.assertIn('task.progress',d['allowedEventTypes'])
 def test_event_bridge_fails_closed(self):
  s=(ROOT/'Contracts/EventV3Bridge.cs').read_text();self.assertIn('EvidenceVerified: false',s);self.assertIn('FileMode.Append',s);self.assertIn('JournalWritten: false',s);self.assertIn('"P03-" + sourceEvent.EventId',s)
 def test_p03_host_wiring(self):
  s=(ROOT/'MainWindow.xaml.cs').read_text();h=(ROOT/'Assets/index.html').read_text();self.assertIn('ModelCenterLauncher.CreateWindow(_modelCenterEvents)',s);self.assertIn('case "openModelCenter"',s);self.assertIn("['model-center','openModelCenter']",h)
 def test_no_accepted_progress(self):
  d=json.loads((ROOT/'INTEGRATION_CONTRACT.json').read_text());self.assertTrue(all(x['accepted'] is None for x in d['installerPackages']))
 def test_chat_zip(self):
  with zipfile.ZipFile(ROOT/'Modules/NOX_APP_R9.zip') as z:self.assertIsNone(z.testzip())
 def test_model_catalog_is_not_claimed_as_license_approved(self):
  s=(ROOT/'Packages/P03/worker-catalog/ModelCatalog.cs').read_text();self.assertIn('Entries.Count != 24',s);self.assertIn('License review is required before use',s);self.assertNotIn('LicenseReviewStatus = "APPROVED"',s)
if __name__=='__main__':unittest.main()
