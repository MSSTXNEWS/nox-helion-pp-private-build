"""Source-level P01 guardrails, not equivalent to NSIS compiler / Windows QA."""
import hashlib
import json
import pathlib
import tempfile
import unittest
import sys

ROOT = next(p for p in pathlib.Path(__file__).resolve().parents if (p / 'Installer').is_dir())
INST = ROOT / 'Installer'
NSIS = (INST / 'NOX-HELION-Setup.nsi').read_text(encoding='utf-8')
BUILD = (INST / 'Build-NSIS.ps1').read_text(encoding='utf-8')
VERIFY = (INST / 'Verify-Payload.ps1').read_text(encoding='utf-8')
UNINST = (INST / 'Remove-InstalledPayload.ps1').read_text(encoding='utf-8')

class InstallerSourceTests(unittest.TestCase):
    def test_user_only_and_scoped_uninstall(self):
        self.assertIn('RequestExecutionLevel user', NSIS)
        self.assertIn('SetOutPath "$TEMP"', NSIS)
        self.assertIn('StrCmp $INSTDIR "$LOCALAPPDATA\\Programs\\NOX HELION"', NSIS)
        self.assertNotIn('RMDir /r "$INSTDIR"', NSIS)
        self.assertNotIn('Delete /REBOOTOK', NSIS)
        self.assertNotIn('ExecWait "http', NSIS)

    def test_stage_validation_before_activation(self):
        code = NSIS.index('Section "NOX HELION application"')
        verify = NSIS.index('Verify-Payload.ps1', code)
        activate = NSIS.index('Rename "$StageDir" "$INSTDIR"', code)
        self.assertLess(verify, activate)
        self.assertIn('IfErrors 0 +4', NSIS)
        self.assertIn('Rename "$BackupDir" "$INSTDIR"', NSIS)

    def test_prereqs_and_payload_manifest(self):
        self.assertIn('P01_WEBVIEW2_RUNTIME_MISSING', (INST / 'Preflight-InstallPath.ps1').read_text())
        self.assertIn('NOX_P01_PAYLOAD_SHA256_V1', BUILD)
        self.assertIn('Get-FileHash', BUILD)
        self.assertIn('P01_WINDOWS_X64_REQUIRED', BUILD)
        self.assertIn('P01_OUTPUT_PAYLOAD_EXISTS_USE_FRESH_DIR', BUILD)

    def test_payload_no_unexpected_files_or_escape(self):
        self.assertIn('unexpected file', VERIFY)
        self.assertIn('duplicate path', VERIFY)
        self.assertIn('file count mismatch', VERIFY)
        self.assertIn('ReparsePoint', VERIFY)
        self.assertIn('P01_UNINSTALL_BAD_PATH', UNINST)

    def test_preserves_user_data_and_recovery(self):
        self.assertNotIn('RMDir /r', NSIS)
        self.assertNotIn('Remove-Item -LiteralPath $env:LOCALAPPDATA', BUILD)
        self.assertIn('__p01_previous', NSIS)
        self.assertIn('__p01_rollback_saved', NSIS)
        self.assertIn('modified files retained', NSIS)

    def test_no_common_mainwindow_changes(self):
        self.assertEqual(hashlib.sha256((ROOT / 'MainWindow.xaml.cs').read_bytes()).hexdigest(), '6fc49544f77ec6ce2e7b2e8f3ab86c9a2a64c25d0eb3eb29547c5677851ef210')

    def test_source_hash_and_no_web_fetch_installer(self):
        for path in INST.iterdir():
            if path.is_file():
                data = path.read_bytes()
                self.assertGreater(len(data), 200)
                self.assertEqual(len(hashlib.sha256(data).hexdigest()), 64)
        for script in (BUILD, NSIS):
            self.assertNotIn('Invoke-WebRequest', script)
            self.assertNotIn('DownloadFile', script)

if __name__ == '__main__': unittest.main()
