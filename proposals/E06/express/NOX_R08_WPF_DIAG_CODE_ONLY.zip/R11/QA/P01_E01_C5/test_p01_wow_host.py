from pathlib import Path
from playwright.sync_api import sync_playwright
from datetime import datetime, timezone
p=Path(__file__).resolve().parents[2]/'Assets/index.html'
with sync_playwright() as playwright:
 browser=playwright.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844})
 page.evaluate('''window.chrome=window.chrome||{};window.chrome.webview={_handlers:[],addEventListener:function(type,fn){if(type==='message')this._handlers.push(fn)},postMessage:function(){}};window.__noxHostEmit=function(data){for(const fn of window.chrome.webview._handlers)fn({data})}''')
 errors=[]
 page.on('pageerror', lambda error:errors.append(str(error)))
 page.set_content(p.read_text('utf-8'),wait_until='domcontentloaded')
 page.wait_for_timeout(150)
 assert page.locator('#home .nox-orbit-core').count()==8
 assert page.locator('#tiles [data-menu-index]').count()==8
 assert page.locator('.nox-wow-feed-list li').count()==1
 host={'kind':'installerEvent','journalWritten':True,'Event':{'schema':'NOX-INSTALLER-EVENT-v3','run_id':'run-12345678','event_id':'a'*32,'event_type':'task.completed','task_id':'P03-abc','package_id':'P03','action_id':'model_pull','timestamp_utc':'2026-10-27T21:00:00Z','state':'COMPLETED','source':'P03.ModelCenter','message':'complete','evidence_verified':False}}
 page.evaluate('(m)=>window.__noxHostEmit(m)',host)
 assert 'task.completed' in page.locator('.nox-wow-feed-list').inner_text()
 assert 'Локальная операция' in page.locator('.nox-wow-toaststack').inner_text()
 assert page.locator('#home .nox-orbit-core[aria-valuenow]').count()==0
 # duplicate event must not repeat or grant acceptance
 page.evaluate('(m)=>window.__noxHostEmit(m)',host)
 assert page.locator('.nox-wow-feed-list li').count()==1
 # Without journal acknowledgement there is no trusted entry.
 host['journalWritten']=False;host['Event']['event_id']='b'*32
 page.evaluate('(m)=>window.__noxHostEmit(m)',host)
 assert page.locator('.nox-wow-feed-list li').count()==1
 page.keyboard.press('Control+k')
 assert page.locator('.nox-wow-palette').is_visible()
 page.keyboard.press('Escape')
 assert not page.locator('.nox-wow-palette').is_visible()
 page.keyboard.press('Tab')
 assert page.locator('body').get_attribute('data-nox-keyboard')=='true'
 page.locator('.nox-wow-switch').click()
 assert 'nox-wow-eco' in page.locator('body').get_attribute('class')
 print('PASS UI: 8 orbits; 8 menu actions; WebView2 installerEvent journal adapter; duplicate reject; unverified ring unknown; Ctrl+K; keyboard focus; ECO')
 print('Existing page JS errors:',errors[:3])
 browser.close()
