"""Source-level regression for P05 typed receipt projection (no dotnet SDK required)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "Packages/P05/InstallerRunReport.cs").read_text(encoding="utf-8")
MAIN = (ROOT / "MainWindow.xaml.cs").read_text(encoding="utf-8")


class P05ReceiptInputContract(unittest.TestCase):
    def test_builder_consumes_separate_typed_receipts(self):
        self.assertIn("P05RunReceipt? runReceipt = null", SOURCE)
        self.assertIn("OverallCycles: BuildPackageOverallCycles(packageLanes)", SOURCE)
        self.assertIn("var packageLanes = PackageLaneStatuses(runId, runReceipt)", SOURCE)
        self.assertIn("public sealed record P05RunReceipt(", SOURCE)
        self.assertIn("public sealed record P05PackageLaneReceipt(", SOURCE)
        self.assertIn("public sealed record P05CycleReceipt(", SOURCE)

    def test_missing_mismatched_or_partial_data_stays_nd(self):
        self.assertIn("if (!MatchesRun(runId, receipt))", SOURCE)
        self.assertIn("receipts is null || receipts.Count != expectedIds.Count", SOURCE)
        self.assertIn("Caller-provided flags and digest-shaped strings are not a trust boundary.", SOURCE)
        self.assertIn("return UnknownCycles(expectedIds);", SOURCE)
        self.assertIn('new P05CycleStatus(id, "N_D", null)', SOURCE)

    def test_untrusted_flags_and_sha_syntax_cannot_promote_cycle(self):
        self.assertNotIn("!item.EvidenceVerified", SOURCE)
        self.assertNotIn("EvidenceHash.IsMatch", SOURCE)
        self.assertIn("No trusted signer or verifier binds package-cycle evidence", SOURCE)
        self.assertIn("Google Drive report/journal writeback and readback acknowledgement are not implemented", SOURCE)
        self.assertIn('ReportGate: "HOLD"', SOURCE)
        self.assertIn('JsonPropertyName("report_gate")', SOURCE)
        self.assertIn('JsonPropertyName("report_gate_reasons")', SOURCE)
        self.assertIn('## REPORT_GATE', SOURCE)
        self.assertIn('REPORT_GATE · ', SOURCE)
        self.assertIn("AcceptedReadinessPercent: null", SOURCE)

    def test_html_and_markdown_render_cycle_statuses_without_readiness_fill(self):
        for package, weight in [("P01", 20), ("P02", 25), ("P03", 20), ("P04", 25), ("P05", 10)]:
            self.assertIn(f'["{package}"] = {weight}', SOURCE)
        self.assertIn('"| ⚪ ОБЩИЙ |', SOURCE)
        self.assertIn('"<tr class=\\"overall-cycle-row\\">', SOURCE)
        self.assertIn('"## Циклы пакетов · V7"', SOURCE)
        self.assertIn('Enumerable.Range(1, 5).Select(index => $"C{index}")', SOURCE)
        self.assertIn("Н/Д", SOURCE)
        self.assertIn("snapshot.AcceptedReadinessPercent", SOURCE)
        self.assertIn('role=\\"progressbar\\"', SOURCE)
        self.assertIn('aria-valuetext=\\"', SOURCE)
        self.assertIn('"width:").Append(width)', SOURCE)
        self.assertIn('var width = ValidPercent(percent) ? value : "0%"', SOURCE)
        self.assertIn('var overallWidth = ValidPercent(overall) ? overallValue : "0%"', SOURCE)
        self.assertIn("BuildMarkdown(snapshot)", SOURCE)
        self.assertIn('statuses.All(value => value == "VERIFIED")', SOURCE)
        self.assertIn('statuses.Any(value => value == "N_D")', SOURCE)
        self.assertIn("BuildPackageOverallCycles(packageLanes)", SOURCE)
        self.assertIn('"NOT_STARTED" => "🟣 NOT_STARTED"', SOURCE)
        self.assertIn('"IN_PROGRESS" => "🟡 IN_PROGRESS"', SOURCE)

    def test_contract_does_not_claim_event_cycle_fields(self):
        contract = (ROOT / "Contracts/events.v3.json").read_text(encoding="utf-8")
        self.assertNotIn("cycle_receipt", contract)
        self.assertNotIn("lane_receipt", contract)

    def test_saved_report_writes_all_formats_from_one_run_snapshot(self):
        start = MAIN.index("private async Task SaveReportAsync()")
        end = MAIN.index("private void CancelAction()", start)
        route = MAIN[start:end]
        self.assertIn("CreateSnapshot(jsonl, _eventV3Bridge.RunId)", route)
        self.assertIn('Path.Combine(reports, stem + ".json")', route)
        self.assertIn('Path.Combine(reports, stem + ".html")', route)
        self.assertIn('Path.Combine(reports, stem + ".md")', route)
        self.assertIn("WriteJsonAsync(snapshot, jsonPath)", route)
        self.assertIn("WriteHtmlAsync(snapshot, htmlPath)", route)
        self.assertIn("WriteMarkdownAsync(snapshot, markdownPath)", route)
        self.assertIn("runId = snapshot.RunId", route)
        self.assertNotIn("P05RunReceipt", route)


if __name__ == "__main__":
    unittest.main()
