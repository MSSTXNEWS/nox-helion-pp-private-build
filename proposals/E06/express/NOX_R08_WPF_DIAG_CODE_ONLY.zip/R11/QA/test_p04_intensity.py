import importlib.util
import subprocess
import unittest
from pathlib import Path
from unittest.mock import patch


SCRIPT = Path(__file__).parents[1] / "Packages" / "P04" / "train_qlora.py"
SPEC = importlib.util.spec_from_file_location("nox_train_qlora", SCRIPT)
WORKER = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(WORKER)


class IntensityProfileTests(unittest.TestCase):
    def test_profiles_only_change_bounded_training_work(self):
        self.assertEqual(
            {name: (p["max_steps"], p["max_seq_length"], p["gradient_accumulation_steps"])
             for name, p in WORKER.INTENSITY_PROFILES.items()},
            {
                "ECO": (20, 1024, 8),
                "BALANCED": (40, 1024, 8),
                "INTENSIVE": (60, 1024, 8),
            },
        )
        self.assertEqual(WORKER.INTENSITY_PROFILES["ECO"]["save_steps"], 5)
        self.assertEqual(WORKER.INTENSITY_PROFILES["ECO"]["eval_steps"], 5)

    def test_temperature_threshold_is_inclusive_and_unknown_fails_closed(self):
        self.assertIsNone(WORKER.gpu_thermal_stop_reason(82.9, 83.0))
        self.assertEqual(WORKER.gpu_thermal_stop_reason(83.0, 83.0), "GPU_TEMPERATURE_LIMIT_EXCEEDED")
        self.assertEqual(WORKER.gpu_thermal_stop_reason(None, 83.0), "GPU_TEMPERATURE_UNAVAILABLE")

    @patch.object(WORKER, "find_nvidia_smi", return_value="nvidia-smi")
    @patch.object(WORKER.subprocess, "run")
    def test_temperature_reads_selected_gpu_by_uuid(self, run, _find):
        run.return_value = subprocess.CompletedProcess([], 0, stdout="81\n", stderr="")
        self.assertEqual(WORKER.read_gpu_temperature_c("GPU-abc"), 81.0)
        self.assertEqual(run.call_args.args[0][:2], ["nvidia-smi", "--id=GPU-abc"])
        self.assertFalse(run.call_args.kwargs["shell"])

    @patch.object(WORKER, "find_nvidia_smi", return_value="nvidia-smi")
    @patch.object(WORKER.subprocess, "run")
    def test_missing_temperature_fails_closed(self, run, _find):
        run.return_value = subprocess.CompletedProcess([], 1, stdout="N/A", stderr="sensor unavailable")
        self.assertIsNone(WORKER.read_gpu_temperature_c("GPU-abc"))

    @patch.object(WORKER, "find_nvidia_smi", return_value="nvidia-smi")
    @patch.object(WORKER.subprocess, "run")
    def test_invalid_temperature_fails_closed(self, run, _find):
        run.return_value = subprocess.CompletedProcess([], 0, stdout="N/A", stderr="")
        self.assertIsNone(WORKER.read_gpu_temperature_c("GPU-abc"))

    @patch.object(WORKER, "find_nvidia_smi", return_value="nvidia-smi")
    @patch.object(WORKER.subprocess, "run", side_effect=subprocess.TimeoutExpired("nvidia-smi", 5))
    def test_temperature_timeout_fails_closed(self, _run, _find):
        self.assertIsNone(WORKER.read_gpu_temperature_c("GPU-abc"))

    def test_stop_and_thermal_hold_skip_post_run_gpu_evaluation(self):
        source = SCRIPT.read_text(encoding="utf-8")
        self.assertIn('if status in {"STOPPED", "HOLD"}:', source)
        self.assertIn("Never reload or evaluate another GPU model after STOP or a thermal guard.", source)


if __name__ == "__main__":
    unittest.main()
