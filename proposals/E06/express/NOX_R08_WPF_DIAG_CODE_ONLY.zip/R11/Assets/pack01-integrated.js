/* E06 R11 single-WPF-host route view. No second backend or browser. */
(()=>{'use strict';
const root=document.querySelector('#functions');if(!root)return;
const native=window.chrome?.webview||null;
const safeNames=new Set(['chat.model','chat.stop','chat.history','models.catalog','models.installed','models.queue','models.preflight','models.licenses','models.digest','gpu.preflight','training.start','training.checkpoints','system.backup','models.pull','models.gguf.import','models.cancel','models.retry','system.telemetry']);
const uiNames=new Set(['helion.chat','core.chat','persona.chat']);
const ownerWindowNames=new Set(['models.pull','models.gguf.import','models.cancel','models.retry']);
let catalog=null,serverStates=Object.create(null),category='all',query='',lastNativeRequest=null;
const status=root.querySelector('#nox-pack-status'),grid=root.querySelector('#nox-pack-grid'),search=root.querySelector('#nox-pack-search');
const details=document.createElement('section');details.id='nox-pack-source-results';details.hidden=true;details.setAttribute('aria-live','polite');root.append(details);
const currentId=()=>sessionStorage.getItem('nox-chat-id')||'';
const announce=s=>{status.textContent=s};
const ready=id=>native&&safeNames.has(id)&&serverStates[id]?.state==='AVAILABLE_HOST_ACTION';
function showRoute(action){
 const id=action.routeId;
 if(uiNames.has(id)){showScreen('chat');announce('Чат открыт. Генерация доступна при установленном Ollama и выбранной модели.');return;}
 if(!ready(id)){announce('HOLD: нет подтверждённого обработчика этой функции в установленном Windows host.');return;}
 if(id==='training.start'){
  const rev=document.getElementById('training-revision')?.value?.trim()||'';
  if(!/^[0-9a-fA-F]{40}$/.test(rev)){showScreen('training');announce('Сначала укажи SHA версии модели и выбери train, holdout и manifest в разделе обучения.');return;}
  lastNativeRequest={routeId:id,requestId:crypto.randomUUID()};
  native.postMessage({action:'packInvoke',routeId:id,requestId:lastNativeRequest.requestId,modelRevision:rev});
  announce('Штатный QLoRA запрашивает подтверждение в Windows. Это не результат обучения.');return;
 }
 const guid=currentId();if((id==='chat.model'||id==='chat.stop'||id==='chat.history')&&!/^[0-9a-f-]{36}$/i.test(guid)){announce('Сначала открой чат, чтобы создать идентификатор диалога.');return;}
 lastNativeRequest={routeId:id,requestId:crypto.randomUUID()};
 native.postMessage({action:'packInvoke',routeId:id,chatId:guid,requestId:lastNativeRequest.requestId});
 announce('Отправлен запрос существующему обработчику Windows. Это не подтверждение завершения операции.');
}
function render(){if(!catalog)return;grid.replaceChildren();let found=0;
 for(const a of catalog.actions){if(category!=='all'&&a.category!==category)continue;
 if(query&&!(a.title+' '+a.routeId).toLocaleLowerCase('ru').includes(query))continue;
 found++;const live=!!ready(a.routeId),navigation=uiNames.has(a.routeId);
 const card=document.createElement('article');card.className='nox-pack-card';card.dataset.status=live?'available':'hold';
 const title=document.createElement('h2');title.textContent=a.title;const desc=document.createElement('small');desc.textContent=a.taskId+' · '+a.routeId+' · исполнитель '+a.owner;
 const hint=document.createElement('div');hint.className='pack-state';hint.textContent=live?(ownerWindowNames.has(a.routeId)?'Открывает штатный мастер; действие подтверждается внутри':'Обработчик доступен (результат не подтверждён)'):navigation?'Открыть существующий чат':'HOLD · не подключено';
 const button=document.createElement('button');button.type='button';button.textContent=live?(ownerWindowNames.has(a.routeId)?'Открыть ModelCenter':'Выполнить'):navigation?'Открыть чат':'Не подключено';button.disabled=!(live||navigation);button.addEventListener('click',()=>showRoute(a));
 card.append(title,desc,hint,button);grid.append(card);}
 if(!found){const empty=document.createElement('p');empty.textContent='Нет функций по этому запросу';grid.append(empty);}
}
root.querySelectorAll('[data-pack-category]').forEach(b=>b.addEventListener('click',()=>{category=b.dataset.packCategory;root.querySelectorAll('[data-pack-category]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));render()}));
search.addEventListener('input',()=>{query=search.value.toLocaleLowerCase('ru').trim().slice(0,100);render()});
window.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&!document.getElementById('home').classList.contains('active')){e.preventDefault();showScreen('functions');search.focus();}});
if(native){native.addEventListener('message',e=>{const d=e.data||{};if(d.kind==='packCapabilities'&&d.routes&&typeof d.routes==='object'){serverStates=d.routes;render();announce('Прямые действия разрешены только существующим Windows host. Остальные функции остаются HOLD.');}
if(d.kind==='packResult'){if(lastNativeRequest?.requestId!==d.requestId)return;
 announce((d.state==='OWNER_WINDOW_OPEN_REQUESTED'?'Открывается штатный мастер: ':d.state==='DISPATCHED'?'Передано существующему обработчику: ':d.state==='COMPLETED'?'Подтверждено локальным host: ':'HOLD: ')+(d.routeId||'')+(d.message?' · '+d.message:''));
 if(d.routeId==='chat.history'&&d.state==='COMPLETED'&&Array.isArray(d.history)&&d.chatId===currentId()){
  showScreen('chat');const log=document.getElementById('chat-log');if(log){log.replaceChildren();for(const msg of d.history.slice(-200)){
   const node=document.createElement('div');node.className='chat-bubble '+(msg.role==='user'?'user':'assistant');
   const label=document.createElement('small');label.textContent=msg.role==='user'?'ВЫ':'NOX';
   const body=document.createElement('span');body.textContent=typeof msg.content==='string'?msg.content:'';
   node.append(label,body);log.appendChild(node);
  }}
 }
 if((d.routeId==='models.installed'||d.routeId==='chat.model')&&d.state==='COMPLETED'&&Array.isArray(d.models)){
  const panel=document.getElementById('nox-pack-source-results');if(panel){panel.replaceChildren();
  const h=document.createElement('h2');h.textContent='Фактически установленные модели Ollama';panel.append(h);
  if(d.models.length===0){const row=document.createElement('p');row.textContent='Локальные модели не установлены.';panel.append(row);}
  for(const item of d.models.slice(0,100)){const row=document.createElement('p');row.textContent=String(item);panel.append(row);}
  panel.hidden=false;
  }
 }
 if(d.routeId==='models.digest'&&d.state==='COMPLETED'&&Array.isArray(d.models)){
  const panel=document.getElementById('nox-pack-source-results');if(panel){panel.replaceChildren();
   const h=document.createElement('h2');h.textContent='Ollama · локальные digest (не SHA файла)';panel.append(h);
   for(const m of d.models){const row=document.createElement('p');row.textContent=String(m.name||'')+' · '+String(m.digest||'Н/Д')+' · '+String(m.sizeBytes??'Н/Д')+' байт';panel.append(row);}panel.hidden=false;}
 }
 if(d.routeId==='training.checkpoints'&&d.state==='COMPLETED'&&Array.isArray(d.runs)){
  const panel=document.getElementById('nox-pack-source-results');if(panel){panel.replaceChildren();
   const h=document.createElement('h2');h.textContent='Локальные checkpoint · RESUME не подтверждён';panel.append(h);
   for(const run of d.runs){const row=document.createElement('p');row.textContent=String(run.name||'')+' · checkpoints '+String(run.checkpoints??0)+' · receipt '+(run.hasReceipt?'есть':'нет');panel.append(row);}panel.hidden=false;}
 }
 if(d.routeId==='system.backup'&&d.state==='COMPLETED'){
  const panel=document.getElementById('nox-pack-source-results');if(panel){panel.replaceChildren();
   const h=document.createElement('h2');h.textContent='Резервная копия создана локально';panel.append(h);
   const p=document.createElement('p');p.textContent=String(d.archiveName||'ZIP')+' · '+String(d.fileCount||0)+' файлов · SHA256 '+String(d.sha256||'Н/Д');panel.append(p);panel.hidden=false;}
 }
 if(d.routeId==='gpu.preflight'&&d.state==='COMPLETED'&&Array.isArray(d.gpus)){
  const panel=document.getElementById('nox-pack-source-results');if(panel){panel.replaceChildren();
   const h=document.createElement('h2');h.textContent='Обнаруженные NVIDIA GPU · CUDA и обучение отдельно';panel.append(h);
   for(const g of d.gpus){const row=document.createElement('p');row.textContent=String(g.Name||'GPU')+' · '+String(g.MemoryUsedMiB??'Н/Д')+'/'+String(g.MemoryTotalMiB??'Н/Д')+' MiB · '+String(g.TemperatureC??'Н/Д')+'°C';panel.append(row);}
   panel.hidden=false;
  }
 }
 if(d.routeId==='models.preflight'&&d.state==='COMPLETED'&&d.result){
  const panel=document.getElementById('nox-pack-source-results');if(panel){panel.replaceChildren();
  const h=document.createElement('h2');h.textContent='Реальная проверка установленных компонентов';panel.append(h);
  for(const key of ['python','ollama','git','nvidiaSmi','webview2']){const row=document.createElement('p');
   row.textContent=key+' · '+String(d.result[key]||'НЕ НАЙДЕНО');panel.append(row);}
  panel.hidden=false;
  }
 }
 if(d.routeId==='models.licenses'&&d.state==='COMPLETED'&&Array.isArray(d.licenses)){
  const panel=document.getElementById('nox-pack-source-results');if(panel){panel.replaceChildren();
   const h=document.createElement('h2');h.textContent='Оригинальный реестр лицензий · не разрешение на скачивание';panel.append(h);
   for(const item of d.licenses.slice(0,40)){const row=document.createElement('p');
    row.textContent=String(item.tag||'')+' — '+String(item.status||'REVIEW_REQUIRED');panel.append(row);}
   panel.hidden=false;
  }
 }
}
if(d.kind==='chatModels'&&document.getElementById('functions').classList.contains('active'))announce(d.state==='ERROR'?'Локальные модели: '+(d.message||'недоступны'):'Ответ Ollama получен. Модели: '+(d.models?.length||0));
});native.postMessage({action:'packCapabilities'});}
else announce('Только просмотр HTML. Для живых функций требуется NOX Windows host.');
fetch('pack01-catalog.json',{credentials:'same-origin'}).then(r=>{if(!r.ok)throw Error('CATALOG_'+r.status);return r.json()}).then(data=>{if(data.version!=='NOX-INTEGRATION-PACK-01'||!Array.isArray(data.actions)||data.actions.length!==50||new Set(data.actions.map(a=>a.routeId)).size!==50)throw Error('SCHEMA');catalog=data;render();}).catch(()=>announce('HOLD: каталог не загружен или повреждён.'));
})();
