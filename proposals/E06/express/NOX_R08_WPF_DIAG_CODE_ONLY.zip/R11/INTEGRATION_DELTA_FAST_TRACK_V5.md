# E06 · FAST TRACK V5 · P03 host integration delta

Run scope: source-only integration of the existing P03 Model Center into the R11 WPF/WebView2 application.

## Inputs pinned

- R11 baseline archive: Drive `1GXaAMDwg8J2vbcUEquwYXxxIx2jP6NHC`; ZIP SHA-256 `69a9778d29eed5fb7a000d17be3af7b75c9cdfaa195b55485d5fa3f21c2525a0`.
- P03 donor archive: Drive `1pvkTEBNKxYev1Hy8ws0877j_zjbEXlsO`; ZIP SHA-256 `66d5d93acdb87dc847810936a948def0e620e0f1c59b01587ace469020c2ca66`.
- Shared contract: new `Contracts/events.v3.json`; R11 V2 contract retained as history.

## Physical delta

- Added P03 model catalog, durable download queue, Ollama streaming pull, preflight, component allowlist, local file review/import, and backup/restore source beneath `Packages/P03/`.
- Added a control-center action that opens the P03 Model Center as an owned WPF window in the same application process and build.
- Added a P03-to-V3 adapter. It writes secret/path-redacted append-only JSONL and sends status to the existing WebView2 shell. Unknown byte totals remain null; `evidence_verified` remains false.
- Kept P01–P05 weights unchanged at 20/25/20/25/10. E06/E07 remain zero weight.
- Added explicit integration/report status: source candidate only, no accepted progress increment.

## Focused verification

- Existing focused Python contract checks: 6/6 PASS.
- Native Windows/WPF build, real Ollama pull, WinGet operation, DPI, GPU training, real GPT, and same-EXE acceptance: NOT_RUN.
- No EXE emitted. Release remains BLOCKED.

## Remaining critical path

1. Carry P02 real provider and chat STOP through the same V3 event contract.
2. Wire P04 RAG/training/GPU worker events and safely managed local/remote execution.
3. Wire P05 reports to fresh source/time/evidence snapshots and unique report IDs.
4. Produce one Windows test candidate, run native button/DPI/runtime/safety checks, then independent same-SHA acceptance before release.
