using System.Globalization;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace NoxP05;

/// <summary>
/// Builds an installer run snapshot from the shared append-only events.v3.jsonl.
/// It does not poll providers or hardware and does not convert runtime activity
/// into accepted package readiness.
/// </summary>
public static class InstallerRunReportBuilder
{
    private const string EventSchema = "NOX-INSTALLER-EVENT-v3";
    private const int MaxEventLineChars = 262_144;
    private const int MaxEventLines = 250_000;
    private static readonly string[] PackageIds = ["P01", "P02", "P03", "P04", "P05"];
    private static readonly HashSet<string> PackageIdSet = new(PackageIds, StringComparer.Ordinal);
    private static readonly string[] RoleIds = ["E01", "E02", "E03", "E04", "E05", "E06", "E07"];
    private static readonly HashSet<string> EventPackageIds = new(StringComparer.Ordinal)
    {
        "P01", "P02", "P03", "P04", "P05", "E06", "E07"
    };
    private static readonly HashSet<string> AllowedEventTypes = new(StringComparer.Ordinal)
    {
        "task.started", "task.progress", "task.failed", "task.completed", "model.tokens",
        "model.stopped", "gpu.sample", "training.step", "checkpoint.saved", "acceptance.updated"
    };
    private static readonly HashSet<string> AllowedEventStates = new(StringComparer.Ordinal)
    {
        "QUEUED", "RUNNING", "PAUSED", "COMPLETED", "ERROR", "STOPPED", "OFFLINE", "HOLD", "READY", "N_D"
    };
    private static readonly IReadOnlyDictionary<string, int> PackageWeights = new Dictionary<string, int>
    {
        ["P01"] = 20, ["P02"] = 25, ["P03"] = 20, ["P04"] = 25, ["P05"] = 10
    };
    private static readonly IReadOnlyDictionary<string, string> PackageColors = new Dictionary<string, string>
    {
        ["P01"] = "🔵", ["P02"] = "🟣", ["P03"] = "🟠", ["P04"] = "🟢", ["P05"] = "🟡"
    };
    private static readonly string[] PackageCycleIds = Enumerable.Range(1, 10).Select(index => $"C{index}").ToArray();
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    public static InstallerRunSnapshot CreateSnapshot(
        string jsonl,
        string? requestedRunId = null,
        P05RunReceipt? runReceipt = null)
    {
        ArgumentNullException.ThrowIfNull(jsonl);
        var parseCounter = new EventParseCounter();
        var events = ParseEvents(jsonl, parseCounter);
        if (requestedRunId is not null)
            events = events.Where(e => string.Equals(e.RunId, requestedRunId, StringComparison.Ordinal)).ToList();

        var runId = requestedRunId ?? events.OrderByDescending(e => e.TimestampUtc).FirstOrDefault()?.RunId;
        var selected = runId is null
            ? new List<SafeEvent>()
            : events.Where(e => string.Equals(e.RunId, runId, StringComparison.Ordinal))
                .OrderBy(e => e.TimestampUtc)
                .ToList();

        var activityCounts = new Dictionary<string, int>(StringComparer.Ordinal)
        {
            ["chat"] = 0, ["models"] = 0, ["training"] = 0, ["gpu"] = 0, ["other"] = 0
        };
        var operationalCompleted = 0;
        var operationalFailed = 0;
        var acceptanceEvents = 0;
        foreach (var item in selected)
        {
            activityCounts[item.Activity]++;
            if (item.Type == "task.completed" || item.State == "COMPLETED") operationalCompleted++;
            if (item.Type == "task.failed" || item.State == "ERROR") operationalFailed++;
            if (item.Type == "acceptance.updated") acceptanceEvents++;
        }
        var groups = activityCounts.Select(pair => new ActivityCount(pair.Key, pair.Value)).ToArray();

        var packageLanes = PackageLaneStatuses(runId, runReceipt);
        return new InstallerRunSnapshot(
            Schema: "NOX-INSTALLER-RUN-SNAPSHOT-v1",
            SnapshotId: Guid.NewGuid().ToString("N"),
            RunId: runId,
            GeneratedUtc: DateTimeOffset.UtcNow,
            Source: "local events.v3.jsonl",
            SourceEventCount: selected.Count,
            ParseDiagnostics: parseCounter.ToSnapshot(),
            SourceFirstUtc: selected.Count == 0 ? null : selected[0].TimestampUtc,
            SourceLastUtc: selected.Count == 0 ? null : selected[^1].TimestampUtc,
            Activity: groups,
            PackageReadiness: PackageReadinessRows(),
            OverallReadiness: new ReadinessBar("EXE", null),
            OverallCycles: BuildPackageOverallCycles(packageLanes),
            PackageLanes: packageLanes,
            OperationalCompletedEvents: operationalCompleted,
            OperationalFailedEvents: operationalFailed,
            AcceptanceEventCount: acceptanceEvents,
            AcceptedReadinessPercent: null,
            DriveSyncStatus: "NOT_SYNCED",
            DriveReadbackAck: false,
            ReportGate: "HOLD",
            ReportGateReasons: BuildReportGateReasons(parseCounter.ToSnapshot()),
            Events: selected.Select(e => new EventSummary(
                e.EventId,
                e.Type,
                e.PackageId,
                e.ActionId,
                e.TimestampUtc,
                e.State,
                e.Numerator,
                e.Denominator,
                e.EvidenceVerified,
                e.Activity)).ToArray(),
            Notice: "Операционные события показывают работу установщика. Принятая готовность не вычисляется из событий; для неё нужен отдельный реестр критериев и подтверждённые квитанции.");
    }

    private static IReadOnlyList<string> BuildReportGateReasons(P05EventParseDiagnostics parse)
    {
        var reasons = new List<string>
        {
            "Trusted receipt verification is unavailable. EvidenceVerified and a 64-character SHA-256 string alone do not prove the source or contents of an evidence artifact.",
            "No trusted signer or verifier binds package-cycle evidence to this exact run and source build.",
            "Google Drive report/journal writeback and readback acknowledgement are not implemented by this local report action.",
            "Per-role approach counts remain N/D because the current events.v3 input has no verified approach ledger bound to each role and cycle."
        };
        if (parse.MalformedJsonLines > 0 || parse.DuplicateEventIds > 0 || parse.InvalidProgressValues > 0 ||
            parse.RejectedLines > 0 || parse.OversizedLines > 0 || parse.InputTruncated)
            reasons.Add($"The local event source contains omissions or invalid values: malformed={parse.MalformedJsonLines}, duplicates={parse.DuplicateEventIds}, invalid_progress={parse.InvalidProgressValues}, rejected={parse.RejectedLines}, oversized={parse.OversizedLines}, truncated={parse.InputTruncated}.");
        return reasons;
    }

    private static IReadOnlyList<P05PackageLaneStatus> PackageLaneStatuses(string? runId, P05RunReceipt? receipt)
    {
        if (!MatchesRun(runId, receipt))
            return PackageIds.Select(id => new P05PackageLaneStatus(id, UnknownCycles(PackageCycleIds))).ToArray();

        var lanes = receipt!.PackageLanes;
        if (lanes is null || lanes.Count != PackageIds.Length)
            return PackageIds.Select(id => new P05PackageLaneStatus(id, UnknownCycles(PackageCycleIds))).ToArray();

        var laneById = new Dictionary<string, P05PackageLaneReceipt>(PackageIds.Length, StringComparer.Ordinal);
        foreach (var lane in lanes)
        {
            if (lane is null || string.IsNullOrWhiteSpace(lane.PackageId) ||
                !PackageIdSet.Contains(lane.PackageId) || !laneById.TryAdd(lane.PackageId, lane))
                return PackageIds.Select(id => new P05PackageLaneStatus(id, UnknownCycles(PackageCycleIds))).ToArray();
        }
        return PackageIds.Select(id =>
            new P05PackageLaneStatus(id, ReceiptCycles(laneById[id].Cycles, PackageCycleIds))).ToArray();
    }

    private static IReadOnlyList<P05PackageReadiness> PackageReadinessRows() =>
        PackageIds.Select(id => new P05PackageReadiness(id, PackageWeights[id], null)).ToArray();

    private static IReadOnlyList<P05CycleStatus> BuildPackageOverallCycles(IReadOnlyList<P05PackageLaneStatus> lanes) =>
        PackageCycleIds.Select((cycleId, index) =>
        {
            var statuses = lanes.Select(lane => lane.Cycles[index].Status).ToArray();
            var status = statuses.Contains("FAILED") ? "FAILED"
                : statuses.Any(value => value == "N_D") ? "N_D"
                : statuses.All(value => value == "VERIFIED") ? "VERIFIED"
                : statuses.Contains("HOLD") ? "HOLD"
                : statuses.Contains("IN_PROGRESS") ? "IN_PROGRESS"
                : statuses.All(value => value == "NOT_STARTED") ? "NOT_STARTED"
                : "HOLD";
            return new P05CycleStatus(cycleId, status, null);
        }).ToArray();

    private static bool MatchesRun(string? runId, P05RunReceipt? receipt) =>
        runId is not null && receipt is not null && string.Equals(runId, receipt.RunId, StringComparison.Ordinal);

    private static IReadOnlyList<P05CycleStatus> ReceiptCycles(
        IReadOnlyList<P05CycleReceipt>? receipts,
        IReadOnlyList<string> expectedIds)
    {
        if (receipts is null || receipts.Count != expectedIds.Count)
            return UnknownCycles(expectedIds);

        // Caller-provided flags and digest-shaped strings are not a trust boundary.
        // Until an evidence resolver verifies artifact bytes and signer/run/build binding,
        // no receipt can promote a package cycle to VERIFIED (or any asserted state).
        return UnknownCycles(expectedIds);
    }

    private static IReadOnlyList<P05CycleStatus> UnknownCycles(IReadOnlyList<string> cycleIds) =>
        cycleIds.Select(id => new P05CycleStatus(id, "N_D", null)).ToArray();

    private static string StatusClass(string? status) => status switch
    {
        "VERIFIED" => "verified",
        "NOT_STARTED" => "not-started",
        "IN_PROGRESS" => "in-progress",
        "HOLD" => "hold",
        "FAILED" => "failed",
        _ => "unknown"
    };

    private static string MarkdownDot(string? status) => status switch
    {
        "VERIFIED" => "🟢 VERIFIED",
        "NOT_STARTED" => "🟣 NOT_STARTED",
        "IN_PROGRESS" => "🟡 IN_PROGRESS",
        "HOLD" => "🟠 HOLD",
        "FAILED" => "🔴 FAILED",
        _ => "⬜ Н/Д"
    };

    private static string HtmlCycleCell(P05CycleStatus? cycle, string cycleId) =>
        $"<td><span class=\"cycle-cell {StatusClass(cycle?.Status)}\" aria-label=\"{WebUtility.HtmlEncode(cycleId)} {WebUtility.HtmlEncode(cycle?.Status ?? "N_D")}\"><i></i>{WebUtility.HtmlEncode(cycle?.Status == "N_D" ? "Н/Д" : cycle?.Status ?? "Н/Д")}</span></td>";

    private static IReadOnlyDictionary<string, P05PackageLaneStatus> LaneMap(InstallerRunSnapshot snapshot)
    {
        var result = new Dictionary<string, P05PackageLaneStatus>(PackageIds.Length, StringComparer.Ordinal);
        var duplicates = new HashSet<string>(StringComparer.Ordinal);
        foreach (var lane in snapshot.PackageLanes ?? Array.Empty<P05PackageLaneStatus>())
        {
            if (lane is null || string.IsNullOrWhiteSpace(lane.PackageId) ||
                !PackageIdSet.Contains(lane.PackageId) || duplicates.Contains(lane.PackageId))
                continue;
            if (!result.TryAdd(lane.PackageId, lane))
            {
                result.Remove(lane.PackageId);
                duplicates.Add(lane.PackageId);
            }
        }
        return result;
    }

    private static string BuildHtmlCycleRows(InstallerRunSnapshot snapshot, Func<string?, string> encode)
    {
        var lanes = LaneMap(snapshot);
        var rows = new StringBuilder();
        foreach (var packageId in PackageIds)
        {
            lanes.TryGetValue(packageId, out var lane);
            var weight = PackageWeights[packageId];
            rows.Append("<tr><th>").Append(encode(packageId)).Append("</th><td>").Append(weight).Append("%</td>");
            for (var index = 0; index < PackageCycleIds.Length; index++)
                rows.Append(HtmlCycleCell(lane?.Cycles?.ElementAtOrDefault(index), PackageCycleIds[index]));
            rows.Append("<td>Н/Д</td></tr>\n");
        }
        rows.Append("<tr class=\"overall-cycle-row\"><th>ОБЩИЙ</th><td>100%</td>");
        var overallCycles = snapshot.OverallCycles ?? Array.Empty<P05CycleStatus>();
        for (var index = 0; index < PackageCycleIds.Length; index++)
            rows.Append(HtmlCycleCell(overallCycles.ElementAtOrDefault(index), PackageCycleIds[index]));
        rows.Append("<td>Н/Д</td></tr>");
        return rows.ToString();
    }

    private static string BuildHtmlReadinessBars(InstallerRunSnapshot snapshot, Func<string?, string> encode)
    {
        var accepted = UniqueReadinessMap(snapshot.PackageReadiness);
        var bars = new StringBuilder();
        foreach (var packageId in PackageIds)
        {
            var weight = PackageWeights[packageId];
            accepted.TryGetValue(packageId, out var percent);
            var value = ValidPercent(percent) ? percent!.Value.ToString("0.##", CultureInfo.InvariantCulture) + "%" : "Н/Д";
            var width = ValidPercent(percent) ? value : "0%";
            bars.Append("<div class=\"readiness-row ").Append(packageId.ToLowerInvariant()).Append("\"><div><strong>")
                .Append(encode(packageId)).Append("</strong> · вес ").Append(weight)
                .Append("% · <span>").Append(value).Append("</span></div><div class=\"readiness-track\" role=\"progressbar\" aria-label=\"")
                .Append(encode(packageId)).Append(" · принятая готовность\" aria-valuemin=\"0\" aria-valuemax=\"100\"");
            if (ValidPercent(percent))
                bars.Append(" aria-valuenow=\"").Append(percent!.Value.ToString("0.##", CultureInfo.InvariantCulture)).Append("\"");
            bars.Append(" aria-valuetext=\"").Append(ValidPercent(percent) ? "Принятая готовность " + value : "Н/Д")
                .Append("\"><i style=\"width:").Append(width).Append("\"></i></div></div>\n");
        }
        var overall = snapshot.OverallReadiness?.AcceptedPercent;
        var overallValue = ValidPercent(overall) ? overall!.Value.ToString("0.##", CultureInfo.InvariantCulture) + "%" : "Н/Д";
        var overallWidth = ValidPercent(overall) ? overallValue : "0%";
        bars.Append("<div class=\"readiness-row overall\"><div><strong>ОБЩИЙ EXE</strong> · вес 100% · <span>").Append(overallValue)
            .Append("</span></div><div class=\"readiness-track\" role=\"progressbar\" aria-label=\"ОБЩИЙ EXE · принятая готовность\" aria-valuemin=\"0\" aria-valuemax=\"100\"");
        if (ValidPercent(overall))
            bars.Append(" aria-valuenow=\"").Append(overall!.Value.ToString("0.##", CultureInfo.InvariantCulture)).Append("\"");
        bars.Append(" aria-valuetext=\"").Append(ValidPercent(overall) ? "Принятая готовность " + overallValue : "Н/Д")
            .Append("\"><i style=\"width:").Append(overallWidth).Append("\"></i></div></div>");
        return bars.ToString();
    }

    private static string BuildHtmlRoleProgressBars()
    {
        var bars = new StringBuilder();
        foreach (var role in RoleIds)
            bars.Append("<div class=\"readiness-row role-unknown\"><div><strong>").Append(role)
                .Append("</strong> · подходы · <span>Н/Д</span></div><div class=\"readiness-track\" role=\"progressbar\" aria-label=\"")
                .Append(role).Append(" · прогресс подходов не подтверждён\" aria-valuemin=\"0\" aria-valuemax=\"10\" aria-valuetext=\"Н/Д\"><i style=\"width:0%\"></i></div></div>\n");
        return bars.ToString();
    }

    private static bool ValidPercent(double? value) => value.HasValue && double.IsFinite(value.Value) && value.Value >= 0 && value.Value <= 100;

    private static async Task WriteAtomicallyAsync(
        string destination,
        Func<Stream, CancellationToken, Task> writeAsync,
        CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destination);
        ArgumentNullException.ThrowIfNull(writeAsync);
        var fullPath = Path.GetFullPath(destination);
        var directory = Path.GetDirectoryName(fullPath) ?? throw new IOException("Report destination has no parent directory.");
        Directory.CreateDirectory(directory);
        var temporaryPath = Path.Combine(directory, $"{Path.GetFileName(fullPath)}.{Guid.NewGuid():N}.tmp");
        try
        {
            await using (var stream = new FileStream(temporaryPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, FileOptions.Asynchronous))
            {
                await writeAsync(stream, cancellationToken);
                await stream.FlushAsync(cancellationToken);
            }
            File.Move(temporaryPath, fullPath, overwrite: true);
        }
        finally
        {
            try { if (File.Exists(temporaryPath)) File.Delete(temporaryPath); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    public static async Task WriteJsonAsync(
        InstallerRunSnapshot snapshot,
        string destination,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        await WriteAtomicallyAsync(destination,
            (stream, token) => JsonSerializer.SerializeAsync(stream, snapshot, JsonOptions, token),
            cancellationToken);
    }

    public static async Task WriteHtmlAsync(
        InstallerRunSnapshot snapshot,
        string destination,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        var html = BuildHtml(snapshot);
        await WriteAtomicallyAsync(destination, async (stream, token) =>
        {
            var bytes = new UTF8Encoding(false).GetBytes(html);
            await stream.WriteAsync(bytes.AsMemory(), token);
        }, cancellationToken);
    }

    public static async Task WriteMarkdownAsync(
        InstallerRunSnapshot snapshot,
        string destination,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        var markdown = BuildMarkdown(snapshot);
        await WriteAtomicallyAsync(destination, async (stream, token) =>
        {
            var bytes = new UTF8Encoding(false).GetBytes(markdown);
            await stream.WriteAsync(bytes.AsMemory(), token);
        }, cancellationToken);
    }

    private static Dictionary<string, double?> UniqueReadinessMap(IReadOnlyList<P05PackageReadiness>? readiness)
    {
        var result = new Dictionary<string, double?>(PackageIds.Length, StringComparer.Ordinal);
        var duplicates = new HashSet<string>(StringComparer.Ordinal);
        foreach (var item in readiness ?? Array.Empty<P05PackageReadiness>())
        {
            if (item is null || string.IsNullOrWhiteSpace(item.PackageId) ||
                !PackageIdSet.Contains(item.PackageId) || duplicates.Contains(item.PackageId))
                continue;
            if (!result.TryAdd(item.PackageId, item.AcceptedPercent))
            {
                result.Remove(item.PackageId);
                duplicates.Add(item.PackageId);
            }
        }
        return result;
    }

    public static string BuildMarkdown(InstallerRunSnapshot snapshot)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        static string Cell(string? value) => (value ?? "Н/Д").Replace("\\", "\\\\").Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("|", "\\|").Replace("\r", " ").Replace("\n", " ");

        var output = new StringBuilder();
        output.AppendLine("# NOX HELION · отчёт установщика");
        output.AppendLine();
        output.AppendLine($"- **RunID:** {Cell(snapshot.RunId)}");
        output.AppendLine($"- **ReportID:** {Cell(snapshot.SnapshotId)}");
        output.AppendLine($"- **Источник:** {Cell(snapshot.Source)} · событий выбранного RunID: {snapshot.SourceEventCount.ToString(CultureInfo.InvariantCulture)}");
        var parse = snapshot.ParseDiagnostics;
        output.AppendLine(parse is null
            ? "- **Разбор журнала:** Н/Д"
            : $"- **Разбор журнала:** строк {parse.LinesRead}; принято {parse.AcceptedLines}; дубликатов {parse.DuplicateEventIds}; неверных счётчиков {parse.InvalidProgressValues}; отклонено {parse.RejectedLines}; повреждено {parse.MalformedJsonLines}; слишком длинных {parse.OversizedLines}; усечено {(parse.InputTruncated ? "да" : "нет")}");
        output.AppendLine();
        output.AppendLine("## Принятая готовность · пакетные полосы");
        output.AppendLine();
        output.AppendLine("| Пакет | Вес | Полоса принятой готовности |");
        output.AppendLine("|---|---|---:|");
        var packageReady = UniqueReadinessMap(snapshot.PackageReadiness);
        foreach (var id in PackageIds)
        {
            packageReady.TryGetValue(id, out var percent);
            var text = ValidPercent(percent) ? percent!.Value.ToString("0.##", CultureInfo.InvariantCulture) + "%" : "Н/Д";
            output.AppendLine($"| {PackageColors[id]} {id} | {PackageWeights[id]}% | ░░░░░░░░░░ {text} |");
        }
        output.AppendLine();
        output.AppendLine("## Ход работы исполнителей · вне весов продукта");
        output.AppendLine();
        output.AppendLine("| Исполнитель | Подходы текущего цикла | Статус |\n|---|---:|---|");
        foreach (var role in RoleIds)
            output.AppendLine($"| {role} | Н/Д из 10 | не подтверждено |");
        output.AppendLine();
        var overall = snapshot.OverallReadiness?.AcceptedPercent;
        var overallText = ValidPercent(overall) ? overall!.Value.ToString("0.##", CultureInfo.InvariantCulture) + "%" : "Н/Д";
        output.AppendLine($"**ОБЩИЙ EXE · 100%:** ░░░░░░░░░░ {overallText}");
        output.AppendLine();
        output.AppendLine("## Циклы пакетов · V15");
        output.AppendLine();
        output.AppendLine("| Пакет | " + string.Join(" | ", PackageCycleIds) + " |");
        output.AppendLine("|---|" + string.Concat(PackageCycleIds.Select(_ => "---|")));
        var lanes = LaneMap(snapshot);
        foreach (var id in PackageIds)
        {
            lanes.TryGetValue(id, out var lane);
            var dots = PackageCycleIds.Select((cycleId, index) => MarkdownDot(lane?.Cycles?.ElementAtOrDefault(index)?.Status));
            output.AppendLine($"| {PackageColors[id]} {id} | {string.Join(" | ", dots)} |");
        }
        var overallCycles = PackageCycleIds.Select((cycleId, index) => MarkdownDot(snapshot.OverallCycles?.ElementAtOrDefault(index)?.Status));
        output.AppendLine($"| ⚪ ОБЩИЙ | {string.Join(" | ", overallCycles)} |");
        output.AppendLine();
        var acceptedReadiness = ValidPercent(snapshot.AcceptedReadinessPercent)
            ? snapshot.AcceptedReadinessPercent!.Value.ToString("0.##", CultureInfo.InvariantCulture) + "%"
            : "Н/Д";
        output.AppendLine($"**Принятая готовность установщика:** {acceptedReadiness}. {Cell(snapshot.Notice)}");
        output.AppendLine();
        output.AppendLine("## Google Drive · синхронизация отчёта");
        output.AppendLine();
        output.AppendLine($"- **Статус:** {Cell(snapshot.DriveSyncStatus)}");
        output.AppendLine($"- **Readback ACK:** {(snapshot.DriveReadbackAck ? "подтверждён" : "нет")}");
        output.AppendLine();
        output.AppendLine("## REPORT_GATE");
        output.AppendLine();
        output.AppendLine($"**{Cell(snapshot.ReportGate)}**");
        foreach (var reason in snapshot.ReportGateReasons ?? Array.Empty<string>())
            output.AppendLine($"- {Cell(reason)}");
        output.AppendLine();
        output.AppendLine("Таблица циклов охватывает C1–C10. Полосы остаются пустыми при Н/Д. Зелёная общая точка цикла появляется только когда этот цикл VERIFIED для всех пяти пакетов; неизвестные значения — белые Н/Д, NOT_STARTED — фиолетовые, IN_PROGRESS — жёлтые.");
        return output.ToString();
    }

    public static string BuildHtml(InstallerRunSnapshot snapshot)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        static string E(string? value) => WebUtility.HtmlEncode(value ?? "Н/Д");
        static string Stamp(DateTimeOffset? value) => value?.ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss 'UTC'", CultureInfo.InvariantCulture) ?? "Н/Д";

        var rows = string.Join("\n", (snapshot.Activity ?? Array.Empty<ActivityCount>()).Select(item =>
            $"<tr><th>{E(item.Name)}</th><td>{item.Events}</td></tr>"));
        var eventRows = string.Join("\n", (snapshot.Events ?? Array.Empty<EventSummary>()).Select(item =>
        {
            var amount = item.Numerator.HasValue && item.Denominator.HasValue
                ? $"{item.Numerator.Value.ToString(CultureInfo.InvariantCulture)} / {item.Denominator.Value.ToString(CultureInfo.InvariantCulture)}"
                : "Н/Д";
            return $"<tr><td>{Stamp(item.TimestampUtc)}</td><td>{E(item.Activity)}</td><td>{E(item.PackageId)} · {E(item.ActionId)}</td><td>{E(item.State)}</td><td>{amount}</td></tr>";
        }));
        var cycleRows = BuildHtmlCycleRows(snapshot, E);
        var cycleTableHeader = "<thead><tr><th>Пакет</th><th>Вес</th>" +
            string.Concat(PackageCycleIds.Select(id => $"<th>{E(id)}</th>")) +
            "<th>Принятая готовность</th></tr></thead>";
        var readinessBars = BuildHtmlReadinessBars(snapshot, E);
        var roleProgressBars = BuildHtmlRoleProgressBars();
        var reportGateReasons = string.Join("", (snapshot.ReportGateReasons ?? Array.Empty<string>()).Select(reason => $"<li>{E(reason)}</li>"));
        var parseDiagnostics = snapshot.ParseDiagnostics is { } parse
            ? $"строк {parse.LinesRead}; принято {parse.AcceptedLines}; дубликатов {parse.DuplicateEventIds}; неверных счётчиков {parse.InvalidProgressValues}; отклонено {parse.RejectedLines}; повреждено {parse.MalformedJsonLines}; слишком длинных {parse.OversizedLines}; усечено {(parse.InputTruncated ? "да" : "нет")}"
            : "Н/Д";

        return """<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>NOX HELION · отчёт установщика</title>
<style>
:root{color-scheme:dark;--bg:#090b0d;--panel:#141719;--line:#383329;--gold:#b6a078;--muted:#9a9b98;--text:#efeee9}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 10% 0,#28231a 0,transparent 38%),var(--bg);color:var(--text);font:15px/1.5 Segoe UI,Arial,sans-serif}
main{max-width:1080px;margin:0 auto;padding:36px 22px 60px}h1{font-size:clamp(25px,4vw,42px);letter-spacing:.08em;margin:0;color:#e8dec9}h2{font-size:14px;letter-spacing:.16em;text-transform:uppercase;color:var(--gold)}
.eyebrow{color:var(--gold);letter-spacing:.22em;font-size:11px}.hero,.panel{border:1px solid var(--line);background:linear-gradient(145deg,#171a1bdf,#0d1011f5);border-radius:12px;padding:22px;margin-top:18px;box-shadow:0 12px 40px #0007}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.tile{border:1px solid #34332e;padding:14px;border-radius:8px;background:#0c0e0f}.label{display:block;color:var(--muted);font-size:12px}.value{font-size:18px;color:#e9d9b4}.hold{color:#d8b66e}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;border-bottom:1px solid #302f2b;padding:9px 8px}th{color:var(--gold);font-weight:600}td{color:#ddd}p{color:var(--muted)}.scroll{overflow:auto}.readiness-row{margin:12px 0}.readiness-track{height:9px;border:1px solid #46443d;border-radius:8px;background:#262828;overflow:hidden;margin-top:5px}.readiness-track i{display:block;height:100%;width:0}.p01 .readiness-track i{background:#66a9ff}.p02 .readiness-track i{background:#b085ff}.p03 .readiness-track i{background:#e9a253}.p04 .readiness-track i{background:#65c98a}.p05 .readiness-track i{background:#e5ca5c}.overall .readiness-track i{background:#b6a078}.cycle-cell{display:inline-flex;align-items:center;gap:4px;white-space:nowrap;font-size:11px}.cycle-cell i{width:11px;height:11px;border-radius:50%;display:inline-block;border:1px solid #ddd;background:#f4f4f4}.cycle-cell.verified i{background:#45c776;border-color:#45c776}.cycle-cell.not-started i{background:#a779e8;border-color:#a779e8}.cycle-cell.in-progress i{background:#f1cf45;border-color:#f1cf45}.cycle-cell.hold i{background:#e69a42;border-color:#e69a42}.cycle-cell.failed i{background:#e95858;border-color:#e95858}.cycle-cell.unknown i{background:#f4f4f4;border-color:#ddd}.overall-cycle-row th{color:#e8dec9}
</style></head><body><main>
<div class="eyebrow">NOX HELION · P05 LOCAL SNAPSHOT</div><h1>INSTALLER RUN</h1>
<section class="hero"><h2>Срез событий установщика</h2><div class="grid">
<div class="tile"><span class="label">Run ID</span><span class="value">""" + E(snapshot.RunId) + """</span></div>
<div class="tile"><span class="label">Snapshot ID</span><span class="value">""" + E(snapshot.SnapshotId) + """</span></div>
<div class="tile"><span class="label">Сформирован</span><span class="value">""" + Stamp(snapshot.GeneratedUtc) + """</span></div>
<div class="tile"><span class="label">Источник · событий</span><span class="value">""" + E(snapshot.Source) + " · " + snapshot.SourceEventCount.ToString(CultureInfo.InvariantCulture) + """</span></div>
</div><p>Время событий: """ + Stamp(snapshot.SourceFirstUtc) + " — " + Stamp(snapshot.SourceLastUtc) + """</p></section>
<section class="panel"><h2>Разбор журнала событий</h2><p>""" + E(parseDiagnostics) + """</p></section>
<section class="panel"><h2>Операционная активность</h2><div class="scroll"><table><thead><tr><th>Поток</th><th>Событий</th></tr></thead><tbody>""" + rows + """</tbody></table></div>
<p>Завершённые события: """ + snapshot.OperationalCompletedEvents.ToString(CultureInfo.InvariantCulture) + " · ошибки: " + snapshot.OperationalFailedEvents.ToString(CultureInfo.InvariantCulture) + " · события приёмки: " + snapshot.AcceptanceEventCount.ToString(CultureInfo.InvariantCulture) + """</p></section>
<section class="panel"><h2>Принятая готовность · веса пакетов</h2><p>Полосы отражают только принятую готовность; запуск и оперативные события не заполняют их.</p>""" + readinessBars + """</section>
<section class="panel"><h2>Ход работы исполнителей · вне весов продукта</h2><p>Полосы показывают десять подходов на роль; пока нет подтверждённого реестра подходов, значения остаются Н/Д.</p>""" + roleProgressBars + """</section>
<section class="panel"><h2>Циклы пакетов · V15</h2><p>Таблица охватывает C1–C10. Зелёный общий статус Cx отображается, только если Cx подтверждён для каждого из пяти пакетов. Н/Д — белая точка; NOT_STARTED — фиолетовая; IN_PROGRESS — жёлтая.</p><div class="scroll"><table><caption>Статус десяти циклов по пяти пакетам; Н/Д означает отсутствие подтверждённого evidence</caption>""" + cycleTableHeader + """<tbody>""" + cycleRows + """</tbody></table></div><p>Этот локальный срез не содержит реестр Run C1–C10: события v3 и квитанции пакетов не предоставляют эти данные.</p></section>
<section class="panel"><h2>Google Drive · синхронизация отчёта</h2><p>Статус: """ + E(snapshot.DriveSyncStatus) + " · Readback ACK: " + (snapshot.DriveReadbackAck ? "подтверждён" : "нет") + """</p></section>
<section class="panel"><h2>REPORT_GATE · """ + E(snapshot.ReportGate) + """</h2><ul>""" + reportGateReasons + """</ul></section>
<section class="panel"><h2>Хронология · секреты и текст чата не включены</h2><div class="scroll"><table><thead><tr><th>UTC</th><th>Поток</th><th>Пакет · действие</th><th>Состояние</th><th>Единицы</th></tr></thead><tbody>""" + eventRows + """</tbody></table></div></section>
</main></body></html>""";
    }

    private sealed class EventParseCounter
    {
        public int LinesRead { get; set; }
        public int AcceptedLines { get; set; }
        public int MalformedJsonLines { get; set; }
        public int DuplicateEventIds { get; set; }
        public int InvalidProgressValues { get; set; }
        public int RejectedLines { get; set; }
        public int OversizedLines { get; set; }
        public bool InputTruncated { get; set; }
        public P05EventParseDiagnostics ToSnapshot() => new(LinesRead, AcceptedLines, MalformedJsonLines, DuplicateEventIds, InvalidProgressValues, RejectedLines, OversizedLines, InputTruncated);
    }

    private static List<SafeEvent> ParseEvents(string jsonl) => ParseEvents(jsonl, new EventParseCounter());

    private static List<SafeEvent> ParseEvents(string jsonl, EventParseCounter diagnostics)
    {
        var result = new List<SafeEvent>();
        var seenEventKeys = new HashSet<(string RunId, string EventId)>();
        using var reader = new StringReader(jsonl);
        while (reader.ReadLine() is { } line)
        {
            if (diagnostics.LinesRead >= MaxEventLines)
            {
                diagnostics.InputTruncated = true;
                break;
            }
            diagnostics.LinesRead++;
            if (line.Length > MaxEventLineChars)
            {
                diagnostics.OversizedLines++;
                continue;
            }
            if (string.IsNullOrWhiteSpace(line)) continue;
            try
            {
                using var document = JsonDocument.Parse(line, new JsonDocumentOptions { MaxDepth = 32 });
                if (document.RootElement.ValueKind != JsonValueKind.Object)
                {
                    // Valid JSON with a non-object root is not an event record; count it as rejected.
                    diagnostics.RejectedLines++;
                    continue;
                }
                var root = document.RootElement;
                if (ReadString(root, "schema") != EventSchema)
                {
                    diagnostics.RejectedLines++;
                    continue;
                }
                var runId = ReadString(root, "run_id");
                var eventId = ReadString(root, "event_id");
                var taskId = ReadString(root, "task_id");
                var type = ReadString(root, "event_type");
                var packageRaw = ReadString(root, "package_id");
                var actionRaw = ReadString(root, "action_id");
                var state = ReadString(root, "state");
                var source = ReadString(root, "source");
                var message = ReadString(root, "message");
                var timestampText = ReadString(root, "timestamp_utc");
                var hasEvidenceFlag = root.TryGetProperty("evidence_verified", out var evidenceFlag) &&
                    evidenceFlag.ValueKind is JsonValueKind.True or JsonValueKind.False;
                if (runId is null || eventId is null || taskId is null || type is null || packageRaw is null ||
                    actionRaw is null || state is null || source is null || message is null || timestampText is null ||
                    !hasEvidenceFlag || !DateTimeOffset.TryParse(timestampText, CultureInfo.InvariantCulture,
                        DateTimeStyles.AssumeUniversal, out var timestamp))
                {
                    diagnostics.RejectedLines++;
                    continue;
                }

                var safeRunId = SafeId(runId, string.Empty);
                var safeEventId = SafeId(eventId, string.Empty);
                var safeTaskId = SafeId(taskId, string.Empty);
                var packageId = SafeId(packageRaw, string.Empty);
                var actionId = SafeId(actionRaw, string.Empty);
                if (safeRunId.Length == 0 || safeEventId.Length == 0 || safeTaskId.Length == 0 ||
                    packageId.Length == 0 || actionId.Length == 0 ||
                    !EventPackageIds.Contains(packageId) ||
                    !AllowedEventTypes.Contains(type) ||
                    !AllowedEventStates.Contains(state))
                {
                    diagnostics.RejectedLines++;
                    continue;
                }

                var numerator = ReadLong(root, "numerator");
                var denominator = ReadLong(root, "denominator");
                if ((numerator.HasValue && numerator.Value < 0) ||
                    (denominator.HasValue && denominator.Value <= 0) ||
                    (numerator.HasValue && denominator.HasValue && numerator.Value > denominator.Value))
                {
                    diagnostics.InvalidProgressValues++;
                    numerator = null;
                    denominator = null;
                }

                if (!seenEventKeys.Add((safeRunId, safeEventId)))
                {
                    diagnostics.DuplicateEventIds++;
                    continue;
                }

                diagnostics.AcceptedLines++;
                result.Add(new SafeEvent(
                    safeRunId,
                    safeEventId,
                    type,
                    packageId,
                    actionId,
                    timestamp.ToUniversalTime(),
                    state,
                    numerator,
                    denominator,
                    evidenceFlag.GetBoolean(),
                    Categorize(type, packageId, actionId)));
            }
            catch (JsonException)
            {
                diagnostics.MalformedJsonLines++;
                // A partially written final line does not invalidate the preceding journal.
            }
        }
        return result;
    }

    private static string? ReadString(JsonElement root, string name) =>
        root.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    private static long? ReadLong(JsonElement root, string name) =>
        root.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.Number && value.TryGetInt64(out var number)
            ? number
            : null;

    private static string SafeId(string? value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length > 80) return fallback;
        foreach (var character in value)
            if (!char.IsAsciiLetterOrDigit(character) && character is not ('-' or '_' or '.'))
                return fallback;
        return value;
    }

    private static string Categorize(string type, string package, string action)
    {
        // Event semantics take precedence over the owning package. A P04 GPU
        // sample is telemetry, not a training event.
        if (type is "model.tokens" or "model.stopped") return "chat";
        if (type == "gpu.sample") return "gpu";
        if (type is "training.step" or "checkpoint.saved") return "training";
        if (action.Contains("download", StringComparison.OrdinalIgnoreCase) ||
            action.Contains("pull", StringComparison.OrdinalIgnoreCase) || package == "P03") return "models";
        if (package == "P02") return "chat";
        if (package == "P04") return "training";
        return "other";
    }

    private sealed record SafeEvent(
        string RunId,
        string EventId,
        string Type,
        string PackageId,
        string ActionId,
        DateTimeOffset TimestampUtc,
        string State,
        long? Numerator,
        long? Denominator,
        bool EvidenceVerified,
        string Activity);
}

public sealed record P05EventParseDiagnostics(
    [property: JsonPropertyName("lines_read")] int LinesRead,
    [property: JsonPropertyName("accepted_lines")] int AcceptedLines,
    [property: JsonPropertyName("malformed_json_lines")] int MalformedJsonLines,
    [property: JsonPropertyName("duplicate_event_ids")] int DuplicateEventIds,
    [property: JsonPropertyName("invalid_progress_values")] int InvalidProgressValues,
    [property: JsonPropertyName("rejected_lines")] int RejectedLines,
    [property: JsonPropertyName("oversized_lines")] int OversizedLines,
    [property: JsonPropertyName("input_truncated")] bool InputTruncated);

public sealed record InstallerRunSnapshot(
    [property: JsonPropertyName("schema")] string Schema,
    [property: JsonPropertyName("snapshot_id")] string SnapshotId,
    [property: JsonPropertyName("run_id")] string? RunId,
    [property: JsonPropertyName("generated_utc")] DateTimeOffset GeneratedUtc,
    [property: JsonPropertyName("source")] string Source,
    [property: JsonPropertyName("source_event_count")] int SourceEventCount,
    [property: JsonPropertyName("source_first_utc")] DateTimeOffset? SourceFirstUtc,
    [property: JsonPropertyName("source_last_utc")] DateTimeOffset? SourceLastUtc,
    [property: JsonPropertyName("activity")] IReadOnlyList<ActivityCount> Activity,
    [property: JsonPropertyName("package_readiness")] IReadOnlyList<P05PackageReadiness> PackageReadiness,
    [property: JsonPropertyName("overall_readiness")] ReadinessBar OverallReadiness,
    [property: JsonPropertyName("overall_cycles")] IReadOnlyList<P05CycleStatus> OverallCycles,
    [property: JsonPropertyName("package_lanes")] IReadOnlyList<P05PackageLaneStatus> PackageLanes,
    [property: JsonPropertyName("operational_completed_events")] int OperationalCompletedEvents,
    [property: JsonPropertyName("operational_failed_events")] int OperationalFailedEvents,
    [property: JsonPropertyName("acceptance_event_count")] int AcceptanceEventCount,
    [property: JsonPropertyName("accepted_readiness_percent")] double? AcceptedReadinessPercent,
    [property: JsonPropertyName("drive_sync_status")] string DriveSyncStatus,
    [property: JsonPropertyName("drive_readback_ack")] bool DriveReadbackAck,
    [property: JsonPropertyName("report_gate")] string ReportGate,
    [property: JsonPropertyName("report_gate_reasons")] IReadOnlyList<string> ReportGateReasons,
    [property: JsonPropertyName("events")] IReadOnlyList<EventSummary> Events,
    [property: JsonPropertyName("notice")] string Notice,
    [property: JsonPropertyName("parse_diagnostics")] P05EventParseDiagnostics? ParseDiagnostics = null);

/// <summary>Explicit, separate report input; the events.v3 contract carries no cycle/lane receipts.</summary>
public sealed record P05RunReceipt(
    string RunId,
    IReadOnlyList<P05PackageLaneReceipt> PackageLanes);

public sealed record P05PackageLaneReceipt(
    string PackageId,
    IReadOnlyList<P05CycleReceipt> Cycles);

public sealed record P05CycleReceipt(
    string CycleId,
    string Status,
    string EvidenceSha256,
    bool EvidenceVerified);

public sealed record P05PackageLaneStatus(
    [property: JsonPropertyName("package_id")] string PackageId,
    [property: JsonPropertyName("cycles")] IReadOnlyList<P05CycleStatus> Cycles);

public sealed record P05CycleStatus(
    [property: JsonPropertyName("cycle_id")] string CycleId,
    [property: JsonPropertyName("status")] string Status,
    [property: JsonPropertyName("evidence_sha256")] string? EvidenceSha256);

public sealed record P05PackageReadiness(
    [property: JsonPropertyName("package_id")] string PackageId,
    [property: JsonPropertyName("weight_percent")] int WeightPercent,
    [property: JsonPropertyName("accepted_percent")] double? AcceptedPercent);

public sealed record ReadinessBar(
    [property: JsonPropertyName("label")] string Label,
    [property: JsonPropertyName("accepted_percent")] double? AcceptedPercent);

public sealed record ActivityCount(
    [property: JsonPropertyName("name")] string Name,
    [property: JsonPropertyName("events")] int Events);

public sealed record EventSummary(
    [property: JsonPropertyName("event_id")] string EventId,
    [property: JsonPropertyName("event_type")] string EventType,
    [property: JsonPropertyName("package_id")] string PackageId,
    [property: JsonPropertyName("action_id")] string ActionId,
    [property: JsonPropertyName("timestamp_utc")] DateTimeOffset TimestampUtc,
    [property: JsonPropertyName("state")] string State,
    [property: JsonPropertyName("numerator")] long? Numerator,
    [property: JsonPropertyName("denominator")] long? Denominator,
    [property: JsonPropertyName("evidence_verified")] bool EvidenceVerified,
    [property: JsonPropertyName("activity")] string Activity);
