using System.Collections.Concurrent;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Channels;

namespace NoxP01.Packages.P02.OpenAI;

/// <summary>
/// Reads a provider secret from an OS-backed secret store. Implementations
/// should use Windows Credential Manager or DPAPI-backed storage; never a
/// WebView setting, source file, or plain-text application config.
/// </summary>
public interface ISecretProvider
{
    ValueTask<string?> GetSecretAsync(string secretName, CancellationToken cancellationToken = default);
}

public sealed record OpenAiInputMessage(string Role, string Content);

public sealed record OpenAiResponsesRequest(
    string RequestId,
    string Model,
    IReadOnlyList<OpenAiInputMessage> Messages,
    string? Instructions = null);

public sealed record OpenAiProviderEvent(
    string RequestId,
    string State,
    string? Delta = null,
    string? ResponseId = null,
    string? ErrorCode = null,
    int? RetryAfterSeconds = null);

/// <summary>
/// Optional cloud provider for the installer's real chat. Uses the official
/// OpenAI Responses API over HTTPS with SSE, stateless requests, and caller
/// cancellation. It does not treat a ChatGPT subscription as an API credential.
/// </summary>
public sealed class OpenAiResponsesProvider : IDisposable
{
    private const string ApiKeySecretName = "OPENAI_API_KEY";
    private const int MaxActiveRequests = 8;
    private const int MaxTotalResponseTextChars = 4 * 1024 * 1024;
    private const int MaxSerializedRequestBytes = 8 * 1024 * 1024;
    private static readonly TimeSpan SecretLookupTimeout = TimeSpan.FromSeconds(15);
    private static readonly TimeSpan ProviderIdleTimeout = TimeSpan.FromSeconds(60);
    private const int MaxTotalInputBytes = 2 * 1024 * 1024;
    private const int MaxSseEventChars = 128 * 1024;
    private const int MaxSseEvents = 20_000;
    private static readonly TimeSpan ProviderRequestTimeout = TimeSpan.FromMinutes(2);
    private static readonly TimeSpan ConfigurationProbeTimeout = TimeSpan.FromSeconds(10);
    private static readonly Uri ResponsesEndpoint = new("https://api.openai.com/v1/responses");
    private static readonly UTF8Encoding StrictUtf8 = new(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    private readonly ISecretProvider _secretProvider;
    private readonly HttpClient _httpClient;
    private readonly bool _ownsHttpClient;
    private readonly ConcurrentDictionary<string, ActiveRequest> _active = new(StringComparer.Ordinal);
    private readonly object _lifecycleGate = new();
    private int _disposed;

    public OpenAiResponsesProvider(ISecretProvider secretProvider, HttpClient? httpClient = null)
    {
        _secretProvider = secretProvider ?? throw new ArgumentNullException(nameof(secretProvider));
        if (httpClient is null)
        {
            var handler = new HttpClientHandler
            {
                AllowAutoRedirect = false,
                UseCookies = false,
                UseDefaultCredentials = false,
                Credentials = null,
                MaxConnectionsPerServer = MaxActiveRequests
            };
            _httpClient = new HttpClient(handler) { Timeout = Timeout.InfiniteTimeSpan };
            _ownsHttpClient = true;
        }
        else
        {
            _httpClient = httpClient;
            _ownsHttpClient = false;
        }
    }

    /// <summary>Reports credential presence only; it does not expose the secret or claim network connectivity.</summary>
    public async ValueTask<string> GetConfigurationStateAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        using var probeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        probeCts.CancelAfter(ConfigurationProbeTimeout);
        try
        {
            var key = await _secretProvider.GetSecretAsync(ApiKeySecretName, probeCts.Token)
                .AsTask().WaitAsync(probeCts.Token).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(key)) return "NOT_CONFIGURED";
            return IsUsableApiKey(key) ? "READY" : "ERROR";
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            return "STOPPED";
        }
        catch
        {
            return "ERROR";
        }
    }

    /// <summary>Cancel the active stream for this request ID. STOPPED is emitted only after the stream observes cancellation.</summary>
    public bool Stop(string requestId)
    {
        if (!IsSafeIdentifier(requestId, 120) ||
            !_active.TryGetValue(requestId!, out var active))
            return false;

        return active.RequestStop();
    }

    public IAsyncEnumerable<OpenAiProviderEvent> StreamAsync(
        OpenAiResponsesRequest? request,
        CancellationToken cancellationToken = default)
    {
        // The caller may supply an IReadOnlyList backed by a mutable List. Freeze the
        // bounded request before async enumeration so the consented/validated context
        // cannot change while the secret lookup or network setup is awaiting.
        if (request is not null && request.Messages is { Count: > 64 })
            request = request with { Messages = Array.Empty<OpenAiInputMessage>() };
        else if (request?.Messages is { } messages)
            request = request with { Messages = messages.ToArray() };

        return StreamCoreAsync(request!, cancellationToken);
    }

    private async IAsyncEnumerable<OpenAiProviderEvent> StreamCoreAsync(
        OpenAiResponsesRequest request,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();

        if (!TryValidate(request, out var validationCode))
        {
            yield return new OpenAiProviderEvent(request?.RequestId ?? string.Empty, "ERROR", ErrorCode: validationCode);
            yield break;
        }

        // Register before secret lookup so Stop(requestId) can cancel the entire
        // operation, including a slow OS credential-store read.
        var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var active = new ActiveRequest(linkedCts);
        string? registrationError = null;
        lock (_lifecycleGate)
        {
            ThrowIfDisposed();
            if (_active.ContainsKey(request.RequestId))
                registrationError = "REQUEST_ID_BUSY";
            else if (_active.Count >= MaxActiveRequests)
                registrationError = "REQUEST_LIMIT";
            else if (!_active.TryAdd(request.RequestId, active))
                registrationError = "REQUEST_ID_BUSY";
        }
        if (registrationError is not null)
        {
            linkedCts.Dispose();
            yield return new OpenAiProviderEvent(request.RequestId, "ERROR", ErrorCode: registrationError);
            yield break;
        }

        try
        {
            string? apiKey = null;
            string? secretError = null;
            using var secretLookupCts = CancellationTokenSource.CreateLinkedTokenSource(linkedCts.Token);
            secretLookupCts.CancelAfter(SecretLookupTimeout);
            try
            {
                apiKey = await _secretProvider.GetSecretAsync(ApiKeySecretName, secretLookupCts.Token)
                    .AsTask().WaitAsync(secretLookupCts.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (linkedCts.IsCancellationRequested)
            {
                secretError = "STOPPED";
            }
            catch (OperationCanceledException) when (secretLookupCts.IsCancellationRequested)
            {
                secretError = "SECRET_STORE_TIMEOUT";
            }
            catch (InvalidDataException)
            {
                secretError = "INVALID_CREDENTIAL_STORE_DATA";
            }
            catch
            {
                secretError = "SECRET_STORE_UNAVAILABLE";
            }

            if (secretError == "STOPPED")
            {
                yield return new OpenAiProviderEvent(request.RequestId, "STOPPED");
                yield break;
            }
            if (secretError is not null)
            {
                yield return new OpenAiProviderEvent(request.RequestId, "ERROR", ErrorCode: secretError);
                yield break;
            }

            if (string.IsNullOrWhiteSpace(apiKey))
            {
                yield return new OpenAiProviderEvent(request.RequestId, "NOT_CONFIGURED", ErrorCode: "OPENAI_API_KEY_MISSING");
                yield break;
            }
            if (!IsUsableApiKey(apiKey))
            {
                yield return new OpenAiProviderEvent(request.RequestId, "ERROR", ErrorCode: "INVALID_CREDENTIAL");
                yield break;
            }

            var channel = Channel.CreateBounded<OpenAiProviderEvent>(new BoundedChannelOptions(64)
            {
                FullMode = BoundedChannelFullMode.Wait,
                SingleReader = true,
                SingleWriter = true,
                AllowSynchronousContinuations = false
            });

            yield return new OpenAiProviderEvent(request.RequestId, "RUNNING");
            var producer = PumpAsync(request, apiKey, channel.Writer, linkedCts.Token, cancellationToken);
            try
            {
                await foreach (var item in channel.Reader.ReadAllAsync().ConfigureAwait(false))
                    yield return item;
            }
            finally
            {
                linkedCts.Cancel();
                try { await producer.ConfigureAwait(false); }
                catch { /* PumpAsync translates provider failures to bounded error codes. */ }
            }
        }
        finally
        {
            _active.TryRemove(request.RequestId, out _);
            linkedCts.Dispose();
        }
    }

    private async Task PumpAsync(
        OpenAiResponsesRequest request,
        string apiKey,
        ChannelWriter<OpenAiProviderEvent> writer,
        CancellationToken cancellationToken,
        CancellationToken consumerCancellationToken)
    {
        using var timeoutCts = new CancellationTokenSource(ProviderRequestTimeout);
        using var requestCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeoutCts.Token);
        var requestToken = requestCts.Token;
        string terminalState = "INCOMPLETE";
        string? responseId = null;
        string? terminalErrorCode = null;
        var totalResponseTextChars = 0;
        try
        {
            var payload = new
            {
                model = request.Model,
                input = request.Messages,
                instructions = request.Instructions,
                stream = true,
                // NOX manages chat history locally and sends the selected context per request.
                store = false
            };
            var payloadBytes = JsonSerializer.SerializeToUtf8Bytes(payload, JsonOptions);
            if (payloadBytes.Length > MaxSerializedRequestBytes)
            {
                CryptographicOperations.ZeroMemory(payloadBytes);
                terminalState = "ERROR";
                await writer.WriteAsync(new OpenAiProviderEvent(
                    request.RequestId, terminalState, ErrorCode: "REQUEST_TOO_LARGE"), requestToken).ConfigureAwait(false);
                return;
            }

            using var httpRequest = new HttpRequestMessage(HttpMethod.Post, ResponsesEndpoint);
            httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
            httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/event-stream"));
            httpRequest.Content = new ZeroingByteArrayContent(payloadBytes);
            httpRequest.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            using var response = await _httpClient.SendAsync(
                httpRequest,
                HttpCompletionOption.ResponseHeadersRead,
                requestToken).ConfigureAwait(false);
            httpRequest.Content.Dispose();

            if (!IsExpectedProviderUri(response.RequestMessage?.RequestUri))
            {
                terminalState = "ERROR";
                await writer.WriteAsync(new OpenAiProviderEvent(
                    request.RequestId, terminalState, ErrorCode: "UNEXPECTED_PROVIDER_ORIGIN"), requestToken).ConfigureAwait(false);
                return;
            }

            if (!response.IsSuccessStatusCode)
            {
                terminalState = "ERROR";
                var statusCode = (int)response.StatusCode;
                var errorCode = statusCode switch
                {
                    401 or 403 => "AUTHENTICATION_FAILED",
                    429 => "RATE_LIMITED",
                    >= 500 => "PROVIDER_UNAVAILABLE",
                    _ => $"HTTP_{statusCode}"
                };
                await writer.WriteAsync(new OpenAiProviderEvent(
                    request.RequestId, terminalState, ErrorCode: errorCode,
                    RetryAfterSeconds: statusCode == 429 ? RetryAfterDeltaSeconds(response) : null),
                    requestToken).ConfigureAwait(false);
                return;
            }

            var responseMediaType = response.Content.Headers.ContentType?.MediaType;
            if (!string.Equals(responseMediaType, "text/event-stream", StringComparison.OrdinalIgnoreCase))
            {
                terminalState = "ERROR";
                await writer.WriteAsync(new OpenAiProviderEvent(
                    request.RequestId, terminalState, ResponseId: responseId,
                    ErrorCode: "UNEXPECTED_CONTENT_TYPE"), requestToken).ConfigureAwait(false);
                return;
            }

            await using var body = await response.Content.ReadAsStreamAsync(requestToken).ConfigureAwait(false);
            using var reader = new StreamReader(body, StrictUtf8, detectEncodingFromByteOrderMarks: false, leaveOpen: false);
            var data = new StringBuilder();
            var sseEventCount = 0;
            var lineReader = new BoundedSseLineReader(reader, MaxSseEventChars);
            while (await lineReader.ReadLineAsync(requestToken).ConfigureAwait(false) is { } line)
            {
                if (line.Length == 0)
                {
                    if (data.Length > 0)
                    {
                        if (++sseEventCount > MaxSseEvents)
                            throw new JsonException("Provider SSE event count exceeded its limit.");
                        var eventTerminal = await ProcessSseDataAsync(data.ToString(), request.RequestId, writer, requestToken, value =>
                            {
                                if (value is null) return;
                                if (responseId is not null && !string.Equals(responseId, value, StringComparison.Ordinal))
                                    throw new JsonException("Provider response ID changed within one stream.");
                                responseId = value;
                            },
                            value => terminalErrorCode = value,
                            chars =>
                            {
                                if (chars > MaxTotalResponseTextChars - totalResponseTextChars)
                                    throw new JsonException("Provider response text exceeded its total size limit.");
                                totalResponseTextChars += chars;
                            }).ConfigureAwait(false);
                        data.Clear();
                        if (eventTerminal is not null)
                        {
                            terminalState = eventTerminal;
                            break;
                        }
                    }
                    continue;
                }

                // Ignore SSE comments and event/id/retry fields. OpenAI includes a JSON `type` in data.
                if (line.StartsWith("data:", StringComparison.Ordinal))
                {
                    if (data.Length > 0) data.Append('\n');
                    data.Append(line.AsSpan(5).TrimStart());
                    if (data.Length > MaxSseEventChars)
                        throw new JsonException("Provider SSE event exceeded its size limit.");
                }
            }

            if (terminalState == "INCOMPLETE" && data.Length > 0)
            {
                if (++sseEventCount > MaxSseEvents)
                    throw new JsonException("Provider SSE event count exceeded its limit.");
                var eventTerminal = await ProcessSseDataAsync(data.ToString(), request.RequestId, writer, requestToken, value =>
                            {
                                if (value is null) return;
                                if (responseId is not null && !string.Equals(responseId, value, StringComparison.Ordinal))
                                    throw new JsonException("Provider response ID changed within one stream.");
                                responseId = value;
                            },
                            value => terminalErrorCode = value,
                            chars =>
                            {
                                if (chars > MaxTotalResponseTextChars - totalResponseTextChars)
                                    throw new JsonException("Provider response text exceeded its total size limit.");
                                totalResponseTextChars += chars;
                            }).ConfigureAwait(false);
                if (eventTerminal is not null) terminalState = eventTerminal;
            }
            if (terminalState == "INCOMPLETE" && sseEventCount == 0)
            {
                terminalState = "ERROR";
                await writer.WriteAsync(new OpenAiProviderEvent(
                    request.RequestId, terminalState, ErrorCode: "EMPTY_PROVIDER_STREAM"), requestToken).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
        {
            terminalState = "ERROR";
            await TryWriteAsync(writer, new OpenAiProviderEvent(
                request.RequestId, terminalState, ResponseId: responseId, ErrorCode: "PROVIDER_TIMEOUT"),
                cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (requestToken.IsCancellationRequested)
        {
            terminalState = "STOPPED";
        }
        catch (OperationCanceledException)
        {
            terminalState = "ERROR";
            await TryWriteAsync(writer, new OpenAiProviderEvent(
                request.RequestId, terminalState, ResponseId: responseId, ErrorCode: "HTTP_CLIENT_TIMEOUT"),
                cancellationToken).ConfigureAwait(false);
        }
        catch (TimeoutException)
        {
            terminalState = "ERROR";
            await TryWriteAsync(writer, new OpenAiProviderEvent(
                request.RequestId, terminalState, ResponseId: responseId, ErrorCode: "PROVIDER_IDLE_TIMEOUT"),
                cancellationToken).ConfigureAwait(false);
        }
        catch (HttpRequestException)
        {
            terminalState = "ERROR";
            await TryWriteAsync(writer, new OpenAiProviderEvent(request.RequestId, terminalState, ResponseId: responseId, ErrorCode: "NETWORK_ERROR"), cancellationToken).ConfigureAwait(false);
        }
        catch (DecoderFallbackException)
        {
            terminalState = "ERROR";
            await TryWriteAsync(writer, new OpenAiProviderEvent(
                request.RequestId, terminalState, ResponseId: responseId, ErrorCode: "INVALID_PROVIDER_EVENT"),
                cancellationToken).ConfigureAwait(false);
        }
        catch (JsonException)
        {
            terminalState = "ERROR";
            await TryWriteAsync(writer, new OpenAiProviderEvent(request.RequestId, terminalState, ResponseId: responseId, ErrorCode: "INVALID_PROVIDER_EVENT"), cancellationToken).ConfigureAwait(false);
        }
        catch
        {
            terminalState = "ERROR";
            await TryWriteAsync(writer, new OpenAiProviderEvent(request.RequestId, terminalState, ResponseId: responseId, ErrorCode: "PROVIDER_ERROR"), cancellationToken).ConfigureAwait(false);
        }
        finally
        {
            if (terminalState is "COMPLETED" or "STOPPED" or "INCOMPLETE")
                await TryWriteAsync(writer, new OpenAiProviderEvent(
                    request.RequestId, terminalState, ResponseId: responseId, ErrorCode: terminalErrorCode),
                    consumerCancellationToken).ConfigureAwait(false);
            writer.TryComplete();
        }
    }

    private static async Task<string?> ProcessSseDataAsync(
        string data,
        string requestId,
        ChannelWriter<OpenAiProviderEvent> writer,
        CancellationToken cancellationToken,
        Action<string?> setResponseId,
        Action<string?> setTerminalErrorCode,
        Action<int> addResponseTextChars)
    {
        if (string.Equals(data, "[DONE]", StringComparison.Ordinal))
            return "COMPLETED";

        using var json = JsonDocument.Parse(data, new JsonDocumentOptions
        {
            MaxDepth = 32,
            CommentHandling = JsonCommentHandling.Disallow,
            AllowTrailingCommas = false
        });
        var root = json.RootElement;
        if (root.ValueKind != JsonValueKind.Object)
            throw new JsonException("Provider event root must be an object.");
        var sawType = false;
        var sawResponse = false;
        var sawDelta = false;
        var sawCode = false;
        foreach (var property in root.EnumerateObject())
        {
            if (property.NameEquals("type"))
            {
                if (sawType) throw new JsonException("Provider event contains a duplicate type property.");
                sawType = true;
            }
            else if (property.NameEquals("response"))
            {
                if (sawResponse) throw new JsonException("Provider event contains a duplicate response property.");
                sawResponse = true;
            }
            else if (property.NameEquals("delta"))
            {
                if (sawDelta) throw new JsonException("Provider event contains a duplicate delta property.");
                sawDelta = true;
            }
            else if (property.NameEquals("code"))
            {
                if (sawCode) throw new JsonException("Provider event contains a duplicate code property.");
                sawCode = true;
            }
        }
        if (!root.TryGetProperty("type", out var typeElement) || typeElement.ValueKind != JsonValueKind.String)
            throw new JsonException("Provider event type must be a string.");
        var type = typeElement.GetString();
        if (string.IsNullOrWhiteSpace(type) || type.Length > 128)
            throw new JsonException("Provider event type is empty or exceeds its limit.");
        if (root.TryGetProperty("response", out var response) && response.ValueKind == JsonValueKind.Object &&
            response.TryGetProperty("id", out var idElement))
        {
            if (idElement.ValueKind != JsonValueKind.String)
                throw new JsonException("Provider response ID must be a string.");
            var responseId = idElement.GetString();
            if (!IsSafeIdentifier(responseId, 256))
                throw new JsonException("Provider response ID contains unsupported characters or exceeds its limit.");
            setResponseId(responseId);
        }

        switch (type)
        {
            case "response.output_text.delta":
                if (!root.TryGetProperty("delta", out var delta) || delta.ValueKind != JsonValueKind.String)
                    throw new JsonException("Provider text delta must be a string.");
                var text = delta.GetString();
                if (text is { Length: > 32_000 })
                    throw new JsonException("Provider text delta exceeded its size limit.");
                addResponseTextChars(text?.Length ?? 0);
                await writer.WriteAsync(new OpenAiProviderEvent(requestId, "TOKEN", Delta: text), cancellationToken).ConfigureAwait(false);
                return null;
            case "response.refusal.delta":
                if (!root.TryGetProperty("delta", out var refusalDelta) || refusalDelta.ValueKind != JsonValueKind.String)
                    throw new JsonException("Provider refusal delta must be a string.");
                var refusalText = refusalDelta.GetString();
                if (refusalText is { Length: > 32_000 })
                    throw new JsonException("Provider refusal delta exceeded its size limit.");
                addResponseTextChars(refusalText?.Length ?? 0);
                await writer.WriteAsync(new OpenAiProviderEvent(requestId, "TOKEN", Delta: refusalText), cancellationToken).ConfigureAwait(false);
                return null;
            case "response.completed":
                return "COMPLETED";
            case "response.failed":
                string? failureCode = null;
                if (root.TryGetProperty("response", out var failedResponse) &&
                    failedResponse.ValueKind == JsonValueKind.Object &&
                    failedResponse.TryGetProperty("error", out var failedError) &&
                    failedError.ValueKind == JsonValueKind.Object &&
                    failedError.TryGetProperty("code", out var failedCode))
                {
                    if (failedCode.ValueKind != JsonValueKind.String)
                        throw new JsonException("Provider response failure code must be a string.");
                    failureCode = failedCode.GetString();
                }
                if (failureCode is null &&
                    root.TryGetProperty("response", out var typedFailureResponse) &&
                    typedFailureResponse.ValueKind == JsonValueKind.Object &&
                    typedFailureResponse.TryGetProperty("error", out var typedFailure) &&
                    typedFailure.ValueKind == JsonValueKind.Object &&
                    typedFailure.TryGetProperty("type", out var failureType))
                {
                    if (failureType.ValueKind != JsonValueKind.String)
                        throw new JsonException("Provider response failure type must be a string.");
                    failureCode = failureType.GetString();
                }
                await writer.WriteAsync(new OpenAiProviderEvent(
                    requestId, "ERROR", ErrorCode: failureCode is null ? "RESPONSE_FAILED" : $"RESPONSE_FAILED_{SafeCode(failureCode)}"),
                    cancellationToken).ConfigureAwait(false);
                return "ERROR";
            case "response.incomplete":
                if (root.TryGetProperty("response", out var incompleteResponse) &&
                    incompleteResponse.ValueKind == JsonValueKind.Object &&
                    incompleteResponse.TryGetProperty("incomplete_details", out var incompleteDetails) &&
                    incompleteDetails.ValueKind == JsonValueKind.Object &&
                    incompleteDetails.TryGetProperty("reason", out var incompleteReason))
                {
                    if (incompleteReason.ValueKind != JsonValueKind.String)
                        throw new JsonException("Provider incomplete reason must be a string.");
                    setTerminalErrorCode($"INCOMPLETE_{SafeCode(incompleteReason.GetString())}");
                }
                return "INCOMPLETE";
            case "error":
                string? code = null;
                if (root.TryGetProperty("code", out var codeElement))
                {
                    if (codeElement.ValueKind != JsonValueKind.String)
                        throw new JsonException("Provider error code must be a string.");
                    code = codeElement.GetString();
                }
                await writer.WriteAsync(new OpenAiProviderEvent(requestId, "ERROR", ErrorCode: SafeCode(code)), cancellationToken).ConfigureAwait(false);
                return "ERROR";
            default:
                return null;
        }
    }

    private sealed class ZeroingByteArrayContent(byte[] content) : ByteArrayContent(content)
    {
        protected override void Dispose(bool disposing)
        {
            if (disposing) CryptographicOperations.ZeroMemory(content);
            base.Dispose(disposing);
        }
    }

    private static int? RetryAfterDeltaSeconds(HttpResponseMessage response)
    {
        var retryAfter = response.Headers.RetryAfter;
        var seconds = retryAfter?.Delta?.TotalSeconds ??
            (retryAfter?.Date is { } date ? (date - DateTimeOffset.UtcNow).TotalSeconds : (double?)null);
        if (seconds is null || double.IsNaN(seconds.Value) || double.IsInfinity(seconds.Value)) return null;
        return (int)Math.Clamp(Math.Ceiling(seconds.Value), 1, 3600);
    }

    private static bool IsExpectedProviderUri(Uri? value) =>
        value is not null &&
        string.Equals(value.Scheme, ResponsesEndpoint.Scheme, StringComparison.OrdinalIgnoreCase) &&
        string.Equals(value.Host, ResponsesEndpoint.Host, StringComparison.OrdinalIgnoreCase) &&
        value.Port == ResponsesEndpoint.Port &&
        string.Equals(value.AbsolutePath, ResponsesEndpoint.AbsolutePath, StringComparison.Ordinal) &&
        string.IsNullOrEmpty(value.UserInfo) &&
        string.IsNullOrEmpty(value.Query) &&
        string.IsNullOrEmpty(value.Fragment);

    private static bool IsSafeIdentifier(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length > maxLength) return false;
        foreach (var character in value)
            if (!char.IsAsciiLetterOrDigit(character) && character is not '_' and not '-') return false;
        return true;
    }

    private static bool IsUsableApiKey(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length > 512 ||
            !string.Equals(value, value.Trim(), StringComparison.Ordinal)) return false;
        foreach (var character in value)
            if (char.IsControl(character)) return false;
        return true;
    }

    private static string SafeCode(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "PROVIDER_ERROR";
        Span<char> buffer = stackalloc char[64];
        var length = 0;
        foreach (var character in value)
        {
            if (char.IsAsciiLetterOrDigit(character) || character is '_' or '-')
                buffer[length++] = character;
            if (length == buffer.Length) break;
        }
        return length == 0 ? "PROVIDER_ERROR" : new string(buffer[..length]);
    }

    private static async Task TryWriteAsync(
        ChannelWriter<OpenAiProviderEvent> writer,
        OpenAiProviderEvent value,
        CancellationToken cancellationToken = default)
    {
        // If the consumer has abandoned the stream, never wait forever for space
        // in the bounded channel while the producer is being joined.
        if (cancellationToken.IsCancellationRequested)
        {
            writer.TryWrite(value);
            return;
        }

        try { await writer.WriteAsync(value, cancellationToken).ConfigureAwait(false); }
        catch (ChannelClosedException) { }
        catch (OperationCanceledException)
        {
            writer.TryWrite(value);
        }
    }

    private sealed class BoundedSseLineReader(StreamReader reader, int maxChars)
    {
        private readonly char[] _buffer = new char[4096];
        private readonly StringBuilder _line = new(256);
        private int _offset;
        private int _count;

        public async ValueTask<string?> ReadLineAsync(CancellationToken cancellationToken)
        {
            var line = _line;
            line.Clear();
            while (true)
            {
                if (_offset >= _count)
                {
                    using var idleCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                    idleCts.CancelAfter(ProviderIdleTimeout);
                    try
                    {
                        _count = await reader.ReadAsync(_buffer.AsMemory(), idleCts.Token).ConfigureAwait(false);
                    }
                    catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested && idleCts.IsCancellationRequested)
                    {
                        throw new TimeoutException("Provider SSE stream exceeded its idle timeout.");
                    }
                    _offset = 0;
                    if (_count == 0)
                        return line.Length == 0 ? null : CompleteLine(line);
                }

                var newline = Array.IndexOf(_buffer, '\n', _offset, _count - _offset);
                var segmentEnd = newline >= 0 ? newline : _count;
                var segmentLength = segmentEnd - _offset;
                if (segmentLength > 0)
                {
                    var combinedLength = line.Length + segmentLength;
                    var possibleTrailingCr = _buffer[segmentEnd - 1] == '\r';
                    // Permit one extra character only when it is the CR stripped by ReadLine.
                    if (combinedLength > maxChars && !(combinedLength == maxChars + 1 && possibleTrailingCr))
                        throw new JsonException("Provider SSE line exceeded its size limit.");
                    line.Append(_buffer, _offset, segmentLength);
                }
                _offset = segmentEnd;
                if (newline >= 0)
                {
                    _offset++;
                    return CompleteLine(line);
                }
            }
        }

        private static string CompleteLine(StringBuilder line)
        {
            if (line.Length > 0 && line[line.Length - 1] == '\r')
                line.Length--;
            return line.ToString();
        }
    }

    private static bool TryValidate(OpenAiResponsesRequest? request, out string errorCode)
    {
        if (request is null || !IsSafeIdentifier(request.RequestId, 120))
        { errorCode = "INVALID_REQUEST_ID"; return false; }
        if (string.IsNullOrWhiteSpace(request.Model) || request.Model.Length > 120 ||
            !string.Equals(request.Model, request.Model.Trim(), StringComparison.Ordinal) ||
            request.Model.Any(char.IsControl))
        { errorCode = "INVALID_MODEL"; return false; }
        if (request.Messages is null || request.Messages.Count == 0 || request.Messages.Count > 64)
        { errorCode = "INVALID_INPUT"; return false; }
        var totalInputBytes = 0;
        foreach (var message in request.Messages)
        {
            if (message is null || message.Content is null || message.Content.Length > 100_000 ||
                message.Role is not ("system" or "developer" or "user" or "assistant"))
            { errorCode = "INVALID_INPUT_MESSAGE"; return false; }
            int messageBytes;
            try { messageBytes = StrictUtf8.GetByteCount(message.Content); }
            catch (EncoderFallbackException) { errorCode = "INVALID_INPUT_MESSAGE"; return false; }
            if (messageBytes > MaxTotalInputBytes - totalInputBytes)
            { errorCode = "INPUT_TOO_LARGE"; return false; }
            totalInputBytes += messageBytes;
        }
        if (request.Instructions?.Length > 20_000 ||
            request.Instructions?.Contains('\0') == true)
        { errorCode = "INVALID_INSTRUCTIONS"; return false; }
        int instructionBytes;
        try { instructionBytes = StrictUtf8.GetByteCount(request.Instructions ?? string.Empty); }
        catch (EncoderFallbackException) { errorCode = "INVALID_INSTRUCTIONS"; return false; }
        if (instructionBytes > MaxTotalInputBytes - totalInputBytes)
        { errorCode = "INPUT_TOO_LARGE"; return false; }
        errorCode = string.Empty;
        return true;
    }

    private void ThrowIfDisposed()
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
    }

    public void Dispose()
    {
        ActiveRequest[] requests;
        lock (_lifecycleGate)
        {
            if (_disposed != 0) return;
            Volatile.Write(ref _disposed, 1);
            requests = _active.Values.ToArray();
        }
        foreach (var request in requests) request.RequestStop();
        if (_ownsHttpClient) _httpClient.Dispose();
    }

    private sealed class ActiveRequest(CancellationTokenSource cancellation)
    {
        private int _stopRequested;
        public bool StopRequested => Volatile.Read(ref _stopRequested) != 0;
        public bool RequestStop()
        {
            if (Interlocked.Exchange(ref _stopRequested, 1) != 0) return false;
            try { cancellation.Cancel(); }
            catch (ObjectDisposedException) { return false; }
            catch (AggregateException) { /* A faulty cancellation callback must not break the STOP command. */ }
            return true;
        }
    }
}
