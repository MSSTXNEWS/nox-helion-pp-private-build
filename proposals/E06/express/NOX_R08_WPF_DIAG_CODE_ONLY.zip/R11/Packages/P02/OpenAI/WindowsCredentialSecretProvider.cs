using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace NoxP01.Packages.P02.OpenAI;

/// <summary>
/// Stores NOX provider secrets as Windows Generic Credentials. Windows
/// Credential Manager binds the record to the current user; credentials are
/// persisted on this computer and are never written to app config or logs.
/// </summary>
public sealed class WindowsCredentialSecretProvider : ISecretProvider
{
    private const string TargetPrefix = "NOX_HELION/";
    private const uint CredentialTypeGeneric = 1;
    private const uint CredentialPersistLocalMachine = 2;
    private const int ErrorNotFound = 1168;
    private static readonly Regex SecretNamePattern = new("^[A-Z0-9_.-]{1,64}$", RegexOptions.Compiled | RegexOptions.CultureInvariant);

    /// <summary>Reads a named secret for the current Windows user.</summary>
    public ValueTask<string?> GetSecretAsync(string secretName, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        EnsureWindows();
        var target = GetTargetName(secretName);
        if (!CredRead(target, CredentialTypeGeneric, 0, out var credentialPointer))
        {
            var error = Marshal.GetLastWin32Error();
            if (error == ErrorNotFound) return ValueTask.FromResult<string?>(null);
            throw new Win32Exception(error, "Windows Credential Manager could not read the requested credential.");
        }

        try
        {
            var credential = Marshal.PtrToStructure<NativeCredential>(credentialPointer);
            if (credential.CredentialBlob == IntPtr.Zero || credential.CredentialBlobSize == 0)
                return ValueTask.FromResult<string?>(string.Empty);

            var bytes = new byte[checked((int)credential.CredentialBlobSize)];
            try
            {
                Marshal.Copy(credential.CredentialBlob, bytes, 0, checked((int)credential.CredentialBlobSize));
                cancellationToken.ThrowIfCancellationRequested();
                return ValueTask.FromResult<string?>(Encoding.UTF8.GetString(bytes));
            }
            finally
            {
                CryptographicOperations.ZeroMemory(bytes);
            }
        }
        finally
        {
            CredFree(credentialPointer);
        }
    }

    /// <summary>Stores the OpenAI API key as a current-user Generic Credential.</summary>
    public ValueTask StoreOpenAiApiKeyAsync(string apiKey, CancellationToken cancellationToken = default) =>
        StoreSecretAsync("OPENAI_API_KEY", apiKey, cancellationToken);

    /// <summary>Deletes the OpenAI API key from this user's Windows Credential Manager.</summary>
    public ValueTask DeleteOpenAiApiKeyAsync(CancellationToken cancellationToken = default) =>
        DeleteSecretAsync("OPENAI_API_KEY", cancellationToken);

    /// <summary>Stores a named UTF-8 secret in this user's Windows Credential Manager.</summary>
    public ValueTask StoreSecretAsync(string secretName, string secret, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        EnsureWindows();
        ArgumentException.ThrowIfNullOrWhiteSpace(secret);

        var target = GetTargetName(secretName);
        var bytes = Encoding.UTF8.GetBytes(secret);
        if (bytes.Length > 2560)
        {
            CryptographicOperations.ZeroMemory(bytes);
            throw new ArgumentOutOfRangeException(nameof(secret), "Windows Generic Credentials support at most 2560 credential-blob bytes.");
        }

        var blob = IntPtr.Zero;
        try
        {
            blob = Marshal.AllocHGlobal(bytes.Length);
            Marshal.Copy(bytes, 0, blob, bytes.Length);
            cancellationToken.ThrowIfCancellationRequested();
            var credential = new NativeCredential
            {
                Type = CredentialTypeGeneric,
                TargetName = target,
                CredentialBlobSize = (uint)bytes.Length,
                CredentialBlob = blob,
                Persist = CredentialPersistLocalMachine,
                UserName = Environment.UserName
            };

            if (!CredWrite(ref credential, 0))
            {
                var error = Marshal.GetLastWin32Error();
                throw new Win32Exception(error, "Windows Credential Manager could not store the requested credential.");
            }
        }
        finally
        {
            CryptographicOperations.ZeroMemory(bytes);
            if (blob != IntPtr.Zero)
            {
                for (var offset = 0; offset < bytes.Length; offset++) Marshal.WriteByte(blob, offset, 0);
                Marshal.FreeHGlobal(blob);
            }
        }

        return ValueTask.CompletedTask;
    }

    /// <summary>Deletes a named secret. Missing credentials are treated as already deleted.</summary>
    public ValueTask DeleteSecretAsync(string secretName, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        EnsureWindows();
        var target = GetTargetName(secretName);
        if (!CredDelete(target, CredentialTypeGeneric, 0))
        {
            var error = Marshal.GetLastWin32Error();
            if (error != ErrorNotFound)
                throw new Win32Exception(error, "Windows Credential Manager could not delete the requested credential.");
        }
        return ValueTask.CompletedTask;
    }

    private static string GetTargetName(string secretName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(secretName);
        if (!SecretNamePattern.IsMatch(secretName))
            throw new ArgumentException("Secret names must use 1–64 uppercase letters, digits, dots, underscores, or hyphens.", nameof(secretName));
        return TargetPrefix + secretName;
    }

    private static void EnsureWindows()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("Windows Credential Manager is available only on Windows.");
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct NativeCredential
    {
        public uint Flags;
        public uint Type;
        [MarshalAs(UnmanagedType.LPWStr)] public string? TargetName;
        [MarshalAs(UnmanagedType.LPWStr)] public string? Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public uint CredentialBlobSize;
        public IntPtr CredentialBlob;
        public uint Persist;
        public uint AttributeCount;
        public IntPtr Attributes;
        [MarshalAs(UnmanagedType.LPWStr)] public string? TargetAlias;
        [MarshalAs(UnmanagedType.LPWStr)] public string? UserName;
    }

    [DllImport("advapi32.dll", EntryPoint = "CredReadW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredRead(string target, uint type, uint flags, out IntPtr credential);

    [DllImport("advapi32.dll", EntryPoint = "CredWriteW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredWrite(ref NativeCredential credential, uint flags);

    [DllImport("advapi32.dll", EntryPoint = "CredDeleteW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredDelete(string target, uint type, uint flags);

    [DllImport("advapi32.dll", EntryPoint = "CredFree", SetLastError = false)]
    private static extern void CredFree(IntPtr buffer);
}
