#!/usr/bin/env python3
"""NOX local QLoRA worker (first profile: Qwen3-0.6B, NVIDIA CUDA).

Uses upstream Transformers + TRL SFTTrainer + PEFT. This worker is invoked by
NOX; it does not install dependencies, fetch a dataset, or claim a run occurred.
"""
from __future__ import annotations

import argparse
import hashlib
from functools import lru_cache
import json
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "NOX-INSTALLER-EVENT-v3"
RECEIPT_SCHEMA = "NOX-QLORA-TRAINING-RECEIPT-v1"
MAX_DATASET_ROW_CHARS = 1_048_576
DEFAULT_MODEL = "Qwen/Qwen3-0.6B"
INTENSITY_PROFILES = {
    "ECO": {"max_steps": 20, "max_seq_length": 1024, "gradient_accumulation_steps": 8, "save_steps": 5, "eval_steps": 5},
    "BALANCED": {"max_steps": 40, "max_seq_length": 1024, "gradient_accumulation_steps": 8, "save_steps": 10, "eval_steps": 10},
    "INTENSIVE": {"max_steps": 60, "max_seq_length": 1024, "gradient_accumulation_steps": 8, "save_steps": 10, "eval_steps": 10},
}
DEFAULT_THERMAL_STOP_C = 83.0
TRAINING_SEED = 42


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def finite_metric(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_tree(root: Path) -> str:
    digest = hashlib.sha256()
    files = []
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise RuntimeError("ADAPTER_OUTPUT_SYMLINK_NOT_ALLOWED")
        if path.is_file():
            files.append(path)
    if not files:
        raise RuntimeError("EMPTY_ADAPTER_OUTPUT")
    for path in files:
        rel = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(rel).to_bytes(4, "big"))
        digest.update(rel)
        digest.update(bytes.fromhex(sha256_file(path)))
    return digest.hexdigest()


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("DUPLICATE_JSON_OBJECT_KEY")
        result[key] = value
    return result


def _reject_non_finite(value: str) -> None:
    raise ValueError("NON_FINITE_JSON_NUMBER")


def strict_json_loads(text: str) -> Any:
    return json.loads(text, object_pairs_hook=_reject_duplicate_keys, parse_constant=_reject_non_finite)


def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    encoded = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def load_json(path: Path) -> dict[str, Any]:
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("JSON_DOCUMENT_TOO_LARGE")
    value = strict_json_loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("EXPECTED_JSON_OBJECT")
    return value


def validate_manifest(manifest_path: Path, train_path: Path, holdout_path: Path) -> dict[str, Any]:
    manifest = load_json(manifest_path)
    required = {
        "schema": "nox-dataset-consent-v1",
        "rights_status": "APPROVED",
        "consent_status": "GRANTED",
    }
    for key, expected in required.items():
        if manifest.get(key) != expected:
            raise ValueError(f"DATASET_{key.upper()}_NOT_APPROVED")
    for key in ("dataset_id", "dataset_revision", "license_id", "owner_approval_id"):
        value = manifest.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"DATASET_{key.upper()}_MISSING")
        if len(value) > 256 or any(ord(char) < 32 or ord(char) == 127 for char in value):
            raise ValueError(f"DATASET_{key.upper()}_INVALID")
    for name, path in (("train", train_path), ("holdout", holdout_path)):
        expected_hash = manifest.get(f"{name}_sha256")
        if not isinstance(expected_hash, str) or len(expected_hash) != 64:
            raise ValueError(f"DATASET_{name.upper()}_SHA256_MISSING")
        actual = sha256_file(path)
        if actual.lower() != expected_hash.lower():
            raise ValueError(f"DATASET_{name.upper()}_SHA256_MISMATCH")
    if manifest["train_sha256"].lower() == manifest["holdout_sha256"].lower():
        raise ValueError("TRAIN_AND_HOLDOUT_MUST_DIFFER")
    return manifest


def validate_jsonl(
    path: Path,
    label: str,
    *,
    fingerprint_sink: set[bytes] | None = None,
    reject_fingerprints: set[bytes] | None = None,
) -> int:
    count = 0
    with path.open("r", encoding="utf-8") as stream:
        line_no = 0
        while True:
            line = stream.readline(MAX_DATASET_ROW_CHARS + 1)
            if not line:
                break
            line_no += 1
            if len(line) > MAX_DATASET_ROW_CHARS:
                raise ValueError(f"{label}_ROW_TOO_LARGE_{line_no}")
            if not line.strip():
                continue
            try:
                row = strict_json_loads(line)
            except (json.JSONDecodeError, ValueError) as exc:
                raise ValueError(f"{label}_INVALID_JSONL_LINE_{line_no}") from exc
            if not isinstance(row, dict):
                raise ValueError(f"{label}_ROW_NOT_OBJECT_{line_no}")
            try:
                canonical = json.dumps(
                    row, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
                ).encode("utf-8")
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{label}_INVALID_JSON_VALUE_{line_no}") from exc
            fingerprint = hashlib.sha256(canonical).digest()
            if reject_fingerprints is not None and fingerprint in reject_fingerprints:
                raise ValueError("TRAIN_HOLDOUT_RECORD_OVERLAP")
            if fingerprint_sink is not None:
                fingerprint_sink.add(fingerprint)
            if isinstance(row.get("text"), str) and row["text"].strip():
                count += 1
                continue
            messages = row.get("messages")
            if not isinstance(messages, list) or not messages:
                raise ValueError(f"{label}_ROW_NEEDS_TEXT_OR_MESSAGES_{line_no}")
            for message in messages:
                if (not isinstance(message, dict)
                        or message.get("role") not in {"system", "user", "assistant"}
                        or not isinstance(message.get("content"), str)):
                    raise ValueError(f"{label}_INVALID_MESSAGE_{line_no}")
            if not any(m.get("role") == "assistant" and m.get("content", "").strip() for m in messages):
                raise ValueError(f"{label}_NO_ASSISTANT_TARGET_{line_no}")
            count += 1
    if count == 0:
        raise ValueError(f"{label}_EMPTY")
    return count


@lru_cache(maxsize=1)
def find_nvidia_smi() -> str | None:
    if os.name == "nt":
        program_files = os.environ.get("ProgramW6432") or os.environ.get("ProgramFiles", r"C:\Program Files")
        candidates = (
            Path(program_files) / "NVIDIA Corporation" / "NVSMI" / "nvidia-smi.exe",
            Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "nvidia-smi.exe",
        )
        for candidate in candidates:
            if candidate.is_file():
                return str(candidate)
        return None
    return shutil.which("nvidia-smi") or shutil.which("nvidia-smi.exe")


def read_gpu_temperature_c(device_uuid: str) -> float | None:
    """Read the selected GPU temperature; missing/stale telemetry fails closed."""
    if not isinstance(device_uuid, str) or not re.fullmatch(r"(?:GPU|MIG)-[A-Fa-f0-9/-]{1,120}", device_uuid):
        return None
    executable = find_nvidia_smi()
    if executable is None:
        return None
    try:
        result = subprocess.run(
            [executable, "--id=" + device_uuid, "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
            shell=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None
    try:
        value = float(result.stdout.strip().splitlines()[0])
        return value if 0.0 <= value <= 150.0 else None
    except (ValueError, IndexError):
        return None


def gpu_thermal_stop_reason(temperature_c: float | None, threshold_c: float) -> str | None:
    if not math.isfinite(threshold_c) or not 50.0 <= threshold_c <= 90.0:
        return "GPU_THERMAL_POLICY_INVALID"
    if temperature_c is None or not math.isfinite(temperature_c) or not 0.0 <= temperature_c <= 150.0:
        return "GPU_TEMPERATURE_UNAVAILABLE"
    if temperature_c >= threshold_c:
        return "GPU_TEMPERATURE_LIMIT_EXCEEDED"
    return None


def list_nvidia_devices() -> dict[int, tuple[str, str]]:
    """Read NVIDIA's local device indices without importing CUDA/PyTorch."""
    executable = find_nvidia_smi()
    if executable is None:
        raise RuntimeError("NVIDIA_GPU_INVENTORY_UNAVAILABLE")
    result = subprocess.run(
        [executable, "--query-gpu=index,name,uuid", "--format=csv,noheader,nounits"],
        check=False,
        capture_output=True,
        text=True,
        timeout=8,
        shell=False,
    )
    if result.returncode != 0:
        raise RuntimeError("NVIDIA_GPU_INVENTORY_FAILED")
    devices: dict[int, tuple[str, str]] = {}
    seen_uuids: set[str] = set()
    for line in result.stdout.splitlines():
        parts = [part.strip() for part in line.split(",", 2)]
        if len(parts) != 3:
            continue
        try:
            index = int(parts[0])
        except ValueError:
            continue
        name, device_uuid = parts[1], parts[2]
        if not name or not device_uuid:
            continue
        if index in devices:
            raise RuntimeError("DUPLICATE_NVIDIA_GPU_INDEX")
        if device_uuid in seen_uuids:
            raise RuntimeError("DUPLICATE_NVIDIA_GPU_UUID")
        seen_uuids.add(device_uuid)
        devices[index] = (name, device_uuid)
    if not devices:
        raise RuntimeError("NO_NVIDIA_GPU_FOUND")
    return devices


def load_nox_adapter(
    adapter_dir: str | Path, model_id: str, model_revision: str, *, expected_adapter_sha256: str
):
    """Load a saved adapter onto its exact recorded base for real chat inference.

    Keep inference on this Transformers/PEFT path until an Ollama conversion is
    separately validated. Never silently attach an adapter to a different base.
    The expected tree digest must come from the accepted training receipt.
    """
    if not re.fullmatch(r"[0-9a-fA-F]{40}", model_revision):
        raise ValueError("MODEL_REVISION_MUST_BE_IMMUTABLE_HUB_COMMIT_SHA")
    if not re.fullmatch(r"[0-9a-fA-F]{64}", expected_adapter_sha256):
        raise ValueError("ADAPTER_TREE_SHA256_REQUIRED_FROM_ACCEPTED_RECEIPT")
    if "qwen3" not in model_id.lower():
        raise ValueError("FIRST_PROFILE_SUPPORTS_QWEN3_ONLY")
    import torch
    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    requested_adapter_path = Path(adapter_dir)
    if requested_adapter_path.is_symlink():
        raise ValueError("ADAPTER_ROOT_SYMLINK_NOT_ALLOWED")
    adapter_path = requested_adapter_path.resolve(strict=True)
    if not adapter_path.is_dir():
        raise ValueError("ADAPTER_ROOT_MUST_BE_DIRECTORY")
    base_manifest_path = adapter_path / "adapter-base.json"
    if base_manifest_path.is_symlink() or not base_manifest_path.is_file():
        raise ValueError("ADAPTER_BASE_MANIFEST_MUST_BE_REGULAR_FILE")
    base_manifest = load_json(base_manifest_path)
    if not (adapter_path / "adapter_config.json").is_file() or not (adapter_path / "adapter_model.safetensors").is_file():
        raise ValueError("PEFT_ADAPTER_ARTIFACTS_MISSING")
    for root, directories, files in os.walk(adapter_path, followlinks=False):
        if any((Path(root) / name).is_symlink() for name in directories + files):
            raise ValueError("ADAPTER_TREE_SYMLINK_NOT_ALLOWED")
    if sha256_tree(adapter_path).lower() != expected_adapter_sha256.lower():
        raise ValueError("ADAPTER_TREE_SHA256_MISMATCH")
    if base_manifest.get("model_id") != model_id or base_manifest.get("model_revision") != model_revision:
        raise ValueError("ADAPTER_BASE_REVISION_MISMATCH")
    if not torch.cuda.is_available():
        raise RuntimeError("NVIDIA_CUDA_GPU_REQUIRED_FOR_THIS_PROFILE")
    dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=dtype,
    )
    base = AutoModelForCausalLM.from_pretrained(
        model_id,
        revision=model_revision,
        trust_remote_code=False,
        quantization_config=quant_config,
        device_map="auto",
    )
    tokenizer = AutoTokenizer.from_pretrained(model_id, revision=model_revision, trust_remote_code=False)
    if tokenizer.pad_token is None:
        if tokenizer.eos_token is None:
            raise RuntimeError("TOKENIZER_PAD_AND_EOS_MISSING")
        tokenizer.pad_token = tokenizer.eos_token
    base.config.pad_token_id = tokenizer.pad_token_id
    model = PeftModel.from_pretrained(base, str(adapter_path), is_trainable=False)
    if tokenizer.pad_token is None:
        if tokenizer.eos_token is None:
            raise RuntimeError("TOKENIZER_PAD_AND_EOS_MISSING")
        tokenizer.pad_token = tokenizer.eos_token
    model.eval()
    return model, tokenizer


class V3Events:
    def __init__(self, path: Path, run_id: str, task_id: str):
        self.path = path
        self.run_id = run_id
        self.task_id = task_id
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event_type: str, state: str, action: str, message: str,
             numerator: int | None = None, denominator: int | None = None) -> None:
        if numerator is not None and numerator < 0:
            raise ValueError("EVENT_NUMERATOR_MUST_BE_NONNEGATIVE")
        if denominator is not None and denominator <= 0:
            raise ValueError("EVENT_DENOMINATOR_MUST_BE_POSITIVE")
        if numerator is not None and denominator is not None and numerator > denominator:
            raise ValueError("EVENT_NUMERATOR_EXCEEDS_DENOMINATOR")
        row = {
            "schema": SCHEMA,
            "run_id": self.run_id,
            "event_id": uuid.uuid4().hex,
            "event_type": event_type,
            "task_id": self.task_id,
            "package_id": "P04",
            "action_id": action,
            "timestamp_utc": utc_now(),
            "state": state,
            "source": "P04.QLoRA",
            "message": "".join(char if char >= " " and char != "\x7f" else " " for char in message)[:240],
            "numerator": numerator,
            "denominator": denominator,
            "evidence_verified": False,
        }
        encoded = json.dumps(row, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n"
        with self.path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())


def validate_worker_paths(args: argparse.Namespace) -> None:
    inputs = [args.train_jsonl, args.holdout_jsonl, args.dataset_manifest, args.cancel_marker]
    input_paths = [path.resolve(strict=False) for path in inputs]
    if len(set(input_paths)) != len(input_paths):
        raise ValueError("WORKER_INPUT_PATH_COLLISION")
    event_path = args.events_jsonl.resolve(strict=False)
    output_path = args.output_dir.resolve(strict=False)
    if event_path in input_paths or output_path in input_paths or event_path == output_path:
        raise ValueError("WORKER_ARTIFACT_PATH_COLLISION")

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--model-revision", required=True, help="immutable Hub commit SHA")
    parser.add_argument("--run-id", help="stable installer-session id supplied by the host; omitted values get a fresh id")
    parser.add_argument("--intensity-profile", choices=tuple(INTENSITY_PROFILES), default="BALANCED")
    parser.add_argument("--thermal-stop-c", type=float, default=DEFAULT_THERMAL_STOP_C)
    parser.add_argument("--gpu-index", type=int, default=0, help="physical NVIDIA index from nvidia-smi; an eGPU visible to CUDA is supported")
    parser.add_argument("--train-jsonl", required=True, type=Path)
    parser.add_argument("--holdout-jsonl", required=True, type=Path)
    parser.add_argument("--dataset-manifest", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--events-jsonl", required=True, type=Path)
    parser.add_argument("--cancel-marker", required=True, type=Path)
    parser.add_argument("--max-steps", type=int)
    parser.add_argument("--save-steps", type=int)
    parser.add_argument("--eval-steps", type=int)
    parser.add_argument("--max-seq-length", type=int)
    args = parser.parse_args()

    if args.run_id and not re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", args.run_id):
        parser.error("--run-id must be 1-128 letters, digits, '.', '_', ':' or '-'")
    run_id = args.run_id or uuid.uuid4().hex
    task_id = "P04-" + uuid.uuid4().hex
    try:
        validate_worker_paths(args)
    except (OSError, RuntimeError, ValueError) as exc:
        parser.error(str(exc))
    events = V3Events(args.events_jsonl, run_id, task_id)
    profile = INTENSITY_PROFILES[args.intensity_profile]
    for name in ("max_steps", "save_steps", "eval_steps", "max_seq_length"):
        if getattr(args, name) is None:
            profile_key = "max_seq_length" if name == "max_seq_length" else name
            setattr(args, name, profile[profile_key])
        elif getattr(args, name) > profile["max_seq_length" if name == "max_seq_length" else name]:
            parser.error(f"--{name.replace('_', '-')} exceeds the selected intensity profile")
    output = None
    output_created = False
    training_started = False
    try:
        if not 128 <= args.max_seq_length <= 4096:
            raise ValueError("MAX_SEQ_LENGTH_OUT_OF_SUPPORTED_RANGE")
        if not re.fullmatch(r"[0-9a-fA-F]{40}", args.model_revision):
            raise ValueError("MODEL_REVISION_MUST_BE_IMMUTABLE_HUB_COMMIT_SHA")
        if "qwen3" not in args.model.lower():
            raise RuntimeError("FIRST_PROFILE_SUPPORTS_QWEN3_ONLY")
        if args.max_steps < 1 or args.save_steps < 1 or args.eval_steps < 1:
            raise ValueError("STEP_COUNTS_MUST_BE_POSITIVE")
        if args.save_steps > args.max_steps or args.eval_steps > args.max_steps:
            raise ValueError("CHECKPOINT_EVAL_CADENCE_EXCEEDS_MAX_STEPS")
        if not 50.0 <= args.thermal_stop_c <= 90.0:
            raise ValueError("THERMAL_STOP_THRESHOLD_OUT_OF_POLICY_RANGE")
        train_path = args.train_jsonl.resolve(strict=True)
        holdout_path = args.holdout_jsonl.resolve(strict=True)
        manifest_path = args.dataset_manifest.resolve(strict=True)
        if not train_path.is_file() or not holdout_path.is_file() or not manifest_path.is_file():
            raise ValueError("INPUT_MUST_BE_FILE")
        if args.cancel_marker.exists():
            events.emit("model.stopped", "STOPPED", "training_cancelled_before_preflight",
                        "Cancellation was already requested; training preflight was skipped.")
            print(json.dumps({"run_id": run_id, "task_id": task_id, "status": "STOPPED", "reason": "CANCEL_REQUESTED_BEFORE_START"}, ensure_ascii=False))
            return 0
        manifest = validate_manifest(manifest_path, train_path, holdout_path)
        if manifest.get("model_id") != args.model or manifest.get("model_revision") != args.model_revision:
            raise ValueError("DATASET_APPROVAL_MODEL_BINDING_MISMATCH")
        train_fingerprints: set[bytes] = set()
        train_count = validate_jsonl(train_path, "TRAIN", fingerprint_sink=train_fingerprints)
        holdout_count = validate_jsonl(
            holdout_path, "HOLDOUT", reject_fingerprints=train_fingerprints
        )
        if args.cancel_marker.exists():
            events.emit("model.stopped", "STOPPED", "training_cancelled_before_gpu_inventory",
                        "Cancellation was honored before NVIDIA inventory or model loading.")
            print(json.dumps({"run_id": run_id, "task_id": task_id, "status": "STOPPED", "reason": "CANCEL_REQUESTED_BEFORE_GPU_INVENTORY"}, ensure_ascii=False))
            return 0
        if args.gpu_index < 0:
            raise ValueError("GPU_INDEX_MUST_BE_NONNEGATIVE")
        nvidia_devices = list_nvidia_devices()
        if args.gpu_index not in nvidia_devices:
            raise ValueError("SELECTED_GPU_INDEX_NOT_FOUND")
        # Use its UUID so CUDA ordinal ordering cannot select a different card.
        # A selected eGPU works when Windows/CUDA expose it to nvidia-smi.
        selected_gpu_name, selected_gpu_uuid = nvidia_devices[args.gpu_index]
        temperature = read_gpu_temperature_c(selected_gpu_uuid)
        temperature_reason = gpu_thermal_stop_reason(temperature, args.thermal_stop_c)
        if temperature_reason:
            raise RuntimeError(temperature_reason)
        if args.cancel_marker.exists():
            events.emit("model.stopped", "STOPPED", "training_cancelled_after_gpu_preflight",
                        "Cancellation was honored before CUDA and ML runtime initialization.")
            print(json.dumps({"run_id": run_id, "task_id": task_id, "status": "STOPPED", "reason": "CANCEL_REQUESTED_AFTER_GPU_PREFLIGHT"}, ensure_ascii=False))
            return 0
        events.emit("task.progress", "RUNNING", "training_profile_selected",
                    f"{args.intensity_profile}: {args.max_steps} steps, {args.max_seq_length} max tokens; thermal stop {args.thermal_stop_c:.0f} C.")
        os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
        os.environ["CUDA_VISIBLE_DEVICES"] = selected_gpu_uuid
        output = args.output_dir.resolve()
        output.mkdir(parents=True, exist_ok=False)
        output_created = True
        checkpoint_dir = output / "checkpoints"
        checkpoint_dir.mkdir()

        # Heavy ML imports happen after all consent, hash, and output-path gates.
        import torch
        import transformers
        import trl
        import peft
        from datasets import load_dataset
        from peft import LoraConfig
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, TrainerCallback, set_seed
        from trl import SFTConfig, SFTTrainer

        if not torch.cuda.is_available():
            raise RuntimeError("NVIDIA_CUDA_GPU_REQUIRED_FOR_THIS_PROFILE")
        if args.max_seq_length > 4096 or args.max_seq_length < 128:
            raise ValueError("MAX_SEQ_LENGTH_OUT_OF_SUPPORTED_RANGE")
        if torch.cuda.device_count() != 1:
            raise RuntimeError("SELECTED_GPU_NOT_VISIBLE_TO_CUDA")
        set_seed(TRAINING_SEED)
        if args.cancel_marker.exists():
            events.emit("model.stopped", "STOPPED", "training_cancelled_before_model_load",
                        "Cancellation was honored before model weights were loaded.")
            print(json.dumps({"run_id": run_id, "task_id": task_id, "status": "STOPPED", "reason": "CANCEL_REQUESTED_BEFORE_MODEL_LOAD"}, ensure_ascii=False))
            return 0
        gpu = torch.cuda.get_device_properties(0)
        bf16 = bool(torch.cuda.is_bf16_supported())
        compute_dtype = torch.bfloat16 if bf16 else torch.float16
        events.emit("task.started", "RUNNING", "training_start", "QLoRA run started after consent and hardware preflight.", 0, args.max_steps)

        tokenizer = AutoTokenizer.from_pretrained(
            args.model, revision=args.model_revision, trust_remote_code=False
        )
        if tokenizer.pad_token is None:
            if tokenizer.eos_token is None:
                raise RuntimeError("TOKENIZER_PAD_AND_EOS_MISSING")
            tokenizer.pad_token = tokenizer.eos_token
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=compute_dtype,
        )
        model = AutoModelForCausalLM.from_pretrained(
            args.model,
            revision=args.model_revision,
            trust_remote_code=False,
            quantization_config=quant_config,
            device_map="auto",
        )
        model.config.pad_token_id = tokenizer.pad_token_id
        model.config.use_cache = False
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

        train_dataset = load_dataset("json", data_files=str(train_path), split="train")
        eval_dataset = load_dataset("json", data_files=str(holdout_path), split="train")
        if (sha256_file(train_path).lower() != manifest["train_sha256"].lower()
                or sha256_file(holdout_path).lower() != manifest["holdout_sha256"].lower()):
            raise ValueError("DATASET_CHANGED_AFTER_PREFLIGHT")
        if args.cancel_marker.exists():
            del model, tokenizer, train_dataset, eval_dataset
            gc = __import__("gc")
            gc.collect()
            torch.cuda.empty_cache()
            shutil.rmtree(output)
            events.emit("model.stopped", "STOPPED", "training_cancelled_after_load",
                        "Cancellation was honored after model/data load and before evaluation.")
            print(json.dumps({"run_id": run_id, "task_id": task_id, "status": "STOPPED", "reason": "CANCEL_REQUESTED_AFTER_LOAD"}, ensure_ascii=False))
            return 0
        lora = LoraConfig(
            r=8,
            lora_alpha=16,
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM",
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        )
        training_args = SFTConfig(
            output_dir=str(checkpoint_dir),
            max_steps=args.max_steps,
            per_device_train_batch_size=1,
            per_device_eval_batch_size=1,
            gradient_accumulation_steps=profile["gradient_accumulation_steps"],
            learning_rate=2e-4,
            seed=TRAINING_SEED,
            data_seed=TRAINING_SEED,
            logging_steps=1,
            save_strategy="steps",
            save_steps=args.save_steps,
            save_total_limit=2,
            save_safetensors=True,
            eval_strategy="steps",
            eval_steps=args.eval_steps,
            bf16=bf16,
            fp16=not bf16,
            gradient_checkpointing=True,
            report_to=[],
            max_length=args.max_seq_length,
            dataset_num_proc=1,
            disable_tqdm=True,
        )

        thermal_hold = {"reason": None, "last_check": 0.0, "last_temperature_c": temperature}
        cancel_state = {"requested": False}

        class NoxCallback(TrainerCallback):
            def on_step_end(self, trainer_args, state, control, **kwargs):
                events.emit("training.step", "RUNNING", "training_step", "Training optimizer step completed.", int(state.global_step), int(state.max_steps))
                now = __import__("time").monotonic()
                if now - thermal_hold["last_check"] >= 5.0:
                    thermal_hold["last_check"] = now
                    current_temp = read_gpu_temperature_c(selected_gpu_uuid)
                    thermal_hold["last_temperature_c"] = current_temp
                    thermal_hold["reason"] = gpu_thermal_stop_reason(current_temp, args.thermal_stop_c)
                    if thermal_hold["reason"]:
                        events.emit("task.progress", "HOLD", "gpu_thermal_stop",
                                    f"{thermal_hold['reason']}; checkpoint requested before stopping.")
                        control.should_save = True
                        control.should_training_stop = True
                        return control
                if args.cancel_marker.exists():
                    cancel_state["requested"] = True
                    # Stop at an optimizer boundary, request a resumable checkpoint,
                    # and do not claim STOPPED until train() has returned.
                    control.should_save = True
                    control.should_training_stop = True
                return control

            def on_save(self, trainer_args, state, control, **kwargs):
                events.emit("checkpoint.saved", "READY", "checkpoint_saved", "Trainer checkpoint saved at optimizer boundary.", int(state.global_step), int(state.max_steps))
                return control

        # Measure the unadapted base first, so the later result is a true
        # baseline comparison rather than an initialized LoRA wrapper.
        baseline_trainer = SFTTrainer(
            model=model,
            args=training_args,
            eval_dataset=eval_dataset,
            processing_class=tokenizer,
        )
        baseline_metrics = baseline_trainer.evaluate()
        if finite_metric(baseline_metrics.get("eval_loss")) is None:
            raise RuntimeError("BASELINE_EVAL_LOSS_UNAVAILABLE")
        if args.cancel_marker.exists():
            del baseline_trainer, model, tokenizer, train_dataset, eval_dataset
            gc = __import__("gc")
            gc.collect()
            torch.cuda.empty_cache()
            shutil.rmtree(output)
            events.emit("model.stopped", "STOPPED", "training_cancelled_after_baseline",
                        "Cancellation was honored after baseline evaluation; no adapter model was reloaded.")
            print(json.dumps({"run_id": run_id, "task_id": task_id, "status": "STOPPED", "reason": "CANCEL_REQUESTED_AFTER_BASELINE"}, ensure_ascii=False))
            return 0
        del baseline_trainer, model
        import gc
        gc.collect()
        torch.cuda.empty_cache()
        temperature_reason = gpu_thermal_stop_reason(read_gpu_temperature_c(selected_gpu_uuid), args.thermal_stop_c)
        if temperature_reason:
            raise RuntimeError(temperature_reason)
        model = AutoModelForCausalLM.from_pretrained(
            args.model,
            revision=args.model_revision,
            trust_remote_code=False,
            quantization_config=quant_config,
            device_map="auto",
        )
        model.config.use_cache = False
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        trainer = SFTTrainer(
            model=model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            processing_class=tokenizer,
            peft_config=lora,
            callbacks=[NoxCallback()],
        )
        events.emit("task.progress", "RUNNING", "baseline_evaluated", "Base model holdout loss recorded.")
        training_started = True
        train_result = trainer.train()
        training_loss = finite_metric(train_result.training_loss)
        quality_hold_reason = "TRAINING_LOSS_UNAVAILABLE" if training_loss is None else None
        if thermal_hold["reason"]:
            trainer.save_model(str(output / "adapter"))
            status = "HOLD"
        elif cancel_state["requested"] or args.cancel_marker.exists():
            trainer.save_model(str(output / "adapter"))
            status = "STOPPED"
        elif quality_hold_reason:
            trainer.save_model(str(output / "adapter"))
            status = "HOLD"
        else:
            trainer.save_model(str(output / "adapter"))
            status = "COMPLETED"
        global_step = int(trainer.state.global_step)
        max_steps = int(trainer.state.max_steps)
        adapter_dir = output / "adapter"
        atomic_write_json(adapter_dir / "adapter-base.json", {
            "model_id": args.model,
            "model_revision": args.model_revision,
            "quantization": "4-bit NF4 QLoRA",
        })
        del trainer, model
        gc.collect()
        torch.cuda.empty_cache()
        if status in {"STOPPED", "HOLD"}:
            # Never reload or evaluate another GPU model after STOP or a thermal guard.
            final_metrics = {}
        else:
            temperature_reason = gpu_thermal_stop_reason(read_gpu_temperature_c(selected_gpu_uuid), args.thermal_stop_c)
            if temperature_reason:
                status = "HOLD"
                thermal_hold["reason"] = temperature_reason
                final_metrics = {}
            else:
                expected_adapter_sha256 = sha256_tree(adapter_dir)
                reloaded_model, reloaded_tokenizer = load_nox_adapter(
                    adapter_dir, args.model, args.model_revision,
                    expected_adapter_sha256=expected_adapter_sha256,
                )
                eval_trainer = SFTTrainer(
                    model=reloaded_model,
                    args=training_args,
                    eval_dataset=eval_dataset,
                    processing_class=reloaded_tokenizer,
                )
                final_metrics = eval_trainer.evaluate()
                if finite_metric(final_metrics.get("eval_loss")) is None:
                    quality_hold_reason = "ADAPTER_EVAL_LOSS_UNAVAILABLE"
                    status = "HOLD"
                del eval_trainer, reloaded_model
                gc.collect()
                torch.cuda.empty_cache()
        adapter_sha = sha256_tree(adapter_dir)
        base_loss = finite_metric(baseline_metrics.get("eval_loss"))
        tuned_loss = finite_metric(final_metrics.get("eval_loss"))
        receipt = {
            "schema": RECEIPT_SCHEMA,
            "run_id": run_id,
            "task_id": task_id,
            "status": status,
            "created_utc": utc_now(),
            "model": {"id": args.model, "revision": args.model_revision, "quantization": "4-bit NF4 QLoRA"},
            "dataset": {
                "id": manifest["dataset_id"],
                "revision": manifest["dataset_revision"],
                "manifest_sha256": sha256_file(manifest_path),
                "license_id": manifest["license_id"],
                "owner_approval_id": manifest["owner_approval_id"],
                "train_sha256": sha256_file(train_path),
                "holdout_sha256": sha256_file(holdout_path),
                "train_records": train_count,
                "holdout_records": holdout_count,
            },
            "runtime": {
                "python": sys.version.split()[0],
                "platform": platform.platform(),
                "torch": torch.__version__,
                "transformers": transformers.__version__,
                "trl": trl.__version__,
                "peft": peft.__version__,
                "cuda": torch.version.cuda,
                "gpu": gpu.name,
                "gpu_selected_physical_index": args.gpu_index,
                "gpu_visible_cuda_index": 0,
                "gpu_inventory_name": selected_gpu_name,
                "gpu_uuid": selected_gpu_uuid,
                "gpu_vram_bytes": int(gpu.total_memory),
            },
            "training": {
                "intensity_profile": args.intensity_profile,
                "seed": TRAINING_SEED,
                "max_seq_length": args.max_seq_length,
                "gradient_accumulation_steps": profile["gradient_accumulation_steps"],
                "thermal_stop_c": args.thermal_stop_c,
                "thermal_stop_reason": thermal_hold["reason"],
                "quality_hold_reason": quality_hold_reason,
                "cancel_requested": bool(cancel_state["requested"] or args.cancel_marker.exists()),
                "gpu_temperature_initial_c": temperature,
                "gpu_temperature_last_c": thermal_hold["last_temperature_c"],
                "global_step": global_step,
                "max_steps": max_steps,
                "train_loss": training_loss,
                "baseline_eval_loss": float(base_loss) if base_loss is not None else None,
                "adapter_eval_loss": float(tuned_loss) if tuned_loss is not None else None,
                "adapter_eval_better_lower_is_better": bool(base_loss is not None and tuned_loss is not None and tuned_loss < base_loss),
                "checkpoint_count": len(list(checkpoint_dir.glob("checkpoint-*"))),
            },
            "adapter": {"path": "adapter", "tree_sha256": adapter_sha},
            "evidence_verified": False,
        }
        receipt_path = output / "training-receipt.json"
        atomic_write_json(receipt_path, receipt)
        terminal_type = "model.stopped" if status == "STOPPED" else "task.failed" if status == "HOLD" else "task.completed"
        hold_reason = thermal_hold["reason"] or quality_hold_reason or "required evidence unavailable"
        terminal_message = (
            f"Training held: {hold_reason}; no completed result claimed." if status == "HOLD"
            else "Training stopped at a safe boundary; no final holdout evaluation was claimed." if status == "STOPPED"
            else "Adapter saved and holdout evaluation completed."
        )
        events.emit(terminal_type, status, "training_finished", terminal_message, int(receipt["training"]["global_step"]), int(receipt["training"]["max_steps"]))
        print(json.dumps({"run_id": run_id, "task_id": task_id, "status": status, "receipt": str(receipt_path), "adapter_sha256": adapter_sha}, ensure_ascii=False))
        return 0
    except Exception as exc:
        if output_created and not training_started and output is not None:
            shutil.rmtree(output, ignore_errors=True)
        message = str(exc)
        safety_hold = message.startswith(("GPU_TEMPERATURE_", "GPU_THERMAL_POLICY_"))
        approval_hold = message in {
            "DATASET_RIGHTS_STATUS_NOT_APPROVED",
            "DATASET_CONSENT_STATUS_NOT_APPROVED",
            "DATASET_LICENSE_ID_MISSING",
            "DATASET_OWNER_APPROVAL_ID_MISSING",
            "DATASET_APPROVAL_MODEL_BINDING_MISMATCH",
            "BASELINE_EVAL_LOSS_UNAVAILABLE",
        }
        terminal_state = "HOLD" if safety_hold or approval_hold else "ERROR"
        try:
            events.emit("task.failed", terminal_state, "training_failed", f"{str(exc) if safety_hold else type(exc).__name__}; details are in the local training log.")
        except Exception:
            pass
        print(json.dumps({"run_id": run_id, "task_id": task_id, "status": terminal_state, "error": str(exc) if safety_hold else type(exc).__name__}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
