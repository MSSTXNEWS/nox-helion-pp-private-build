using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text.Json.Serialization;
using Microsoft.Win32.SafeHandles;

namespace NoxP04.GpuGuardian;

/// <summary>One truthful NVIDIA sample. Missing sensors are null, never zero.</summary>
public sealed record GpuSample(
    DateTimeOffset TimestampUtc,
    string State,
    int? Index,
    string? Name,
    double? UtilizationPercent,
    long? MemoryUsedMiB,
    long? MemoryTotalMiB,
    double? TemperatureC,
    string Source,
    string? ErrorCode);

/// <summary>Subset of the V3 event envelope used by GPU and worker events.</summary>
public sealed record GpuGuardianEvent(
    [property: JsonPropertyName("schema")] string Schema,
    [property: JsonPropertyName("run_id")] string RunId,
    [property: JsonPropertyName("event_id")] string EventId,
    [property: JsonPropertyName("event_type")] string EventType,
    [property: JsonPropertyName("task_id")] string TaskId,
    [property: JsonPropertyName("package_id")] string PackageId,
    [property: JsonPropertyName("action_id")] string ActionId,
    [property: JsonPropertyName("timestamp_utc")] DateTimeOffset TimestampUtc,
    [property: JsonPropertyName("state")] string State,
    [property: JsonPropertyName("source")] string Source,
    [property: JsonPropertyName("message")] string Message,
    [property: JsonPropertyName("numerator")] long? Numerator,
    [property: JsonPropertyName("denominator")] long? Denominator,
    [property: JsonPropertyName("evidence_verified")] bool EvidenceVerified);

/// <summary>
/// Small Windows-first GPU sensor and NOX-worker controller. NVIDIA values are
/// read from nvidia-smi when present. It does not claim generic GPU caps, clocks,
/// or fan control. Worker controls apply only to processes started by this class.
/// </summary>
public sealed class GpuGuardian
{
    private const string EventSchema = "NOX-INSTALLER-EVENT-v3";
    private readonly string _runId;
    private readonly string? _nvidiaSmiPath;

    public GpuGuardian(string? runId = null)
    {
        if (runId is not null && !string.IsNullOrWhiteSpace(runId) && !IsSafeIdentifier(runId))
            throw new ArgumentException("Run ID must contain 1–128 safe identifier characters.", nameof(runId));
        _runId = string.IsNullOrWhiteSpace(runId) ? Guid.NewGuid().ToString("N") : runId;
        _nvidiaSmiPath = FindNvidiaSmi();
    }

    public event Action<GpuGuardianEvent>? EventRaised;

    public async Task<IReadOnlyList<GpuSample>> ReadNvidiaAsync(CancellationToken cancellationToken = default)
    {
        var now = DateTimeOffset.UtcNow;
        cancellationToken.ThrowIfCancellationRequested();
        if (!OperatingSystem.IsWindows() || _nvidiaSmiPath is null)
        {
            var errorCode = !OperatingSystem.IsWindows()
                ? "NVIDIA_TELEMETRY_UNSUPPORTED_PLATFORM"
                : "NVIDIA_SMI_NOT_FOUND_CHECK_DRIVER";
            var unavailable = new GpuSample(now, "OFFLINE", null, null, null, null, null, null,
                "nvidia-smi", errorCode);
            EmitGpuEvent(unavailable);
            return [unavailable];
        }

        using var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = _nvidiaSmiPath,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                ArgumentList =
                {
                    "--query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu",
                    "--format=csv,noheader,nounits"
                }
            },
            EnableRaisingEvents = true
        };

        try
        {
            if (!process.Start()) return [EmitGpuError(now, "NVIDIA_QUERY_START_FAILED")];
            var outputTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
            var errorTask = process.StandardError.ReadToEndAsync(cancellationToken);
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(TimeSpan.FromSeconds(4));
            await process.WaitForExitAsync(timeout.Token).ConfigureAwait(false);
            var output = await outputTask.ConfigureAwait(false);
            _ = await errorTask.ConfigureAwait(false); // Never include vendor stderr in UI/logs.

            if (process.ExitCode != 0 || string.IsNullOrWhiteSpace(output))
                return [EmitGpuError(DateTimeOffset.UtcNow, "NVIDIA_QUERY_FAILED")];

            var samples = new List<GpuSample>();
            var seenIndices = new HashSet<int>();
            foreach (var line in output.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                var fields = ParseCsv(line);
                if (fields.Count != 6)
                {
                    EmitGpuError(DateTimeOffset.UtcNow, "NVIDIA_SAMPLE_SCHEMA_INVALID");
                    continue;
                }
                var index = ParseInt(fields[0]);
                var name = Unknown(fields[1]);
                var utilization = ParseDouble(fields[2]);
                var memoryUsed = ParseLong(fields[3]);
                var memoryTotal = ParseLong(fields[4]);
                var temperature = ParseDouble(fields[5]);
                var invalid = !index.HasValue || index.Value < 0 ||
                    (index.HasValue && !seenIndices.Add(index.Value)) ||
                    utilization is < 0 or > 100 ||
                    memoryUsed is < 0 || memoryTotal is <= 0 ||
                    (memoryUsed.HasValue && memoryTotal.HasValue && memoryUsed.Value > memoryTotal.Value) ||
                    temperature is < 0 or > 150;
                if (invalid)
                {
                    EmitGpuError(DateTimeOffset.UtcNow, "NVIDIA_SAMPLE_INVALID");
                    continue;
                }

                var hasMetrics = index.HasValue && !string.IsNullOrWhiteSpace(name) &&
                    utilization.HasValue && memoryUsed.HasValue && memoryTotal.HasValue && temperature.HasValue;
                var sample = new GpuSample(
                    DateTimeOffset.UtcNow,
                    hasMetrics ? "READY" : "N_D",
                    index,
                    name,
                    utilization,
                    memoryUsed,
                    memoryTotal,
                    temperature,
                    "nvidia-smi",
                    hasMetrics ? null : "NVIDIA_METRICS_PARTIAL");
                samples.Add(sample);
                EmitGpuEvent(sample);
            }

            return samples.Count == 0 ? [EmitGpuError(DateTimeOffset.UtcNow, "NVIDIA_SAMPLE_UNAVAILABLE")] : samples;
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            TryKill(process);
            return [EmitGpuError(DateTimeOffset.UtcNow, "NVIDIA_QUERY_TIMEOUT")];
        }
        catch (OperationCanceledException)
        {
            TryKill(process);
            throw;
        }
        catch
        {
            return [EmitGpuError(DateTimeOffset.UtcNow, "NVIDIA_QUERY_FAILED")];
        }
    }

    /// <summary>
    /// Starts an explicitly named NOX worker without going through a shell.
    /// Only the returned handle can subsequently be paused, stopped, or limited.
    /// </summary>
    public NoxManagedWorker StartNoxWorker(
        string workerId,
        ProcessStartInfo startInfo,
        INoxWorkerControl workerControl)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(workerId);
        if (!IsSafeIdentifier(workerId))
            throw new ArgumentException("Worker ID must contain 1–128 safe identifier characters.", nameof(workerId));
        ArgumentNullException.ThrowIfNull(startInfo);
        ArgumentNullException.ThrowIfNull(workerControl);
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("NOX worker controls require Windows.");
        if (!Path.IsPathFullyQualified(startInfo.FileName))
            throw new ArgumentException("Worker executable must be an absolute path.", nameof(startInfo));
        if (!File.Exists(startInfo.FileName))
            throw new FileNotFoundException("Worker executable does not exist.", startInfo.FileName);
        if (startInfo.UseShellExecute)
            throw new ArgumentException("NOX workers must be started without a shell.", nameof(startInfo));
        if (string.IsNullOrWhiteSpace(startInfo.WorkingDirectory) || !Path.IsPathFullyQualified(startInfo.WorkingDirectory))
            throw new ArgumentException("Worker working directory must be an absolute path.", nameof(startInfo));
        if (!Directory.Exists(startInfo.WorkingDirectory))
            throw new DirectoryNotFoundException("Worker working directory does not exist.");

        var process = new Process { StartInfo = startInfo, EnableRaisingEvents = true };
        CpuLimitJob? job = null;
        try
        {
            if (!process.Start()) throw new InvalidOperationException("NOX worker did not start.");
            job = new CpuLimitJob();
            job.Assign(process);
            var worker = new NoxManagedWorker(workerId, process, job, workerControl, EmitWorkerEvent);
            EmitWorkerEvent(workerId, "task.started", "RUNNING", "NOX worker started.");
            return worker;
        }
        catch
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
            job?.Dispose();
            process.Dispose();
            throw;
        }
    }

    private void RaiseEvent(GpuGuardianEvent value)
    {
        var handlers = EventRaised;
        if (handlers is null) return;
        foreach (Action<GpuGuardianEvent> handler in handlers.GetInvocationList())
        {
            try { handler(value); }
            catch (Exception ex) { System.Diagnostics.Debug.WriteLine($"P04 event subscriber failed: {ex.GetType().Name}"); }
        }
    }

    private void EmitGpuEvent(GpuSample sample)
    {
        var msg = sample.Index.HasValue ? $"NVIDIA GPU {sample.Index.Value} sample." : "NVIDIA GPU sample unavailable.";
        RaiseEvent(new GpuGuardianEvent(
            EventSchema, _runId, Guid.NewGuid().ToString("N"), "gpu.sample",
            sample.Index.HasValue ? $"GPU-{sample.Index.Value}" : "GPU-UNKNOWN",
            "P04", "gpu_sample", sample.TimestampUtc, sample.State, sample.Source, msg,
            sample.UtilizationPercent.HasValue ? (long?)Math.Round(sample.UtilizationPercent.Value, MidpointRounding.AwayFromZero) : null,
            sample.UtilizationPercent.HasValue ? 100L : null,
            EvidenceVerified: false));
    }

    private void EmitWorkerEvent(string workerId, string eventType, string state, string message) =>
        RaiseEvent(new GpuGuardianEvent(
            EventSchema, _runId, Guid.NewGuid().ToString("N"), eventType,
            workerId, "P04", "worker_control", DateTimeOffset.UtcNow, state,
            "P04.GpuGuardian", message, null, null, EvidenceVerified: false));

    private GpuSample EmitGpuError(DateTimeOffset timestamp, string code)
    {
        var sample = GpuError(timestamp, code);
        EmitGpuEvent(sample);
        return sample;
    }

    private static GpuSample GpuError(DateTimeOffset timestamp, string code) =>
        new(timestamp, "N_D", null, null, null, null, null, null, "nvidia-smi", code);

    private static bool IsSafeIdentifier(string value) =>
        value.Length is >= 1 and <= 128 && value.All(static ch =>
            ch is >= 'A' and <= 'Z' or >= 'a' and <= 'z' or >= '0' and <= '9' or '.' or '_' or ':' or '-');

    private static string? FindNvidiaSmi()
    {
        if (!OperatingSystem.IsWindows()) return null;
        var candidates = new List<string>();
        var programFiles = Environment.GetEnvironmentVariable("ProgramW6432")
            ?? Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        if (!string.IsNullOrWhiteSpace(programFiles))
            candidates.Add(Path.Combine(programFiles, "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe"));
        candidates.Add(Path.Combine(Environment.SystemDirectory, "nvidia-smi.exe"));
        return candidates.FirstOrDefault(File.Exists);
    }

    private static List<string> ParseCsv(string line)
    {
        var fields = new List<string>();
        var value = new System.Text.StringBuilder();
        var inQuotes = false;
        for (var i = 0; i < line.Length; i++)
        {
            var c = line[i];
            if (c == '"')
            {
                if (inQuotes && i + 1 < line.Length && line[i + 1] == '"') { value.Append('"'); i++; }
                else inQuotes = !inQuotes;
            }
            else if (c == ',' && !inQuotes) { fields.Add(value.ToString().Trim()); value.Clear(); }
            else value.Append(c);
        }
        if (inQuotes) return [];
        fields.Add(value.ToString().Trim());
        return fields;
    }

    private static string? Unknown(string value) =>
        string.IsNullOrWhiteSpace(value) || value.Equals("N/A", StringComparison.OrdinalIgnoreCase) ? null : value;

    private static int? ParseInt(string value) => int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) ? n : null;
    private static long? ParseLong(string value) => long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) ? n : null;
    private static double? ParseDouble(string value) =>
        double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var n) && double.IsFinite(n) ? n : null;

    private static void TryKill(Process process)
    {
        try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
    }
}

/// <summary>Cooperative controls implemented by the specific NOX worker.</summary>
public interface INoxWorkerControl
{
    Task<bool> PauseAsync(CancellationToken cancellationToken);
    Task<bool> ResumeAsync(CancellationToken cancellationToken);
    Task RequestStopAsync(CancellationToken cancellationToken);
}

/// <summary>
/// A handle to exactly one process started by GpuGuardian. Pause and stop are
/// cooperative; an unavailable worker control never triggers arbitrary process
/// suspension or force-kill.
/// </summary>
public sealed class NoxManagedWorker : IAsyncDisposable
{
    private readonly Process _process;
    private readonly CpuLimitJob _job;
    private readonly INoxWorkerControl _control;
    private readonly Action<string, string, string, string> _emit;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private int _disposed;

    internal NoxManagedWorker(string workerId, Process process, CpuLimitJob job, INoxWorkerControl control,
        Action<string, string, string, string> emit)
    {
        WorkerId = workerId;
        _process = process;
        _job = job;
        _control = control;
        _emit = emit;
    }

    public string WorkerId { get; }
    public int ProcessId { get { ThrowIfDisposed(); return _process.Id; } }
    public bool HasExited { get { ThrowIfDisposed(); return _process.HasExited; } }
    public int ExitCode { get { ThrowIfDisposed(); return _process.ExitCode; } }

    public Task<string> ReadStandardOutputToEndAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        if (!_process.StartInfo.RedirectStandardOutput)
            throw new InvalidOperationException("Worker standard output was not redirected.");
        return _process.StandardOutput.ReadToEndAsync(cancellationToken);
    }

    public Task<string> ReadStandardErrorToEndAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        if (!_process.StartInfo.RedirectStandardError)
            throw new InvalidOperationException("Worker standard error was not redirected.");
        return _process.StandardError.ReadToEndAsync(cancellationToken);
    }

    public Task WaitForExitAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        return _process.WaitForExitAsync(cancellationToken);
    }

    public void SetCpuLimit(int percent)
    {
        ThrowIfDisposed();
        if (_process.HasExited) throw new InvalidOperationException("Cannot change CPU limit after worker exit.");
        _job.SetCpuLimit(percent);
        _emit(WorkerId, "task.progress", "RUNNING", $"CPU hard cap set to {percent}%.");
    }

    public async Task<bool> PauseAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            ThrowIfDisposed();
            if (_process.HasExited)
            {
                _emit(WorkerId, "task.progress", "HOLD", "Pause unavailable; worker already exited.");
                return false;
            }
            bool paused;
            try { paused = await _control.PauseAsync(cancellationToken).ConfigureAwait(false); }
            catch (OperationCanceledException)
            {
                _emit(WorkerId, "task.progress", "HOLD", "Pause wait was cancelled; worker state is unknown.");
                throw;
            }
            _emit(WorkerId, "task.progress", paused ? "PAUSED" : "HOLD",
                paused ? "Worker acknowledged pause." : "Worker does not support cooperative pause.");
            return paused;
        }
        finally { _gate.Release(); }
    }

    public async Task<bool> ResumeAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            ThrowIfDisposed();
            if (_process.HasExited)
            {
                _emit(WorkerId, "task.progress", "HOLD", "Resume unavailable; worker already exited.");
                return false;
            }
            bool resumed;
            try { resumed = await _control.ResumeAsync(cancellationToken).ConfigureAwait(false); }
            catch (OperationCanceledException)
            {
                _emit(WorkerId, "task.progress", "HOLD", "Resume wait was cancelled; worker state is unknown.");
                throw;
            }
            _emit(WorkerId, "task.progress", resumed ? "RUNNING" : "HOLD",
                resumed ? "Worker acknowledged resume." : "Worker does not support cooperative resume.");
            return resumed;
        }
        finally { _gate.Release(); }
    }

    public async Task<bool> StopAsync(TimeSpan? timeout = null, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        var effectiveTimeout = timeout ?? TimeSpan.FromSeconds(30);
        if (effectiveTimeout < TimeSpan.Zero && effectiveTimeout != Timeout.InfiniteTimeSpan)
            throw new ArgumentOutOfRangeException(nameof(timeout), "Stop timeout must be nonnegative or infinite.");
        await _gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            ThrowIfDisposed();
            if (_process.HasExited)
            {
                var exitCode = _process.ExitCode;
                var successful = exitCode == 0;
                _emit(WorkerId, successful ? "model.stopped" : "task.failed", successful ? "STOPPED" : "FAILED",
                    successful ? "Worker had already exited successfully." : $"Worker had already exited with code {exitCode}.");
                return successful;
            }
            try { await _control.RequestStopAsync(cancellationToken).ConfigureAwait(false); }
            catch (OperationCanceledException)
            {
                _emit(WorkerId, "task.progress", "HOLD", "Stop request was cancelled before acknowledgement.");
                throw;
            }
            _emit(WorkerId, "task.progress", "RUNNING", "Cooperative stop requested; waiting for worker.");
            try
            {
                await _process.WaitForExitAsync(cancellationToken)
                    .WaitAsync(effectiveTimeout, cancellationToken).ConfigureAwait(false);
                var exitCode = _process.ExitCode;
                var successful = exitCode == 0;
                _emit(WorkerId, successful ? "model.stopped" : "task.failed", successful ? "STOPPED" : "FAILED",
                    successful ? "Worker stopped after acknowledgement." : $"Worker exited with code {exitCode} after stop request.");
                return successful;
            }
            catch (OperationCanceledException)
            {
                _emit(WorkerId, "task.progress", "HOLD", "Stop wait was cancelled; worker may still be running.");
                throw;
            }
            catch (TimeoutException)
            {
                _emit(WorkerId, "task.progress", "HOLD", "Worker did not stop before timeout; it was not force-killed.");
                return false;
            }
        }
        finally { _gate.Release(); }
    }

    private void ThrowIfDisposed()
    {
        if (Volatile.Read(ref _disposed) != 0) throw new ObjectDisposedException(nameof(NoxManagedWorker));
    }

    public async ValueTask DisposeAsync()
    {
        if (Volatile.Read(ref _disposed) != 0) return;
        await _gate.WaitAsync().ConfigureAwait(false);
        try
        {
            if (Volatile.Read(ref _disposed) != 0) return;
            if (!_process.HasExited)
            {
                try { await _control.RequestStopAsync(CancellationToken.None).ConfigureAwait(false); }
                catch (OperationCanceledException)
                {
                    _emit(WorkerId, "task.progress", "HOLD", "Stop request cancelled during disposal; process and control handles were retained.");
                    throw;
                }
                _emit(WorkerId, "task.progress", "RUNNING", "Cooperative stop requested before worker disposal.");
                try
                {
                    await _process.WaitForExitAsync()
                        .WaitAsync(TimeSpan.FromSeconds(30)).ConfigureAwait(false);
                    var exitCode = _process.ExitCode;
                    _emit(WorkerId, exitCode == 0 ? "model.stopped" : "task.failed", exitCode == 0 ? "STOPPED" : "FAILED",
                        exitCode == 0 ? "Worker stopped before control handles were released." : $"Worker exited with code {exitCode} before disposal completed.");
                }
                catch (OperationCanceledException)
                {
                    _emit(WorkerId, "task.progress", "HOLD", "Worker wait was cancelled; disposal retained its process and CPU-control handles.");
                    throw;
                }
                catch (TimeoutException)
                {
                    _emit(WorkerId, "task.progress", "HOLD", "Worker remains active; disposal retained its process and CPU-control handles.");
                    throw new InvalidOperationException("Worker is still active; stop it successfully before disposing its control handle.");
                }
            }

            Interlocked.Exchange(ref _disposed, 1);
            _job.Dispose();
            _process.Dispose();
        }
        finally { _gate.Release(); }
    }
}

internal sealed class CpuLimitJob : IDisposable
{
    private readonly SafeJobHandle _handle;
    private const uint CpuRateControlEnable = 0x1;
    private const uint CpuRateControlHardCap = 0x4;
    private const int JobObjectCpuRateControlInformation = 15;

    public CpuLimitJob()
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
        _handle = Native.CreateJobObject(IntPtr.Zero, null);
        if (_handle.IsInvalid) throw new InvalidOperationException("Could not create a Windows Job Object.");
    }

    public void Assign(Process process)
    {
        if (!Native.AssignProcessToJobObject(_handle, process.Handle))
            throw new InvalidOperationException("Could not assign NOX worker to a Windows Job Object.");
    }

    public void SetCpuLimit(int percent)
    {
        if (percent is < 1 or > 100) throw new ArgumentOutOfRangeException(nameof(percent), "CPU limit must be 1–100%.");
        var info = new CpuRateControlInfo
        {
            ControlFlags = CpuRateControlEnable | CpuRateControlHardCap,
            CpuRate = checked((uint)(percent * 100))
        };
        var size = Marshal.SizeOf<CpuRateControlInfo>();
        var ptr = Marshal.AllocHGlobal(size);
        try
        {
            Marshal.StructureToPtr(info, ptr, false);
            if (!Native.SetInformationJobObject(_handle, JobObjectCpuRateControlInformation, ptr, (uint)size))
                throw new InvalidOperationException("Windows did not accept the NOX worker CPU limit.");
        }
        finally { Marshal.FreeHGlobal(ptr); }
    }

    public void Dispose() => _handle.Dispose();

    [StructLayout(LayoutKind.Sequential)]
    private struct CpuRateControlInfo
    {
        public uint ControlFlags;
        public uint CpuRate;
    }

    private sealed class SafeJobHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        private SafeJobHandle() : base(ownsHandle: true) { }
        protected override bool ReleaseHandle() => Native.CloseHandle(handle);
    }

    private static class Native
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern SafeJobHandle CreateJobObject(IntPtr jobAttributes, string? name);
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool AssignProcessToJobObject(SafeJobHandle job, IntPtr process);
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool SetInformationJobObject(SafeJobHandle job, int infoClass, IntPtr info, uint infoLength);
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool CloseHandle(IntPtr handle);
    }
}
