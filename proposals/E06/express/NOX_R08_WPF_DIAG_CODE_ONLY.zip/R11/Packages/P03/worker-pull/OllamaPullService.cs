using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using NoxP01.WorkerCatalog;

namespace NOX.P01.ModelCenter;

public sealed record PullProgress(
    string Status,
    string? Digest,
    long TotalBytes,
    long CompletedBytes,
    long AggregateTotalBytes,
    long AggregateCompletedBytes,
    string? InstalledDigest,
    long? InstalledSizeBytes,
    bool IsComplete,
    bool HasTotalMeasurement,
    bool HasCompletedMeasurement,
    bool HasAggregateTotalMeasurement,
    bool HasAggregateCompletedMeasurement);

/// <summary>
/// HashVerified means Ollama reported pull success and its installed /api/tags
/// manifest supplied a syntactically valid SHA-256 digest and positive model size.
/// The verification source is Ollama's server-side pull verification plus that
/// installed manifest; it is not a comparison with an external file checksum.
/// </summary>
public sealed record PullResult(string Tag, long SizeBytes, string Digest, bool HashVerified);

public sealed class OllamaApiException : Exception
{
    public OllamaApiException(HttpStatusCode statusCode, string message)
        : base(message) => StatusCode = statusCode;

    public HttpStatusCode StatusCode { get; }
}

/// <summary>Streams a model pull from the Ollama API bound to this machine's loopback interface.</summary>
public sealed class OllamaPullService : IDisposable
{
    public const string HashVerificationSource = "Ollama /api/pull success + installed /api/tags manifest digest and size";
    private static readonly Uri OllamaRoot = new("http://127.0.0.1:11434/", UriKind.Absolute);
    private static readonly UTF8Encoding StrictUtf8 = new(false, true);
    private const int MaxTagLength = 128;
    private const int MaxStatusLength = 256;
    private const int MaxErrorMessageLength = 4096;
    private const int MaxTrackedPullLayers = 4096;
    private const int MaxNdjsonLineBytes = 1024 * 1024;
    private const int MaxApiErrorBytes = 64 * 1024;
    private const int MaxTagsResponseBytes = 4 * 1024 * 1024;

    private readonly HttpClient _httpClient;
    private int _disposed;

    public OllamaPullService()
    {
        var handler = new SocketsHttpHandler
        {
            AllowAutoRedirect = false,
            UseProxy = false,
            ConnectTimeout = TimeSpan.FromSeconds(5)
        };

        _httpClient = new HttpClient(handler, disposeHandler: true)
        {
            BaseAddress = OllamaRoot,
            Timeout = Timeout.InfiniteTimeSpan
        };
    }

    /// <summary>
    /// Pulls one catalog-approved model. Cancellation aborts the active HTTP stream;
    /// a later call for the same tag lets Ollama reuse whatever it has already downloaded.
    /// </summary>
    public async Task<PullResult> PullAsync(
        string tag,
        IProgress<PullProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        ValidateCatalogTag(tag);
        cancellationToken.ThrowIfCancellationRequested();

        var layers = new Dictionary<string, LayerProgress>(StringComparer.OrdinalIgnoreCase);
        string? activeDigest = null;
        string? lastDigest = null;
        string lastStatus = "starting";
        var sawSuccess = false;

        using (var request = new HttpRequestMessage(HttpMethod.Post, new Uri(OllamaRoot, "api/pull")))
        {
            request.Content = new StringContent(
                JsonSerializer.Serialize(new { model = tag, stream = true }),
                Encoding.UTF8,
                "application/json");

            using var response = await _httpClient.SendAsync(
                request,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken).ConfigureAwait(false);

            EnsureLoopback(response.RequestMessage?.RequestUri ?? request.RequestUri!);
            if (!response.IsSuccessStatusCode)
            {
                var errorBody = await ReadBoundedTextAsync(
                    response.Content,
                    MaxApiErrorBytes,
                    cancellationToken).ConfigureAwait(false);
                throw new OllamaApiException(response.StatusCode, ExtractApiError(errorBody));
            }

            await using var stream = await response.Content
                .ReadAsStreamAsync(cancellationToken)
                .ConfigureAwait(false);
            using var reader = new BoundedNdjsonReader(stream, MaxNdjsonLineBytes);

            while (await reader.ReadLineAsync(cancellationToken).ConfigureAwait(false) is { } line)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                using var document = ParseNdjsonLine(line);
                var root = document.RootElement;
                if (root.ValueKind != JsonValueKind.Object)
                    throw new InvalidDataException("Ollama returned a non-object pull event.");

                if (root.TryGetProperty("error", out var errorElement))
                    throw new OllamaApiException(HttpStatusCode.OK, ReadErrorValue(errorElement));

                var status = ReadString(root, "status");
                if (string.IsNullOrWhiteSpace(status))
                    throw new InvalidDataException("Ollama pull event did not contain a status.");
                if (status.Length > MaxStatusLength || status.Any(char.IsControl))
                    throw new InvalidDataException("Ollama returned an invalid pull status.");

                lastStatus = status;
                if (status.Equals("success", StringComparison.OrdinalIgnoreCase)) sawSuccess = true;
                var eventDigest = ReadString(root, "digest");
                if (!string.IsNullOrWhiteSpace(eventDigest))
                {
                    if (eventDigest.Length > 128 || eventDigest.Any(char.IsControl))
                        throw new InvalidDataException("Ollama returned an invalid layer digest.");
                    activeDigest = eventDigest;
                    lastDigest = eventDigest;
                }

                var hasTotal = TryReadInt64(root, "total", out var total);
                var hasCompleted = TryReadInt64(root, "completed", out var completed);
                if (root.TryGetProperty("total", out _) && !hasTotal)
                    throw new InvalidDataException("Ollama reported an invalid layer size.");
                if (root.TryGetProperty("completed", out _) && !hasCompleted)
                    throw new InvalidDataException("Ollama reported invalid completed bytes.");

                if (activeDigest is not null && (hasTotal || hasCompleted))
                {
                    if (!layers.TryGetValue(activeDigest, out var layer))
                    {
                        if (layers.Count >= MaxTrackedPullLayers)
                            throw new InvalidDataException("Ollama pull exceeded the tracked-layer limit.");
                        layer = new LayerProgress();
                    }

                    if (hasTotal)
                    {
                        if (total < 0) throw new InvalidDataException("Ollama reported a negative layer size.");
                        if (total > layer.TotalBytes) layer.TotalBytes = total;
                        layer.HasTotalMeasurement = true;
                    }

                    if (hasCompleted)
                    {
                        if (completed < 0) throw new InvalidDataException("Ollama reported negative completed bytes.");
                        if (completed > layer.CompletedBytes) layer.CompletedBytes = completed;
                        layer.HasCompletedMeasurement = true;
                    }

                    if (layer.TotalBytes > 0 && layer.CompletedBytes > layer.TotalBytes)
                        layer.CompletedBytes = layer.TotalBytes;
                    layers[activeDigest] = layer;
                }

                var aggregate = GetAggregateProgress(layers.Values);
                var currentLayer = activeDigest is not null && layers.TryGetValue(activeDigest, out var current)
                    ? current
                    : null;

                progress?.Report(new PullProgress(
                    status,
                    activeDigest,
                    currentLayer?.TotalBytes ?? 0,
                    currentLayer?.CompletedBytes ?? 0,
                    aggregate.TotalBytes,
                    aggregate.CompletedBytes,
                    InstalledDigest: null,
                    InstalledSizeBytes: null,
                    IsComplete: false,
                    HasTotalMeasurement: currentLayer?.HasTotalMeasurement == true,
                    HasCompletedMeasurement: currentLayer?.HasCompletedMeasurement == true,
                    HasAggregateTotalMeasurement: aggregate.HasTotalMeasurement,
                    HasAggregateCompletedMeasurement: aggregate.HasCompletedMeasurement));

                // Ollama defines `success` as the terminal pull event. Stop
                // consuming immediately so a peer that leaves the NDJSON
                // connection open cannot block installed-manifest verification.
                if (status.Equals("success", StringComparison.OrdinalIgnoreCase)) break;
            }
        }

        if (!sawSuccess)
            throw new InvalidDataException("Ollama closed the pull stream before reporting success.");

        var installed = await GetInstalledModelAsync(tag, cancellationToken).ConfigureAwait(false);
        var finalAggregate = GetAggregateProgress(layers.Values);

        progress?.Report(new PullProgress(
            "success",
            lastDigest,
            activeDigest is not null && layers.TryGetValue(activeDigest, out var finalLayer) ? finalLayer.TotalBytes : 0,
            activeDigest is not null && layers.TryGetValue(activeDigest, out finalLayer) ? finalLayer.CompletedBytes : 0,
            finalAggregate.TotalBytes,
            finalAggregate.CompletedBytes,
            installed.Digest,
            installed.SizeBytes,
            IsComplete: true,
            HasTotalMeasurement: activeDigest is not null && layers.TryGetValue(activeDigest, out var finalTotalLayer) && finalTotalLayer.HasTotalMeasurement,
            HasCompletedMeasurement: activeDigest is not null && layers.TryGetValue(activeDigest, out var finalCompletedLayer) && finalCompletedLayer.HasCompletedMeasurement,
            HasAggregateTotalMeasurement: finalAggregate.HasTotalMeasurement,
            HasAggregateCompletedMeasurement: finalAggregate.HasCompletedMeasurement));

        return new PullResult(tag, installed.SizeBytes, installed.Digest, HashVerified: true);
    }

    private static void ValidateCatalogTag(string tag)
    {
        if (string.IsNullOrWhiteSpace(tag) || tag.Length > MaxTagLength)
            throw new ArgumentException($"Model tag must be between 1 and {MaxTagLength} characters.", nameof(tag));
        foreach (var character in tag)
        {
            if (char.IsControl(character) || char.IsWhiteSpace(character))
                throw new ArgumentException("Model tag cannot contain whitespace or control characters.", nameof(tag));
        }

        if (ModelCatalog.TryGetByTag(tag, out _)) return;
        throw new ArgumentException("Model tag is not present in the approved model catalog.", nameof(tag));
    }

    private async Task<InstalledModel> GetInstalledModelAsync(string requestedTag, CancellationToken cancellationToken)
    {
        var latestTag = requestedTag.IndexOf(':') < 0 ? requestedTag + ":latest" : null;
        using var request = new HttpRequestMessage(HttpMethod.Get, new Uri(OllamaRoot, "api/tags"));
        using var response = await _httpClient.SendAsync(
            request,
            HttpCompletionOption.ResponseHeadersRead,
            cancellationToken).ConfigureAwait(false);

        EnsureLoopback(response.RequestMessage?.RequestUri ?? request.RequestUri!);
        if (!response.IsSuccessStatusCode)
        {
            var errorBody = await ReadBoundedTextAsync(
                response.Content,
                MaxApiErrorBytes,
                cancellationToken).ConfigureAwait(false);
            throw new OllamaApiException(response.StatusCode, ExtractApiError(errorBody));
        }

        var json = await ReadBoundedTextAsync(
            response.Content,
            MaxTagsResponseBytes,
            cancellationToken,
            rejectAtLimit: true).ConfigureAwait(false);

        JsonDocument document;
        try { document = JsonDocument.Parse(json); }
        catch (JsonException ex) { throw new InvalidDataException("Ollama /api/tags returned invalid JSON.", ex); }

        using (document)
        {
            if (!document.RootElement.TryGetProperty("models", out var models) || models.ValueKind != JsonValueKind.Array)
                throw new InvalidDataException("Ollama /api/tags response did not contain a models array.");

            foreach (var model in models.EnumerateArray())
            {
                if (model.ValueKind != JsonValueKind.Object) continue;
                var name = ReadString(model, "name");
                var modelName = ReadString(model, "model");
                if (!TagMatches(requestedTag, latestTag, name) && !TagMatches(requestedTag, latestTag, modelName)) continue;

                var digest = ReadString(model, "digest");
                if (!IsSha256Digest(digest))
                    throw new InvalidDataException("Ollama installed model did not provide a valid sha256 digest.");
                if (!TryReadInt64(model, "size", out var sizeBytes) || sizeBytes <= 0)
                    throw new InvalidDataException("Ollama installed model did not provide a positive size.");

                return new InstalledModel(sizeBytes, digest!.ToLowerInvariant());
            }
        }

        throw new InvalidDataException($"Ollama reported pull success, but '{requestedTag}' was not found in /api/tags.");
    }

    private static bool TagMatches(string requestedTag, string? latestTag, string? installedTag)
    {
        if (string.IsNullOrEmpty(installedTag)) return false;
        return string.Equals(requestedTag, installedTag, StringComparison.OrdinalIgnoreCase) ||
               (latestTag is not null && string.Equals(latestTag, installedTag, StringComparison.OrdinalIgnoreCase));
    }

    private static bool IsSha256Digest(string? digest)
    {
        if (digest is null || digest.Length != 71 ||
            !digest.StartsWith("sha256:", StringComparison.OrdinalIgnoreCase)) return false;
        for (var i = 7; i < digest.Length; i++)
        {
            var c = digest[i];
            if (!(c is >= '0' and <= '9' or >= 'a' and <= 'f' or >= 'A' and <= 'F')) return false;
        }
        return true;
    }

    private static void EnsureLoopback(Uri uri)
    {
        if (!uri.IsAbsoluteUri || uri.Scheme != Uri.UriSchemeHttp ||
            !string.Equals(uri.Host, "127.0.0.1", StringComparison.OrdinalIgnoreCase) ||
            uri.Port != 11434 || !uri.IsLoopback || uri.UserInfo.Length != 0)
            throw new InvalidOperationException("Ollama service is restricted to http://127.0.0.1:11434.");
    }

    private static JsonDocument ParseNdjsonLine(string line)
    {
        try { return JsonDocument.Parse(line, new JsonDocumentOptions { MaxDepth = 32 }); }
        catch (JsonException ex) { throw new InvalidDataException("Ollama returned malformed NDJSON.", ex); }
    }

    private static string? ReadString(JsonElement element, string propertyName)
    {
        if (!element.TryGetProperty(propertyName, out var value) || value.ValueKind != JsonValueKind.String)
            return null;
        return value.GetString();
    }

    private static bool TryReadInt64(JsonElement element, string propertyName, out long value)
    {
        value = 0;
        return element.TryGetProperty(propertyName, out var property) &&
               property.ValueKind == JsonValueKind.Number && property.TryGetInt64(out value);
    }

    private static string ReadErrorValue(JsonElement error)
    {
        var text = error.ValueKind == JsonValueKind.String ? error.GetString() : error.ToString();
        if (string.IsNullOrWhiteSpace(text)) return "Ollama reported an unspecified API error.";
        return text.Length <= MaxErrorMessageLength ? text : text[..MaxErrorMessageLength] + " [truncated]";
    }

    private static string ExtractApiError(string body)
    {
        if (string.IsNullOrWhiteSpace(body)) return "Ollama API request failed without an error body.";
        try
        {
            using var document = JsonDocument.Parse(body, new JsonDocumentOptions { MaxDepth = 16 });
            if (document.RootElement.ValueKind == JsonValueKind.Object &&
                document.RootElement.TryGetProperty("error", out var error))
                return ReadErrorValue(error);
        }
        catch (JsonException) { }
        return body;
    }

    private static async Task<string> ReadBoundedTextAsync(
        HttpContent content,
        int maxBytes,
        CancellationToken cancellationToken,
        bool rejectAtLimit = false)
    {
        var declaredLength = content.Headers.ContentLength;
        if (rejectAtLimit && declaredLength is > 0 && declaredLength.Value >= maxBytes)
            throw new InvalidDataException("Ollama API response reached the configured size limit.");

        await using var stream = await content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        var initialCapacity = declaredLength is > 0
            ? (int)Math.Min(maxBytes, Math.Min(declaredLength.Value, 16 * 1024))
            : Math.Min(maxBytes, 16 * 1024);
        using var buffer = new MemoryStream(initialCapacity);
        var chunk = new byte[8192];
        while (buffer.Length < maxBytes)
        {
            var remaining = maxBytes - (int)buffer.Length;
            var read = await stream.ReadAsync(chunk.AsMemory(0, Math.Min(chunk.Length, remaining)), cancellationToken)
                .ConfigureAwait(false);
            if (read == 0) break;
            buffer.Write(chunk, 0, read);
        }

        // Do not probe past the limit: a local HTTP peer can keep the response
        // open indefinitely after sending exactly maxBytes. Treat the cap as a
        // strict limit for structured data; diagnostics may be returned truncated.
        var reachedLimit = buffer.Length == maxBytes;
        if (reachedLimit && rejectAtLimit)
            throw new InvalidDataException("Ollama API response reached the configured size limit.");

        string text;
        try { text = StrictUtf8.GetString(buffer.GetBuffer(), 0, (int)buffer.Length); }
        catch (DecoderFallbackException) { text = "Ollama API returned a non-UTF-8 error body."; }
        return reachedLimit ? text + " [truncated at configured limit]" : text;
    }

    private static PullAggregateProgress GetAggregateProgress(IEnumerable<LayerProgress> layers)
    {
        long total = 0;
        long completed = 0;
        var hasTotalMeasurement = false;
        var hasCompletedMeasurement = false;
        foreach (var layer in layers)
        {
            total = AddSaturated(total, layer.TotalBytes);
            var layerCompleted = layer.TotalBytes > 0 ? Math.Min(layer.CompletedBytes, layer.TotalBytes) : layer.CompletedBytes;
            completed = AddSaturated(completed, layerCompleted);
            hasTotalMeasurement |= layer.HasTotalMeasurement;
            hasCompletedMeasurement |= layer.HasCompletedMeasurement;
        }
        return new PullAggregateProgress(total, completed, hasTotalMeasurement, hasCompletedMeasurement);
    }

    private static long AddSaturated(long sum, long value) =>
        value <= 0 ? sum : long.MaxValue - sum < value ? long.MaxValue : sum + value;

    public void Dispose()
    {
        if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
        _httpClient.Dispose();
    }

    private sealed record InstalledModel(long SizeBytes, string Digest);

    private readonly record struct PullAggregateProgress(
        long TotalBytes, long CompletedBytes, bool HasTotalMeasurement, bool HasCompletedMeasurement);

    private sealed class LayerProgress
    {
        public long TotalBytes { get; set; }
        public long CompletedBytes { get; set; }
        public bool HasTotalMeasurement { get; set; }
        public bool HasCompletedMeasurement { get; set; }
    }

    /// <summary>Reads line-delimited JSON while enforcing a strict per-event byte limit.</summary>
    private sealed class BoundedNdjsonReader : IDisposable
    {
        private readonly Stream _stream;
        private readonly int _maxLineBytes;
        private readonly byte[] _buffer = new byte[8192];
        private readonly MemoryStream _line;
        private int _offset;
        private int _count;
        private bool _eof;

        public BoundedNdjsonReader(Stream stream, int maxLineBytes)
        {
            ArgumentNullException.ThrowIfNull(stream);
            ArgumentOutOfRangeException.ThrowIfNegativeOrZero(maxLineBytes);
            _stream = stream;
            _maxLineBytes = maxLineBytes;
            _line = new MemoryStream(Math.Min(maxLineBytes, 8192));
        }

        public void Dispose() => _line.Dispose();

        public async Task<string?> ReadLineAsync(CancellationToken cancellationToken)
        {
            while (true)
            {
                if (_offset < _count)
                {
                    var newline = Array.IndexOf(_buffer, (byte)'\n', _offset, _count - _offset);
                    if (newline >= 0)
                    {
                        Append(_buffer, _offset, newline - _offset);
                        _offset = newline + 1;
                        return DecodeAndResetLine();
                    }

                    Append(_buffer, _offset, _count - _offset);
                    _offset = _count;
                }

                if (_eof)
                    return _line.Length == 0 ? null : DecodeAndResetLine();

                _count = await _stream.ReadAsync(_buffer.AsMemory(), cancellationToken).ConfigureAwait(false);
                _offset = 0;
                _eof = _count == 0;
            }
        }

        private void Append(byte[] source, int offset, int count)
        {
            if (count == 0) return;
            if (count > _maxLineBytes - (int)_line.Length)
                throw new InvalidDataException("Ollama pull event exceeded the NDJSON line limit.");
            _line.Write(source, offset, count);
        }

        private string DecodeAndResetLine()
        {
            var length = (int)_line.Length;
            var bytes = _line.GetBuffer();
            if (length > 0 && bytes[length - 1] == (byte)'\r') length--;

            string result;
            try { result = StrictUtf8.GetString(bytes, 0, length); }
            catch (DecoderFallbackException ex) { throw new InvalidDataException("Ollama pull stream contained invalid UTF-8.", ex); }
            _line.SetLength(0);
            return result;
        }
    }
}
