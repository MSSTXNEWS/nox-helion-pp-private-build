# NOX HELION — исполнитель 03

Standalone WPF Model Center source candidate for Windows. It provides Ollama model downloads, a durable queue, read-only PC diagnostics, a fixed WinGet component allowlist, local GGUF review/import, and hash-checked backup/restore. The UI uses the NOX graphite/amber palette and does not edit or replace the executor 01 shell.

## Package layout

The root `NOX.Block03.ModelCenter.csproj` is the assembled package project used by `Scripts/Build-Windows.ps1`; it targets `net8.0-windows` and retains `EnableWindowsTargeting=true`. Active lane sources are included under `module/` and `worker-*/`, including the lane project file at `module/NOX.Block03.ModelCenter.csproj`. The ZIP expands with project, source, documentation, and script paths at its root. `SOURCE_MANIFEST_SHA256.json` records every package file except the manifest itself.

## Build

On Windows with the .NET 8 SDK, run `Scripts/Build-Windows.ps1`. Open the returned WPF window through `ModelCenterLauncher.CreateWindow()` from the host. See `worker-window/WINDOWS_ACCEPTANCE.md` before any acceptance run.

No build, tests, or Windows runtime acceptance were run during this packaging refresh. Windows acceptance remains **PENDING / N/D**. This source package is not an EXE and does not establish product release acceptance.

## Safety and truth in status

- Ollama pulls call only the local loopback API. Progress is byte-based when the API sends totals; otherwise the UI is indeterminate. Queue progress and terminal states are bound to the persisted pull owner lease and stop generation; Pause/Cancel release ownership after the pull has stopped.
- The catalog contains 24 official Ollama library entries. The size column says `Локально не измерен до загрузки` before a pull and displays a measured local size only when Ollama `/api/tags` returns it. An installed model without a confirmed size shows `Локальный размер N/D`. Mutable library page sizes are not treated as a pinned catalog checksum or local measurement. License review, catalog runtime size, independent checksum, and VRAM fit remain `REVIEW_REQUIRED` or `N/D` unless supported by source evidence; user acknowledgement does not replace license review.
- Ollama import is limited to GGUF. The candidate is rehashed; the selected license text, file path/SHA, format/compatibility review, rights attestation, and a separate import confirmation are required. `.safetensors`, ONNX, and other recognized formats can be scanned and hashed but remain unsupported for Ollama import. The separate staging action only copies the file; it does not install or execute it.
- Component changes use these six WinGet IDs: `Python.Python.3.12`, `Ollama.Ollama`, `Git.Git`, `Microsoft.EdgeWebView2Runtime`, `Microsoft.VCRedist.2015+.x64`, and `Microsoft.DotNet.DesktopRuntime.8`. The WinGet process is started without a console window or shell wrapper and uses argument-list parameters. An explicitly confirmed installer may request UAC/elevated privileges; install/update also require package-agreement acknowledgement. ([Microsoft manifest repository](https://github.com/microsoft/winget-pkgs), [WinGet manifest format](https://learn.microsoft.com/windows/package-manager/package/manifest))
- WebView2 uses the Evergreen Runtime. The app checks availability with `GetAvailableBrowserVersionString()` and reports `N/D` when the API cannot find it; install the runtime only when the check shows it is missing. ([Microsoft distribution guidance](https://learn.microsoft.com/microsoft-edge/webview2/concepts/distribution), [Microsoft API reference](https://learn.microsoft.com/dotnet/api/microsoft.web.webview2.core.corewebview2environment.getavailablebrowserversionstring))
- Backup archives include a SHA-256 manifest. Restore validates paths and file hashes before writing and asks for confirmation.
- WEB progress and Windows EXE acceptance are separate. This source package does not establish either status; telemetry requires user consent and must remain stoppable and revocable.

## Entry points

- `ModelCenterLauncher.CreateWindow()` — host integration.
- `ModelCenterEventHub` — local structured events plus a `NOX events.v3` adapter (`EventRaisedV3`, stable per-hub `RunId`). Download operations correlate through the persistent queue row ID; byte/percent progress remains nullable when unmeasured. Raw install output and paths are not copied into V3 evidence.
- `DownloadQueueStore` — persistent FIFO queue under LocalAppData.
- `OllamaPullService` — streaming `/api/pull` and installed `/api/tags` readback.
- `ComponentInstaller`, `LocalModelFileScanner`, `OllamaGgufImporter`, `BackupRestoreService` — bounded component operations.
