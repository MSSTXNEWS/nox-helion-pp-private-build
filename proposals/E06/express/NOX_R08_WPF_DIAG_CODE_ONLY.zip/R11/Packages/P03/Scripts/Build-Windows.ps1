param(
    [ValidateSet('Debug','Release')]
    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$resultPath = Join-Path $PSScriptRoot 'results/Build-Windows.json'
$resultDir = Split-Path -Parent $resultPath
New-Item -ItemType Directory -Force -Path $resultDir | Out-Null

$result = [ordered]@{
    status = 'N/D'
    reason = $null
    configuration = $Configuration
    project = (Join-Path $root 'NOX.Block03.ModelCenter.csproj')
    utc = [DateTime]::UtcNow.ToString('o')
}

$isWindowsHost = [System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT
if (-not $isWindowsHost) {
    $result.reason = 'Windows WPF build requires a Windows host; no build was attempted.'
    $result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $resultPath -Encoding utf8
    Write-Output 'N/D: Windows WPF build requires a Windows host.'
    exit 2
}

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) {
    $result.reason = '.NET SDK not found; no build was attempted.'
    $result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $resultPath -Encoding utf8
    Write-Output 'N/D: .NET SDK not found.'
    exit 2
}

Push-Location $root
try {
    & dotnet restore $result.project
    if ($LASTEXITCODE -ne 0) { throw "dotnet restore exited with $LASTEXITCODE" }
    & dotnet build $result.project --no-restore --configuration $Configuration
    if ($LASTEXITCODE -ne 0) { throw "dotnet build exited with $LASTEXITCODE" }
    $result.status = 'PASS'
    $result.reason = 'WPF source built on Windows.'
}
catch {
    $result.status = 'FAIL'
    $result.reason = $_.Exception.Message
    throw
}
finally {
    $result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $resultPath -Encoding utf8
    Pop-Location
}

