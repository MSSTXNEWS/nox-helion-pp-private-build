param(
    [string]$BlockRoot = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),
    [string]$OutputPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'results/Windows-Acceptance.json')
)

$ErrorActionPreference = 'Stop'
$packagedSourceRoot = [IO.Path]::GetFullPath($BlockRoot)
$nestedPackageRoot = Join-Path $BlockRoot 'package'
if ((Test-Path -LiteralPath (Join-Path $nestedPackageRoot 'NOX.Block03.ModelCenter.csproj') -PathType Leaf) -and
    (Test-Path -LiteralPath (Join-Path $nestedPackageRoot 'worker-catalog/ModelCatalog.cs') -PathType Leaf)) {
    $packagedSourceRoot = [IO.Path]::GetFullPath($nestedPackageRoot)
}
$sourceFiles = @(
    'r7-source.zip',
    'r7/SOURCE_MANIFEST_SHA256.json',
    'r7/Modules/NOX_APP_R9.zip',
    'r7/Modules/ai_lab_v4.ps1',
    'r7/Modules/integrator_v5_core.ps1',
    'r7/Modules/NoxActions.ps1',
    'r7/MainWindow.xaml.cs',
    'r7/NOX.P01.Shell.csproj'
)
$moduleFiles = @(
    'worker-catalog/ModelCatalog.cs',
    'worker-queue/ModelDownloadQueueStore.cs',
    'worker-pull/OllamaPullService.cs',
    'worker-preflight/ModelPreflight.cs',
    'worker-files/LocalModelFileScanner.cs',
    'worker-import/OllamaGgufImporter.cs',
    'module/ComponentInstaller.cs',
    'module/BackupRestoreService.cs',
    'module/ModelCenterEvent.cs',
    'worker-window/ModelDownloaderWindow.xaml',
    'worker-window/ModelDownloaderWindow.xaml.cs',
    'NOX.Block03.ModelCenter.csproj'
)
$sourceHashes = [ordered]@{}
$moduleHashes = [ordered]@{}
$packagedScriptSha256 = [ordered]@{}

foreach ($relativePath in $sourceFiles) {
    $path = Join-Path $BlockRoot $relativePath
    $sourceHashes[$relativePath] = if (Test-Path -LiteralPath $path -PathType Leaf) {
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    } else { 'N/D' }
}
foreach ($relativePath in $moduleFiles) {
    $path = Join-Path $packagedSourceRoot $relativePath
    $moduleHashes[$relativePath] = if (Test-Path -LiteralPath $path -PathType Leaf) {
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    } else { 'N/D' }
}
if (Test-Path -LiteralPath $packagedSourceRoot -PathType Container) {
    $packagedScriptExtensions = @('.ps1', '.psm1', '.psd1', '.bat', '.cmd')
    $packagedScripts = @(Get-ChildItem -LiteralPath $packagedSourceRoot -File -Recurse |
        Where-Object { $packagedScriptExtensions -contains $_.Extension.ToLowerInvariant() } |
        Sort-Object -Property FullName)
    foreach ($scriptFile in $packagedScripts) {
        $relativePath = $scriptFile.FullName.Substring($packagedSourceRoot.TrimEnd([char[]]@('\', '/')).Length).TrimStart([char[]]@('\', '/')).Replace('\', '/')
        $packagedScriptSha256[$relativePath] = (Get-FileHash -LiteralPath $scriptFile.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    }
}
$packagedSourceSha256 = [ordered]@{}
foreach ($relativePath in $moduleHashes.Keys) { $packagedSourceSha256[$relativePath] = $moduleHashes[$relativePath] }
foreach ($relativePath in $packagedScriptSha256.Keys) { $packagedSourceSha256[$relativePath] = $packagedScriptSha256[$relativePath] }
$requiredPackagedScripts = @('Scripts/Build-Windows.ps1', 'worker-tests/Scripts/Test-Block03-Contracts.ps1',
                             'worker-tests/Scripts/Windows-Acceptance.ps1')
$missingPackagedScripts = @($requiredPackagedScripts | Where-Object {
    -not $packagedScriptSha256.Contains($_) -or $packagedScriptSha256[$_] -eq 'N/D'
})

$catalogModulePath = 'worker-catalog/ModelCatalog.cs'
$catalogSha256 = $moduleHashes[$catalogModulePath]
$windowsHost = ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT)
$checks = New-Object 'System.Collections.Generic.List[object]'
$checklist = [ordered]@{
    'build.release-wpf' = 'Windows: собрать WPF проект Release для net8.0-windows и сохранить build receipt.'
    'launch.owner-and-five-tabs' = 'Показать ModelCenterLauncher.CreateWindow() от WPF owner; проверить доступность пяти вкладок.'
    'catalog.24-metadata-and-installed-detection' = 'Проверить 24+ уникальных тега, статусы лицензии/размеров/VRAM/SHA, официальные страницы и detection установленных моделей.'
    'preflight.read-only-inventory' = 'Проверить read-only снимок CPU, RAM, GPU/VRAM, диск, Ollama, Python, Git, WinGet, WebView2, network endpoints и component/library inventory.'
    'model.license-gate' = 'До открытия официальной model/license page acknowledgement и enqueue controls должны быть недоступны.'
    'model.acknowledgement-recorded' = 'Открыть страницу, вручную проверить условия, подтвердить и enqueue; запись acknowledgement должна сохраниться.'
    'queue.fifo-progress' = 'Добавить две модели; убедиться в одном активном PullAsync, FIFO и byte-based progress с indeterminate режимом без total.'
    'queue.pause-resume-cancel-retry' = 'Проверить active pause/resume, active/queued cancel и retry только для FAILED; поздний progress не меняет terminal state.'
    'ollama.digest-gate' = 'Успешный pull и установленный /api/tags digest/size завершают запись; непроверенный PullResult остаётся FAILED. Layer digest event может отсутствовать.'
    'components.agreement-and-confirmation' = 'Install/Update блокируется до открытия terms, acknowledgement и действия; Remove требует отдельного подтверждения.'
    'components.cancel-events' = 'Отменить allowlisted WinGet операцию; подтвердить остановку process tree и событие cancellation/failure.'
    'components.no-shell-or-hidden-runas' = 'После явного подтверждения проверить прямой запуск WinGet без cmd.exe/PowerShell wrapper, command window и скрытого runas; UAC от выбранного установщика разрешён.'
    'ui.theme-initial-gates' = 'Проверить graphite/amber тему, пять вкладок и выключенные действия до выполнения предпосылок/подтверждений.'
    'files.scan-boundary' = 'Сканировать выбранную папку с рекурсией off/on; только read-only кандидаты, формат и хэш, без запуска.'
    'files.review-gate' = 'Проверить HTTPS license reference и обязательные license/compatibility/rights attestation; это user attestation, не независимая legal verification.'
    'gguf.review-binding' = 'Связать GGUF review с текущим path+SHA; изменить файл или review input и подтвердить блокировку import.'
    'gguf.import-readback' = 'Импортировать reviewed GGUF в неиспользуемый tag; проверить запрет перезаписи и tag/digest/size/source/license hashes.'
    'files.staging-copy-only' = 'Подтвердить copy-only staging; проверить запрет same-root destination/overwrite и отсутствие import/execute.'
    'queue.corrupt-file-quarantine' = 'Подать повреждённый queue.json; проверить сохранение quarantine, предупреждение и восстановление пустой очереди.'
    'files.scan-terminal-events' = 'Завершить и отменить scan; проверить отдельные FileScanCompleted и FileScanCancelled events.'
    'backup.scopes-and-manifest' = 'Создать NOX/Ollama backup scopes; проверить отдельные архивы, SHA-256 manifest и пропуск secret files/missing scopes.'
    'backup.cancel' = 'Отменить backup во время выполнения; неполный временный архив не должен показываться как готовый.'
    'restore.validation-and-rollback' = 'Проверить архив, пути/размеры/хэши до записи; проверить confirmation, unrelated files и corrupt archive rollback.'
    'restore.cancel-and-recovery' = 'Отклонить второй confirmation и отменить restore; проверить CANCELLED/rollback/recovery data.'
    'events.secret-free-hub' = 'Подписаться на EventRaised; проверить queue/component/file/backup events и устойчивость к subscriber exception.'
    'window.close-during-pull' = 'Закрыть окно во время pull и открыть снова; очередь должна восстановиться PAUSED и не стать falsely COMPLETED.'
    'layout.dpi-100-150-200' = 'Проверить resize/minimum/maximized и scaling 100%, 150%, 200%; вкладки, действия и status не обрезаны.'
}
$requirementSourceFiles = @{
    'build.release-wpf' = @('NOX.Block03.ModelCenter.csproj', 'Scripts/Build-Windows.ps1')
    'launch.owner-and-five-tabs' = @('NOX.Block03.ModelCenter.csproj', 'worker-window/ModelDownloaderWindow.xaml', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'catalog.24-metadata-and-installed-detection' = @('worker-catalog/ModelCatalog.cs', 'worker-preflight/ModelPreflight.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'preflight.read-only-inventory' = @('worker-preflight/ModelPreflight.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'model.license-gate' = @('worker-catalog/ModelCatalog.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'model.acknowledgement-recorded' = @('worker-queue/ModelDownloadQueueStore.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'queue.fifo-progress' = @('worker-queue/ModelDownloadQueueStore.cs', 'worker-pull/OllamaPullService.cs', 'worker-window/ModelDownloaderWindow.xaml', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'queue.pause-resume-cancel-retry' = @('worker-queue/ModelDownloadQueueStore.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'ollama.digest-gate' = @('worker-pull/OllamaPullService.cs', 'worker-queue/ModelDownloadQueueStore.cs')
    'components.agreement-and-confirmation' = @('module/ComponentInstaller.cs', 'worker-window/ModelDownloaderWindow.xaml', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'components.cancel-events' = @('module/ComponentInstaller.cs', 'module/ModelCenterEvent.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'components.no-shell-or-hidden-runas' = @('module/ComponentInstaller.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'ui.theme-initial-gates' = @('worker-window/ModelDownloaderWindow.xaml', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'files.scan-boundary' = @('worker-files/LocalModelFileScanner.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'files.review-gate' = @('worker-files/LocalModelFileScanner.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'gguf.review-binding' = @('worker-import/OllamaGgufImporter.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'gguf.import-readback' = @('worker-import/OllamaGgufImporter.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'files.staging-copy-only' = @('worker-files/LocalModelFileScanner.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'queue.corrupt-file-quarantine' = @('worker-queue/ModelDownloadQueueStore.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'files.scan-terminal-events' = @('worker-files/LocalModelFileScanner.cs', 'module/ModelCenterEvent.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'backup.scopes-and-manifest' = @('module/BackupRestoreService.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'backup.cancel' = @('module/BackupRestoreService.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'restore.validation-and-rollback' = @('module/BackupRestoreService.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'restore.cancel-and-recovery' = @('module/BackupRestoreService.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'events.secret-free-hub' = @('module/ModelCenterEvent.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'window.close-during-pull' = @('worker-pull/OllamaPullService.cs', 'worker-queue/ModelDownloadQueueStore.cs', 'worker-window/ModelDownloaderWindow.xaml.cs')
    'layout.dpi-100-150-200' = @('worker-window/ModelDownloaderWindow.xaml', 'worker-window/ModelDownloaderWindow.xaml.cs', 'NOX.Block03.ModelCenter.csproj')
}

Write-Host 'Windows acceptance is manual and evidence-based.'
Write-Host 'This script does not launch the application, run user executables, install packages, download weights, or change system settings.'
Write-Host 'Record only observations from an approved Windows session. Do not enter secrets or tokens as evidence.'

foreach ($id in $checklist.Keys) {
    if (-not $windowsHost) {
        $status = 'N/D'
        $evidence = 'Host is not Windows; Windows runtime acceptance was not performed.'
    } else {
        Write-Host "`n[$id] $($checklist[$id])"
        $enteredStatus = (Read-Host 'Status: PASS / FAIL / N/D').Trim().ToUpperInvariant()
        if ($enteredStatus -notin @('PASS', 'FAIL', 'N/D')) { $enteredStatus = 'N/D' }
        $enteredEvidence = (Read-Host 'Evidence reference or concise observation (no secrets)').Trim()
        if ($enteredStatus -in @('PASS', 'FAIL') -and [string]::IsNullOrWhiteSpace($enteredEvidence)) {
            $status = 'N/D'
            $evidence = 'Status was downgraded to N/D because no evidence was recorded.'
        } else {
            $status = $enteredStatus
            $evidence = $enteredEvidence
        }
    }

    $checks.Add([pscustomobject][ordered]@{
        id = $id
        status = $status
        evidence = $evidence
        modelCatalogModuleSha256 = $catalogSha256
    })
}

$requirementAlignment = @($checklist.Keys | ForEach-Object {
    $id = $_
    $observed = @($checks | Where-Object { $_.id -eq $id })[0]
    $sourceFilesForRequirement = @($requirementSourceFiles[$id])
    $missingFiles = @($sourceFilesForRequirement | Where-Object {
        -not $packagedSourceSha256.Contains($_) -or $packagedSourceSha256[$_] -eq 'N/D'
    })
    $sourceStatus = if ($missingFiles.Count -eq 0) { 'PASS' } else { 'N/D' }
    $requirementStatus = if ($sourceStatus -eq 'PASS' -and $observed.status -eq 'PASS') { 'PASS' } else { 'N/D' }
    $errors = @()
    if ($observed.status -eq 'FAIL') { $errors += $observed.evidence }
    if ($missingFiles.Count -gt 0) { $errors += ('Packaged source hash is N/D for: ' + ($missingFiles -join ', ')) }
    if ($observed.status -eq 'N/D') { $errors += 'Windows runtime evidence is not recorded for this requirement.' }
    [pscustomobject][ordered]@{
        id = $id
        requirement = $checklist[$id]
        status = $requirementStatus
        sourceStatus = $sourceStatus
        windowsEvidenceStatus = $observed.status
        evidenceFiles = $sourceFilesForRequirement
        errors = @($errors)
        improvements = if ($requirementStatus -eq 'PASS') { @() } else { @('Resolve listed source gaps and record an evidence-backed Windows acceptance result.') }
    }
})

$failedCount = @($checks | Where-Object { $_.status -eq 'FAIL' }).Count
$notDeterminedCount = @($checks | Where-Object { $_.status -eq 'N/D' }).Count
$packagedSourceHashStatus = if ($packagedSourceSha256.Count -gt 0 -and -not ($packagedSourceSha256.Values -contains 'N/D') -and $missingPackagedScripts.Count -eq 0) { 'PASS' } else { 'N/D' }
$overallStatus = if ($failedCount -gt 0) { 'FAIL' } elseif ($notDeterminedCount -gt 0 -or $packagedSourceHashStatus -ne 'PASS') { 'N/D' } else { 'PASS' }
$webV1_2Boundary = [pscustomobject][ordered]@{
    boundaryStatus = 'BOUNDARY_ONLY'
    sourceRecordId = 'G02-R7'
    sourceReportedLocalTests = '21/21 (reported by G02-R7; not run by this Block03 acceptance script)'
    liveOllamaStatus = 'N/D'
    independentAcceptanceStatus = 'N/D'
    acceptedWebProgress = 'N/D'
    webReleaseStatus = 'RELEASE_BLOCKED'
    webProgressCreditToBlock03 = 'NONE'
    exeProgressCreditToBlock03 = 'NONE'
    block03WindowsAcceptance = $overallStatus
    errors = @('G02-R7 reports no live Ollama evidence and no independent acceptance; WEB accepted progress remains N/D and release remains blocked.')
    improvements = @('Close live Ollama and independent WEB acceptance only in the WEB V1.2 lane; do not transfer WEB or EXE progress into Block03.')
}
$result = [pscustomobject][ordered]@{
    schema = 'NOX.BLOCK03.WINDOWS_ACCEPTANCE.1'
    createdUtc = [DateTimeOffset]::UtcNow.ToString('o')
    status = $overallStatus
    acceptanceClass = 'BLOCK03_MANUAL_WINDOWS_EVIDENCE_ONLY; NOT_INDEPENDENT_RELEASE_ACCEPTANCE'
    independentAcceptanceStatus = 'N/D'
    releaseStatus = 'RELEASE_BLOCKED'
    hostPlatform = if ($windowsHost) { 'WINDOWS' } else { 'NON_WINDOWS' }
    blockRoot = [IO.Path]::GetFullPath($BlockRoot)
    packagedSourceRoot = [IO.Path]::GetFullPath($packagedSourceRoot)
    modelCatalogModulePath = $catalogModulePath
    modelCatalogModuleSha256 = $catalogSha256
    sameModuleSha256 = $catalogSha256
    testHarnessSha256 = (Get-FileHash -LiteralPath $MyInvocation.MyCommand.Path -Algorithm SHA256).Hash.ToLowerInvariant()
    sourceSha256 = $sourceHashes
    moduleSha256 = $moduleHashes
    packagedSourceSha256 = $packagedSourceSha256
    packagedScriptSha256 = $packagedScriptSha256
    packagedSourceHashStatus = $packagedSourceHashStatus
    missingPackagedScripts = $missingPackagedScripts
    requirementAlignment = $requirementAlignment
    webV1_2Boundary = $webV1_2Boundary
    executionScope = 'MANUAL_OBSERVATION_ONLY; SCRIPT_NEVER_LAUNCHES_APP_OR_USER_EXE_OR_INSTALLS_OR_DOWNLOADS'
    checks = @($checks)
}

$json = $result | ConvertTo-Json -Depth 8
$resolvedOutput = [IO.Path]::GetFullPath($OutputPath)
$outputDirectory = Split-Path -Parent $resolvedOutput
if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}
[IO.File]::WriteAllText($resolvedOutput, $json, [System.Text.UTF8Encoding]::new($false))
Write-Output $json
