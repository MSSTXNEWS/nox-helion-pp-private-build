param(
    [string]$BlockRoot = '',
    [string]$OutputPath = ''
)

$scriptDirectory = [IO.Path]::GetFullPath($PSScriptRoot)
if ([string]::IsNullOrWhiteSpace($BlockRoot)) {
    $directory = [IO.DirectoryInfo]::new($scriptDirectory)
    while ($null -ne $directory) {
        $candidateRoot = $directory.FullName
        if (Test-Path -LiteralPath (Join-Path $candidateRoot 'worker-tests/Scripts/Test-Block03-Contracts.ps1') -PathType Leaf) {
            $BlockRoot = $candidateRoot
            break
        }
        $directory = $directory.Parent
    }
    if ([string]::IsNullOrWhiteSpace($BlockRoot)) {
        $directory = [IO.DirectoryInfo]::new($scriptDirectory)
        while ($null -ne $directory) {
            $candidateRoot = $directory.FullName
            if (Test-Path -LiteralPath (Join-Path $candidateRoot 'Scripts/Test-Block03-Contracts.ps1') -PathType Leaf) {
                $BlockRoot = $candidateRoot
                break
            }
            $directory = $directory.Parent
        }
    }
    if ([string]::IsNullOrWhiteSpace($BlockRoot)) {
        $scriptParent = [IO.DirectoryInfo]::new($scriptDirectory).Parent
        if ($null -ne $scriptParent -and $scriptParent.Name -eq 'worker-tests') {
            $BlockRoot = $scriptParent.Parent.FullName
        } elseif ($null -ne $scriptParent) {
            $BlockRoot = $scriptParent.FullName
        } else {
            $BlockRoot = $scriptDirectory
        }
    }
}
$BlockRoot = [IO.Path]::GetFullPath($BlockRoot)
$packagedSourceRoot = $BlockRoot
$nestedPackageRoot = Join-Path $BlockRoot 'package'
if ((Test-Path -LiteralPath (Join-Path $nestedPackageRoot 'NOX.Block03.ModelCenter.csproj') -PathType Leaf) -and
    (Test-Path -LiteralPath (Join-Path $nestedPackageRoot 'worker-catalog/ModelCatalog.cs') -PathType Leaf)) {
    $packagedSourceRoot = [IO.Path]::GetFullPath($nestedPackageRoot)
}
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $scriptDirectory 'results/Block03-Contracts.json'
}

$ErrorActionPreference = 'Stop'
$checks = New-Object 'System.Collections.Generic.List[object]'
$sourceHashes = [ordered]@{}
$moduleHashes = [ordered]@{}
$sourceText = @{}
$moduleText = @{}

function Add-Check {
    param([string]$Id, [string]$Status, [string]$Evidence)
    $checks.Add([pscustomobject][ordered]@{
        id = $Id
        status = $Status
        evidence = $Evidence
        modelCatalogModuleSha256 = $script:catalogSha256
    })
}

function Test-AllPatterns {
    param([string]$Text, [string[]]$Patterns)
    foreach ($pattern in $Patterns) {
        if ($Text -notmatch $pattern) { return $false }
    }
    return $true
}

function Get-ParameterSizeFromTag {
    param([string]$Tag)
    if ($Tag -match ':(?<size>[0-9]+(?:\.[0-9]+)?b)$') { return $Matches['size'].ToUpperInvariant() }
    return 'N/D'
}

# Pass 2: exact tag/title comparison against the R7 source; no candidate code is executed.
$sourceFiles = [ordered]@{
    'r7-source.zip' = 'R7 exact source archive'
    'r7/SOURCE_MANIFEST_SHA256.json' = 'R7 source SHA manifest'
    'r7/Modules/NOX_APP_R9.zip' = 'R7 bundled candidate archive'
    'r7/Modules/ai_lab_v4.ps1' = 'R7 AI Lab source'
    'r7/Modules/integrator_v5_core.ps1' = 'R7 installer/integrator source'
    'r7/Modules/NoxActions.ps1' = 'R7 actions source'
    'r7/MainWindow.xaml.cs' = 'R7 WPF/WebView2 host source'
    'r7/NOX.P01.Shell.csproj' = 'R7 project source'
}
$moduleFiles = [ordered]@{
    'worker-catalog/ModelCatalog.cs' = 'model catalog module'
    'worker-queue/ModelDownloadQueueStore.cs' = 'download queue module'
    'worker-pull/OllamaPullService.cs' = 'Ollama pull module'
    'worker-preflight/ModelPreflight.cs' = 'local preflight module'
    'worker-window/ModelDownloaderWindow.xaml' = 'model downloader window markup'
    'worker-window/ModelDownloaderWindow.xaml.cs' = 'model downloader UI module'
    'worker-files/LocalModelFileScanner.cs' = 'local file inspection and hash module'
    'worker-import/OllamaGgufImporter.cs' = 'reviewed GGUF import module'
    'module/ComponentInstaller.cs' = 'WinGet allowlist installer module'
    'module/BackupRestoreService.cs' = 'backup/restore module'
    'module/ModelCenterEvent.cs' = 'Model Center event module'
    'NOX.Block03.ModelCenter.csproj' = 'Block 03 worker project'
}

foreach ($relativePath in $sourceFiles.Keys) {
    $path = Join-Path $BlockRoot $relativePath
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $sourceHashes[$relativePath] = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        $sourceText[$relativePath] = if ($relativePath -match '\.zip$') { '' } else { Get-Content -LiteralPath $path -Raw }
    } else {
        $sourceHashes[$relativePath] = 'N/D'
        $sourceText[$relativePath] = ''
    }
}
foreach ($relativePath in $moduleFiles.Keys) {
    $path = Join-Path $packagedSourceRoot $relativePath
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $moduleHashes[$relativePath] = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        $moduleText[$relativePath] = Get-Content -LiteralPath $path -Raw
    } else {
        $moduleHashes[$relativePath] = 'N/D'
        $moduleText[$relativePath] = ''
    }
}
$packagedScriptSha256 = [ordered]@{}
$packagedScriptExtensions = @('.ps1', '.psm1', '.psd1', '.bat', '.cmd')
if (Test-Path -LiteralPath $packagedSourceRoot -PathType Container) {
    $packagedScripts = @(Get-ChildItem -LiteralPath $packagedSourceRoot -File -Recurse |
        Where-Object { $packagedScriptExtensions -contains $_.Extension.ToLowerInvariant() } |
        Sort-Object -Property FullName)
    foreach ($scriptFile in $packagedScripts) {
        $relativePath = $scriptFile.FullName.Substring($packagedSourceRoot.TrimEnd([char[]]@('\', '/')).Length).TrimStart([char[]]@('\', '/')).Replace('\', '/')
        $packagedScriptSha256[$relativePath] = (Get-FileHash -LiteralPath $scriptFile.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    }
}
$packagedSourceSha256 = [ordered]@{}
foreach ($relativePath in $moduleHashes.Keys) { $packagedSourceSha256[$relativePath] = $moduleHashes[$relativePath] }
foreach ($relativePath in $packagedScriptSha256.Keys) { $packagedSourceSha256[$relativePath] = $packagedScriptSha256[$relativePath] }
$requiredPackagedScripts = @('Scripts/Build-Windows.ps1', 'worker-tests/Scripts/Test-Block03-Contracts.ps1',
                             'worker-tests/Scripts/Windows-Acceptance.ps1')
$missingPackagedScripts = @($requiredPackagedScripts | Where-Object {
    -not $packagedScriptSha256.Contains($_) -or $packagedScriptSha256[$_] -eq 'N/D'
})

$catalogRelativePath = 'worker-catalog/ModelCatalog.cs'
$catalogSha256 = $moduleHashes[$catalogRelativePath]
$catalogText = $moduleText[$catalogRelativePath]
$script:catalogSha256 = $catalogSha256
$aiLabText = $sourceText['r7/Modules/ai_lab_v4.ps1']
$sourceModelMatches = [regex]::Matches($aiLabText, "@\{tag='(?<tag>[^']+)';title='(?<title>[^']+)'\}")
$sourceModels = @($sourceModelMatches | ForEach-Object { [pscustomobject]@{ tag=$_.Groups['tag'].Value; title=$_.Groups['title'].Value } })
$r7ReferencePresent = Test-Path -LiteralPath (Join-Path $BlockRoot 'r7/Modules/ai_lab_v4.ps1') -PathType Leaf
$r7ManifestPresent = Test-Path -LiteralPath (Join-Path $BlockRoot 'r7/SOURCE_MANIFEST_SHA256.json') -PathType Leaf
$r7ManifestVerified = $false
$r7ManifestError = $null
if ($r7ReferencePresent -and $r7ManifestPresent) {
    try {
        $manifestPath = Join-Path $BlockRoot 'r7/SOURCE_MANIFEST_SHA256.json'
        $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
        $manifestProperties = @($manifest.PSObject.Properties)
        if ($manifestProperties.Count -eq 0) { throw 'R7 SHA-256 manifest is empty or not an object.' }
        $manifestValid = $true
        foreach ($property in $manifestProperties) {
            $relativePath = [string]$property.Name
            $expectedHash = [string]$property.Value
            if ([IO.Path]::IsPathRooted($relativePath) -or $relativePath -match '(^|[\\/])\.\.([\\/]|$)' -or
                $expectedHash -notmatch '^[0-9a-fA-F]{64}$') {
                $manifestValid = $false
                $r7ManifestError = "Invalid manifest entry: $relativePath"
                break
            }
            $manifestFile = Join-Path (Join-Path $BlockRoot 'r7') $relativePath
            if (-not (Test-Path -LiteralPath $manifestFile -PathType Leaf)) {
                $manifestValid = $false
                $r7ManifestError = "Manifest file is missing: $relativePath"
                break
            }
            $actualHash = (Get-FileHash -LiteralPath $manifestFile -Algorithm SHA256).Hash
            if ($actualHash -ine $expectedHash) {
                $manifestValid = $false
                $r7ManifestError = "Manifest hash mismatch: $relativePath"
                break
            }
        }
        $r7ManifestVerified = $manifestValid
        if (-not $manifestValid -and [string]::IsNullOrWhiteSpace($r7ManifestError)) {
            $r7ManifestError = 'R7 manifest verification failed.'
        }
    } catch {
        $r7ManifestVerified = $false
        $r7ManifestError = $_.Exception.Message
    }
}
$r7CatalogSourceAvailable = $r7ReferencePresent -and $r7ManifestVerified -and $sourceModels.Count -gt 0
$missingCandidateModules = @($moduleHashes.Keys | Where-Object { $moduleHashes[$_] -eq 'N/D' })
if ($missingCandidateModules.Count -eq 0) {
    Add-Check 'candidate.module-hashes-captured' 'PASS' 'Every required packaged candidate module exists and has an exact SHA-256 hash.'
} else {
    Add-Check 'candidate.module-hashes-captured' 'FAIL' ('Missing candidate module(s): ' + ($missingCandidateModules -join ', '))
}

$r7ReferenceExists = $r7ReferencePresent -or $r7ManifestPresent
if (-not $r7ReferenceExists) {
    Add-Check 'r7.reference-manifest-verification' 'N/D' 'Optional R7 reference tree is absent from this package.'
} elseif ($r7ManifestVerified) {
    Add-Check 'r7.reference-manifest-verification' 'PASS' 'Every file listed in the R7 SHA-256 manifest matches its recorded digest.'
} else {
    Add-Check 'r7.reference-manifest-verification' 'FAIL' ("R7 source cannot be trusted for exact comparison: " + $r7ManifestError)
}
if (-not $r7ReferenceExists) {
    Add-Check 'r7.reference-catalog-source' 'N/D' 'R7 reference tree is absent; candidate checks continue independently.'
} elseif ($r7CatalogSourceAvailable) {
    Add-Check 'r7.reference-catalog-source' 'PASS' 'Optional R7 catalog reference source is present for exact comparison.'
} else {
    Add-Check 'r7.reference-catalog-source' 'FAIL' 'R7 catalog source is present but not verified or contains no parseable model records.'
}

$catalogModelMatches = [regex]::Matches($catalogText, 'new\s+ModelCatalogEntry\("(?<tag>[^"]+)",\s*"(?<title>[^"]+)",\s*"(?<category>[^"]+)",\s*"(?<slug>[^"]+)"\)')
$catalogModels = @($catalogModelMatches | ForEach-Object { [pscustomobject]@{
    tag=$_.Groups['tag'].Value
    title=$_.Groups['title'].Value
    category=$_.Groups['category'].Value
    slug=$_.Groups['slug'].Value
    libraryUrl=('https://ollama.com/library/' + $_.Groups['slug'].Value)
    licenseUrl=('https://ollama.com/library/' + $_.Groups['slug'].Value)
    licenseReviewStatus='REVIEW_REQUIRED'
    parameterSize=(Get-ParameterSizeFromTag $_.Groups['tag'].Value)
    runtimeSize='N/D'
    runtimeSizeSource='N/D'
    sha256='N/D'
    sha256Source='N/D'
    vramEstimate='N/D'
    vramEstimateSource='N/D'
} })

$sourceTags = @($sourceModels | ForEach-Object { $_.tag })
$catalogTags = @($catalogModels | ForEach-Object { $_.tag })
$catalogCategories = @($catalogModels | ForEach-Object { $_.category })
$sourceUnique = @($sourceTags | Sort-Object -Unique)
$catalogUnique = @($catalogTags | Sort-Object -Unique)
$uniqueCategories = @($catalogCategories | Sort-Object -Unique)
$catalogExact = $false
if ($r7CatalogSourceAvailable -and $catalogTags.Count -eq $sourceTags.Count) {
    $catalogExact = $true
    for ($index = 0; $index -lt $sourceModels.Count; $index++) {
        if ($sourceModels[$index].tag -cne $catalogModels[$index].tag -or
            $sourceModels[$index].title -cne $catalogModels[$index].title) {
            $catalogExact = $false
            break
        }
    }
}

if ($catalogTags.Count -eq 24 -and $catalogUnique.Count -eq 24) {
    Add-Check 'catalog.24-plus-unique-official-tags' 'PASS' 'Packaged catalog has exactly 24 unique model tags.'
} else {
    Add-Check 'catalog.24-plus-unique-official-tags' 'FAIL' "Packaged catalog tags=$($catalogTags.Count), unique=$($catalogUnique.Count); expected exactly 24."
}

$expectedCategories = @('Light', 'Core', 'Reasoning', 'Code', 'Multimodal', 'Embeddings')
$unexpectedCategories = @($uniqueCategories | Where-Object { $expectedCategories -notcontains $_ })
if ($catalogTags.Count -ge 24 -and $catalogUnique.Count -eq $catalogTags.Count -and
    $uniqueCategories.Count -eq 6 -and $unexpectedCategories.Count -eq 0 -and
    @($expectedCategories | Where-Object { $uniqueCategories -notcontains $_ }).Count -eq 0) {
    Add-Check 'catalog.24-unique-tags-six-categories' 'PASS' 'All catalog tags are unique and distributed across the six required categories.'
} else {
    Add-Check 'catalog.24-unique-tags-six-categories' 'FAIL' "Tags=$($catalogTags.Count), unique=$($catalogUnique.Count), categories=$($uniqueCategories.Count): $($uniqueCategories -join ', ')."
}

if (-not $r7ReferenceExists) {
    Add-Check 'catalog.exact-r7-tags-and-titles' 'N/D' 'Exact R7 comparison was skipped because the optional reference tree is absent.'
} elseif ($catalogExact) {
    Add-Check 'catalog.exact-r7-tags-and-titles' 'PASS' 'Catalog tag and display-title pairs match the R7 AI Lab source in order.'
} else {
    Add-Check 'catalog.exact-r7-tags-and-titles' 'FAIL' 'Catalog entries differ from R7 or the present R7 source failed manifest verification.'
}

$officialUrlsValid = ($catalogText -match 'https://ollama\.com/library/\{librarySlug\}') -and
    ($catalogText -match 'LicenseUrl\s*=\s*LibraryUrl') -and
    (@($catalogModels | Where-Object { $_.tag -notlike ($_.slug + ':*') -and $_.tag -ne $_.slug }).Count -eq 0)
if ($officialUrlsValid -and $catalogModels.Count -gt 0) {
    Add-Check 'catalog.official-model-and-license-urls' 'PASS' 'All model and license links resolve from the matching official Ollama library slug.'
} else {
    Add-Check 'catalog.official-model-and-license-urls' 'FAIL' 'Official URL builder or tag-to-library slug mapping is missing or inconsistent.'
}
Add-Check 'catalog.official-url-live-resolution' 'N/D' 'URLs follow the official Ollama library route; this read-only contract script makes no network requests.'

if ($catalogText -match 'REVIEW_REQUIRED' -and
    (Test-AllPatterns $moduleText['worker-queue/ModelDownloadQueueStore.cs'] @('licenseAcknowledged', 'must be acknowledged before enqueueing'))) {
    Add-Check 'catalog.license-review-ack-gate' 'PASS' 'Catalog defaults to REVIEW_REQUIRED and queue enqueue requires explicit acknowledgement.'
} else {
    Add-Check 'catalog.license-review-ack-gate' 'FAIL' 'Review status or explicit queue acknowledgement gate is missing.'
}

# Pass 3: inspect contracts and labels without invoking or compiling the candidate.
$queueText = $moduleText['worker-queue/ModelDownloadQueueStore.cs']
$pullText = $moduleText['worker-pull/OllamaPullService.cs']
$preflightText = $moduleText['worker-preflight/ModelPreflight.cs']
$windowText = $moduleText['worker-window/ModelDownloaderWindow.xaml.cs']
$componentInstallerText = $moduleText['module/ComponentInstaller.cs']
$backupRestoreText = $moduleText['module/BackupRestoreService.cs']
$eventHubText = $moduleText['module/ModelCenterEvent.cs']
$localScannerText = $moduleText['worker-files/LocalModelFileScanner.cs']
$ggufImporterText = $moduleText['worker-import/OllamaGgufImporter.cs']

if ((Test-AllPatterns $queueText @('next\.Add\(item\.Copy\(\)\)', 'ReadOnlyObservableCollection')) -and
    (Test-AllPatterns $windowText @('Items\.FirstOrDefault\([^\r\n]*IsQueuedState', 'FIFO'))) {
    Add-Check 'queue.fifo-tail-and-head-order' 'PASS' 'Enqueue appends to the durable list; the window selects the first queued row.'
} else {
    Add-Check 'queue.fifo-tail-and-head-order' 'FAIL' 'FIFO append or first-queued dispatch contract is missing.'
}

$queueActions = @('Enqueue', 'Pause', 'Resume', 'Retry', 'Cancel')
$queueActionMissing = @($queueActions | Where-Object { $queueText -notmatch "public\s+DownloadQueueItem\s+$($_)\(" })
if ($queueActionMissing.Count -eq 0) {
    Add-Check 'queue.pause-resume-retry-cancel' 'PASS' 'Queue store exposes enqueue, pause, resume, retry, and cancel operations.'
} else {
    Add-Check 'queue.pause-resume-retry-cancel' 'FAIL' ('Missing queue actions: ' + ($queueActionMissing -join ', '))
}

if ((Test-AllPatterns $queueText @('BytesCompleted', 'BytesTotal', 'InstalledSizeBytes', 'Math\.Max\(0, total\)')) -and
    (Test-AllPatterns $windowText @('OverallProgress\.Value', 'FormatBytes', 'total'))) {
    Add-Check 'queue.progress-and-size-fields' 'PASS' 'Byte totals/completed and installed size are tracked; the UI displays percentage and human-readable bytes.'
} else {
    Add-Check 'queue.progress-and-size-fields' 'FAIL' 'Queue progress, size capture, or UI progress display contract is missing.'
}

if ((Test-AllPatterns $pullText @('sawSuccess', 'GetInstalledModelAsync', 'new Uri\(OllamaRoot, "api/tags"\)',
                                  'IsSha256Digest\(digest\)', 'sizeBytes <= 0', 'HashVerified:\s*true')) -and
    (Test-AllPatterns $queueText @('result\.HashVerified', 'Completion requires a PullResult with a verified digest', 'NormalizeSha256'))) {
    Add-Check 'ollama.digest-verification-gate' 'PASS' 'Completion requires Ollama pull success, installed /api/tags SHA-256 digest and positive size, and the queue HashVerified gate; pull-layer digest events are optional and no external checksum is implied.'
} else {
    Add-Check 'ollama.digest-verification-gate' 'FAIL' 'Ollama success, valid installed /api/tags digest and positive size, or the queue HashVerified gate is missing.'
}

if (Test-AllPatterns $preflightText @('ToolKind\.Python', 'ToolKind\.Ollama', 'ToolKind\.Git', 'FindToolPath')) {
    Add-Check 'preflight.python-ollama-git' 'PASS' 'Read-only preflight has discovery paths for Python, Ollama, and Git.'
} else {
    Add-Check 'preflight.python-ollama-git' 'FAIL' 'One or more requested developer tools lack a preflight discovery path.'
}

if (Test-AllPatterns $preflightText @('Environment\.ProcessorCount', 'ProcessorCount')) {
    Add-Check 'preflight.cpu' 'PASS' 'Read-only preflight records the available logical processor count.'
} else {
    Add-Check 'preflight.cpu' 'N/D' 'Processor-count telemetry is not exposed by the packaged preflight source.'
}

if ((Test-AllPatterns $moduleText['NOX.Block03.ModelCenter.csproj'] @('Microsoft\.Web\.WebView2')) -and
    (Test-AllPatterns $windowText @('CoreWebView2Environment', 'EnsureCoreWebView2Async'))) {
    Add-Check 'preflight.webview2' 'PASS' 'Packaged candidate references WebView2 and initializes its runtime.'
} else {
    Add-Check 'preflight.webview2' 'FAIL' 'Packaged WebView2 package or runtime initialization evidence is missing.'
}

if (Test-AllPatterns $preflightText @('VramTotalBytes', 'VramFreeBytes', 'nvidia-smi', 'FreeDiskBytes', 'DriveInfo')) {
    Add-Check 'preflight.vram-and-disk' 'PASS' 'Source includes NVIDIA VRAM and Ollama model-storage free-disk inventory.'
} else {
    Add-Check 'preflight.vram-and-disk' 'FAIL' 'VRAM or model-storage disk inventory is missing.'
}

if ((Test-AllPatterns $localScannerText @('Directory\.EnumerateFiles', 'DISCOVERED_NOT_MOVED', 'SHA256\.HashDataAsync')) -and
    $localScannerText -notmatch 'Process\.Start|ProcessStartInfo') {
    Add-Check 'local-files.read-only-discovery' 'PASS' 'Packaged scanner enumerates candidates, hashes them, and does not launch discovered files.'
} else {
    Add-Check 'local-files.read-only-discovery' 'FAIL' 'Packaged read-only local file discovery/hash/no-execute contract is missing.'
}

if ($localScannerText -match 'SHA256\.HashDataAsync' -and $localScannerText -notmatch 'Process\.Start|ProcessStartInfo') {
    Add-Check 'local-files.sha256-no-execute' 'PASS' 'Local scanner calculates SHA-256 and contains no process-launch path.'
} else {
    Add-Check 'local-files.sha256-no-execute' 'FAIL' 'Local scanner hash or no-execution guarantee is missing.'
}

if ($preflightText -match 'TotalVisibleMemorySize|GlobalMemoryStatusEx|MemoryLoad|PhysicalMemory') {
    Add-Check 'preflight.ram' 'PASS' 'A RAM telemetry source is present in the preflight module.'
} else {
    Add-Check 'preflight.ram' 'N/D' 'Current preflight does not expose physical RAM telemetry.'
}
if (Test-AllPatterns $preflightText @('CaptureNetworkAsync', 'ProbeTcpAsync', 'NetworkEndpointSnapshot', 'NetworkTimeout')) {
    Add-Check 'preflight.network' 'PASS' 'Preflight probes named network endpoints over TCP only; HTTPS/content and throughput are not verified.'
} else {
    Add-Check 'preflight.network' 'N/D' 'No generic endpoint probe was found; network connectivity/throughput remains undetermined.'
}

$xamlText = $moduleText['worker-window/ModelDownloaderWindow.xaml']
$xamlHandlerMatches = [regex]::Matches($xamlText, '\b(?:Click|Checked|Unchecked|SelectionChanged|TextChanged)\s*=\s*"(?<handler>[A-Za-z_][A-Za-z0-9_]*)"')
$xamlHandlerNames = @($xamlHandlerMatches | ForEach-Object { $_.Groups['handler'].Value } | Sort-Object -Unique)
$missingXamlHandlers = @($xamlHandlerNames | Where-Object {
    $handlerPattern = '(?m)\b(?:async\s+)?(?:void|Task)\s+' + [regex]::Escape($_) + '\s*\('
    $windowText -notmatch $handlerPattern
})
if ($xamlHandlerMatches.Count -gt 0 -and $missingXamlHandlers.Count -eq 0) {
    Add-Check 'ui.xaml-event-handler-wiring' 'PASS' "All $($xamlHandlerMatches.Count) declared XAML event references resolve to code-behind handler methods."
} else {
    Add-Check 'ui.xaml-event-handler-wiring' 'FAIL' ('XAML event references are absent or unresolved: ' + ($missingXamlHandlers -join ', '))
}

if (Test-AllPatterns $backupRestoreText @('CreateBackupAsync', 'IncrementalHash\.CreateHash\(HashAlgorithmName\.SHA256\)', 'BackupManifest')) {
    Add-Check 'components.backup' 'PASS' 'Backup service creates a manifest with per-file SHA-256 evidence.'
} else {
    Add-Check 'components.backup' 'FAIL' 'Verified backup implementation or per-file SHA-256 manifest is missing.'
}
if (Test-AllPatterns $backupRestoreText @('RestoreAsync', 'confirm\(', 'HashDataAsync', 'RESTORE_FAILED')) {
    Add-Check 'components.restore' 'PASS' 'Restore requires a confirmation callback and verifies archive contents against hashes.'
} else {
    Add-Check 'components.restore' 'FAIL' 'Restore confirmation or hash verification is missing.'
}
if (Test-AllPatterns $backupRestoreText @('catch\s*\(OperationCanceledException\)', 'RollbackChanges\(\)',
                                         'RestoreResult\("CANCELLED"', 'RestoreCancelled',
                                         'RESTORE_CANCELLED_ROLLBACK_INCOMPLETE')) {
    Add-Check 'components.restore-cancel-rollback-status' 'PASS' 'Restore cancellation has a distinct CANCELLED result/event and reports whether rollback completed or recovery data remains.'
} else {
    Add-Check 'components.restore-cancel-rollback-status' 'FAIL' 'Restore cancellation is not distinguished from failure or does not report rollback/recovery status.'
}
if (Test-AllPatterns $eventHubText @('GetInvocationList\(\)', 'foreach\s*\(EventHandler<ModelCenterEvent> subscriber',
                                   'catch\s*\(Exception\)')) {
    Add-Check 'events.subscriber-exception-isolation' 'PASS' 'Each event subscriber is isolated so its exception cannot abort the publishing operation or suppress later subscribers.'
} else {
    Add-Check 'events.subscriber-exception-isolation' 'FAIL' 'Event subscriber exceptions can still propagate into operations or prevent later subscribers from receiving events.'
}

$packageMatches = [regex]::Matches($componentInstallerText, '\["(?<key>[^"]+)"\]\s*=\s*new\(\s*"(?<id>[^"]+)"')
$packageKeys = @($packageMatches | ForEach-Object { $_.Groups['key'].Value })
$packageIds = @($packageMatches | ForEach-Object { $_.Groups['id'].Value })
$expectedWingetIds = @('Python.Python.3.12', 'Ollama.Ollama', 'Git.Git', 'Microsoft.EdgeWebView2Runtime',
                       'Microsoft.VCRedist.2015+.x64', 'Microsoft.DotNet.DesktopRuntime.8')
$wingetAllowlistValid = $packageIds.Count -eq 6 -and
    @($packageKeys | Sort-Object -Unique).Count -eq $packageKeys.Count -and
    @($packageIds | Sort-Object -Unique).Count -eq $packageIds.Count -and
    (@(Compare-Object -ReferenceObject $packageKeys -DifferenceObject $packageIds -CaseSensitive).Count -eq 0) -and
    (@(Compare-Object -ReferenceObject $expectedWingetIds -DifferenceObject $packageIds -CaseSensitive).Count -eq 0) -and
    (Test-AllPatterns $componentInstallerText @('ApprovedPackages', 'TryGetApprovedPackage', 'Packages\.TryGetValue\(packageId',
                                                'ProcessStartInfo', 'UseShellExecute\s*=\s*false',
                                                'ComponentOperation\.Install\s*=>\s*"install"',
                                                'ComponentOperation\.Update\s*=>\s*"upgrade"',
                                                'ComponentOperation\.Remove\s*=>\s*"uninstall"',
                                                'ArgumentList\.Add\("--exact"\)', 'ArgumentList\.Add\("--source"\)'))
if ($wingetAllowlistValid) {
    Add-Check 'components.winget-allowlist' 'PASS' "WinGet IDs are unique and checked against the explicit allowlist ($($packageIds.Count) packages)."
} else {
    Add-Check 'components.winget-allowlist' 'FAIL' 'WinGet package IDs are not statically constrained by a consistent explicit allowlist.'
}

$componentRunMethod = [regex]::Match($windowText, '(?s)private async void ComponentRunButton_Click.*?\n    private void ').Value
$uiConfirmIndex = $componentRunMethod.IndexOf('MessageBox.Show', [StringComparison]::Ordinal)
$uiRunIndex = $componentRunMethod.IndexOf('_componentInstaller.RunAsync', [StringComparison]::Ordinal)
$manualInstallRemoveConfirmation = $uiConfirmIndex -ge 0 -and $uiRunIndex -gt $uiConfirmIndex -and
    (Test-AllPatterns $componentRunMethod @('MessageBoxButton\.YesNo', 'MessageBoxResult\.Yes', 'actionConfirmed:\s*true', 'ComponentOperation\.Remove')) -and
    (Test-AllPatterns $componentInstallerText @('if\s*\(!actionConfirmed\)', 'packageAgreementConfirmed', 'ComponentOperation\.Remove\s*=>\s*"uninstall"'))
if ($manualInstallRemoveConfirmation) {
    Add-Check 'components.manual-install-remove-confirmation' 'PASS' 'UI requires a Yes/No action confirmation and the installer rechecks actionConfirmed for install/update/remove.'
} else {
    Add-Check 'components.manual-install-remove-confirmation' 'FAIL' 'Manual install/remove confirmation is missing in the UI or installer gate.'
}

$allCandidateText = ($moduleText.Values -join "`n")
if ($allCandidateText -notmatch '(?i)cmd\.exe') {
    Add-Check 'components.no-cmd-exe-candidate-source-tree' 'PASS' 'Packaged candidate source tree contains no cmd.exe wrapper.'
} else {
    $cmdFiles = @($moduleText.Keys | Where-Object { $moduleText[$_] -match '(?i)cmd\.exe' })
    Add-Check 'components.no-cmd-exe-candidate-source-tree' 'FAIL' ('cmd.exe remains in packaged source: ' + ($cmdFiles -join ', '))
}

if ((Test-AllPatterns $pullText @('http://127\.0\.0\.1:11434/', 'IsLoopback', 'EnsureLoopback')) -and
    (Test-AllPatterns $preflightText @('ResolveLocalOllamaTagsUri', 'IsLoopback', 'api/tags')) -and
    (Test-AllPatterns $ggufImporterText @('http://127\.0\.0\.1:11434', 'OLLAMA_HOST', 'api/tags', 'IsLoopback'))) {
    Add-Check 'ollama.local-api-only' 'PASS' 'Pull, preflight, and GGUF import bind Ollama API calls to loopback only.'
} else {
    Add-Check 'ollama.local-api-only' 'FAIL' 'A worker Ollama API path is missing the required loopback restriction.'
}

foreach ($id in @('queue.fifo-runtime', 'queue.pause-runtime', 'queue.resume-runtime', 'queue.retry-runtime',
                  'queue.cancel-runtime', 'ollama.pull-runtime', 'hardware.runtime', 'backup.restore-runtime')) {
    Add-Check $id 'N/D' 'Runtime behavior is not executed by this source-only contract script.'
}

# Pass 4: fail closed on metadata omissions and cross-module API/state mismatches.
if ((Test-AllPatterns $catalogText @('ParameterSize\s*=\s*ParseParameterSize\(tag\)', 'RuntimeSize\s*=\s*runtimeSize',
                                     'Sha256\s*=\s*sha256', 'VramEstimate\s*=\s*vramEstimate',
                                     'NotDetermined\s*=\s*"N/D"')) -and
    ($catalogModels | Where-Object { $_.licenseReviewStatus -ne 'REVIEW_REQUIRED' }).Count -eq 0) {
    Add-Check 'catalog.fail-closed-unknown-metadata' 'PASS' 'Unknown size, digest, and VRAM remain N/D; no catalog row is license-approved by default.'
} else {
    Add-Check 'catalog.fail-closed-unknown-metadata' 'FAIL' 'Catalog does not keep unknown metadata and license review fail-closed.'
}

$entryCalls = [regex]::Matches($catalogText, 'new\s+ModelCatalogEntry\((?<args>[^)]*)\)')
$noPerModelMetadata = $entryCalls.Count -eq $catalogTags.Count
foreach ($entryCall in $entryCalls) {
    # Four string arguments only: tag, title, category, library slug. All size/digest values stay at N/D defaults.
    if ([regex]::Matches($entryCall.Groups['args'].Value, '"[^"\\]*(?:\\.[^"\\]*)*"').Count -ne 4) {
        $noPerModelMetadata = $false
        break
    }
}
$fakeDigestLiteral = $catalogText -match '"[0-9a-fA-F]{64}"'
$fakeRuntimeSizeLiteral = $catalogText -match '"[0-9]+(?:\.[0-9]+)?\s*(?:MB|GB|MiB|GiB)"'
if ($noPerModelMetadata -and -not $fakeDigestLiteral -and -not $fakeRuntimeSizeLiteral -and
    (Test-AllPatterns $catalogText @('runtimeSize\s*=\s*NotDetermined', 'sha256\s*=\s*NotDetermined',
                                     'runtimeSize == NotDetermined && runtimeSizeSource != NotDetermined',
                                     'sha256 == NotDetermined && sha256Source != NotDetermined'))) {
    Add-Check 'catalog.no-fabricated-size-or-sha256' 'PASS' 'Every model uses N/D size/digest defaults; any later value must provide a source and valid 64-hex SHA-256.'
} else {
    Add-Check 'catalog.no-fabricated-size-or-sha256' 'FAIL' 'A literal model size/digest lacks source-backed metadata or a guarded N/D default.'
}

$requiredCatalogAliases = @('Title', 'ModelPageUrl', 'LicenseStatus', 'SizeSourceStatus', 'EstimatedMinVramGiB')
$catalogAliasMissing = @($requiredCatalogAliases | Where-Object { $catalogText -notmatch "public\s+[^\r\n]+\s+$($_)\s*=>" })
if ($catalogAliasMissing.Count -eq 0) {
    Add-Check 'integration.catalog-api-compatibility' 'PASS' 'Catalog exposes the read-only aliases consumed by the downloader window and queue.'
} else {
    Add-Check 'integration.catalog-api-compatibility' 'FAIL' ('Missing catalog API members: ' + ($catalogAliasMissing -join ', '))
}

$stateMatch = [regex]::Match($queueText, 'public\s+enum\s+DownloadQueueState\s*\{(?<body>[^}]+)\}')
$stateNames = @()
if ($stateMatch.Success) {
    $stateNames = @([regex]::Matches($stateMatch.Groups['body'].Value, '(?m)^\s*([A-Za-z_][A-Za-z0-9_]*)\s*,?\s*$') | ForEach-Object { $_.Groups[1].Value })
}
$windowStateCalls = @([regex]::Matches($windowText, 'SetState\([^\r\n]*?"(?<state>[A-Za-z_]+)"') | ForEach-Object { $_.Groups['state'].Value })
$unknownStates = @($windowStateCalls | Where-Object { $stateNames -notcontains $_ })
if ($unknownStates.Count -eq 0 -and $stateNames.Count -gt 0) {
    Add-Check 'integration.queue-state-compatibility' 'PASS' 'All literal UI queue states exist in DownloadQueueState.'
} else {
    Add-Check 'integration.queue-state-compatibility' 'FAIL' ('UI states absent from DownloadQueueState: ' + ($unknownStates -join ', '))
}

if ((Test-AllPatterns $windowText @('_pullService\s*=\s*new\s*\(', '_pullService\.PullAsync\(')) -and
    $pullText -match 'public\s+async\s+Task<PullResult>\s+PullAsync\(') {
    Add-Check 'integration.pull-service-call-shape' 'PASS' 'Window creates the instance pull service and invokes its instance PullAsync API.'
} else {
    Add-Check 'integration.pull-service-call-shape' 'FAIL' 'The window-to-pull-service instance call or its matching PullAsync method is missing.'
}

if ($moduleHashes.Values -contains 'N/D') {
    Add-Check 'evidence.candidate-module-hashes' 'FAIL' 'At least one required packaged candidate module is missing; its exact hash is N/D.'
} else {
    Add-Check 'evidence.candidate-module-hashes' 'PASS' 'Exact SHA-256 hashes are captured for every required packaged candidate module.'
}
if ($packagedSourceSha256.Count -gt 0 -and -not ($packagedSourceSha256.Values -contains 'N/D') -and
    $missingPackagedScripts.Count -eq 0) {
    Add-Check 'evidence.packaged-source-sha256-map' 'PASS' 'Exact SHA-256 values are present for all required packaged source modules and scripts.'
} else {
    Add-Check 'evidence.packaged-source-sha256-map' 'FAIL' ('The packaged source SHA-256 map is incomplete; missing script(s): ' + ($missingPackagedScripts -join ', '))
}
if (-not $r7ReferenceExists) {
    Add-Check 'evidence.optional-r7-reference-hashes' 'N/D' 'R7 reference hashes are N/D because the final package may omit the historical source tree.'
} elseif ($r7CatalogSourceAvailable) {
    Add-Check 'evidence.optional-r7-reference-hashes' 'PASS' 'R7 catalog reference is present and its source SHA-256 was captured.'
} else {
    Add-Check 'evidence.optional-r7-reference-hashes' 'FAIL' 'R7 reference files exist but cannot be verified against the supplied manifest.'
}

$requirementSpecs = @(
    [pscustomobject]@{ id='catalog'; title='Каталог моделей, официальные страницы и fail-closed review лицензии'; files=@('worker-catalog/ModelCatalog.cs','worker-queue/ModelDownloadQueueStore.cs'); checkIds=@('catalog.24-plus-unique-official-tags','catalog.24-unique-tags-six-categories','catalog.official-model-and-license-urls','catalog.license-review-ack-gate','catalog.fail-closed-unknown-metadata','catalog.no-fabricated-size-or-sha256'); improvement='Закрыть source-contract замечания и отдельно проверить доступность официальных страниц и условия лицензий.' }
    [pscustomobject]@{ id='downloads'; title='FIFO, пауза/возобновление/повтор/отмена, прогресс и размер'; files=@('worker-queue/ModelDownloadQueueStore.cs','worker-pull/OllamaPullService.cs','worker-window/ModelDownloaderWindow.xaml','worker-window/ModelDownloaderWindow.xaml.cs'); checkIds=@('queue.fifo-tail-and-head-order','queue.pause-resume-retry-cancel','queue.progress-and-size-fields'); improvement='Устранить source-contract ошибки; затем зафиксировать Windows runtime поведение очереди.' }
    [pscustomobject]@{ id='ollama'; title='Локальный Ollama API и digest verification'; files=@('worker-pull/OllamaPullService.cs','worker-preflight/ModelPreflight.cs','worker-import/OllamaGgufImporter.cs','worker-queue/ModelDownloadQueueStore.cs'); checkIds=@('ollama.digest-verification-gate','ollama.local-api-only'); improvement='Устранить source-contract ошибки и выполнить pull/readback на Windows с сохранёнными evidence.' }
    [pscustomobject]@{ id='pc-detection'; title='Обнаружение Python, Ollama, Git и WebView2'; files=@('worker-preflight/ModelPreflight.cs','worker-window/ModelDownloaderWindow.xaml.cs','NOX.Block03.ModelCenter.csproj'); checkIds=@('preflight.python-ollama-git','preflight.webview2'); improvement='Устранить недостающие статические контракты и подтвердить обнаружение компонентов на Windows.' }
    [pscustomobject]@{ id='hardware'; title='CPU, RAM, VRAM, диск и сетевые endpoints'; files=@('worker-preflight/ModelPreflight.cs'); checkIds=@('preflight.cpu','preflight.ram','preflight.vram-and-disk','preflight.network'); improvement='Разделить N/D hardware fields от измеренных значений; проверить TCP endpoints, GPU/VRAM и дисковый снимок на Windows.' }
    [pscustomobject]@{ id='ui-source-wiring'; title='XAML events связаны с WPF code-behind'; files=@('worker-window/ModelDownloaderWindow.xaml','worker-window/ModelDownloaderWindow.xaml.cs'); checkIds=@('ui.xaml-event-handler-wiring'); improvement='Закрыть отсутствующие XAML обработчики, затем подтвердить запуск/навигацию вкладок на Windows.' }
    [pscustomobject]@{ id='local-files'; title='Локальное сканирование и SHA-256 без запуска файлов'; files=@('worker-files/LocalModelFileScanner.cs'); checkIds=@('local-files.read-only-discovery','local-files.sha256-no-execute'); improvement='Устранить source-contract ошибки и подтвердить безопасный просмотр локальных файлов на Windows.' }
    [pscustomobject]@{ id='backup-restore'; title='Резервное копирование и проверенное восстановление с корректной отменой'; files=@('module/BackupRestoreService.cs','module/ModelCenterEvent.cs'); checkIds=@('components.backup','components.restore','components.restore-cancel-rollback-status'); improvement='Устранить source-contract ошибки и проверить backup/restore/cancel/rollback на тестовом профиле Windows.' }
    [pscustomobject]@{ id='event-hub'; title='Изоляция подписчиков локального event hub'; files=@('module/ModelCenterEvent.cs','module/ComponentInstaller.cs','module/BackupRestoreService.cs'); checkIds=@('events.subscriber-exception-isolation'); improvement='Проверить на Windows, что бросающий subscriber не меняет исход queue/install/backup/restore операций.' }
    [pscustomobject]@{ id='component-management'; title='Allowlist и подтверждение install/update/remove'; files=@('module/ComponentInstaller.cs','worker-window/ModelDownloaderWindow.xaml.cs'); checkIds=@('components.winget-allowlist','components.manual-install-remove-confirmation'); improvement='Устранить source-contract ошибки и подтвердить все операции вручную на Windows.' }
)
$requirementAlignment = @($requirementSpecs | ForEach-Object {
    $spec = $_
    $relatedChecks = @($checks | Where-Object { $spec.checkIds -contains $_.id })
    $missingFiles = @($spec.files | Where-Object { -not $moduleHashes.Contains($_) -or $moduleHashes[$_] -eq 'N/D' })
    $failedChecks = @($relatedChecks | Where-Object { $_.status -eq 'FAIL' })
    $undeterminedChecks = @($relatedChecks | Where-Object { $_.status -eq 'N/D' })
    $sourceStatus = if ($relatedChecks.Count -eq $spec.checkIds.Count -and $failedChecks.Count -eq 0 -and
        $undeterminedChecks.Count -eq 0 -and $missingFiles.Count -eq 0) { 'PASS' } else { 'N/D' }
    $errors = @($failedChecks | ForEach-Object { $_.evidence })
    if ($missingFiles.Count -gt 0) { $errors += ('Missing packaged source file(s): ' + ($missingFiles -join ', ')) }
    if ($undeterminedChecks.Count -gt 0) { $errors += ('Not determined: ' + (($undeterminedChecks | ForEach-Object { $_.id }) -join ', ')) }
    $errors += 'Windows runtime evidence has not been recorded; this source contract does not establish product acceptance.'
    [pscustomobject][ordered]@{
        id = $spec.id
        requirement = $spec.title
        status = 'N/D'
        sourceStatus = $sourceStatus
        windowsEvidenceStatus = 'N/D'
        sourceFiles = @($spec.files)
        errors = @($errors)
        improvements = if ($sourceStatus -eq 'PASS') { @('Record evidence-backed Windows acceptance for this requirement.') } else { @($spec.improvement) }
    }
})

$webV1_2Boundary = [pscustomobject][ordered]@{
    boundaryStatus = 'BOUNDARY_ONLY'
    sourceRecordId = 'G02-R7'
    sourceReportedLocalTests = '21/21 (reported by G02-R7; not run by this Block03 contract report)'
    liveOllamaStatus = 'N/D'
    independentAcceptanceStatus = 'N/D'
    acceptedWebProgress = 'N/D'
    webReleaseStatus = 'RELEASE_BLOCKED'
    webProgressCreditToBlock03 = 'NONE'
    exeProgressCreditToBlock03 = 'NONE'
    block03WindowsAcceptance = 'N/D until Windows evidence is recorded'
    errors = @('G02-R7 reports no live Ollama evidence and no independent acceptance; WEB accepted progress remains N/D and release remains blocked.')
    improvements = @('Close live Ollama and independent WEB acceptance only in the WEB V1.2 lane; do not transfer WEB or EXE progress into Block03.')
}

$staticFailures = @($checks | Where-Object { $_.status -eq 'FAIL' }).Count
$nonDetermined = @($checks | Where-Object { $_.status -eq 'N/D' }).Count
$overallStatus = if ($staticFailures -gt 0) { 'FAIL' } elseif ($nonDetermined -gt 0) { 'N/D' } else { 'PASS' }

$result = [pscustomobject][ordered]@{
    schema = 'NOX.BLOCK03.CONTRACTS.1'
    createdUtc = [DateTimeOffset]::UtcNow.ToString('o')
    status = $overallStatus
    releaseStatus = 'RELEASE_BLOCKED'
    independentAcceptanceStatus = 'N/D'
    progressAttribution = 'Block03 source-contract checks only; no WEB V1.2 or EXE progress is transferred.'
    blockRoot = [IO.Path]::GetFullPath($BlockRoot)
    packagedSourceRoot = [IO.Path]::GetFullPath($packagedSourceRoot)
    modelCatalogModuleSha256 = $catalogSha256
    sameModuleSha256 = $catalogSha256
    testHarnessSha256 = (Get-FileHash -LiteralPath $MyInvocation.MyCommand.Path -Algorithm SHA256).Hash.ToLowerInvariant()
    executionScope = 'STATIC_SOURCE_CONTRACTS_ONLY; NO_BUILD, NO_RUNTIME_EXECUTION, NO_INSTALL, NO_DOWNLOAD, NO_USER_EXE'
    sourceModelCount = if ($r7CatalogSourceAvailable) { $sourceTags.Count } else { 'N/D' }
    r7ReferenceAvailable = $r7CatalogSourceAvailable
    catalogModelCount = $catalogTags.Count
    catalogUniqueTagCount = $catalogUnique.Count
    catalogCategories = $uniqueCategories
    wingetAllowlist = $packageIds
    sourceSha256 = $sourceHashes
    moduleSha256 = $moduleHashes
    packagedSourceSha256 = $packagedSourceSha256
    packagedScriptSha256 = $packagedScriptSha256
    requirementAlignment = $requirementAlignment
    webV1_2Boundary = $webV1_2Boundary
    catalog = $catalogModels
    checks = @($checks)
}

# Pass 5: final stable JSON shape; runtime acceptance remains N/D until a Windows receipt exists.
$json = $result | ConvertTo-Json -Depth 8
$resolvedOutput = [IO.Path]::GetFullPath($OutputPath)
$outputDirectory = Split-Path -Parent $resolvedOutput
if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}
[IO.File]::WriteAllText($resolvedOutput, $json, [System.Text.UTF8Encoding]::new($false))
Write-Output $json
