# Block 03 · Windows acceptance contract

This is a Windows test contract for the standalone Model Center window, not a test result. It has not been built or run on Windows here.

## Preconditions

- Windows 10 or 11 x64 and .NET 8 Windows Desktop SDK/runtime.
- Assemble the catalog, queue store, Ollama pull service, PC preflight, component installer, local-file scanner, backup service, event contract, and this WPF window into one WPF project.
- For model-download cases, run a local Ollama service. Do not use a model whose license terms the tester has not reviewed.
- Use a disposable model and a separate restore destination for destructive scenarios.

## Русские вкладки и контрольные элементы

| Вкладка | Ключевые элементы |
| --- | --- |
| **Модели** | `SearchBox`, `CategoryFilter`, `CatalogGrid`, `OpenLicenseButton`, `LicenseCheck`, `InstallButton`, `QueueGrid`, `PauseButton`, `ResumeButton`, `RetryButton`, `CancelButton`; read-only снимок ПК показан через `PreflightButton` и `PreflightSummary`. |
| **Windows компоненты** | `ComponentGrid`, `ComponentOperationCombo`, `ComponentProductButton`, `ComponentTermsButton`, `PackageAgreementCheck`, `ComponentRunButton`, `ComponentCancelButton`, `ComponentStatusText`. |
| **Локальные файлы** | `ScanFolderText`, `ChooseScanFolderButton`, `IncludeSubdirectoriesCheck`, `ScanFilesButton`, `CancelFileScanButton`, `LocalFilesGrid`; лицензия/совместимость/права — `LocalLicenseCheck`, `LocalCompatibilityCheck`, `LocalRightsCheck`; copy-only staging — `StageFolderText`, `StageLocalFileButton`; импорт GGUF — `LocalImportTagText`, `ImportGgufButton`, `CancelLocalActionButton`. |
| **Backup / Restore** | `BackupNoxScopeCheck`, `BackupOllamaScopeCheck`, `BackupArchiveText`, `CreateBackupButton`, `CancelBackupButton`, `RestoreArchiveText`, `RestoreDestinationText`, `RestoreBackupButton`, `BackupStatusText`. |
| **События** | `EventSummaryText` и `EventGrid`. |

`OverallProgress`, `ProgressText` и `StatusLine` выведены в общий нижний статусный блок и остаются видимыми при переключении вкладок.

Статическая сверка исходников подтверждает: XAML event names разрешаются в обработчики code-behind, а используемые им control names объявлены в XAML. Это проверка связей исходников; она не подтверждает сборку или запуск Windows.

## Launch and catalog

1. Build the assembled WPF project in Release for net8.0-windows.
2. Show ModelCenterLauncher.CreateWindow() from a WPF owner window.
3. Confirm the five tabs are reachable: Models, Windows Components, Local Files, Backup / Restore, and Events.
4. Confirm the catalog has at least 24 unique tags and shows license status, official model page, size-source status, VRAM estimate, catalog SHA-256 status, and installed-model detection.
5. Refresh the read-only PC snapshot. Confirm CPU, RAM, GPU/VRAM, disk, Ollama, Python, Git, WinGet path, WebView2 runtime, network endpoints, and the complete installed component/library lists appear without package installation or elevation.

## Acceptance cases

| Case | Action | Pass condition |
| --- | --- | --- |
| Model license gate | Select a model. Before opening its HTTPS catalog/license page, try the acknowledgement and queue controls. | Acknowledgement and queue controls remain disabled. |
| Model acknowledgement | Open the page, review its license, check the acknowledgement, and enqueue. | Queue item records acknowledgement; pull starts only after enqueue. |
| FIFO and progress | Enqueue two distinct models and observe Ollama progress while switching between tabs. | One PullAsync runs at a time; the earlier queue item runs first; global `OverallProgress` / `ProgressText` remain visible on every tab; known byte totals drive progress; unknown totals remain indeterminate. |
| Pause/resume/cancel/retry | Pause an active pull and immediately resume while its cancellation is settling; also cancel an active/queued item and retry a failed item. | Action buttons reflect each persisted state immediately; only one pull runs at a time; no late progress update reverses PAUSED/CANCELLED; retry is available only for FAILED. |
| Digest gate | Complete with verified and unverified PullResult values. | Only verified digest results become COMPLETED; unverified pulls remain FAILED with an explicit message. |
| Component agreement | Select Install/Update, leave agreement unchecked, then open terms and acknowledge; confirm each action. | Install/Update stay blocked until link-open, checkbox, and action confirmation. Remove requires action confirmation. After confirmation, the selected package may show its own UAC/elevation prompt; that prompt is permitted. |
| Component cancellation | Start an allowlisted WinGet operation, then cancel. | Process tree is stopped and failure/cancellation reaches the event stream. |
| No command window, shell wrapper, or hidden `runas` | Run an approved component action after completing its required confirmation, then inspect the launched executable/process tree. | ModelCenter starts WinGet directly with no `cmd.exe`/PowerShell wrapper, console window, or explicit `runas`/hidden elevation. The selected package installer may display UAC when required; that prompt is permitted and is not a failure. Legacy R6/R7 source shells are not part of the assembled ModelCenter runtime. |
| Theme and initial gates | Open each tab before selecting work; inspect disabled actions and the dark/bronze theme. | Graphite/amber styling is consistent; install, queue control, file-review/staging/import, backup/restore, and cancel actions start disabled until their prerequisites are met. Confirmation dialogs remain required before component operations, GGUF import, staging copy, backup creation, and restore. |
| Local scan boundary | Select a test folder; scan with recursion off and on. | Only selected-folder candidates appear; scan is read-only, bounded, and reports format/hash without executing files. |
| Local file review gate | Select a supported candidate, open a user-provided HTTPS license reference, check license, compatibility, and rights boxes, then record review. | Candidate becomes VERIFIED_FORMAT only after all confirmations; user attestation is not described as independent legal verification. |
| GGUF review binding | Select a scanner-verified GGUF; open its HTTPS license reference, enter the exact reviewed license text, check license, format/compatibility, and rights, then register review. Change the selected file or any review input and try import. | Import remains gated until the current review is bound to that candidate's scanned path and SHA-256; the service re-hashes the source before use. |
| Ollama GGUF import | Enter an unused Ollama tag, confirm the separate import prompt, and import a reviewed GGUF. Try a tag that already exists. | Existing tags are not overwritten; the UI shows state, tag readback, digest, installed size, source hash, and license-text hash. Import never executes model files. |
| Local file staging | Choose a separate destination and confirm copy. Try a source-contained destination and an existing filename. | Scanner blocks same-root destination and overwrite; source remains unchanged; event is `STAGED_COPY_ONLY`; staged file is not imported into Ollama or executed. |
| Queue quarantine warning | Supply a corrupt saved `queue.json`, then launch Model Center. | The preserved quarantine path and recovery warning appear in StatusLine and Events; queue loading continues with a new empty queue. |
| Scan terminal events | Complete and cancel read-only scans. | Events use `FileScanCompleted` and `FileScanCancelled`, separate from `FileScanStarted`. |
| Backup scopes | Select NOX and Ollama scopes and create backup. | One archive is created per existing scope, each with a SHA-256 manifest; secret files are skipped. Missing scopes are reported as skipped. |
| Backup cancel | Start a backup to a new temporary destination and use Cancel while it is running. | Operation reports cancellation; incomplete temporary archives are not presented as completed backups. |
| Restore | Select one archive, select its matching destination, and approve both confirmation prompts. | All manifest paths/sizes/hashes are validated before writes; matching prior files are recoverable; unrelated files remain. Corrupt archive does not partially restore. |
| Restore cancel/recovery | Accept the initial restore prompt, decline the second prompt, then retry with both confirmations. Also try a corrupted copy. | Declining returns `CANCELLED` before writes. Retrying with a valid archive restores only verified files; corrupt input reports `FAILED`, preserves pre-existing data where rollback is possible, and retains recovery data. |
| Restore cancellation/error | Cancel during restore validation or file replacement; then use a corrupt archive. | UI distinguishes cancellation from failure; cancellation during writes reports rollback behavior; corruption reports failure and preserves the original destination files. |
| Event hub | Subscribe through ModelDownloaderWindow.EventHub.EventRaised and run a queue/component/file/backup operation. | Host receives secret-free events; a throwing subscriber does not stop local queue or installer work. |
| Close during pull | Close while downloading and reopen. | Active pull is asked to pause; durable queue recovers to PAUSED and is never falsely marked COMPLETED. |
| Layout | Resize through minimum/maximized sizes and test Windows scaling at 100%, 150%, and 200%. | All five tabs, important actions, global progress, and status remain reachable without clipped controls. |

## Evidence for a Windows PASS

- Build output and source revision/hash.
- Windows version, display scale, .NET Desktop runtime, and Ollama version.
- Queue readback for acknowledgement, progress, pause/resume, retry, cancel, and digest outcomes.
- Evidence from component consent/cancel, local-file scan/review/staging, and backup/restore verification.
- Screenshots of each tab plus progress and terminal states.

Until a Windows machine produces this evidence, status remains **SOURCE CANDIDATE / WINDOWS ACCEPTANCE PENDING**.
