using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Data;
using Microsoft.Win32;
using NoxP01.WorkerCatalog;

namespace NOX.P01.ModelCenter;

/// <summary>
/// Standalone native Model Center. Installs use the explicit WinGet allowlist;
/// model pulls use the local Ollama API; file discovery is read-only until
/// separate review and copy consent; restore is hash-checked and confirmed.
/// </summary>
public partial class ModelDownloaderWindow : Window, INotifyPropertyChanged
{
    private readonly DownloadQueueStore _queueStore;
    private readonly OllamaPullService _pullService = new();
    private readonly OllamaGgufImporter _ggufImporter;
    private readonly ComponentInstaller _componentInstaller;
    private readonly BackupRestoreService _backupRestoreService;
    private readonly LocalModelFileScanner _fileScanner = new();
    private readonly IModelCenterEventSink _eventSink;
    private readonly NotifyCollectionChangedEventHandler _queueItemsChanged;
    private readonly ICollectionView _modelView;
    private readonly SemaphoreSlim _queuePumpGate = new(1, 1);
    private readonly ObservableCollection<CatalogRow> _models = new();
    private readonly Dictionary<string, CatalogRow> _modelsByTag = new(StringComparer.OrdinalIgnoreCase);
    private readonly ObservableCollection<ComponentRow> _components = new();
    private readonly ObservableCollection<LocalFileRow> _localFiles = new();
    private readonly ObservableCollection<ModelCenterEvent> _events = new();
    private CancellationTokenSource? _pullCts;
    private CancellationTokenSource? _componentCts;
    private CancellationTokenSource? _fileScanCts;
    private CancellationTokenSource? _fileActionCts;
    private CancellationTokenSource? _backupCts;
    private string? _activeQueueId;
    private long? _activeStopGeneration;
    private Guid? _activeLeaseId;
    private TaskCompletionSource<bool>? _activePullSettled;
    private string? _localLicenseOpenedForPath;
    private string? _reviewedLocalFilePath;
    private string? _reviewedLocalFileSha256;
    private string? _reviewedLicenseReference;
    private string? _reviewedLicenseText;
    private string? _surfaceQueueWarningText;
    private CatalogRow? _selectedModel;
    private ComponentRow? _selectedComponent;
    private LocalFileRow? _selectedLocalFile;
    private PreflightSnapshot? _lastPreflight;
    private bool _modelLicensePageOpened;
    private bool _componentLicensePageOpened;
    private bool _closing;
    private bool _windowClosed;
    private bool _waitingForPullClose;
    private bool _allowCloseAfterPull;
    private bool _controlsReady;
    private string _statusLine = "Инициализация Model Center…";
    private string _preflightSummary = "Сведения системы ещё не получены.";

    public event PropertyChangedEventHandler? PropertyChanged;
    public event EventHandler<ModelCenterEvent>? EventRaised
    {
        add => EventHub.EventRaised += value;
        remove => EventHub.EventRaised -= value;
    }
    public event EventHandler<NoxEventV3>? EventRaisedV3
    {
        add => EventHub.EventRaisedV3 += value;
        remove => EventHub.EventRaisedV3 -= value;
    }
    public string RunId => EventHub.RunId;

    /// <summary>Host subscribers can observe local, secret-free model-center events.</summary>
    public ModelCenterEventHub EventHub { get; }
    public ObservableCollection<CatalogRow> Models => _models;
    public ObservableCollection<ComponentRow> Components => _components;
    public ObservableCollection<LocalFileRow> LocalFiles => _localFiles;
    public ObservableCollection<ModelCenterEvent> Events => _events;
    public ReadOnlyObservableCollection<DownloadQueueItem> QueueItems => _queueStore.Items;
    public ICollectionView ModelView => _modelView;

    public string StatusLine
    {
        get => _statusLine;
        private set { if (_statusLine == value) return; _statusLine = value; OnPropertyChanged(); }
    }

    public string PreflightSummary
    {
        get => _preflightSummary;
        private set { if (_preflightSummary == value) return; _preflightSummary = value; OnPropertyChanged(); }
    }

    public CatalogRow? SelectedModel
    {
        get => _selectedModel;
        set
        {
            if (ReferenceEquals(_selectedModel, value)) return;
            _selectedModel = value;
            OnPropertyChanged();
            UpdateSelectedModel();
        }
    }

    public ComponentRow? SelectedComponent
    {
        get => _selectedComponent;
        set
        {
            if (ReferenceEquals(_selectedComponent, value)) return;
            _selectedComponent = value;
            OnPropertyChanged();
            UpdateSelectedComponent();
        }
    }

    public LocalFileRow? SelectedLocalFile
    {
        get => _selectedLocalFile;
        set
        {
            if (ReferenceEquals(_selectedLocalFile, value)) return;
            _selectedLocalFile = value;
            OnPropertyChanged();
            _localLicenseOpenedForPath = null;
            ClearRecordedLocalReview();
            if (_controlsReady)
            {
                LocalLicenseUrlText.Text = "";
                LocalLicenseTextBox.Text = "";
                LocalImportTagText.Text = value is null ? "" : SuggestedLocalImportTag(value.Candidate);
                LocalLicenseCheck.IsChecked = false;
                LocalCompatibilityCheck.IsChecked = false;
                LocalRightsCheck.IsChecked = false;
                LocalLicenseCheck.IsEnabled = false;
                LocalImportResultText.Text = "Импорт ещё не выполнялся для выбранного файла.";
            }
            UpdateSelectedLocalFile();
            UpdateLocalFileActions();
        }
    }

    public ModelDownloaderWindow(DownloadQueueStore? queueStore = null, ModelCenterEventHub? eventHub = null)
    {
        _queueStore = queueStore ?? new DownloadQueueStore();
        EventHub = eventHub ?? new ModelCenterEventHub();
        _eventSink = new SafeEventSink(EventHub);
        _ggufImporter = new OllamaGgufImporter(_eventSink);
        _componentInstaller = new ComponentInstaller(_eventSink);
        _backupRestoreService = new BackupRestoreService(_eventSink);

        InitializeComponent();
        DataContext = this;
        EventHub.EventRaised += EventHub_EventRaised;
        _queueStore.WarningRaised += QueueStore_WarningRaised;
        _queueStore.Load();
        _modelView = CollectionViewSource.GetDefaultView(_models);
        _modelView.Filter = MatchesModelFilter;
        CatalogGrid.ItemsSource = _modelView;
        QueueGrid.ItemsSource = _queueStore.Items;
        ComponentGrid.ItemsSource = _components;
        LocalFilesGrid.ItemsSource = _localFiles;
        EventGrid.ItemsSource = _events;

        foreach (var entry in ModelCatalog.GetAll())
        {
            var row = new CatalogRow(entry);
            _models.Add(row);
            _modelsByTag.Add(row.Tag, row);
        }
        foreach (var package in ComponentInstaller.ApprovedPackages) _components.Add(new ComponentRow(package));
        RefreshCategoryFilter();
        RefreshActionButtons();

        _queueItemsChanged = (_, _) =>
        {
            if (!Dispatcher.HasShutdownStarted) Dispatcher.InvokeAsync(RefreshActionButtons);
        };
        _queueStore.Items.CollectionChanged += _queueItemsChanged;
        _queueStore.StateChanged += QueueStore_StateChanged;
        SurfaceQueueWarning(_queueStore.LastWarning);
        Loaded += Window_Loaded;
        Closing += Window_Closing;
        Closed += Window_Closed;
        _controlsReady = true;
        UpdateLocalFileActions();
        UpdateBackupActions();
        if (_models.Count > 0) SelectedModel = _models[0];
        if (_components.Count > 0) SelectedComponent = _components[0];
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        await RefreshPreflightAsync();
        var queueStatusItem = _queueStore.Items.FirstOrDefault(x => IsState(x.State, "DOWNLOADING")) ??
            _queueStore.Items.FirstOrDefault(x =>
                IsState(x.State, "PAUSED") || IsState(x.State, "CANCELLED") || IsState(x.State, "FAILED"));
        if (queueStatusItem is not null) ShowQueueState(queueStatusItem);
        _ = PumpQueueAsync();
    }

    private async Task RefreshPreflightAsync()
    {
        var operationId = Guid.NewGuid().ToString("N");
        PreflightButton.IsEnabled = false;
        StatusLine = "Снимаю read-only сведения о ПК…";
        PublishEvent(ModelCenterEventKind.SystemProbe, "local-pc", "RUNNING", "Read-only PC preflight started.", operationId: operationId);
        try
        {
            var snapshot = await ModelPreflight.CaptureAsync();
            _lastPreflight = snapshot;
            var json = JsonSerializer.Serialize(snapshot, new JsonSerializerOptions { WriteIndented = true });
            PreflightSummary = json;
            RefreshInstalledModels(snapshot);
            RefreshComponentInventory(snapshot);
            StatusLine = string.IsNullOrWhiteSpace(_queueStore.LastWarning)
                ? "Снимок обновлён. Пакеты не устанавливались и системные настройки не менялись."
                : "Восстановление очереди: " + _queueStore.LastWarning;
            PublishEvent(ModelCenterEventKind.SystemProbe, "local-pc", "COMPLETED", "Read-only PC preflight completed.", operationId: operationId);
        }
        catch (Exception ex)
        {
            PreflightSummary = "Не удалось получить сведения: " + ex.Message;
            StatusLine = string.IsNullOrWhiteSpace(_queueStore.LastWarning)
                ? "Проверка системы завершилась ошибкой."
                : "Восстановление очереди: " + _queueStore.LastWarning + " · проверка системы завершилась ошибкой.";
            PublishEvent(ModelCenterEventKind.Error, "local-pc", "FAILED", "Read-only PC preflight failed.",
                errorCode: ex.GetType().Name, operationId: operationId);
        }
        finally { PreflightButton.IsEnabled = true; }
    }

    private void RefreshInstalledModels(PreflightSnapshot snapshot)
    {
        var installed = new Dictionary<string, InstalledModel>(StringComparer.OrdinalIgnoreCase);
        foreach (var installedModel in snapshot.InstalledModels)
            installed.TryAdd(installedModel.Name, installedModel);
        foreach (var model in _models)
        {
            installed.TryGetValue(model.Tag, out var installedModel);
            if (installedModel is null && model.Tag.IndexOf(':') < 0)
                installed.TryGetValue(model.Tag + ":latest", out installedModel);
            model.SetInstalled(installedModel is not null, installedModel?.SizeBytes);
        }
    }

    private void RefreshComponentInventory(PreflightSnapshot snapshot)
    {
        foreach (var row in _components)
        {
            var expectedName = row.Package.Id switch
            {
                "Python.Python.3.12" => "Python",
                "Ollama.Ollama" => "Ollama",
                "Git.Git" => "Git",
                "Microsoft.EdgeWebView2Runtime" => "Microsoft Edge WebView2 Runtime",
                "Microsoft.VCRedist.2015+.x64" => "Microsoft Visual C++ Redistributable",
                "Microsoft.DotNet.DesktopRuntime.8" => ".NET Windows Desktop Runtime",
                _ => row.Package.Name
            };
            var component = snapshot.InstalledComponents.FirstOrDefault(x =>
                string.Equals(x.Name, expectedName, StringComparison.OrdinalIgnoreCase));
            var library = snapshot.RequiredLibraries.FirstOrDefault(x =>
                string.Equals(x.Name, expectedName, StringComparison.OrdinalIgnoreCase));
            row.UpdateInventory(component?.Status ?? library?.Status ?? "N/D",
                component?.Version ?? library?.VersionOrEvidence ?? component?.Path ?? "N/D");
            PublishEvent(ModelCenterEventKind.ComponentDetected, row.Package.Id,
                component?.Status ?? library?.Status ?? "N/D", "Read-only component inventory updated.");
        }
    }

    private void RefreshCategoryFilter()
    {
        CategoryFilter.Items.Clear();
        CategoryFilter.Items.Add("Все категории");
        foreach (var category in _models.Select(x => x.Category)
                     .Where(x => !string.IsNullOrWhiteSpace(x))
                     .Distinct(StringComparer.CurrentCultureIgnoreCase)
                     .OrderBy(x => x))
            CategoryFilter.Items.Add(category);
        CategoryFilter.SelectedIndex = 0;
    }

    private bool MatchesModelFilter(object item)
    {
        if (item is not CatalogRow model) return false;
        var query = SearchBox.Text?.Trim();
        if (!string.IsNullOrEmpty(query) &&
            !($"{model.Title} {model.Tag} {model.Category}".Contains(query, StringComparison.CurrentCultureIgnoreCase)))
            return false;
        var category = CategoryFilter.SelectedItem as string;
        return string.IsNullOrWhiteSpace(category) || category == "Все категории" ||
               string.Equals(category, model.Category, StringComparison.CurrentCultureIgnoreCase);
    }

    private void SearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_controlsReady) _modelView.Refresh();
    }
    private void CategoryFilter_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (_controlsReady) _modelView.Refresh();
    }
    private void CatalogGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) =>
        SelectedModel = CatalogGrid.SelectedItem as CatalogRow;
    private void QueueGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) => RefreshActionButtons();
    private void ComponentGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) =>
        SelectedComponent = ComponentGrid.SelectedItem as ComponentRow;
    private void LocalFilesGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) =>
        SelectedLocalFile = LocalFilesGrid.SelectedItem as LocalFileRow;

    private void UpdateSelectedLocalFile()
    {
        if (SelectedLocalFile is null)
        {
            LocalFileDetailsText.Text = "Выберите найденный файл для просмотра формата, SHA-256 и примечаний.";
            return;
        }
        var candidate = SelectedLocalFile.Candidate;
        LocalFileDetailsText.Text =
            $"{candidate.FileName}\nФормат: {candidate.Format} · {candidate.Status}\n" +
            $"Размер: {FormatBytes(candidate.SizeBytes)}\nSHA-256: {candidate.Sha256}\n" +
            $"Изменён (UTC): {candidate.LastWriteTimeUtc:O}\n{candidate.InspectionNote}";
    }

    private void UpdateSelectedModel()
    {
        _modelLicensePageOpened = false;
        LicenseCheck.IsChecked = false;
        if (SelectedModel is null)
        {
            ModelDetailsText.Text = "";
            LicenseStatusText.Text = "Выберите модель.";
        }
        else
        {
            var model = SelectedModel;
            var vram = model.EstimatedMinVramGiB is { } value
                ? value.ToString("0.#", CultureInfo.InvariantCulture) + " GiB"
                : "N/D";
            ModelDetailsText.Text =
                $"{model.Title}\n{model.Tag}\nКатегория: {model.Category}\n" +
                $"Оценка VRAM: {vram} ({model.Entry.VramEstimateSource})\n" +
                $"Размер: {model.SizeDisplay}\n{model.SizeToolTip}\n" +
                $"Каталожный SHA-256: {model.Entry.Sha256} · источник: {model.Entry.Sha256Source}";
            LicenseStatusText.Text =
                $"Статус лицензии: {model.LicenseStatus}. Ссылка ведёт на официальный каталог модели; проверьте лицензию на странице.";
        }
        RefreshActionButtons();
    }

    private void RefreshActionButtons()
    {
        var hasModel = SelectedModel is not null;
        OpenModelButton.IsEnabled = hasModel && IsHttps(SelectedModel!.ModelPageUrl);
        OpenLicenseButton.IsEnabled = hasModel && IsHttps(SelectedModel!.LicenseUrl);
        LicenseCheck.IsEnabled = hasModel && _modelLicensePageOpened;
        InstallButton.IsEnabled = hasModel && _modelLicensePageOpened && LicenseCheck.IsChecked == true;

        var queueItem = QueueGrid.SelectedItem as DownloadQueueItem;
        PauseButton.IsEnabled = queueItem is not null && IsState(queueItem.State, "DOWNLOADING");
        ResumeButton.IsEnabled = queueItem is not null && IsState(queueItem.State, "PAUSED");
        RetryButton.IsEnabled = queueItem is not null && IsState(queueItem.State, "FAILED");
        CancelButton.IsEnabled = queueItem is not null && !IsTerminalQueueState(queueItem.State);
    }

    private async void PreflightButton_Click(object sender, RoutedEventArgs e) => await RefreshPreflightAsync();

    private void OpenModelButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedModel is not null && !OpenExternal(SelectedModel.ModelPageUrl))
            StatusLine = "Не удалось открыть страницу модели.";
    }

    private void OpenLicenseButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedModel is null) return;
        if (!OpenExternal(SelectedModel.LicenseUrl))
        {
            StatusLine = "Не удалось открыть каталог с лицензионными сведениями.";
            return;
        }
        _modelLicensePageOpened = true;
        LicenseCheck.IsEnabled = true;
        StatusLine = "Проверьте лицензию на странице модели, затем подтвердите согласие.";
        RefreshActionButtons();
    }

    private void LicenseCheck_Changed(object sender, RoutedEventArgs e) => RefreshActionButtons();

    private void InstallButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedModel is null || !_modelLicensePageOpened || LicenseCheck.IsChecked != true)
        {
            StatusLine = "Очередь заблокирована: откройте страницу лицензии и подтвердите согласие.";
            return;
        }
        try
        {
            var queued = _queueStore.Enqueue(SelectedModel.Entry, licenseAcknowledged: true);
            StatusLine = $"В FIFO добавлена {queued.Tag}; лицензия отмечена как просмотренная пользователем.";
            PublishEvent(ModelCenterEventKind.DownloadQueued, queued.Tag, queued.State,
                "Model queued after explicit license acknowledgement.", operationId: queued.Id);
            _ = PumpQueueAsync();
        }
        catch (Exception ex) { StatusLine = "Не удалось добавить модель в очередь: " + ex.Message; }
    }

    private async Task PumpQueueAsync()
    {
        if (_closing || !await _queuePumpGate.WaitAsync(0)) return;
        try
        {
            while (!_closing)
            {
                var next = _queueStore.Items.FirstOrDefault(x => IsState(x.State, "QUEUED"));
                if (next is null) break;
                if (!await RunQueueItemAsync(next)) break;
            }
        }
        finally
        {
            if (!_closing) _queuePumpGate.Release();
            RefreshActionButtons();
        }
    }

    private CatalogRow? FindCatalogRow(string tag) =>
        _modelsByTag.TryGetValue(tag, out var row) ? row : null;

    private async Task<bool> RunQueueItemAsync(DownloadQueueItem item)
    {
        var model = FindCatalogRow(item.Tag);
        if (model is null || !item.LicenseAcknowledged)
        {
            var reason = model is null ? "Тег отсутствует в текущем каталоге." : "Нет сохранённого подтверждения лицензии.";
            try
            {
                var failedItem = _queueStore.SetState(item.Id, "FAILED", reason);
                if (IsState(failedItem.State, "FAILED"))
                {
                    if (SyncDownloadFooter(failedItem)) StatusLine = $"{item.Title}: FAILED · {reason}";
                    PublishEvent(ModelCenterEventKind.DownloadFailed, item.Tag, "FAILED", reason,
                        errorCode: "PRECONDITION_FAILED", operationId: item.Id);
                }
                else ShowQueueState(failedItem);
            }
            catch (Exception ex) { ShowQueueOperationFailure(item.Id, "Не удалось проверить задачу перед запуском", ex); }
            return true;
        }

        using var operationCts = new CancellationTokenSource();
        DownloadQueueItem startedItem;
        try
        {
            if (!_queueStore.TryStartDownload(item.Id, out startedItem))
            {
                QueueGrid.Items.Refresh();
                ShowQueueState(startedItem);
                RefreshActionButtons();
                return false;
            }
        }
        catch (Exception ex)
        {
            ShowQueueOperationFailure(item.Id, "Запуск загрузки не принят очередью", ex);
            return false;
        }

        item = startedItem;
        var stopGeneration = startedItem.StopGeneration;
        var leaseId = startedItem.DownloaderLeaseId;
        _pullCts = operationCts;
        _activeQueueId = item.Id;
        _activeStopGeneration = stopGeneration;
        _activeLeaseId = leaseId;
        _activePullSettled = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);

        try
        {
            if (leaseId is null)
                throw new InvalidOperationException("Queue started the pull without returning its owner lease.");

            BeginDownloadFooter(item);
            StatusLine = $"Загружается {item.Title}; параллельная загрузка не запускается.";
            PublishEvent(ModelCenterEventKind.DownloadProgress, item.Tag, "DOWNLOADING", "Model pull started.", operationId: item.Id);

            var expectedLeaseId = leaseId.Value;
            var progress = new Progress<PullProgress>(update =>
                HandlePullProgress(item.Id, item.Tag, update, stopGeneration, expectedLeaseId));
            var result = await _pullService.PullAsync(item.Tag, progress, operationCts.Token);
            if (operationCts.IsCancellationRequested)
            {
                ReflectCurrentQueueState(item.Id);
                return true;
            }

            if (result.HashVerified)
            {
                var finalItem = _queueStore.SetState(item.Id, "COMPLETED", stopGeneration, expectedLeaseId, result: result);
                if (IsState(finalItem.State, "COMPLETED") && finalItem.HashVerified)
                {
                    if (SyncDownloadFooter(finalItem))
                    {
                        StatusLine = $"{item.Title}: проверена и установлена · {ShortDigest(result.Digest)} · {FormatBytes(result.SizeBytes)}.";
                        FindCatalogRow(item.Tag)?.SetInstalled(true, result.SizeBytes);
                    }
                    PublishEvent(ModelCenterEventKind.DownloadCompleted, item.Tag, "COMPLETED",
                        "Ollama pull completed with a verified SHA-256 digest.", bytesCompleted: result.SizeBytes,
                        bytesTotal: result.SizeBytes, digest: result.Digest, operationId: item.Id);
                }
                else ShowQueueState(finalItem);
            }
            else
            {
                const string error = "Модель получена, но digest не подтверждён; очередь не помечена завершённой.";
                var finalItem = _queueStore.SetState(item.Id, "FAILED", stopGeneration, expectedLeaseId, error: error);
                if (IsState(finalItem.State, "FAILED"))
                {
                    if (SyncDownloadFooter(finalItem)) StatusLine = $"{item.Title}: локальная модель не прошла проверку SHA-256.";
                    PublishEvent(ModelCenterEventKind.DownloadFailed, item.Tag, "FAILED",
                        "Ollama pull finished without a verified digest.", errorCode: "DIGEST_UNVERIFIED", operationId: item.Id);
                }
                else ShowQueueState(finalItem);
            }
        }
        catch (OperationCanceledException)
        {
            var currentItem = _queueStore.Items.FirstOrDefault(x => string.Equals(x.Id, item.Id, StringComparison.Ordinal));
            if (leaseId is Guid expectedLeaseId && currentItem is not null &&
                IsState(currentItem.State, "DOWNLOADING") && currentItem.StopGeneration == stopGeneration &&
                currentItem.DownloaderLeaseId == expectedLeaseId)
            {
                const string error = "The Ollama pull stopped without a persisted pause or cancel request.";
                var failedItem = _queueStore.SetState(item.Id, "FAILED", stopGeneration, expectedLeaseId, error: error);
                if (IsState(failedItem.State, "FAILED"))
                {
                    if (SyncDownloadFooter(failedItem)) StatusLine = $"Ошибка загрузки {item.Title}: запрос остановился без команды паузы или отмены.";
                    PublishEvent(ModelCenterEventKind.DownloadFailed, item.Tag, "FAILED",
                        "Ollama pull was cancelled without a durable stop request.", errorCode: "UNEXPECTED_CANCELLATION", operationId: item.Id);
                }
                else ShowQueueState(failedItem);
            }
            else if (currentItem is not null) ShowQueueState(currentItem);
        }
        catch (Exception ex)
        {
            if (leaseId is Guid expectedLeaseId)
            {
                DownloadQueueItem failedItem;
                try
                {
                    failedItem = _queueStore.SetState(item.Id, "FAILED", stopGeneration, expectedLeaseId, error: ex.Message);
                }
                catch (Exception persistenceError)
                {
                    // A full or unavailable profile disk can make the durable FAILED
                    // transition fail too. Keep that second failure visible instead
                    // of letting this fire-and-forget queue pump fault unobserved.
                    StatusLine = $"Ошибка загрузки {item.Title}: {ex.Message}. Не удалось сохранить состояние FAILED: {persistenceError.Message}. Освободите место/проверьте доступ и восстановите очередь.";
                    PublishEvent(ModelCenterEventKind.Error, item.Tag, "QUEUE_FAILURE_PERSIST_FAILED",
                        "The model pull failed and the queue could not persist its FAILED state.",
                        errorCode: persistenceError.GetType().Name, operationId: item.Id);
                    return true;
                }
                if (IsState(failedItem.State, "FAILED"))
                {
                    if (SyncDownloadFooter(failedItem)) StatusLine = $"Ошибка загрузки {item.Title}: {ex.Message}";
                    PublishEvent(ModelCenterEventKind.DownloadFailed, item.Tag, "FAILED",
                        "Ollama model pull failed.", errorCode: ex.GetType().Name, operationId: item.Id);
                }
                else ShowQueueState(failedItem);
            }
            else ShowQueueOperationFailure(item.Id, "Ошибка загрузки до получения owner lease", ex);
        }
        finally
        {
            if (leaseId is Guid ownerLeaseId)
            {
                try
                {
                    var acknowledgedItem = _queueStore.AcknowledgePullStopped(item.Id, stopGeneration, ownerLeaseId);
                    if (IsState(acknowledgedItem.State, "PAUSED") || IsState(acknowledgedItem.State, "CANCELLED") ||
                        IsState(acknowledgedItem.State, "QUEUED"))
                        ShowQueueState(acknowledgedItem);
                    if (IsState(acknowledgedItem.State, "PAUSED"))
                        PublishEvent(ModelCenterEventKind.DownloadPaused, item.Tag, "PAUSED", "Local HTTP pull stop was acknowledged by its owner; remote Ollama pull state is N/D.", operationId: item.Id);
                    else if (IsState(acknowledgedItem.State, "CANCELLED"))
                        PublishEvent(ModelCenterEventKind.DownloadCancelled, item.Tag, "CANCELLED", "Local HTTP pull cancellation was acknowledged by its owner; remote Ollama pull state is N/D.", operationId: item.Id);
                }
                catch (Exception ex)
                {
                    if (string.Equals(_activeQueueId, item.Id, StringComparison.Ordinal))
                        StatusLine = $"{item.Title}: остановка ещё не подтверждена очередью · {ex.Message}";
                    PublishEvent(ModelCenterEventKind.Error, item.Tag, "STOP_ACK_FAILED",
                        "The pull owner could not acknowledge its durable stop request.", errorCode: ex.GetType().Name, operationId: item.Id);
                }
            }
            if (ReferenceEquals(_pullCts, operationCts)) _pullCts = null;
            if (string.Equals(_activeQueueId, item.Id, StringComparison.Ordinal)) _activeQueueId = null;
            _activeStopGeneration = null;
            _activeLeaseId = null;
            if (_closing) _pullService.Dispose();
            RefreshActionButtons();
            _activePullSettled?.TrySetResult(true);
            _activePullSettled = null;
            if (_windowClosed) _queueStore.Dispose();
        }
        return true;
    }

    private void HandlePullProgress(string jobId, string tag, PullProgress update, long stopGeneration, Guid leaseId)
    {
        if (!Dispatcher.CheckAccess())
        {
            if (!Dispatcher.HasShutdownStarted)
                Dispatcher.InvokeAsync(() => HandlePullProgress(jobId, tag, update, stopGeneration, leaseId));
            return;
        }
        var item = _queueStore.UpdateProgress(jobId, update, stopGeneration, leaseId);
        if (!IsState(item.State, "DOWNLOADING") || item.StopGeneration != stopGeneration || item.DownloaderLeaseId != leaseId)
        {
            // A delayed dispatcher callback from an earlier lease must not cancel
            // a newer owner that resumed the same queue row.
            if (string.Equals(_activeQueueId, jobId, StringComparison.Ordinal) &&
                _activeStopGeneration == stopGeneration && _activeLeaseId == leaseId)
                _pullCts?.Cancel();
            ShowQueueState(item);
            return;
        }

        var useAggregate = update.HasAggregateTotalMeasurement || update.HasAggregateCompletedMeasurement;
        var hasCompleted = useAggregate ? update.HasAggregateCompletedMeasurement : update.HasCompletedMeasurement;
        var hasTotal = useAggregate ? update.HasAggregateTotalMeasurement : update.HasTotalMeasurement;
        var completed = useAggregate ? update.AggregateCompletedBytes : update.CompletedBytes;
        var total = useAggregate ? update.AggregateTotalBytes : update.TotalBytes;
        OverallProgress.IsIndeterminate = !hasCompleted || !hasTotal || total <= 0;
        OverallProgress.Value = OverallProgress.IsIndeterminate ? 0 : Math.Clamp(completed * 100d / total, 0, 100);
        ProgressText.Text = hasCompleted && hasTotal && total > 0
            ? $"DOWNLOADING · {update.Status}: {FormatBytes(completed)} / {FormatBytes(total)}"
            : $"DOWNLOADING · {update.Status}: прогресс N/D";
        StatusLine = $"{tag} · {ProgressText.Text}";
        PublishEvent(ModelCenterEventKind.DownloadProgress, tag, update.Status,
            "Ollama model download progress.", hasCompleted ? completed : null,
            hasTotal && total > 0 ? total : null, update.InstalledDigest ?? update.Digest, operationId: jobId);
    }

    private void QueueStore_StateChanged(object? sender, DownloadQueueItemStateChangedEventArgs e)
    {
        void Apply()
        {
            if (_windowClosed || Dispatcher.HasShutdownStarted) return;
            if (string.Equals(_activeQueueId, e.ItemId, StringComparison.Ordinal) &&
                _activeStopGeneration is { } baseline && e.StopGeneration > baseline)
                _pullCts?.Cancel();

            QueueGrid.Items.Refresh();
            var item = _queueStore.Items.FirstOrDefault(x => string.Equals(x.Id, e.ItemId, StringComparison.Ordinal));
            if (item is not null)
            {
                if (IsState(item.State, "COMPLETED") && item.HashVerified)
                    FindCatalogRow(item.Tag)?.SetInstalled(true, item.InstalledSizeBytes);
                ShowQueueState(item);
            }
            RefreshActionButtons();
        }

        if (Dispatcher.CheckAccess()) Apply();
        else if (!Dispatcher.HasShutdownStarted) Dispatcher.BeginInvoke((Action)Apply);
    }

    private void ReflectCurrentQueueState(string itemId)
    {
        var item = _queueStore.Items.FirstOrDefault(x => string.Equals(x.Id, itemId, StringComparison.Ordinal));
        if (item is not null) ShowQueueState(item);
    }

    private bool ShowQueueState(DownloadQueueItem item)
    {
        if (_activeQueueId is null)
        {
            var globallyActive = _queueStore.Items.FirstOrDefault(x => IsState(x.State, "DOWNLOADING"));
            if (globallyActive is not null && !string.Equals(globallyActive.Id, item.Id, StringComparison.Ordinal))
                item = globallyActive;
        }
        if (!SyncDownloadFooter(item)) return false;
        StatusLine = QueueStateStatus(item);
        return true;
    }

    private static string QueueStateStatus(DownloadQueueItem item) => item.State.ToUpperInvariant() switch
    {
        "PAUSED" => $"{item.Title}: локальный HTTP pull приостановлен; состояние Ollama — N/D.",
        "CANCELLED" => $"{item.Title}: локальная отмена подтверждена; состояние pull на сервере Ollama — N/D.",
        "FAILED" => $"{item.Title}: FAILED · {item.LastError ?? "причина не указана"}",
        "COMPLETED" when item.HashVerified => $"{item.Title}: COMPLETED · SHA-256 подтверждён.",
        "QUEUED" => $"{item.Title}: QUEUED · ожидание FIFO.",
        "DOWNLOADING" => $"{item.Title}: DOWNLOADING · активный pull.",
        _ => $"{item.Title}: состояние очереди — {item.State}."
    };

    private void ShowQueueOperationFailure(string itemId, string operation, Exception exception)
    {
        QueueGrid.Items.Refresh();
        var globallyActive = _activeQueueId is null
            ? _queueStore.Items.FirstOrDefault(x => IsState(x.State, "DOWNLOADING"))
            : null;
        if (globallyActive is not null && !string.Equals(globallyActive.Id, itemId, StringComparison.Ordinal))
        {
            if (ShowQueueState(globallyActive)) StatusLine += $" · {operation}: {exception.Message}";
            RefreshActionButtons();
            return;
        }
        var item = _queueStore.Items.FirstOrDefault(x => string.Equals(x.Id, itemId, StringComparison.Ordinal));
        if (item is not null && SyncDownloadFooter(item))
            StatusLine = $"{item.Title}: {item.State} · {operation}: {exception.Message}";
        else StatusLine = $"{operation}: {exception.Message}";
        RefreshActionButtons();
    }

    private void BeginDownloadFooter(DownloadQueueItem item)
    {
        OverallProgress.IsIndeterminate = true;
        OverallProgress.Value = 0;
        ProgressText.Text = $"DOWNLOADING · {item.Title}: ожидание прогресса";
    }

    private bool SyncDownloadFooter(DownloadQueueItem item)
    {
        if (_activeQueueId is not null && !string.Equals(_activeQueueId, item.Id, StringComparison.Ordinal))
            return false;

        var state = item.State.ToUpperInvariant();
        var hasCompleted = item.HasBytesCompletedMeasurement;
        var hasTotal = item.HasBytesTotalMeasurement;
        var completed = hasCompleted ? Math.Max(0, item.BytesCompleted) : 0;
        var total = hasTotal ? Math.Max(0, item.BytesTotal) : 0;
        var hasRatio = hasCompleted && hasTotal && total > 0;

        if (state == "COMPLETED" && item.HashVerified)
        {
            OverallProgress.IsIndeterminate = false;
            OverallProgress.Value = 100;
            ProgressText.Text = $"COMPLETED · {FormatBytes(item.InstalledSizeBytes ?? total)} · SHA-256 подтверждён";
            return true;
        }

        OverallProgress.IsIndeterminate = state == "DOWNLOADING" && !hasRatio;
        OverallProgress.Value = hasRatio ? Math.Clamp(completed * 100d / total, 0, 100) : 0;
        var completedText = hasCompleted ? FormatBytes(completed) : "N/D";
        var totalText = hasTotal ? FormatBytes(total) : "N/D";
        var progressText = $"{completedText} / {totalText}";

        ProgressText.Text = state == "DOWNLOADING" && !hasRatio
            ? $"DOWNLOADING · {item.Title}: ожидание измерений"
            : state == "QUEUED" && !hasCompleted && !hasTotal
                ? $"QUEUED · {item.Title}"
                : $"{state} · {progressText}";
        return true;
    }

    private void PauseButton_Click(object sender, RoutedEventArgs e)
    {
        if (QueueGrid.SelectedItem is not DownloadQueueItem item || !IsState(item.State, "DOWNLOADING")) return;
        try
        {
            var pausedItem = _queueStore.Pause(item.Id);
            if (string.Equals(_activeQueueId, item.Id, StringComparison.Ordinal)) _pullCts?.Cancel();
            if (SyncDownloadFooter(pausedItem)) StatusLine = $"{item.Title} приостановлена.";
            RefreshActionButtons();
        }
        catch (Exception ex) { ShowQueueOperationFailure(item.Id, "Не удалось приостановить загрузку", ex); }
    }

    private void ResumeButton_Click(object sender, RoutedEventArgs e)
    {
        if (QueueGrid.SelectedItem is not DownloadQueueItem item || !IsState(item.State, "PAUSED")) return;
        try
        {
            var queuedItem = _queueStore.Resume(item.Id);
            if (SyncDownloadFooter(queuedItem)) StatusLine = $"{item.Title} возвращена в FIFO.";
            PublishEvent(ModelCenterEventKind.DownloadResumed, item.Tag, "QUEUED", "Paused pull requeued for resume.", operationId: item.Id);
            RefreshActionButtons();
            _ = PumpQueueAsync();
        }
        catch (Exception ex) { ShowQueueOperationFailure(item.Id, "Не удалось возобновить загрузку", ex); }
    }

    private void RetryButton_Click(object sender, RoutedEventArgs e)
    {
        if (QueueGrid.SelectedItem is not DownloadQueueItem item || !IsState(item.State, "FAILED")) return;
        try
        {
            var queuedItem = _queueStore.Retry(item.Id);
            if (SyncDownloadFooter(queuedItem)) StatusLine = $"{item.Title} поставлена в очередь повторно.";
            PublishEvent(ModelCenterEventKind.DownloadRetry, item.Tag, "QUEUED", "Failed pull retried.", operationId: item.Id);
            RefreshActionButtons();
            _ = PumpQueueAsync();
        }
        catch (Exception ex) { ShowQueueOperationFailure(item.Id, "Не удалось повторить загрузку", ex); }
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        if (QueueGrid.SelectedItem is not DownloadQueueItem item || IsTerminalQueueState(item.State)) return;
        try
        {
            var activePull = string.Equals(_activeQueueId, item.Id, StringComparison.Ordinal);
            var cancelledItem = _queueStore.Cancel(item.Id);
            if (activePull) _pullCts?.Cancel();
            if (SyncDownloadFooter(cancelledItem)) StatusLine = activePull
                ? $"{item.Title}: остановка запрошена; ждём подтверждение владельца загрузки."
                : $"{item.Title}: отмена подтверждена до начала загрузки.";
            if (!activePull)
                PublishEvent(ModelCenterEventKind.DownloadCancelled, item.Tag, "CANCELLED", "Queued model pull cancelled before network start.", operationId: item.Id);
            RefreshActionButtons();
        }
        catch (Exception ex) { ShowQueueOperationFailure(item.Id, "Не удалось отменить", ex); }
    }

    private void UpdateSelectedComponent()
    {
        _componentLicensePageOpened = false;
        PackageAgreementCheck.IsChecked = false;
        if (SelectedComponent is null)
        {
            ComponentDetailsText.Text = "Выберите компонент из allowlist.";
        }
        else
        {
            var package = SelectedComponent.Package;
            ComponentDetailsText.Text =
                $"{package.Name}\nID: {package.Id}\nИздатель: {package.Publisher}\n" +
                $"Инвентаризация: {SelectedComponent.InventoryStatus} · {SelectedComponent.VersionOrPath}\n" +
                $"Официальная страница: {package.ProductPage}\nСведения о лицензии: {package.LicensePage}";
        }
        RefreshComponentActions();
    }

    private void RefreshComponentActions()
    {
        var hasComponent = SelectedComponent is not null;
        var operation = ReadComponentOperation();
        var agreementRequired = operation is ComponentOperation.Install or ComponentOperation.Update;
        ComponentProductButton.IsEnabled = hasComponent && IsHttps(SelectedComponent!.Package.ProductPage);
        ComponentTermsButton.IsEnabled = hasComponent && IsHttps(SelectedComponent!.Package.LicensePage);
        PackageAgreementCheck.IsEnabled = hasComponent && agreementRequired && _componentLicensePageOpened;
        ComponentRunButton.IsEnabled = hasComponent &&
            (!agreementRequired || (_componentLicensePageOpened && PackageAgreementCheck.IsChecked == true)) &&
            _componentCts is null;
        ComponentCancelButton.IsEnabled = _componentCts is not null;
    }

    private ComponentOperation ReadComponentOperation()
    {
        var value = ComponentOperationCombo.SelectedValue as string;
        return Enum.TryParse<ComponentOperation>(value, ignoreCase: true, out var operation)
            ? operation
            : ComponentOperation.Install;
    }

    private void ComponentOperationCombo_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (!_controlsReady) return;
        _componentLicensePageOpened = false;
        if (PackageAgreementCheck is not null) PackageAgreementCheck.IsChecked = false;
        if (ComponentOperationCombo is not null) RefreshComponentActions();
    }

    private void PackageAgreementCheck_Changed(object sender, RoutedEventArgs e) => RefreshComponentActions();

    private void ComponentProductButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedComponent is not null && !OpenExternal(SelectedComponent.Package.ProductPage))
            ComponentStatusText.Text = "Не удалось открыть страницу продукта.";
    }

    private void ComponentTermsButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedComponent is null) return;
        if (!OpenExternal(SelectedComponent.Package.LicensePage))
        {
            ComponentStatusText.Text = "Не удалось открыть сведения о лицензии.";
            return;
        }
        _componentLicensePageOpened = true;
        RefreshComponentActions();
        ComponentStatusText.Text = "Проверьте условия; для Install/Update требуется отдельное подтверждение.";
    }

    private async void ComponentRunButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedComponent is null || _componentCts is not null) return;
        var operation = ReadComponentOperation();
        var needsAgreement = operation is ComponentOperation.Install or ComponentOperation.Update;
        var agreementConfirmed = !needsAgreement ||
            (_componentLicensePageOpened && PackageAgreementCheck.IsChecked == true);
        if (!agreementConfirmed)
        {
            ComponentStatusText.Text = "Операция заблокирована: откройте страницу условий и подтвердите согласие.";
            return;
        }

        var package = SelectedComponent.Package;
        var actionText = operation switch
        {
            ComponentOperation.Install => "установить",
            ComponentOperation.Update => "обновить",
            ComponentOperation.Remove => "удалить",
            _ => "изменить"
        };
        if (MessageBox.Show(this, $"Подтвердите действие: {actionText} «{package.Name}». Установщик пакета может отдельно запросить UAC; автоматическое повышение прав не запускается оболочкой.",
                "Подтверждение компонента", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
        {
            ComponentStatusText.Text = $"{package.Name}: действие отменено; изменений не выполнялось.";
            return;
        }

        _componentCts = new CancellationTokenSource();
        RefreshComponentActions();
        ComponentStatusText.Text = $"{operation}: выполняется…";
        try
        {
            var exitCode = await _componentInstaller.RunAsync(
                package.Id, operation, actionConfirmed: true,
                packageAgreementConfirmed: agreementConfirmed,
                cancellationToken: _componentCts.Token);
            ComponentStatusText.Text = exitCode == 0
                ? $"{package.Name}: операция завершена."
                : $"{package.Name}: WinGet завершился с кодом {exitCode}.";
            if (exitCode == 0) await RefreshPreflightAsync();
        }
        catch (OperationCanceledException)
        {
            ComponentStatusText.Text = $"{package.Name}: операция отменена.";
        }
        catch (Exception ex)
        {
            ComponentStatusText.Text = $"{package.Name}: {ex.Message}";
        }
        finally
        {
            _componentCts.Dispose();
            _componentCts = null;
            RefreshComponentActions();
        }
    }

    private void ComponentCancelButton_Click(object sender, RoutedEventArgs e) => _componentCts?.Cancel();

    private void ChooseScanFolderButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = "Выберите папку для read-only сканирования" };
        if (dialog.ShowDialog(this) == true) ScanFolderText.Text = dialog.FolderName;
    }

    private async void ScanFilesButton_Click(object sender, RoutedEventArgs e)
    {
        var folder = ScanFolderText.Text.Trim();
        if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
        {
            FileStatusText.Text = "Выберите существующую папку.";
            return;
        }

        _fileScanCts?.Cancel();
        _fileScanCts?.Dispose();
        _fileScanCts = new CancellationTokenSource();
        var operationId = Guid.NewGuid().ToString("N");
        ScanFilesButton.IsEnabled = false;
        CancelFileScanButton.IsEnabled = true;
        ScanProgressBar.IsIndeterminate = true;
        _localFiles.Clear();
        FileIssuesText.Text = "";
        FileStatusText.Text = "Сканирование только чтением…";
        PublishEvent(ModelCenterEventKind.FileScanStarted, "local-file-scan", "RUNNING", "User-selected folder scan started.", operationId: operationId);

        var scanProgress = new Progress<LocalModelScanProgress>(progress =>
        {
            ScanProgressText.Text = $"{progress.FilesInspected} · {progress.CurrentFile} · {FormatBytes(progress.CurrentFileSizeBytes)}";
            PublishEvent(ModelCenterEventKind.FileFound, "local-file-scan", progress.CurrentStatus.ToString(),
                $"Candidate inspected: {progress.CurrentStatus}; {FormatBytes(progress.CurrentFileSizeBytes)}.",
                progress.CurrentFileSizeBytes, progress.CurrentFileSizeBytes, progress.CurrentSha256, operationId: operationId);
        });

        try
        {
            var options = new LocalModelScanOptions(
                IncludeSubdirectories: IncludeSubdirectoriesCheck.IsChecked == true,
                MaxDepth: 3, MaxFiles: 500);
            var batch = await _fileScanner.ScanAsync(folder, options, scanProgress, _fileScanCts.Token);
            foreach (var candidate in batch.Candidates) _localFiles.Add(new LocalFileRow(candidate));
            FileIssuesText.Text = batch.Issues.Count == 0
                ? "Проблем не обнаружено."
                : string.Join(Environment.NewLine, batch.Issues.Take(20).Select(x => $"{x.Path}: {x.Message}"));
            FileStatusText.Text = $"Сканирование завершено · {batch.FilesInspected} файлов · кандидатов {batch.Candidates.Count}. Ничего не скопировано.";
            PublishEvent(ModelCenterEventKind.FileScanCompleted, "local-file-scan", "COMPLETED",
                $"Read-only scan finished; inspected={batch.FilesInspected}; candidates={batch.Candidates.Count}.", operationId: operationId);
        }
        catch (OperationCanceledException)
        {
            FileStatusText.Text = "Сканирование отменено.";
            PublishEvent(ModelCenterEventKind.FileScanCancelled, "local-file-scan", "CANCELLED", "Read-only scan was cancelled.", operationId: operationId);
        }
        catch (Exception ex)
        {
            FileStatusText.Text = "Сканирование завершилось ошибкой: " + ex.Message;
            PublishEvent(ModelCenterEventKind.Error, "local-file-scan", "FAILED", "Read-only file scan failed.",
                errorCode: ex.GetType().Name, operationId: operationId);
        }
        finally
        {
            ScanProgressBar.IsIndeterminate = false;
            ScanProgressBar.Value = 0;
            ScanFilesButton.IsEnabled = true;
            CancelFileScanButton.IsEnabled = false;
            _fileScanCts.Dispose();
            _fileScanCts = null;
            UpdateLocalFileActions();
        }
    }

    private void CancelFileScanButton_Click(object sender, RoutedEventArgs e) => _fileScanCts?.Cancel();

    private void LocalReviewCheck_Changed(object sender, RoutedEventArgs e)
    {
        if (!_controlsReady) return;
        ClearRecordedLocalReview();
        UpdateLocalFileActions();
    }

    private void OpenLocalLicenseButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedLocalFile is null) return;
        ClearRecordedLocalReview();
        LocalLicenseCheck.IsChecked = false;
        if (!OpenExternal(LocalLicenseUrlText.Text.Trim()))
        {
            FileStatusText.Text = "Введите и откройте HTTPS-ссылку на лицензию/страницу издателя.";
            return;
        }
        _localLicenseOpenedForPath = SelectedLocalFile.Candidate.SourcePath;
        LocalLicenseCheck.IsEnabled = true;
        FileStatusText.Text = "Ссылка открыта. Вставьте точный текст лицензии в поле, прочитайте его и отметьте проверку.";
        UpdateLocalFileActions();
    }

    private void LocalLicenseUrl_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (!_controlsReady) return;
        _localLicenseOpenedForPath = null;
        LocalLicenseCheck.IsChecked = false;
        LocalLicenseCheck.IsEnabled = false;
        ClearRecordedLocalReview();
        UpdateLocalFileActions();
    }

    private void LocalLicenseText_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (!_controlsReady) return;
        LocalLicenseCheck.IsChecked = false;
        ClearRecordedLocalReview();
        UpdateLocalFileActions();
    }

    private void LocalImportTag_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_controlsReady) UpdateLocalFileActions();
    }

    private void ReviewLocalFileButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedLocalFile is null) return;
        var candidate = SelectedLocalFile.Candidate;
        var licenseReference = LocalLicenseUrlText.Text.Trim();
        var licenseText = LocalLicenseTextBox.Text;
        var userReviewedLicense = LocalLicenseCheck.IsChecked == true &&
                                  _localLicenseOpenedForPath == candidate.SourcePath &&
                                  IsHttps(licenseReference) && !string.IsNullOrWhiteSpace(licenseText);
        var compatibilityAccepted = LocalCompatibilityCheck.IsChecked == true;
        var rightsAttested = LocalRightsCheck.IsChecked == true;
        var reviewed = LocalModelFileScanner.AcknowledgeReview(
            candidate,
            userReviewedLicense: userReviewedLicense,
            formatAndCompatibilityAccepted: compatibilityAccepted,
            userRightsAttested: rightsAttested);
        SelectedLocalFile.Update(reviewed);
        var fullyReviewed = reviewed.Status == LocalModelImportStatus.VERIFIED_FORMAT;
        ClearRecordedLocalReview();
        if (fullyReviewed)
        {
            _reviewedLocalFilePath = reviewed.SourcePath;
            _reviewedLocalFileSha256 = reviewed.Sha256;
            _reviewedLicenseReference = licenseReference;
            _reviewedLicenseText = licenseText;
        }
        FileStatusText.Text = fullyReviewed
            ? "Проверка привязана к этому пути и SHA-256. Импорт в Ollama и staging потребуют отдельных подтверждений."
            : reviewed.Status == LocalModelImportStatus.UNSUPPORTED_IMPORT
                ? reviewed.InspectionNote
                : "Нужны HTTPS-ссылка, открытая страница, точный текст лицензии и три отметки: лицензия, совместимость, права.";
        PublishEvent(fullyReviewed ? ModelCenterEventKind.FileFound : ModelCenterEventKind.FileImportBlocked,
            "local-file-review", reviewed.Status.ToString(),
            fullyReviewed
                ? $"User review bound to candidate path and SHA-256 {reviewed.Sha256}; legal rights are not independently verified."
                : "Local file review was incomplete or unsupported.", digest: fullyReviewed ? reviewed.Sha256 : null);
        UpdateLocalFileActions();
    }

    private async void ImportGgufButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedLocalFile is null || !IsCurrentLocalReview(SelectedLocalFile.Candidate))
        {
            FileStatusText.Text = "Сначала откройте и вставьте текст лицензии, подтвердите совместимость и права, затем зарегистрируйте проверку.";
            return;
        }

        var candidate = SelectedLocalFile.Candidate;
        var tag = LocalImportTagText.Text.Trim();
        if (candidate.Format != LocalModelFileFormat.Gguf)
        {
            FileStatusText.Text = "В Ollama через этот поток импортируются только файлы GGUF.";
            return;
        }
        if (string.IsNullOrWhiteSpace(tag))
        {
            FileStatusText.Text = "Укажите тег Ollama для импортируемой модели.";
            return;
        }

        var importConfirmed = MessageBox.Show(this,
            $"Импортировать проверенный GGUF в локальную Ollama под тегом '{tag}'?\n\n" +
            $"Файл: {candidate.SourcePath}\nSHA-256: {candidate.Sha256}\n" +
            "Лицензия, совместимость и права подтверждены отдельно. Существующий тег не будет перезаписан.",
            "Отдельное подтверждение импорта GGUF", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
        if (!importConfirmed)
        {
            LocalImportResultText.Text = "Импорт отменён до запуска; Ollama не изменялась.";
            FileStatusText.Text = "Импорт GGUF отменён пользователем.";
            return;
        }

        var authorization = new OllamaGgufImportAuthorization(
            ReviewedSourcePath: _reviewedLocalFilePath!,
            ReviewedSourceSha256: _reviewedLocalFileSha256!,
            ReviewedLicenseReference: LocalLicenseUrlText.Text.Trim(),
            ReviewedLicenseText: LocalLicenseTextBox.Text,
            UserReviewedExactLicense: LocalLicenseCheck.IsChecked == true &&
                                      _localLicenseOpenedForPath == candidate.SourcePath,
            FormatAndCompatibilityAccepted: LocalCompatibilityCheck.IsChecked == true,
            UserRightsAttested: LocalRightsCheck.IsChecked == true,
            SeparateImportConfirmed: importConfirmed);

        BeginLocalFileAction("Проверяю GGUF и создаю тег через локальную Ollama CLI…");
        try
        {
            var result = await _ggufImporter.ImportAsync(candidate, tag, authorization, _fileActionCts!.Token);
            var readback = result.InstalledDigest is null
                ? "Tag readback: тег не подтверждён в /api/tags."
                : $"Tag readback: {result.Tag} · digest {result.InstalledDigest} · размер " +
                  (result.InstalledSizeBytes is { } installedSize ? FormatBytes(installedSize) : "N/D") + ".";
            LocalImportResultText.Text =
                $"Состояние: {result.State}\n{readback}\n" +
                $"SHA-256 исходного файла: {result.SourceSha256}\n" +
                $"SHA-256 текста лицензии: {result.LicenseTextSha256}\n" +
                $"Код Ollama CLI: {result.ProcessExitCode?.ToString(CultureInfo.InvariantCulture) ?? "N/D"}\n" +
                result.Message;
            FileStatusText.Text = result.State == OllamaGgufImporter.ImportedVerified
                ? "Импорт завершён; tag, digest и размер прочитаны из локальной Ollama."
                : "Импорт выполнен без полной проверки; смотрите статус, tag readback и digest.";
        }
        catch (OperationCanceledException)
        {
            LocalImportResultText.Text = "Импорт отменён. Проверьте список моделей Ollama перед повтором.";
            FileStatusText.Text = "Импорт GGUF отменён.";
        }
        catch (Exception ex)
        {
            LocalImportResultText.Text = "Импорт не выполнен: " + ex.Message;
            FileStatusText.Text = "Импорт GGUF завершился ошибкой.";
        }
        finally { EndLocalFileAction(); }
    }

    private void CancelLocalActionButton_Click(object sender, RoutedEventArgs e) => _fileActionCts?.Cancel();

    private void ChooseStageFolderButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = "Выберите отдельную папку назначения" };
        if (dialog.ShowDialog(this) == true) StageFolderText.Text = dialog.FolderName;
        UpdateLocalFileActions();
    }

    private async void StageLocalFileButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedLocalFile is null || !IsCurrentLocalReview(SelectedLocalFile.Candidate))
        {
            FileStatusText.Text = "Сначала подтвердите лицензию, совместимость и права.";
            return;
        }
        var destination = StageFolderText.Text.Trim();
        if (string.IsNullOrWhiteSpace(destination))
        {
            FileStatusText.Text = "Выберите папку назначения.";
            return;
        }
        var copyConfirmed = MessageBox.Show(this,
                $"Скопировать файл {SelectedLocalFile.Candidate.FileName} в выбранную папку? Источник останется без изменений; файл не будет запускаться.",
                "Подтверждение копирования", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
        if (!copyConfirmed)
        {
            FileStatusText.Text = "Копирование в staging отменено; файл не скопирован и не импортирован.";
            return;
        }

        var operationId = Guid.NewGuid().ToString("N");
        BeginLocalFileAction("Копирую отдельный staging-файл; в Ollama он не импортируется…");
        try
        {
            var authorization = new LocalModelImportAuthorization(
                UserConfirmedCopy: copyConfirmed,
                UserReviewedLicense: LocalLicenseCheck.IsChecked == true &&
                                     _localLicenseOpenedForPath == SelectedLocalFile.Candidate.SourcePath,
                FormatAndCompatibilityAccepted: LocalCompatibilityCheck.IsChecked == true,
                UserRightsAttested: LocalRightsCheck.IsChecked == true);
            var result = await _fileScanner.StageAsync(
                SelectedLocalFile.Candidate, destination, authorization, _fileActionCts!.Token);
            SelectedLocalFile.Update(result.Candidate);
            FileStatusText.Text = result.Staged
                ? $"Файл скопирован в staging · {result.StagedPath}. Он не импортирован в Ollama и не запущен."
                : result.Message;
            PublishEvent(result.Staged ? ModelCenterEventKind.FileFound : ModelCenterEventKind.Error,
                "local-file-stage", result.Staged ? "STAGED_COPY_ONLY" : "BLOCKED",
                result.Staged
                    ? $"Reviewed file copied to staging only; no Ollama import occurred. sha256={result.Candidate.Sha256}"
                    : "Copy-only staging was blocked: " + result.Message,
                bytesCompleted: result.Staged ? result.Candidate.SizeBytes : null,
                bytesTotal: result.Staged ? result.Candidate.SizeBytes : null,
                digest: result.Staged ? result.Candidate.Sha256 : null,
                operationId: operationId);
        }
        catch (OperationCanceledException)
        {
            FileStatusText.Text = "Копирование в staging отменено.";
            PublishEvent(ModelCenterEventKind.Error, "local-file-stage", "CANCELLED",
                "Copy-only staging was cancelled; no Ollama import occurred.", operationId: operationId);
        }
        catch (Exception ex)
        {
            FileStatusText.Text = "Копирование не выполнено: " + ex.Message;
            PublishEvent(ModelCenterEventKind.Error, "local-file-stage", "FAILED",
                "Copy-only staging failed; no Ollama import occurred.", errorCode: ex.GetType().Name, operationId: operationId);
        }
        finally { EndLocalFileAction(); }
    }

    private void ChooseBackupPathButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog
        {
            AddExtension = true,
            DefaultExt = ".zip",
            Filter = "NOX backup (*.zip)|*.zip",
            FileName = "NOX_BACKUP_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".zip"
        };
        if (dialog.ShowDialog(this) == true) BackupArchiveText.Text = dialog.FileName;
        UpdateBackupActions();
    }

    private void ChooseRestoreArchiveButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { CheckFileExists = true, Filter = "NOX backup (*.zip)|*.zip" };
        if (dialog.ShowDialog(this) == true) RestoreArchiveText.Text = dialog.FileName;
        UpdateBackupActions();
    }

    private void ChooseRestoreDestinationButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = "Выберите корневую папку восстановления" };
        if (dialog.ShowDialog(this) == true) RestoreDestinationText.Text = dialog.FolderName;
        UpdateBackupActions();
    }

    private async void CreateBackupButton_Click(object sender, RoutedEventArgs e)
    {
        var scopes = BackupRestoreService.DefaultScopes(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile))
            .Where(scope =>
                (scope.Name == "nox-integrator" && BackupNoxScopeCheck.IsChecked == true) ||
                (scope.Name == "ollama-model-store" && BackupOllamaScopeCheck.IsChecked == true))
            .ToArray();
        var archive = BackupArchiveText.Text.Trim();
        if (scopes.Length == 0 || string.IsNullOrWhiteSpace(archive))
        {
            BackupStatusText.Text = "Выберите хотя бы одну область и путь архива.";
            return;
        }
        var availableScopes = scopes.Where(scope => Directory.Exists(scope.RootPath)).ToArray();
        if (availableScopes.Length == 0)
        {
            BackupStatusText.Text = "Выбранные области не найдены на этом ПК; пустой архив не создавался.";
            return;
        }
        if (MessageBox.Show(this, "Создать архив выбранных областей? Секретные файлы и ссылки будут пропущены.",
                "Подтверждение резервного копирования", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
        {
            BackupStatusText.Text = "Резервное копирование отменено до запуска; архив не создан.";
            return;
        }

        _backupCts?.Cancel();
        _backupCts?.Dispose();
        _backupCts = new CancellationTokenSource();
        UpdateBackupActions();
        BackupStatusText.Text = availableScopes.Length > 1
            ? "Создаю отдельный ZIP с SHA-256 манифестом для каждой области…"
            : "Создаю архив и SHA-256 манифест…";
        var createdBackups = new List<BackupResult>();
        try
        {
            var fullArchive = Path.GetFullPath(archive);
            var parent = Path.GetDirectoryName(fullArchive)!;
            var baseName = Path.GetFileNameWithoutExtension(fullArchive);
            var extension = Path.GetExtension(fullArchive);
            var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture);

            foreach (var scope in availableScopes)
            {
                _backupCts.Token.ThrowIfCancellationRequested();
                var outputPath = availableScopes.Length == 1
                    ? fullArchive
                    : Path.Combine(parent, $"{baseName}_{scope.Name}_{stamp}{extension}");
                var result = await _backupRestoreService.CreateBackupAsync(
                    outputPath, new[] { scope }, _backupCts.Token);
                createdBackups.Add(result);
            }
            var summary = createdBackups.Select(result =>
                $"{Path.GetFileName(result.ArchivePath)} · {result.FileCount} файлов · {FormatBytes(result.SizeBytes)} · SHA-256 {ShortDigest(result.Sha256)}");
            var skipped = scopes.Except(availableScopes).Select(scope => scope.Name).ToArray();
            BackupStatusText.Text = string.Join(Environment.NewLine, summary) +
                (skipped.Length == 0 ? "" : Environment.NewLine + "Не найдены, пропущены: " + string.Join(", ", skipped));
        }
        catch (OperationCanceledException)
        {
            BackupStatusText.Text = createdBackups.Count == 0
                ? "Резервное копирование отменено."
                : $"Отменено после создания {createdBackups.Count} архива(ов): " +
                  string.Join(", ", createdBackups.Select(result => Path.GetFileName(result.ArchivePath)));
        }
        catch (Exception ex)
        {
            BackupStatusText.Text = (createdBackups.Count == 0 ? "" : "Уже созданы: " +
                string.Join(", ", createdBackups.Select(result => Path.GetFileName(result.ArchivePath))) + ". ") +
                "Резервное копирование не выполнено: " + ex.Message;
        }
        finally
        {
            _backupCts.Dispose();
            _backupCts = null;
            UpdateBackupActions();
        }
    }

    private async void RestoreBackupButton_Click(object sender, RoutedEventArgs e)
    {
        var archive = RestoreArchiveText.Text.Trim();
        var destination = RestoreDestinationText.Text.Trim();
        if (string.IsNullOrWhiteSpace(archive) || string.IsNullOrWhiteSpace(destination))
        {
            BackupStatusText.Text = "Выберите архив и папку назначения.";
            return;
        }
        if (MessageBox.Show(this, "Начать проверку архива и восстановление в выбранную папку?",
                "Подтверждение восстановления", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
        {
            BackupStatusText.Text = "Восстановление отменено до проверки архива; файлы не изменялись.";
            return;
        }

        _backupCts?.Cancel();
        _backupCts?.Dispose();
        _backupCts = new CancellationTokenSource();
        UpdateBackupActions();
        BackupStatusText.Text = "Проверяю манифест и SHA-256 перед восстановлением…";
        try
        {
            async Task<bool> ConfirmRestoreAsync(string message)
            {
                var operation = Dispatcher.InvokeAsync(() =>
                    MessageBox.Show(this, message, "Подтверждение восстановления",
                        MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes);
                return await operation.Task;
            }

            var result = await _backupRestoreService.RestoreAsync(archive, destination, ConfirmRestoreAsync, _backupCts.Token);
            if (result.State == "COMPLETED")
                BackupStatusText.Text = $"Восстановлено {result.RestoredFiles}; SHA-256 проверено {result.VerifiedFiles} файлов.";
            else if (result.State == "CANCELLED" || _backupCts.IsCancellationRequested)
                BackupStatusText.Text = "Восстановление отменено. При прерывании во время записи сервис откатывает уже заменённые файлы. " + result.Error;
            else
                BackupStatusText.Text = $"Восстановление: {result.State}. {result.Error}";
        }
        catch (Exception ex) { BackupStatusText.Text = "Восстановление не выполнено: " + ex.Message; }
        finally
        {
            _backupCts.Dispose();
            _backupCts = null;
            UpdateBackupActions();
        }
    }

    private void CancelBackupButton_Click(object sender, RoutedEventArgs e) => _backupCts?.Cancel();
    private void BackupPath_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) => UpdateBackupActions();
    private void StageFolder_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_controlsReady) UpdateLocalFileActions();
    }
    private void UpdateBackupActions()
    {
        if (CreateBackupButton is not null)
        {
            CreateBackupButton.IsEnabled = _backupCts is null &&
                (BackupNoxScopeCheck.IsChecked == true || BackupOllamaScopeCheck.IsChecked == true) &&
                !string.IsNullOrWhiteSpace(BackupArchiveText.Text);
            RestoreBackupButton.IsEnabled = _backupCts is null &&
                !string.IsNullOrWhiteSpace(RestoreArchiveText.Text) &&
                !string.IsNullOrWhiteSpace(RestoreDestinationText.Text);
            CancelBackupButton.IsEnabled = _backupCts is not null;
        }
    }

    private void BackupScopeCheck_Changed(object sender, RoutedEventArgs e) => UpdateBackupActions();

    private void EventHub_EventRaised(object? sender, ModelCenterEvent modelCenterEvent)
    {
        if (Dispatcher.HasShutdownStarted) return;
        Dispatcher.InvokeAsync(() =>
        {
            Events.Insert(0, modelCenterEvent);
            while (Events.Count > 300) Events.RemoveAt(Events.Count - 1);
            EventSummaryText.Text = $"{modelCenterEvent.TimestampUtc:HH:mm:ss} · {modelCenterEvent.Kind} · {modelCenterEvent.State}";
        });
    }

    private void QueueStore_WarningRaised(object? sender, DownloadQueueWarningEventArgs warning)
    {
        try { SurfaceQueueWarning(warning.Message); }
        catch { /* Queue recovery warnings must never break queue loading. */ }
    }

    private void SurfaceQueueWarning(string? warning)
    {
        if (string.IsNullOrWhiteSpace(warning) || warning == _surfaceQueueWarningText || Dispatcher.HasShutdownStarted)
            return;
        _surfaceQueueWarningText = warning;

        void Apply()
        {
            try
            {
                StatusLine = "Восстановление очереди: " + warning;
                PublishEvent(ModelCenterEventKind.Error, "model-download-queue", "QUEUE_RECOVERY_WARNING", warning);
            }
            catch { /* UI subscribers cannot interrupt store recovery. */ }
        }

        if (Dispatcher.CheckAccess()) Apply();
        else Dispatcher.BeginInvoke(Apply);
    }

    private async void Window_Closing(object? sender, CancelEventArgs e)
    {
        _closing = true;
        if (_allowCloseAfterPull)
        {
            CancelWindowOperations();
            return;
        }
        if (_waitingForPullClose)
        {
            e.Cancel = true;
            return;
        }

        if (_activeQueueId is not null)
        {
            e.Cancel = true;
            _waitingForPullClose = true;
            try
            {
                var pausedItem = _queueStore.Pause(_activeQueueId);
                ShowQueueState(pausedItem);
                var item = _queueStore.Items.FirstOrDefault(x => x.Id == _activeQueueId);
            }
            catch { }
            _pullCts?.Cancel();
            CancelWindowOperations();
            var activePullSettled = _activePullSettled?.Task;
            if (activePullSettled is not null) await activePullSettled;
            _waitingForPullClose = false;
            _allowCloseAfterPull = true;
            Close();
            return;
        }

        CancelWindowOperations();
    }

    private void CancelWindowOperations()
    {
        _componentCts?.Cancel();
        _fileScanCts?.Cancel();
        _fileActionCts?.Cancel();
        _backupCts?.Cancel();
    }

    private void Window_Closed(object? sender, EventArgs e)
    {
        _windowClosed = true;
        _queueStore.Items.CollectionChanged -= _queueItemsChanged;
        _queueStore.WarningRaised -= QueueStore_WarningRaised;
        _queueStore.StateChanged -= QueueStore_StateChanged;
        EventHub.EventRaised -= EventHub_EventRaised;
        if (_activeQueueId is null)
        {
            _pullService.Dispose();
            _queueStore.Dispose();
        }
        if (_fileActionCts is null) _ggufImporter.Dispose();
    }

    private void PublishEvent(
        ModelCenterEventKind kind,
        string componentId,
        string state,
        string message,
        long? bytesCompleted = null,
        long? bytesTotal = null,
        string? digest = null,
        string? errorCode = null,
        string? operationId = null)
    {
        var percent = bytesTotal is > 0 && bytesCompleted is not null
            ? Math.Clamp(bytesCompleted.Value * 100d / bytesTotal.Value, 0, 100)
            : null;
        _eventSink.Publish(new ModelCenterEvent
        {
            Kind = kind,
            ComponentId = componentId,
            State = state,
            Message = message,
            ProgressPercent = percent,
            BytesCompleted = bytesCompleted,
            BytesTotal = bytesTotal,
            Sha256Digest = digest,
            ErrorCode = errorCode,
            OperationId = operationId
        });
    }

    private void UpdateLocalFileActions()
    {
        if (ReviewLocalFileButton is null) return;
        var candidate = SelectedLocalFile?.Candidate;
        var licenseOpened = candidate is not null && _localLicenseOpenedForPath == candidate.SourcePath;
        var licenseReference = LocalLicenseUrlText.Text.Trim();
        var licenseTextPresent = !string.IsNullOrWhiteSpace(LocalLicenseTextBox.Text) &&
                                 LocalLicenseTextBox.Text.Length <= 1_000_000;
        OpenLocalLicenseButton.IsEnabled = candidate is not null && IsHttps(licenseReference);
        LocalLicenseCheck.IsEnabled = licenseOpened && licenseTextPresent;
        var supported = candidate is { FormatVerified: true, Status: not LocalModelImportStatus.UNSUPPORTED_IMPORT };
        var allReviewChecks = licenseOpened && licenseTextPresent && IsHttps(licenseReference) &&
                              LocalLicenseCheck.IsChecked == true &&
                              LocalCompatibilityCheck.IsChecked == true &&
                              LocalRightsCheck.IsChecked == true;
        ReviewLocalFileButton.IsEnabled = supported && allReviewChecks;
        var reviewCurrent = candidate is not null && IsCurrentLocalReview(candidate);
        StageLocalFileButton.IsEnabled = reviewCurrent && !string.IsNullOrWhiteSpace(StageFolderText.Text) &&
                                         _fileActionCts is null;
        ImportGgufButton.IsEnabled = reviewCurrent && candidate?.Format == LocalModelFileFormat.Gguf &&
                                    !string.IsNullOrWhiteSpace(LocalImportTagText.Text.Trim()) &&
                                    _fileActionCts is null;
        CancelLocalActionButton.IsEnabled = _fileActionCts is not null;
        ScanFilesButton.IsEnabled = _fileActionCts is null && _fileScanCts is null;
    }

    private bool IsCurrentLocalReview(LocalModelCandidate candidate) =>
        candidate.Status == LocalModelImportStatus.VERIFIED_FORMAT &&
        candidate.FormatVerified &&
        LocalLicenseCheck.IsChecked == true &&
        LocalCompatibilityCheck.IsChecked == true &&
        LocalRightsCheck.IsChecked == true &&
        _localLicenseOpenedForPath == candidate.SourcePath &&
        string.Equals(_reviewedLocalFilePath, candidate.SourcePath, StringComparison.OrdinalIgnoreCase) &&
        string.Equals(_reviewedLocalFileSha256, candidate.Sha256, StringComparison.OrdinalIgnoreCase) &&
        string.Equals(_reviewedLicenseReference, LocalLicenseUrlText.Text.Trim(), StringComparison.Ordinal) &&
        string.Equals(_reviewedLicenseText, LocalLicenseTextBox.Text, StringComparison.Ordinal) &&
        IsHttps(LocalLicenseUrlText.Text.Trim()) &&
        !string.IsNullOrWhiteSpace(LocalLicenseTextBox.Text) &&
        LocalLicenseTextBox.Text.Length <= 1_000_000;

    private void ClearRecordedLocalReview()
    {
        _reviewedLocalFilePath = null;
        _reviewedLocalFileSha256 = null;
        _reviewedLicenseReference = null;
        _reviewedLicenseText = null;
    }

    private static string SuggestedLocalImportTag(LocalModelCandidate candidate) =>
        "nox-local-" + candidate.Sha256[..Math.Min(candidate.Sha256.Length, 12)].ToLowerInvariant();

    private void BeginLocalFileAction(string status)
    {
        _fileActionCts?.Cancel();
        _fileActionCts?.Dispose();
        _fileActionCts = new CancellationTokenSource();
        FileStatusText.Text = status;
        ScanProgressBar.IsIndeterminate = true;
        UpdateLocalFileActions();
    }

    private void EndLocalFileAction()
    {
        _fileActionCts?.Dispose();
        _fileActionCts = null;
        ScanProgressBar.IsIndeterminate = false;
        if (_closing) _ggufImporter.Dispose();
        UpdateLocalFileActions();
    }

    private void RefreshComponentActionsGuarded()
    {
        if (ComponentRunButton is not null) RefreshComponentActions();
    }

    private void RefreshComponentActions()
    {
        var hasComponent = SelectedComponent is not null;
        var operation = ReadComponentOperation();
        var agreementRequired = operation is ComponentOperation.Install or ComponentOperation.Update;
        ComponentProductButton.IsEnabled = hasComponent && IsHttps(SelectedComponent!.Package.ProductPage);
        ComponentTermsButton.IsEnabled = hasComponent && IsHttps(SelectedComponent!.Package.LicensePage);
        PackageAgreementCheck.IsEnabled = hasComponent && agreementRequired && _componentLicensePageOpened;
        ComponentRunButton.IsEnabled = hasComponent &&
            (!agreementRequired || (_componentLicensePageOpened && PackageAgreementCheck.IsChecked == true)) &&
            _componentCts is null;
        ComponentCancelButton.IsEnabled = _componentCts is not null;
    }

    private ComponentOperation ReadComponentOperation()
    {
        var value = ComponentOperationCombo.SelectedValue as string;
        return Enum.TryParse<ComponentOperation>(value, ignoreCase: true, out var operation)
            ? operation
            : ComponentOperation.Install;
    }

    private static bool IsHttps(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme == Uri.UriSchemeHttps;

    private static bool OpenExternal(string? value)
    {
        if (!IsHttps(value)) return false;
        try { Process.Start(new ProcessStartInfo(value!) { UseShellExecute = true }); return true; }
        catch { return false; }
    }

    private static bool IsState(string? state, string expected) =>
        string.Equals(state, expected, StringComparison.OrdinalIgnoreCase);
    private static bool IsTerminalQueueState(string? state) =>
        IsState(state, "COMPLETED") || IsState(state, "CANCELLED");

    private static string FormatBytes(long bytes)
    {
        string[] units = { "B", "KiB", "MiB", "GiB", "TiB" };
        double value = Math.Max(0, bytes);
        var unit = 0;
        while (value >= 1024 && unit < units.Length - 1) { value /= 1024; unit++; }
        return $"{value:0.#} {units[unit]}";
    }

    private static string ShortDigest(string? digest) =>
        string.IsNullOrWhiteSpace(digest) ? "N/D" : digest.Length > 18 ? digest[..10] + "…" + digest[^6..] : digest;

    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    private sealed class SafeEventSink : IModelCenterEventSink
    {
        private readonly IModelCenterEventSink _inner;
        public SafeEventSink(IModelCenterEventSink inner) => _inner = inner;
        public void Publish(ModelCenterEvent modelCenterEvent)
        {
            try { _inner.Publish(modelCenterEvent); } catch { }
        }
    }

    public sealed class CatalogRow : INotifyPropertyChanged
    {
        private bool _installed;
        private long? _installedSizeBytes;
        public event PropertyChangedEventHandler? PropertyChanged;
        public ModelCatalogEntry Entry { get; }
        public string Tag => Entry.Tag;
        public string Title => Entry.Title;
        public string Category => Entry.Category;
        public string ModelPageUrl => Entry.ModelPageUrl;
        public string LicenseUrl => Entry.LicenseUrl;
        public string LicenseStatus => Entry.LicenseStatus;
        public double? EstimatedMinVramGiB => Entry.EstimatedMinVramGiB;
        public string VramText => EstimatedMinVramGiB is { } value ? $"{value:0.#} GiB" : "N/D";
        public string SizeSourceStatus => Entry.SizeSourceStatus;
        public string SizeDisplay => _installedSizeBytes is > 0
            ? ModelDownloaderWindow.FormatBytes(_installedSizeBytes.Value)
            : _installed ? "Локальный размер N/D" : "Локально не измерен до загрузки";
        public string SizeToolTip => _installedSizeBytes is > 0
            ? "Локальный размер прочитан из Ollama /api/tags после загрузки."
            : _installed
                ? "Модель обнаружена локально, но размер не подтверждён в Ollama /api/tags."
                : "Размеры на официальной странице Ollama могут меняться. Здесь показывается только локально измеренный размер после pull; параметр модели указан в названии. До загрузки локально не измерен.";
        public string InstalledText => _installed ? "УСТАНОВЛЕНА" : "—";
        public CatalogRow(ModelCatalogEntry entry) => Entry = entry;
        public void SetInstalled(bool installed, long? installedSizeBytes = null)
        {
            var safeSize = installedSizeBytes is > 0 ? installedSizeBytes : null;
            if (_installed == installed && _installedSizeBytes == safeSize) return;
            _installed = installed;
            _installedSizeBytes = safeSize;
            foreach (var property in new[] { nameof(InstalledText), nameof(SizeDisplay), nameof(SizeToolTip) })
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }

    public sealed class ComponentRow : INotifyPropertyChanged
    {
        private string _inventoryStatus = "N/D";
        private string _versionOrPath = "N/D";
        public event PropertyChangedEventHandler? PropertyChanged;
        public ComponentPackage Package { get; }
        public string Id => Package.Id;
        public string Name => Package.Name;
        public string Publisher => Package.Publisher;
        public string InventoryStatus => _inventoryStatus;
        public string VersionOrPath => _versionOrPath;
        public ComponentRow(ComponentPackage package) => Package = package;
        public void UpdateInventory(string status, string versionOrPath)
        {
            _inventoryStatus = status;
            _versionOrPath = versionOrPath;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(InventoryStatus)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(VersionOrPath)));
        }
    }

    public sealed class LocalFileRow : INotifyPropertyChanged
    {
        private LocalModelCandidate _candidate;
        public event PropertyChangedEventHandler? PropertyChanged;
        public LocalModelCandidate Candidate => _candidate;
        public string FileName => _candidate.FileName;
        public string Format => _candidate.Format.ToString();
        public string Status => _candidate.Status.ToString();
        public string Size => FormatBytes(_candidate.SizeBytes);
        public string Sha256 => _candidate.Sha256;
        public string InspectionNote => _candidate.InspectionNote;
        public LocalFileRow(LocalModelCandidate candidate) => _candidate = candidate;
        public void Update(LocalModelCandidate candidate)
        {
            _candidate = candidate;
            foreach (var property in new[] { nameof(FileName), nameof(Format), nameof(Status), nameof(Size), nameof(Sha256), nameof(InspectionNote) })
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }
}

/// <summary>Factory for hosts that want a standalone native Model Center window.</summary>
public static class ModelCenterLauncher
{
    public static Window CreateWindow() => new ModelDownloaderWindow();
    public static Window CreateWindow(ModelCenterEventHub eventHub) => new ModelDownloaderWindow(eventHub: eventHub);
}
