# Source and licensing notes

This module adapts the user-provided NOX R6 installer and NOX V6 model hub references, plus the later R7 source inventory, without modifying the Executor 01 shell. The V6 reference is a Windows binary and was not executed. The R6/R7 GUI model lists informed the catalog; this package replaces separate CMD pulls with the Ollama local API and a persistent queue.

- User R6 Installer source: https://drive.google.com/file/d/1hZM59TOnXgNnxvlDPc-8SFXWCJ11QdmX/view
- User V6 Model Hub reference (binary, not run): https://drive.google.com/file/d/1AW9IbgOco4m1PkGPu8_9D2Ie6ldk8rtG/view

## Runtime source links

- Ollama API pull: https://docs.ollama.com/api/pull
- Ollama installed-model metadata: https://docs.ollama.com/api/tags
- Official Ollama model library: https://ollama.com/library
- WinGet usage and package operations: https://learn.microsoft.com/windows/package-manager/winget/
- WinGet package manifests: https://github.com/microsoft/winget-pkgs
- WebView2 WPF NuGet package (pinned at 1.0.4314.35): https://www.nuget.org/packages/Microsoft.Web.WebView2/
- Python licensing: https://docs.python.org/3/license.html
- Git licensing: https://git-scm.com/about/free-and-open-source
- Ollama source license: https://github.com/ollama/ollama/blob/main/LICENSE
- WebView2 runtime detection: https://learn.microsoft.com/dotnet/api/microsoft.web.webview2.core.corewebview2environment.getavailablebrowserversionstring

## Catalog and integrity policy

All 24 model tags point to `https://ollama.com/library/{slug}`. License terms are not inferred from model names; all entries remain `REVIEW_REQUIRED` until a user reviews the model card and license. Download sizes, VRAM fit, and third-party catalog checksums are `N/D` unless supported by measured/source evidence. A successful Ollama pull is reported with the digest and size read back from `/api/tags`; that is an Ollama integrity receipt, not a claim that the installed bytes were compared with a separately pinned catalog checksum.

## Web-release boundary

The latest WEB RELEASE V1.2 requirement was reread for this package. Its newer G02-R7 entry describes a 21/21 local-test source candidate without live Ollama response or independent acceptance; accepted WEB progress remains N/D and release remains blocked. Browser delivery does not imply Windows EXE acceptance; PC control is optional and must remain local, consent-based, and stoppable. This WPF candidate does not change WEB progress or product acceptance status.

