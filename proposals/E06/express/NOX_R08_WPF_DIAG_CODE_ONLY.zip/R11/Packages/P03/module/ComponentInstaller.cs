using System.Diagnostics;
using System.Text.RegularExpressions;

namespace NOX.P01.ModelCenter;

public enum ComponentOperation
{
    Install,
    Update,
    Remove
}

public sealed record ComponentPackage(
    string Id,
    string Name,
    string Publisher,
    string ProductPage,
    string LicensePage);

/// <summary>
/// Runs a small allowlist of WinGet operations without a console window or
/// shell interpolation. The process is not explicitly launched with runas;
/// package installers may still request UAC/elevation when required. Install
/// and update require explicit package-agreement confirmation.
/// </summary>
public sealed class ComponentInstaller
{
    private static readonly IReadOnlyDictionary<string, ComponentPackage> Packages =
        new Dictionary<string, ComponentPackage>(StringComparer.OrdinalIgnoreCase)
        {
            ["Python.Python.3.12"] = new(
                "Python.Python.3.12", "Python 3.12", "Python Software Foundation",
                "https://www.python.org/", "https://docs.python.org/3/license.html"),
            ["Ollama.Ollama"] = new(
                "Ollama.Ollama", "Ollama", "Ollama",
                "https://ollama.com/", "https://github.com/ollama/ollama/blob/main/LICENSE"),
            ["Git.Git"] = new(
                "Git.Git", "Git", "Software Freedom Conservancy",
                "https://git-scm.com/", "https://git-scm.com/about/free-and-open-source"),
            ["Microsoft.EdgeWebView2Runtime"] = new(
                "Microsoft.EdgeWebView2Runtime", "Microsoft Edge WebView2 Runtime", "Microsoft Corporation",
                "https://developer.microsoft.com/microsoft-edge/webview2/", "https://www.microsoft.com/legal/terms-of-use"),
            ["Microsoft.VCRedist.2015+.x64"] = new(
                "Microsoft.VCRedist.2015+.x64", "Microsoft Visual C++ Redistributable x64", "Microsoft Corporation",
                "https://learn.microsoft.com/cpp/windows/latest-supported-vc-redist", "https://www.microsoft.com/legal/terms-of-use"),
            ["Microsoft.DotNet.DesktopRuntime.8"] = new(
                "Microsoft.DotNet.DesktopRuntime.8", ".NET Desktop Runtime 8", "Microsoft Corporation",
                "https://dotnet.microsoft.com/download/dotnet/8.0", "https://dotnet.microsoft.com/platform/free")
        };

    private static readonly Regex SecretLine =
        new(@"(?i)(token|password|secret|api[_-]?key|authorization)\s*[:=]\s*[^\s]+", RegexOptions.Compiled);
    private readonly IModelCenterEventSink? _events;

    public ComponentInstaller(IModelCenterEventSink? events = null) => _events = events;

    public static IReadOnlyCollection<ComponentPackage> ApprovedPackages => Packages.Values.ToArray();

    public static bool TryGetApprovedPackage(string id, out ComponentPackage package) =>
        Packages.TryGetValue(id, out package!);

    public async Task<int> RunAsync(
        string packageId,
        ComponentOperation operation,
        bool actionConfirmed,
        bool packageAgreementConfirmed,
        CancellationToken cancellationToken = default)
    {
        if (!Packages.TryGetValue(packageId, out var package))
            throw new InvalidOperationException("Component is not on the approved WinGet allowlist.");
        if (!actionConfirmed)
            throw new UnauthorizedAccessException("Explicit user confirmation is required for this operation.");
        if (operation is ComponentOperation.Install or ComponentOperation.Update && !packageAgreementConfirmed)
            throw new UnauthorizedAccessException("Package agreement must be reviewed and explicitly accepted.");
        var operationId = Guid.NewGuid().ToString("N");
        var operationLogPath = CreateOperationLogPath(operationId);

        var winget = FindWinget();
        if (winget is null)
            throw new FileNotFoundException("WinGet was not found. Install Microsoft App Installer from Microsoft Store.");

        var start = new ProcessStartInfo
        {
            FileName = winget,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            WorkingDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
        };
        start.ArgumentList.Add(operation switch
        {
            ComponentOperation.Install => "install",
            ComponentOperation.Update => "upgrade",
            ComponentOperation.Remove => "uninstall",
            _ => throw new ArgumentOutOfRangeException(nameof(operation))
        });
        start.ArgumentList.Add("--id");
        start.ArgumentList.Add(package.Id);
        start.ArgumentList.Add("--exact");
        start.ArgumentList.Add("--source");
        start.ArgumentList.Add("winget");
        start.ArgumentList.Add("--disable-interactivity");
        start.ArgumentList.Add("--log");
        start.ArgumentList.Add(operationLogPath);

        if (operation is ComponentOperation.Install or ComponentOperation.Update)
        {
            start.ArgumentList.Add("--accept-source-agreements");
            // This flag is only sent after the caller has presented package terms and
            // passed the explicit user agreement checkbox.
            start.ArgumentList.Add("--accept-package-agreements");
        }

        var kind = operation switch
        {
            ComponentOperation.Install => ModelCenterEventKind.InstallStarted,
            ComponentOperation.Update => ModelCenterEventKind.UpdateStarted,
            ComponentOperation.Remove => ModelCenterEventKind.RemoveStarted,
            _ => ModelCenterEventKind.Error
        };
        _events?.Publish(new ModelCenterEvent
        {
            Kind = kind,
            ComponentId = package.Id,
            State = "RUNNING",
            Message = $"{operation} started after explicit confirmation. WinGet log: {operationLogPath}",
            OperationId = operationId
        });

        using var process = new Process { StartInfo = start, EnableRaisingEvents = true };
        try
        {
            if (!process.Start()) throw new InvalidOperationException("WinGet failed to start.");
        }
        catch (Exception ex)
        {
            PublishFailure(package, operation, "WINGET_START_FAILED", ex.Message, operationId);
            throw;
        }

        var stdout = PumpAsync(process.StandardOutput, package, operation, operationId, cancellationToken);
        var stderr = PumpAsync(process.StandardError, package, operation, operationId, cancellationToken);
        try
        {
            await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);
            await Task.WhenAll(stdout, stderr).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
            PublishFailure(package, operation, "CANCELLED", "The confirmed component operation was cancelled.", operationId);
            throw;
        }

        if (process.ExitCode != 0)
        {
            PublishFailure(package, operation, "WINGET_EXIT_" + process.ExitCode,
                $"WinGet exited with code {process.ExitCode}; see the local event stream.", operationId);
            return process.ExitCode;
        }

        var successKind = operation switch
        {
            ComponentOperation.Install => ModelCenterEventKind.InstallCompleted,
            ComponentOperation.Update => ModelCenterEventKind.UpdateCompleted,
            ComponentOperation.Remove => ModelCenterEventKind.RemoveCompleted,
            _ => ModelCenterEventKind.Error
        };
        _events?.Publish(new ModelCenterEvent
        {
            Kind = successKind,
            ComponentId = package.Id,
            State = "COMPLETED",
            Message = $"{package.Name} {operation.ToString().ToLowerInvariant()} completed.",
            OperationId = operationId
        });
        return 0;
    }

    private async Task PumpAsync(
        StreamReader reader,
        ComponentPackage package,
        ComponentOperation operation,
        string operationId,
        CancellationToken cancellationToken)
    {
        while (await reader.ReadLineAsync(cancellationToken).ConfigureAwait(false) is { } line)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            var safeLine = SecretLine.Replace(line, "$1=[REDACTED]");
            double? progressPercent = null;
            var match = Regex.Match(safeLine, @"(?<!\d)(?<percent>\d{1,3}(?:\.\d+)?)%", RegexOptions.CultureInvariant);
            if (match.Success &&
                double.TryParse(match.Groups["percent"].Value, System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out var parsed) &&
                parsed is >= 0 and <= 100)
                progressPercent = parsed;
            _events?.Publish(new ModelCenterEvent
            {
                Kind = ModelCenterEventKind.InstallOutput,
                ComponentId = package.Id,
                State = operation.ToString().ToUpperInvariant(),
                Message = safeLine.Length > 1000 ? safeLine[..1000] : safeLine,
                ProgressPercent = progressPercent,
                OperationId = operationId
            });
        }
    }

    private void PublishFailure(ComponentPackage package, ComponentOperation operation, string code, string message, string operationId)
    {
        var kind = operation switch
        {
            ComponentOperation.Install => ModelCenterEventKind.InstallFailed,
            ComponentOperation.Update => ModelCenterEventKind.InstallFailed,
            ComponentOperation.Remove => ModelCenterEventKind.Error,
            _ => ModelCenterEventKind.Error
        };
        _events?.Publish(new ModelCenterEvent
        {
            Kind = kind,
            ComponentId = package.Id,
            State = "FAILED",
            Message = message,
            ErrorCode = code,
            OperationId = operationId
        });
    }

    private static string CreateOperationLogPath(string operationId)
    {
        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (string.IsNullOrWhiteSpace(localAppData))
            throw new InvalidOperationException("The local application data directory is unavailable for WinGet logs.");

        var logDirectory = Path.Combine(localAppData, "NOX", "Logs", "WinGet");
        Directory.CreateDirectory(logDirectory);
        var timestamp = DateTimeOffset.UtcNow.ToString("yyyyMMdd'T'HHmmss'Z'", System.Globalization.CultureInfo.InvariantCulture);
        return Path.Combine(logDirectory, $"{timestamp}_{operationId}.log");
    }

    private static string? FindWinget()
    {
        // Resolve WinGet only through the Windows App Installer execution alias.
        // A PATH search could launch an unrelated or attacker-planted winget.exe
        // while the caller assumes the Microsoft package manager is being used.
        var appAlias = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Microsoft", "WindowsApps", "winget.exe");
        return File.Exists(appAlias) ? appAlias : null;
    }
}
