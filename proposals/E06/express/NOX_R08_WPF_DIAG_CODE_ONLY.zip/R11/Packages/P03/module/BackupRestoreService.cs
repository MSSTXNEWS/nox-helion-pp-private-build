using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace NOX.P01.ModelCenter;

public sealed record BackupScope(string Name, string RootPath);
public sealed record BackupFileRecord(string Entry, long SizeBytes, string Sha256);
public sealed record BackupManifest(int SchemaVersion, DateTimeOffset CreatedUtc, IReadOnlyList<BackupFileRecord> Files);
public sealed record BackupResult(string ArchivePath, int FileCount, long SizeBytes, string Sha256);
public sealed record RestoreResult(string State, int RestoredFiles, int VerifiedFiles, string? Error);

/// <summary>
/// Creates verifiable ZIP backups and restores only after full path/hash
/// validation and explicit confirmation. Secrets and reparse points are skipped.
/// Existing destination files are preserved for rollback; unrelated files are
/// never deleted.
/// </summary>
public sealed class BackupRestoreService
{
    private const int MaxRestoreFiles = 100_000;
    private const long MaxManifestBytes = 16 * 1024 * 1024;
    private const long MaxRestoreTotalBytes = 4L * 1024 * 1024 * 1024 * 1024;
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private readonly IModelCenterEventSink? _events;

    public BackupRestoreService(IModelCenterEventSink? events = null) => _events = events;

    public async Task<BackupResult> CreateBackupAsync(
        string archivePath,
        IEnumerable<BackupScope> scopes,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(archivePath);
        var selected = scopes?.Where(scope => !string.IsNullOrWhiteSpace(scope.Name) &&
            !string.IsNullOrWhiteSpace(scope.RootPath)).ToArray() ?? Array.Empty<BackupScope>();
        if (selected.Length == 0) throw new ArgumentException("Choose at least one backup scope.", nameof(scopes));
        if (selected.Any(scope => !IsSafeScopeName(scope.Name)) ||
            selected.Select(scope => scope.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != selected.Length)
            throw new ArgumentException("Backup scope names must be unique safe identifiers.", nameof(scopes));
        var operationId = Guid.NewGuid().ToString("N");

        var fullArchivePath = Path.GetFullPath(archivePath);
        if (selected.Any(scope => IsWithinDirectory(fullArchivePath, Path.GetFullPath(scope.RootPath))))
            throw new InvalidOperationException("Choose a backup destination outside the selected source folders.");
        var parent = Path.GetDirectoryName(fullArchivePath)!;
        Directory.CreateDirectory(parent);
        var temp = fullArchivePath + ".partial-" + Guid.NewGuid().ToString("N");
        var records = new List<BackupFileRecord>();
        long bytes = 0;

        Publish(ModelCenterEventKind.BackupStarted, "RUNNING", "Backup started.", operationId: operationId);
        try
        {
            await using (var archiveFile = new FileStream(temp, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None, 128 * 1024, useAsync: true))
            using (var archive = new ZipArchive(archiveFile, ZipArchiveMode.Create, leaveOpen: true, Encoding.UTF8))
            {
                foreach (var scope in selected)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    var root = Path.GetFullPath(scope.RootPath);
                    if (!Directory.Exists(root)) continue;
                    foreach (var file in EnumerateRegularFiles(root))
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        var attributes = File.GetAttributes(file);
                        if ((attributes & FileAttributes.ReparsePoint) != 0 || IsSensitive(Path.GetFileName(file)))
                            continue;
                        var relative = Path.GetRelativePath(root, file);
                        var entryName = NormalizeArchivePath(scope.Name + "/" + relative);
                        var entry = archive.CreateEntry(entryName, CompressionLevel.Optimal);
                        long fileSize = 0;
                        using var sha = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                        await using (var input = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read, 128 * 1024, useAsync: true))
                        await using (var output = entry.Open())
                        {
                            var buffer = new byte[128 * 1024];
                            int read;
                            while ((read = await input.ReadAsync(buffer, cancellationToken).ConfigureAwait(false)) > 0)
                            {
                                await output.WriteAsync(buffer.AsMemory(0, read), cancellationToken).ConfigureAwait(false);
                                sha.AppendData(buffer, 0, read);
                                fileSize += read;
                            }
                        }
                        var digest = Convert.ToHexString(sha.GetHashAndReset()).ToLowerInvariant();
                        records.Add(new BackupFileRecord(entryName, fileSize, digest));
                        bytes += fileSize;
                        Publish(ModelCenterEventKind.BackupProgress, "RUNNING",
                            $"Backed up {records.Count} file(s); {bytes} bytes.", bytesCompleted: bytes, operationId: operationId);
                    }
                }

                var manifest = new BackupManifest(1, DateTimeOffset.UtcNow, records);
                var manifestEntry = archive.CreateEntry("nox-backup-manifest.json", CompressionLevel.Optimal);
                await using var manifestStream = manifestEntry.Open();
                await JsonSerializer.SerializeAsync(manifestStream, manifest, JsonOptions, cancellationToken).ConfigureAwait(false);
                await manifestStream.FlushAsync(cancellationToken).ConfigureAwait(false);
            }

            File.Move(temp, fullArchivePath, overwrite: true);
            var archiveHash = await HashFileAsync(fullArchivePath, cancellationToken).ConfigureAwait(false);
            Publish(ModelCenterEventKind.BackupCompleted, "COMPLETED", $"Backup created; files={records.Count}; sha256={archiveHash}.", archiveHash,
                operationId: operationId);
            return new BackupResult(fullArchivePath, records.Count, bytes, archiveHash);
        }
        catch (Exception ex)
        {
            TryDelete(temp);
            Publish(ModelCenterEventKind.Error, "FAILED", "Backup failed: " + ex.Message, errorCode: "BACKUP_FAILED", operationId: operationId);
            throw;
        }
    }

    public async Task<RestoreResult> RestoreAsync(
        string archivePath,
        string destinationRoot,
        Func<string, Task<bool>> confirm,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(archivePath);
        ArgumentException.ThrowIfNullOrWhiteSpace(destinationRoot);
        ArgumentNullException.ThrowIfNull(confirm);
        var operationId = Guid.NewGuid().ToString("N");
        var archiveFullPath = Path.GetFullPath(archivePath);
        var destination = Path.GetFullPath(destinationRoot);
        if (!File.Exists(archiveFullPath)) return new RestoreResult("FAILED", 0, 0, "Backup archive is missing.");
        if (!await confirm($"Restore the backup into {destination}? Existing matching files will be backed up first.").ConfigureAwait(false))
        {
            const string cancelledBeforeStart = "Restore was cancelled before archive processing; no files were changed.";
            Publish(ModelCenterEventKind.RestoreCancelled, "CANCELLED", cancelledBeforeStart,
                errorCode: "RESTORE_CANCELLED", operationId: operationId);
            return new RestoreResult("CANCELLED", 0, 0, null);
        }

        var staging = Path.Combine(Path.GetDirectoryName(destination)!, ".nox-restore-" + Guid.NewGuid().ToString("N"));
        var rollback = Path.Combine(Path.GetDirectoryName(destination)!, ".nox-rollback-" + Guid.NewGuid().ToString("N"));
        var verified = new List<(BackupFileRecord Record, string StagedPath, string TargetPath)>();
        var replaced = new List<(string Original, string Saved)>();
        var created = new List<string>();
        long totalRestoreBytes = 0;
        long restoredBytes = 0;

        bool RollbackChanges()
        {
            var complete = true;
            foreach (var target in created.AsEnumerable().Reverse())
            {
                try { if (File.Exists(target)) File.Delete(target); }
                catch { complete = false; }
            }
            foreach (var item in replaced.AsEnumerable().Reverse())
            {
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(item.Original)!);
                    if (File.Exists(item.Original)) File.Delete(item.Original);
                    File.Move(item.Saved, item.Original, overwrite: true);
                }
                catch { complete = false; }
            }
            return complete;
        }

        Publish(ModelCenterEventKind.RestoreStarted, "RUNNING", "Restore validation started.", operationId: operationId);
        try
        {
            Directory.CreateDirectory(staging);
            Directory.CreateDirectory(rollback);
            using (var archiveFile = new FileStream(archiveFullPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var archive = new ZipArchive(archiveFile, ZipArchiveMode.Read, leaveOpen: false, Encoding.UTF8))
            {
                var manifestEntry = archive.GetEntry("nox-backup-manifest.json")
                    ?? throw new InvalidDataException("Backup manifest is missing.");
                if (manifestEntry.Length is < 1 or > MaxManifestBytes)
                    throw new InvalidDataException("Backup manifest exceeds the supported size.");
                BackupManifest manifest;
                await using (var stream = manifestEntry.Open())
                    manifest = await JsonSerializer.DeserializeAsync<BackupManifest>(stream, JsonOptions, cancellationToken).ConfigureAwait(false)
                        ?? throw new InvalidDataException("Backup manifest is invalid.");
                if (manifest.SchemaVersion != 1) throw new InvalidDataException("Unsupported backup manifest version.");
                if (manifest.Files is null || manifest.Files.Count > MaxRestoreFiles)
                    throw new InvalidDataException("Backup manifest contains an invalid file count.");

                foreach (var record in manifest.Files)
                {
                    if (record.SizeBytes < 0 || record.SizeBytes > MaxRestoreTotalBytes || string.IsNullOrWhiteSpace(record.Sha256) || record.Sha256.Length != 64 ||
                        record.Sha256.Any(ch => !Uri.IsHexDigit(ch)))
                        throw new InvalidDataException("Backup manifest contains invalid size or SHA-256 metadata.");
                    totalRestoreBytes = checked(totalRestoreBytes + record.SizeBytes);
                    if (totalRestoreBytes > MaxRestoreTotalBytes)
                        throw new InvalidDataException("Backup exceeds the supported restore size.");
                }

                var records = manifest.Files.ToDictionary(record => NormalizeArchivePath(record.Entry), StringComparer.OrdinalIgnoreCase);
                if (records.Count != manifest.Files.Count) throw new InvalidDataException("Backup manifest contains duplicate paths.");
                var scopes = records.Keys.Select(GetScopePrefix).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
                if (scopes.Length != 1 || scopes.Any(scope => !IsSafeScopeName(scope)))
                    throw new InvalidDataException("Restore one named backup scope at a time; separate multi-scope backups before restoring.");
                if (archive.Entries.Count > MaxRestoreFiles + 1)
                    throw new InvalidDataException("Backup archive contains too many entries.");
                var volumeRoot = Path.GetPathRoot(staging);
                if (!string.IsNullOrWhiteSpace(volumeRoot))
                {
                    var volume = new DriveInfo(volumeRoot);
                    if (volume.IsReady && volume.AvailableFreeSpace < totalRestoreBytes)
                        throw new IOException("Not enough free space to stage the verified restore.");
                }
                foreach (var entry in archive.Entries)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (entry.FullName == "nox-backup-manifest.json") continue;
                    var safeName = NormalizeArchivePath(entry.FullName);
                    if (!records.TryGetValue(safeName, out var record)) throw new InvalidDataException("Archive entry is not declared in its manifest.");
                    if (entry.Length != record.SizeBytes)
                        throw new InvalidDataException("Archive entry size disagrees with its manifest: " + safeName);
                    var stagedPath = ResolveInside(staging, safeName);
                    Directory.CreateDirectory(Path.GetDirectoryName(stagedPath)!);
                    await using (var input = entry.Open())
                    await using (var output = new FileStream(stagedPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 128 * 1024, useAsync: true))
                        await input.CopyToAsync(output, cancellationToken).ConfigureAwait(false);
                    var info = new FileInfo(stagedPath);
                    if (info.Length != record.SizeBytes) throw new InvalidDataException("Backup entry size mismatch: " + safeName);
                    var actualHash = await HashFileAsync(stagedPath, cancellationToken).ConfigureAwait(false);
                    if (!FixedTimeHexEquals(actualHash, record.Sha256)) throw new InvalidDataException("Backup entry SHA-256 mismatch: " + safeName);
                    var relative = RemoveScopePrefix(safeName);
                    verified.Add((record, stagedPath, ResolveInside(destination, relative)));
                }
                if (verified.Count != manifest.Files.Count) throw new InvalidDataException("Some manifest entries are missing from the archive.");
            }

            Directory.CreateDirectory(destination);
            foreach (var item in verified)
            {
                cancellationToken.ThrowIfCancellationRequested();
                EnsureNoReparsePointInPath(destination, item.TargetPath);
                Directory.CreateDirectory(Path.GetDirectoryName(item.TargetPath)!);
                EnsureNoReparsePointInPath(destination, item.TargetPath);
                if (File.Exists(item.TargetPath))
                {
                    var saved = ResolveInside(rollback, Path.GetRelativePath(destination, item.TargetPath));
                    Directory.CreateDirectory(Path.GetDirectoryName(saved)!);
                    File.Move(item.TargetPath, saved, overwrite: true);
                    replaced.Add((item.TargetPath, saved));
                }
                File.Move(item.StagedPath, item.TargetPath, overwrite: true);
                if (!replaced.Any(entry => string.Equals(entry.Original, item.TargetPath, StringComparison.OrdinalIgnoreCase)))
                    created.Add(item.TargetPath);
                restoredBytes = checked(restoredBytes + item.Record.SizeBytes);
                var restoredCount = created.Count + replaced.Count;
                Publish(ModelCenterEventKind.RestoreProgress, "RUNNING",
                    $"Restored {restoredCount} of {verified.Count} verified files.",
                    progressPercent: totalRestoreBytes == 0 ? 100 : Math.Min(100, restoredBytes * 100d / totalRestoreBytes),
                    bytesCompleted: restoredBytes, bytesTotal: totalRestoreBytes, operationId: operationId);
            }

            Publish(ModelCenterEventKind.RestoreCompleted, "COMPLETED", $"Restored {verified.Count} SHA-256 verified files.",
                operationId: operationId);
            TryDelete(staging);
            TryDelete(rollback);
            return new RestoreResult("COMPLETED", verified.Count, verified.Count, null);
        }
        catch (OperationCanceledException)
        {
            var rollbackComplete = RollbackChanges();
            TryDelete(staging);
            var message = rollbackComplete
                ? "Restore was cancelled; changed files were rolled back."
                : "Restore was cancelled, but rollback was incomplete; recovery data remains at " + rollback;
            if (rollbackComplete) TryDelete(rollback);
            Publish(ModelCenterEventKind.RestoreCancelled, "CANCELLED", message,
                errorCode: rollbackComplete ? "RESTORE_CANCELLED" : "RESTORE_CANCELLED_ROLLBACK_INCOMPLETE", operationId: operationId);
            return new RestoreResult("CANCELLED", 0, verified.Count, rollbackComplete ? null : message);
        }
        catch (Exception ex)
        {
            var rollbackComplete = RollbackChanges();
            TryDelete(staging);
            var message = rollbackComplete
                ? "Restore failed; original files were restored. " + ex.Message
                : "Restore failed; rollback was incomplete and recovery data remains at " + rollback + ". " + ex.Message;
            if (rollbackComplete) TryDelete(rollback);
            Publish(ModelCenterEventKind.Error, "FAILED", message, errorCode: "RESTORE_FAILED", operationId: operationId);
            return new RestoreResult("FAILED", 0, verified.Count, message);
        }
    }

    public static IReadOnlyList<BackupScope> DefaultScopes(string localAppData, string userProfile) =>
        new[]
        {
            new BackupScope("nox-integrator", Path.Combine(localAppData, "NOX_HELION_Integrator")),
            new BackupScope("ollama-model-store", Path.Combine(userProfile, ".ollama", "models"))
        };

    private void Publish(ModelCenterEventKind kind, string state, string message, string? digest = null,
        string? errorCode = null, double? progressPercent = null, long? bytesCompleted = null, long? bytesTotal = null,
        string? operationId = null) =>
        _events?.Publish(new ModelCenterEvent
        {
            Kind = kind,
            ComponentId = "backup-restore",
            State = state,
            Message = message,
            Sha256Digest = digest,
            ErrorCode = errorCode,
            ProgressPercent = progressPercent,
            BytesCompleted = bytesCompleted,
            BytesTotal = bytesTotal,
            OperationId = operationId
        });

    private static IEnumerable<string> EnumerateRegularFiles(string root)
    {
        var pending = new Stack<string>();
        pending.Push(root);
        while (pending.Count > 0)
        {
            var directory = pending.Pop();
            foreach (var entry in Directory.EnumerateFileSystemEntries(directory))
            {
                var attributes = File.GetAttributes(entry);
                if ((attributes & FileAttributes.ReparsePoint) != 0) continue;
                if ((attributes & FileAttributes.Directory) != 0) pending.Push(entry);
                else yield return entry;
            }
        }
    }

    private static bool IsSafeScopeName(string name) =>
        name.Length is > 0 and <= 64 && name.All(ch => char.IsAsciiLetterOrDigit(ch) || ch is '-' or '_');

    private static bool IsWithinDirectory(string path, string directory)
    {
        var root = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        return Path.GetFullPath(path).StartsWith(root, StringComparison.OrdinalIgnoreCase);
    }

    private static void EnsureNoReparsePointInPath(string root, string targetPath)
    {
        var fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
        var fullTarget = Path.GetFullPath(targetPath);
        var prefix = fullRoot + Path.DirectorySeparatorChar;
        if (!fullTarget.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Restore target escapes the selected destination.");

        var current = fullRoot;
        if (Directory.Exists(current) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Restore destination cannot be a reparse point.");
        var relativeParent = Path.GetRelativePath(fullRoot, Path.GetDirectoryName(fullTarget)!);
        foreach (var part in relativeParent.Split(Path.DirectorySeparatorChar, StringSplitOptions.RemoveEmptyEntries))
        {
            current = Path.Combine(current, part);
            if (Directory.Exists(current) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("Restore path contains a reparse point.");
        }
        if (File.Exists(fullTarget) && (File.GetAttributes(fullTarget) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Restore will not replace a reparse-point file.");
    }

    private static bool IsSensitive(string fileName)
    {
        var name = fileName.ToLowerInvariant();
        return name == "token.txt" || name == ".env" || name.EndsWith(".key") ||
               name.EndsWith(".pem") || name.Contains("credential") || name.Contains("secret");
    }

    private static string NormalizeArchivePath(string path)
    {
        var normalized = path.Replace('\\', '/');
        if (Path.IsPathRooted(normalized) || normalized.StartsWith('/') ||
            normalized.Split('/').Any(part => part is ".." or "." or ""))
            throw new InvalidDataException("Unsafe archive path.");
        return normalized;
    }

    private static string RemoveScopePrefix(string path)
    {
        var separator = path.IndexOf('/');
        if (separator <= 0 || separator == path.Length - 1) throw new InvalidDataException("Backup path is missing a scope prefix.");
        return path[(separator + 1)..];
    }

    private static string GetScopePrefix(string path)
    {
        var separator = path.IndexOf('/');
        if (separator <= 0 || separator == path.Length - 1) throw new InvalidDataException("Backup path is missing a scope prefix.");
        return path[..separator];
    }

    private static string ResolveInside(string root, string relative)
    {
        var fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var full = Path.GetFullPath(Path.Combine(fullRoot, relative.Replace('/', Path.DirectorySeparatorChar)));
        if (!full.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Archive path escapes the selected root.");
        return full;
    }

    private static async Task<string> HashFileAsync(string path, CancellationToken cancellationToken)
    {
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 128 * 1024, useAsync: true);
        var hash = await SHA256.HashDataAsync(stream, cancellationToken).ConfigureAwait(false);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static bool FixedTimeHexEquals(string left, string right)
    {
        if (left.Length != 64 || right.Length != 64) return false;
        try { return CryptographicOperations.FixedTimeEquals(Convert.FromHexString(left), Convert.FromHexString(right)); }
        catch { return false; }
    }

    private static void TryDelete(string path)
    {
        try { if (Directory.Exists(path)) Directory.Delete(path, recursive: true); else if (File.Exists(path)) File.Delete(path); } catch { }
    }
}
