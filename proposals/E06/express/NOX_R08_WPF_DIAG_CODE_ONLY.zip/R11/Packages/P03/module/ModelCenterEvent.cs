using System.Text.Json;
using System.Text.Json.Serialization;

namespace NOX.P01.ModelCenter;

public enum ModelCenterEventKind
{
    SystemProbe,
    ComponentDetected,
    ComponentProgress,
    DownloadQueued,
    DownloadProgress,
    DownloadPaused,
    DownloadResumed,
    DownloadRetry,
    DownloadCancelled,
    DownloadCompleted,
    DownloadFailed,
    InstallStarted,
    InstallOutput,
    InstallCompleted,
    InstallFailed,
    UpdateStarted,
    UpdateCompleted,
    RemoveStarted,
    RemoveCompleted,
    FileScanStarted,
    FileScanCompleted,
    FileScanCancelled,
    FileScanProgress,
    FileFound,
    FileImportStarted,
    FileImportBlocked,
    FileImported,
    FileImportFailed,
    BackupStarted,
    BackupProgress,
    BackupCompleted,
    RestoreStarted,
    RestoreProgress,
    RestoreCompleted,
    Error,
    RestoreCancelled
}

/// <summary>
/// Local, secret-free event contract shared by the installer, model queue,
/// diagnostics, import, backup, and restore operations.
/// </summary>
public sealed class ModelCenterEvent : EventArgs
{
    public Guid EventId { get; init; } = Guid.NewGuid();
    public DateTimeOffset TimestampUtc { get; init; } = DateTimeOffset.UtcNow;
    public required ModelCenterEventKind Kind { get; init; }
    public required string ComponentId { get; init; }
    public required string State { get; init; }
    public required string Message { get; init; }
    public double? ProgressPercent { get; init; }
    public long? BytesCompleted { get; init; }
    public long? BytesTotal { get; init; }
    public string? Sha256Digest { get; init; }
    public string? ErrorCode { get; init; }
    public string? OperationId { get; init; }
    public string? OperationId { get; init; }
}

/// <summary>Shared NOX events.v3 envelope emitted by the P03 adapter.</summary>
public sealed class NoxEventV3 : EventArgs
{
    [JsonPropertyName("event_id")] public required string EventId { get; init; }
    [JsonPropertyName("run_id")] public required string RunId { get; init; }
    [JsonPropertyName("package_id")] public required string PackageId { get; init; }
    [JsonPropertyName("operation_id")] public required string OperationId { get; init; }
    [JsonPropertyName("timestamp_utc")] public required DateTimeOffset TimestampUtc { get; init; }
    [JsonPropertyName("state")] public required string State { get; init; }
    [JsonPropertyName("source")] public required string Source { get; init; }
    [JsonPropertyName("evidence")] public required NoxEventV3Evidence Evidence { get; init; }
    [JsonPropertyName("progress")] public NoxEventV3Progress Progress { get; init; } = new();
}

public sealed class NoxEventV3Progress
{
    [JsonPropertyName("completed")] public double? Completed { get; init; }
    [JsonPropertyName("total")] public double? Total { get; init; }
    [JsonPropertyName("units")] public string? Units { get; init; }
}

public sealed class NoxEventV3Evidence
{
    [JsonPropertyName("event_kind")] public required string EventKind { get; init; }
    [JsonPropertyName("component_id")] public required string ComponentId { get; init; }
    [JsonPropertyName("summary")] public required string Summary { get; init; }
    [JsonPropertyName("source_sha256")] public string? SourceSha256 { get; init; }
    [JsonPropertyName("error_code")] public string? ErrorCode { get; init; }
}

/// <summary>Enriches P03 events with the shared NOX events.v3 fields.</summary>
public sealed class ModelCenterEventsV3Adapter
{
    public const string PackageId = "P03";
    public string RunId { get; } = Guid.NewGuid().ToString("N");

    public NoxEventV3 Adapt(ModelCenterEvent source)
    {
        ArgumentNullException.ThrowIfNull(source);
        var progress = GetProgress(source);
        return new NoxEventV3
        {
            EventId = source.EventId.ToString("D"),
            RunId = RunId,
            PackageId = PackageId,
            OperationId = string.IsNullOrWhiteSpace(source.OperationId) ? source.EventId.ToString("D") : source.OperationId,
            TimestampUtc = source.TimestampUtc.ToUniversalTime(),
            State = NormalizeState(source),
            Source = GetSource(source),
            Evidence = new NoxEventV3Evidence
            {
                EventKind = source.Kind.ToString(),
                ComponentId = source.ComponentId,
                Summary = SafeSummary(source),
                SourceSha256 = source.Kind is ModelCenterEventKind.FileFound or ModelCenterEventKind.FileImported
                    ? source.Sha256Digest
                    : null,
                ErrorCode = source.ErrorCode
            },
            Progress = progress
        };
    }

    public string Serialize(ModelCenterEvent source) => JsonSerializer.Serialize(Adapt(source));

    private static NoxEventV3Progress GetProgress(ModelCenterEvent source)
    {
        if (source.BytesCompleted is not null || source.BytesTotal is not null)
        {
            double? completed = source.BytesCompleted is { } observedCompleted
                ? Math.Max(0, observedCompleted)
                : null;
            var total = source.BytesTotal is > 0 ? source.BytesTotal : null;
            if (total is not null && completed is not null) completed = Math.Min(completed.Value, total.Value);
            return new NoxEventV3Progress { Completed = completed, Total = total, Units = "bytes" };
        }
        if (source.ProgressPercent is { } percent)
            return new NoxEventV3Progress { Completed = Math.Clamp(percent, 0, 100), Total = 100, Units = "percent" };
        return new NoxEventV3Progress();
    }

    private static string NormalizeState(ModelCenterEvent source)
    {
        var state = source.State.Trim().ToUpperInvariant();
        if (state is "CANCELLED" or "CANCELED" or "RESTORE_CANCELLED") return "STOPPED";
        if (source.Kind == ModelCenterEventKind.FileFound && state == "STAGED_COPY_ONLY")
            return source.Sha256Digest is not null && source.BytesCompleted is > 0 && source.BytesTotal is > 0 ? "SUCCESS" : "HOLD";
        if (state is "PAUSED" or "BLOCKED" or "IMPORT_BLOCKED" or "IMPORTED_UNVERIFIED" or "QUEUE_RECOVERY_WARNING") return "HOLD";
        if (state == "STOP_ACK_FAILED") return "ERROR";
        if (state is "FAILED" or "ERROR" or "IMPORT_FAILED") return "ERROR";
        if (state is "OFFLINE") return "OFFLINE";
        if (state is "N/D" or "ND" or "UNKNOWN" or "NOT_MEASURED") return "N/D";
        if (state is "QUEUED" or "READY") return "READY";
        if (IsProgressEvent(source.Kind)) return "RUNNING";
        if (source.Kind == ModelCenterEventKind.DownloadCompleted)
            return source.Sha256Digest is not null && source.BytesCompleted is > 0 && source.BytesTotal is > 0 ? "SUCCESS" : "HOLD";
        if (source.Kind == ModelCenterEventKind.FileImported)
            return state == "IMPORTED_VERIFIED" && source.Sha256Digest is not null &&
                source.BytesCompleted is > 0 && source.BytesTotal is > 0 ? "SUCCESS" : "HOLD";
        if (state == "COMPLETED" || state == "SUCCESS")
            return source.Kind is ModelCenterEventKind.InstallCompleted or ModelCenterEventKind.BackupCompleted or
                ModelCenterEventKind.RestoreCompleted or ModelCenterEventKind.FileScanCompleted or
                ModelCenterEventKind.FileImported or ModelCenterEventKind.DownloadCompleted ? "SUCCESS" : "N/D";
        return state is "RUNNING" or "DOWNLOADING" or "INSTALLING" or "UPDATING" or "RESTORING" or "SCANNING"
            ? "RUNNING" : "N/D";
    }

    private static bool IsProgressEvent(ModelCenterEventKind kind) => kind is
        ModelCenterEventKind.DownloadProgress or ModelCenterEventKind.ComponentProgress or
        ModelCenterEventKind.InstallOutput or ModelCenterEventKind.FileScanProgress or
        ModelCenterEventKind.BackupProgress or ModelCenterEventKind.RestoreProgress;

    private static string GetSource(ModelCenterEvent source)
    {
        if (source.ComponentId == "ollama.gguf.import") return "P03.ModelCenter.GgufImport";
        if (source.ComponentId == "local-file-stage") return "P03.ModelCenter.FileStage";
        return source.Kind switch
        {
            ModelCenterEventKind.SystemProbe or ModelCenterEventKind.ComponentDetected => "P03.ModelCenter.Preflight",
            ModelCenterEventKind.DownloadQueued or ModelCenterEventKind.DownloadProgress or ModelCenterEventKind.DownloadPaused or
            ModelCenterEventKind.DownloadResumed or ModelCenterEventKind.DownloadRetry or ModelCenterEventKind.DownloadCancelled or
            ModelCenterEventKind.DownloadCompleted or ModelCenterEventKind.DownloadFailed => "P03.ModelCenter.OllamaPull",
            ModelCenterEventKind.InstallStarted or ModelCenterEventKind.InstallOutput or ModelCenterEventKind.InstallCompleted or
            ModelCenterEventKind.InstallFailed or ModelCenterEventKind.UpdateStarted or ModelCenterEventKind.UpdateCompleted or
            ModelCenterEventKind.RemoveStarted or ModelCenterEventKind.RemoveCompleted => "P03.ModelCenter.ComponentInstaller",
            ModelCenterEventKind.FileScanStarted or ModelCenterEventKind.FileScanCompleted or ModelCenterEventKind.FileScanCancelled or
            ModelCenterEventKind.FileScanProgress or ModelCenterEventKind.FileFound => "P03.ModelCenter.FileScan",
            ModelCenterEventKind.FileImportStarted or ModelCenterEventKind.FileImportBlocked or ModelCenterEventKind.FileImported or
            ModelCenterEventKind.FileImportFailed => "P03.ModelCenter.GgufImport",
            ModelCenterEventKind.BackupStarted or ModelCenterEventKind.BackupProgress or ModelCenterEventKind.BackupCompleted or
            ModelCenterEventKind.RestoreStarted or ModelCenterEventKind.RestoreProgress or ModelCenterEventKind.RestoreCompleted or
            ModelCenterEventKind.RestoreCancelled => "P03.ModelCenter.BackupRestore",
            _ => "P03.ModelCenter"
        };
    }

    private static string SafeSummary(ModelCenterEvent source) =>
        source.Kind switch
        {
            ModelCenterEventKind.DownloadCancelled => "DownloadCancelled: local HTTP pull cancellation confirmed; remote Ollama pull state N/D.",
            ModelCenterEventKind.DownloadPaused => "DownloadPaused: local HTTP pull stop confirmed; remote Ollama pull state N/D.",
            _ => $"{source.Kind}:{NormalizeState(source)}; raw local detail omitted from shared event."
        };
}

public interface IModelCenterEventSink
{
    void Publish(ModelCenterEvent modelCenterEvent);
}

public sealed class ModelCenterEventHub : IModelCenterEventSink
{
    private readonly ModelCenterEventsV3Adapter _v3Adapter = new();
    public event EventHandler<ModelCenterEvent>? EventRaised;
    public event EventHandler<NoxEventV3>? EventRaisedV3;
    public string RunId => _v3Adapter.RunId;

    public void Publish(ModelCenterEvent modelCenterEvent)
    {
        ArgumentNullException.ThrowIfNull(modelCenterEvent);
        var v3 = EventRaisedV3;
        if (v3 is not null)
        {
            var adapted = _v3Adapter.Adapt(modelCenterEvent);
            foreach (EventHandler<NoxEventV3> subscriber in v3.GetInvocationList())
            {
                try { subscriber(this, adapted); }
                catch (Exception) { /* An observer cannot interrupt the installer. */ }
            }
        }
        var subscribers = EventRaised;
        if (subscribers is null) return;

        foreach (EventHandler<ModelCenterEvent> subscriber in subscribers.GetInvocationList())
        {
            try
            {
                subscriber(this, modelCenterEvent);
            }
            catch (Exception)
            {
                // Observers cannot abort downloads, installs, backup, or restore.
            }
        }
    }
}
