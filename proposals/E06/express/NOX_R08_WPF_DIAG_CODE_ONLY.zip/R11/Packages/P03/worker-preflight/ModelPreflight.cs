using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Text.Json;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Core;

namespace NOX.P01.ModelCenter;

/// <summary>
/// Read-only local inventory for Ollama, Python, Git, model storage and NVIDIA VRAM.
/// It never installs software, writes registry values, creates directories, or elevates.
/// Sources: Ollama list-models API https://docs.ollama.com/api/tags; Ollama Windows model
/// storage and OLLAMA_MODELS https://docs.ollama.com/windows; Microsoft registry access
/// https://learn.microsoft.com/dotnet/api/microsoft.win32.registrykey.openbasekey;
/// Microsoft process invocation https://learn.microsoft.com/dotnet/api/system.diagnostics.processstartinfo.argumentlist;
/// Microsoft disk capacity https://learn.microsoft.com/dotnet/api/system.io.driveinfo.availablefreespace;
/// Microsoft physical-memory query https://learn.microsoft.com/windows/win32/api/sysinfoapi/nf-sysinfoapi-globalmemorystatusex;
/// Microsoft WebView2 runtime detection https://learn.microsoft.com/dotnet/api/microsoft.web.webview2.core.corewebview2environment.getavailablebrowserversionstring;
/// Microsoft WinGet CDN troubleshooting https://github.com/microsoft/winget-cli/blob/master/doc/troubleshooting/README.md;
/// Microsoft present-device enumeration https://learn.microsoft.com/windows/win32/api/setupapi/nf-setupapi-setupdigetclassdevsw and display class GUID https://learn.microsoft.com/windows-hardware/drivers/install/system-defined-device-setup-classes-available-to-vendors;
/// NVIDIA query interface https://docs.nvidia.com/deploy/nvidia-smi/index.html.
/// </summary>
public static class ModelPreflight
{
    private const string NotDetermined = "N/D";
    private const long MiB = 1024L * 1024L;
    private const long GiB = 1024L * 1024L * 1024L;
    private const int MaxTagsResponseBytes = 8 * 1024 * 1024;
    private const int StreamChunkSize = 16 * 1024;
    private static readonly TimeSpan OllamaTimeout = TimeSpan.FromSeconds(4);
    private static readonly TimeSpan NvidiaTimeout = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan NetworkTimeout = TimeSpan.FromSeconds(2);
    private static readonly Guid DisplayAdapterClass = new("4d36e968-e325-11ce-bfc1-08002be10318");
    private static readonly RegistryHive[] UninstallRegistryHives = { RegistryHive.CurrentUser, RegistryHive.LocalMachine };
    private static readonly RegistryView[] UninstallRegistryViews = { RegistryView.Registry64, RegistryView.Registry32 };
    private static readonly string[] NvidiaQueryArguments =
    {
        "--query-gpu=index,name,memory.total,memory.free",
        "--format=csv,noheader,nounits"
    };

    /// <summary>Captures a best-effort, read-only snapshot of local model tooling.</summary>
    public static async Task<PreflightSnapshot> CaptureAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        var pythonPath = FindToolPath(ToolKind.Python) ?? NotDetermined;
        var ollamaPath = FindToolPath(ToolKind.Ollama) ?? NotDetermined;
        var gitPath = FindToolPath(ToolKind.Git) ?? NotDetermined;
        var wingetPath = FindWingetPath() ?? NotDetermined;
        var freeDiskBytes = GetOllamaModelsFreeSpace();
        var windowsVersion = GetWindowsVersion();
        var processorCount = Math.Max(0, Environment.ProcessorCount);
        var (ramTotalBytes, ramFreeBytes) = GetPhysicalMemory();
        var webView2Version = GetWebView2RuntimeVersion();

        var ollamaTask = CaptureOllamaAsync(cancellationToken);
        var gpuTask = CaptureGpuAsync(cancellationToken);
        var networkTask = CaptureNetworkAsync(cancellationToken);
        await Task.WhenAll(ollamaTask, gpuTask, networkTask).ConfigureAwait(false);

        var ollama = await ollamaTask.ConfigureAwait(false);
        var gpu = await gpuTask.ConfigureAwait(false);
        if (!IsKnownPath(gpu.Name))
        {
            var windowsGpuNames = FindPresentDisplayAdapterNames();
            if (IsKnownPath(windowsGpuNames))
                gpu = gpu with { Name = windowsGpuNames! };
        }
        var network = (await networkTask.ConfigureAwait(false)).ToList();
        var localOllamaUri = ResolveLocalOllamaTagsUri();
        if (localOllamaUri is not null)
        {
            network.Insert(0, new NetworkEndpointSnapshot(
                "Ollama local API",
                localOllamaUri.Host,
                localOllamaUri.Port,
                ollama.Ready ? "AVAILABLE_HTTP" : "UNREACHABLE_OR_N/D",
                "GET /api/tags; local API response only"));
        }
        var compatibility = BuildCompatibilityNote(ollama.Models, gpu);
        var components = BuildComponentInventory(pythonPath, ollamaPath, gitPath, wingetPath, ollama.Ready, webView2Version);
        var libraries = BuildRequiredLibraryInventory(webView2Version, windowsVersion, ollama.Ready, pythonPath, gitPath, wingetPath);

        return new PreflightSnapshot(
            pythonPath,
            ollamaPath,
            gitPath,
            wingetPath,
            ollama.Ready,
            ollama.Models,
            freeDiskBytes,
            gpu.TotalBytes,
            gpu.FreeBytes,
            gpu.Name,
            gpu.Status,
            compatibility,
            windowsVersion,
            processorCount,
            ramTotalBytes,
            ramFreeBytes,
            webView2Version,
            network,
            components,
            libraries);
    }

    private static string GetWindowsVersion()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion", writable: false);
            var product = key?.GetValue("ProductName") as string;
            var displayVersion = key?.GetValue("DisplayVersion") as string;
            var build = key?.GetValue("CurrentBuildNumber") as string;
            var updateBuild = key?.GetValue("UBR");
            var buildText = build;
            if (!string.IsNullOrWhiteSpace(build) && updateBuild is not null &&
                int.TryParse(Convert.ToString(updateBuild, CultureInfo.InvariantCulture), NumberStyles.Integer, CultureInfo.InvariantCulture, out var ubr))
            {
                buildText = $"{build}.{ubr}";
            }

            var parts = new[] { product, displayVersion, string.IsNullOrWhiteSpace(buildText) ? null : $"Build {buildText}" }
                .Where(x => !string.IsNullOrWhiteSpace(x));
            var value = string.Join(" · ", parts);
            return string.IsNullOrWhiteSpace(value) ? Environment.OSVersion.VersionString : value;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Security.SecurityException or PlatformNotSupportedException)
        {
            return Environment.OSVersion.VersionString;
        }
    }

    private static (long? TotalBytes, long? FreeBytes) GetPhysicalMemory()
    {
        try
        {
            var status = new MemoryStatusEx { Length = (uint)Marshal.SizeOf<MemoryStatusEx>() };
            return GlobalMemoryStatusEx(ref status)
                ? ((long?)status.TotalPhys, (long?)status.AvailablePhys)
                : (null, null);
        }
        catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException or TypeLoadException)
        {
            return (null, null);
        }
    }

    private static string GetWebView2RuntimeVersion()
    {
        try
        {
            var version = CoreWebView2Environment.GetAvailableBrowserVersionString();
            return string.IsNullOrWhiteSpace(version) ? NotDetermined : version;
        }
        catch (WebView2RuntimeNotFoundException)
        {
            return NotDetermined;
        }
        catch (Exception ex) when (ex is DllNotFoundException or FileNotFoundException or BadImageFormatException or InvalidOperationException)
        {
            return NotDetermined;
        }
    }

    private static IReadOnlyList<InstalledComponent> BuildComponentInventory(
        string pythonPath,
        string ollamaPath,
        string gitPath,
        string wingetPath,
        bool ollamaReady,
        string webView2Version)
    {
        return new[]
        {
            new InstalledComponent("Python", IsKnownPath(pythonPath) ? "FOUND" : NotDetermined, pythonPath, NotDetermined),
            new InstalledComponent("Ollama", ollamaReady ? "API_READY" : IsKnownPath(ollamaPath) ? "INSTALLED_API_UNAVAILABLE" : NotDetermined, ollamaPath, NotDetermined),
            new InstalledComponent("Git", IsKnownPath(gitPath) ? "FOUND" : NotDetermined, gitPath, NotDetermined),
            new InstalledComponent("Microsoft WinGet", IsKnownPath(wingetPath) ? "FOUND" : NotDetermined, wingetPath, NotDetermined),
            new InstalledComponent("Microsoft Edge WebView2 Runtime", IsKnownPath(webView2Version) ? "AVAILABLE" : NotDetermined, NotDetermined, webView2Version)
        };
    }

    private static IReadOnlyList<RequiredLibrarySnapshot> BuildRequiredLibraryInventory(
        string webView2Version,
        string windowsVersion,
        bool ollamaReady,
        string pythonPath,
        string gitPath,
        string wingetPath)
    {
        var webView2SdkVersion = typeof(CoreWebView2Environment).Assembly.GetName().Version?.ToString() ?? NotDetermined;
        var runtime = RuntimeInformation.FrameworkDescription;
        var pythonPackages = "N/D (package inventory not executed; Python is discovery-only)";
        return new[]
        {
            new RequiredLibrarySnapshot("Microsoft.Web.WebView2 SDK", IsKnownPath(webView2SdkVersion) ? "AVAILABLE_IN_APP" : NotDetermined, webView2SdkVersion),
            new RequiredLibrarySnapshot("Microsoft Edge WebView2 Runtime", IsKnownPath(webView2Version) ? "AVAILABLE" : NotDetermined, webView2Version),
            new RequiredLibrarySnapshot(".NET Windows Desktop Runtime", string.IsNullOrWhiteSpace(runtime) ? NotDetermined : "CURRENT_PROCESS", runtime),
            new RequiredLibrarySnapshot("Ollama local API", ollamaReady ? "AVAILABLE" : NotDetermined, "N/D"),
            new RequiredLibrarySnapshot("Python interpreter", IsKnownPath(pythonPath) ? "FOUND" : NotDetermined, pythonPath),
            new RequiredLibrarySnapshot("Git client", IsKnownPath(gitPath) ? "FOUND" : NotDetermined, gitPath),
            new RequiredLibrarySnapshot("Microsoft WinGet", IsKnownPath(wingetPath) ? "FOUND" : NotDetermined, wingetPath),
            new RequiredLibrarySnapshot("Python package set", NotDetermined, pythonPackages),
            new RequiredLibrarySnapshot("Windows host", IsKnownPath(windowsVersion) ? "AVAILABLE" : NotDetermined, windowsVersion)
        };
    }

    private static bool IsKnownPath(string value) => !string.IsNullOrWhiteSpace(value) && value != NotDetermined;

    private static async Task<IReadOnlyList<NetworkEndpointSnapshot>> CaptureNetworkAsync(CancellationToken cancellationToken)
    {
        var endpoints = new[]
        {
            ProbeTcpAsync("WinGet CDN", "cdn.winget.microsoft.com", 443, cancellationToken),
            ProbeTcpAsync("Ollama model registry", "registry.ollama.ai", 443, cancellationToken),
            ProbeTcpAsync("Ollama web domain", "ollama.com", 443, cancellationToken)
        };
        return await Task.WhenAll(endpoints).ConfigureAwait(false);
    }

    private static async Task<NetworkEndpointSnapshot> ProbeTcpAsync(
        string name,
        string host,
        int port,
        CancellationToken cancellationToken)
    {
        try
        {
            using var client = new TcpClient();
            using var timeoutSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutSource.CancelAfter(NetworkTimeout);
            await client.ConnectAsync(host, port, timeoutSource.Token).ConfigureAwait(false);
            return new NetworkEndpointSnapshot(name, host, port, "REACHABLE_TCP", "TCP connect only; HTTPS/content not verified");
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex) when (ex is SocketException or OperationCanceledException or IOException or ArgumentException)
        {
            return new NetworkEndpointSnapshot(name, host, port, "UNREACHABLE_OR_N/D", "TCP connect only; DNS, proxy or policy may affect result");
        }
    }

    private static async Task<OllamaProbe> CaptureOllamaAsync(CancellationToken cancellationToken)
    {
        var tagsUri = ResolveLocalOllamaTagsUri();
        if (tagsUri is null)
            return new OllamaProbe(false, Array.Empty<InstalledModel>());

        try
        {
            using var handler = new HttpClientHandler { UseProxy = false };
            using var client = new HttpClient(handler) { Timeout = OllamaTimeout };
            using var response = await client.GetAsync(
                tagsUri,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode ||
                response.Content.Headers.ContentLength is > MaxTagsResponseBytes)
            {
                return new OllamaProbe(false, Array.Empty<InstalledModel>());
            }

            await using var body = await response.Content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
            var jsonBytes = await ReadBoundedAsync(
                body,
                MaxTagsResponseBytes,
                response.Content.Headers.ContentLength,
                cancellationToken).ConfigureAwait(false);
            using var document = JsonDocument.Parse(jsonBytes);
            if (!document.RootElement.TryGetProperty("models", out var modelsElement) ||
                modelsElement.ValueKind != JsonValueKind.Array)
            {
                return new OllamaProbe(false, Array.Empty<InstalledModel>());
            }

            var models = new List<InstalledModel>(modelsElement.GetArrayLength());
            foreach (var item in modelsElement.EnumerateArray())
            {
                var size = ReadInt64(item, "size") ?? 0L;
                var details = item.TryGetProperty("details", out var detailsElement) &&
                              detailsElement.ValueKind == JsonValueKind.Object
                    ? detailsElement
                    : default;

                models.Add(new InstalledModel(
                    ReadString(item, "name") ?? ReadString(item, "model") ?? NotDetermined,
                    Math.Max(0L, size),
                    NormalizeSha256(ReadString(item, "digest")),
                    ReadString(details, "format") ?? NotDetermined,
                    ReadFirstString(details, "families") ?? ReadString(details, "family") ?? NotDetermined,
                    ReadString(details, "parameter_size") ?? NotDetermined,
                    ReadString(details, "quantization_level") ?? NotDetermined));
            }

            return new OllamaProbe(true, models);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return new OllamaProbe(false, Array.Empty<InstalledModel>());
        }
        catch (HttpRequestException)
        {
            return new OllamaProbe(false, Array.Empty<InstalledModel>());
        }
        catch (IOException)
        {
            return new OllamaProbe(false, Array.Empty<InstalledModel>());
        }
        catch (JsonException)
        {
            return new OllamaProbe(false, Array.Empty<InstalledModel>());
        }
    }

    private static Uri? ResolveLocalOllamaTagsUri()
    {
        try
        {
            var configuredHost = Environment.GetEnvironmentVariable("OLLAMA_HOST");
            var raw = string.IsNullOrWhiteSpace(configuredHost)
                ? "http://127.0.0.1:11434"
                : configuredHost.Trim().Trim('"');

            if (!raw.Contains("://", StringComparison.Ordinal))
                raw = "http://" + raw;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out var baseUri) ||
                !string.Equals(baseUri.Scheme, Uri.UriSchemeHttp, StringComparison.OrdinalIgnoreCase) ||
                !string.IsNullOrEmpty(baseUri.UserInfo))
            {
                return null;
            }

            var host = baseUri.Host;
            if (IPAddress.TryParse(host, out var address))
            {
                if (IPAddress.Any.Equals(address)) host = IPAddress.Loopback.ToString();
                else if (IPAddress.IPv6Any.Equals(address)) host = IPAddress.IPv6Loopback.ToString();
            }

            var port = baseUri.IsDefaultPort ? 11434 : baseUri.Port;
            var localBase = new UriBuilder(Uri.UriSchemeHttp, host, port).Uri;
            if (!localBase.IsLoopback)
                return null;

            return new UriBuilder(localBase) { Path = "/api/tags", Query = string.Empty, Fragment = string.Empty }.Uri;
        }
        catch (UriFormatException)
        {
            return null;
        }
        catch (ArgumentException)
        {
            return null;
        }
    }

    private static async Task<byte[]> ReadBoundedAsync(
        Stream stream,
        int maxBytes,
        long? expectedLength,
        CancellationToken cancellationToken)
    {
        var initialCapacity = expectedLength is >= 0
            ? (int)Math.Min(expectedLength.Value, maxBytes)
            : 16 * 1024;
        using var buffer = new MemoryStream(initialCapacity);
        var chunk = new byte[StreamChunkSize];
        while (true)
        {
            var read = await stream.ReadAsync(chunk.AsMemory(0, chunk.Length), cancellationToken).ConfigureAwait(false);
            if (read == 0) break;
            if (buffer.Length + read > maxBytes)
                throw new InvalidDataException("Ollama /api/tags response exceeded the preflight size limit.");
            buffer.Write(chunk, 0, read);
        }

        return buffer.ToArray();
    }

    private static async Task<GpuProbe> CaptureGpuAsync(CancellationToken cancellationToken)
    {
        var nvidiaSmi = FindExecutableOnPath("nvidia-smi.exe") ??
                        FindExecutableOnPath("nvidia-smi") ??
                        ExistingExecutable(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "nvidia-smi.exe")) ??
                        ExistingExecutable(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe"));
        if (nvidiaSmi is null)
            return GpuProbe.NotAvailable;

        try
        {
            var result = await RunProcessAsync(
                nvidiaSmi,
                NvidiaQueryArguments,
                NvidiaTimeout,
                cancellationToken).ConfigureAwait(false);

            if (result.TimedOut || result.ExitCode != 0)
                return GpuProbe.NotAvailable;

            var devices = ParseGpuRows(result.StandardOutput);
            if (devices.Count == 0)
                return GpuProbe.NotAvailable;

            // Use one device's memory, not a sum across cards: VRAM is not assumed to be pooled.
            GpuDevice? representative = null;
            var deviceNames = new List<string>(devices.Count);
            foreach (var device in devices)
            {
                if (!string.IsNullOrWhiteSpace(device.Name))
                    deviceNames.Add(device.Name);
                if (!device.TotalBytes.HasValue)
                    continue;
                if (representative is null ||
                    (device.FreeBytes ?? device.TotalBytes.Value) > (representative.FreeBytes ?? representative.TotalBytes!.Value))
                    representative = device;
            }

            var names = string.Join(", ", deviceNames);
            if (representative is null)
                return new GpuProbe(names, null, null, "PARTIAL");

            var status = representative.FreeBytes.HasValue ? "AVAILABLE" : "PARTIAL";
            return new GpuProbe(names, representative.TotalBytes, representative.FreeBytes, status);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return GpuProbe.NotAvailable;
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or Win32Exception or FormatException)
        {
            return GpuProbe.NotAvailable;
        }
    }

    private static string? FindPresentDisplayAdapterNames()
    {
        try
        {
            var displayClass = DisplayAdapterClass;
            var devices = SetupDiGetClassDevs(ref displayClass, null, IntPtr.Zero, DigcfPresent);
            if (devices == InvalidHandleValue)
                return null;

            try
            {
                var names = new List<string>(4);
                var seenNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                for (uint index = 0; index < 64; index++)
                {
                    var device = new SpDevInfoData { CbSize = (uint)Marshal.SizeOf<SpDevInfoData>() };
                    if (!SetupDiEnumDeviceInfo(devices, index, ref device))
                        break;

                    var name = ReadDisplayDeviceProperty(devices, ref device, SpdrpFriendlyName) ??
                               ReadDisplayDeviceProperty(devices, ref device, SpdrpDeviceDescription);
                    if (string.IsNullOrWhiteSpace(name) || string.Equals(name, NotDetermined, StringComparison.OrdinalIgnoreCase))
                        continue;

                    name = name.Trim();
                    if (seenNames.Add(name))
                        names.Add(name);
                }

                return names.Count == 0 ? null : string.Join("; ", names);
            }
            finally
            {
                SetupDiDestroyDeviceInfoList(devices);
            }
        }
        catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException or MarshalDirectiveException or ArgumentException or OverflowException)
        {
            return null;
        }
    }

    private static string? ReadDisplayDeviceProperty(IntPtr deviceSet, ref SpDevInfoData device, uint property)
    {
        _ = SetupDiGetDeviceRegistryPropertyW(deviceSet, ref device, property, out _, IntPtr.Zero, 0, out var requiredBytes);
        if (requiredBytes is 0 or > 8192)
            return null;

        var buffer = Marshal.AllocHGlobal(checked((int)requiredBytes));
        try
        {
            if (!SetupDiGetDeviceRegistryPropertyW(deviceSet, ref device, property, out _, buffer, requiredBytes, out _))
                return null;
            return Marshal.PtrToStringUni(buffer)?.TrimEnd('\0').Trim();
        }
        finally
        {
            Marshal.FreeHGlobal(buffer);
        }
    }

    private static List<GpuDevice> ParseGpuRows(string output)
    {
        var devices = new List<GpuDevice>(Math.Min(output.Length / 32 + 1, 16));
        foreach (var line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
        {
            var fields = line.Split(',');
            if (fields.Length < 4 || !int.TryParse(fields[0].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
                continue;

            var totalText = fields[^2].Trim();
            var freeText = fields[^1].Trim();
            var name = string.Join(",", fields.Skip(1).Take(fields.Length - 3)).Trim();
            var total = TryParseMegabytes(totalText);
            var free = TryParseMegabytes(freeText);
            devices.Add(new GpuDevice(string.IsNullOrWhiteSpace(name) ? NotDetermined : name, total, free));
        }

        return devices;
    }

    private static long? TryParseMegabytes(string value)
    {
        if (!long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var megabytes) || megabytes < 0)
            return null;
        try { return checked(megabytes * MiB); }
        catch (OverflowException) { return null; }
    }

    private static async Task<ProcessResult> RunProcessAsync(
        string executable,
        IReadOnlyList<string> arguments,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        using var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = executable,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                WorkingDirectory = Path.GetDirectoryName(executable) ?? Environment.CurrentDirectory
            }
        };
        foreach (var argument in arguments)
            process.StartInfo.ArgumentList.Add(argument);

        if (!process.Start())
            return new ProcessResult(-1, string.Empty, string.Empty, false);

        var stdoutTask = process.StandardOutput.ReadToEndAsync();
        var stderrTask = process.StandardError.ReadToEndAsync();
        using var timeoutSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutSource.CancelAfter(timeout);

        try
        {
            await process.WaitForExitAsync(timeoutSource.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            TryKill(process);
            if (cancellationToken.IsCancellationRequested)
                throw;
            try { await process.WaitForExitAsync(CancellationToken.None).ConfigureAwait(false); }
            catch (InvalidOperationException) { }
            return new ProcessResult(-1, string.Empty, string.Empty, true);
        }

        return new ProcessResult(process.ExitCode, await stdoutTask.ConfigureAwait(false), await stderrTask.ConfigureAwait(false), false);
    }

    private static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited)
                process.Kill(entireProcessTree: true);
        }
        catch (InvalidOperationException) { }
        catch (System.ComponentModel.Win32Exception) { }
    }

    private static string BuildCompatibilityNote(IReadOnlyList<InstalledModel> models, GpuProbe gpu)
    {
        const string caveat = "Heuristic only: Ollama model disk size is not exact runtime VRAM need; context, architecture, quantization and concurrent GPU use change fit. VRAM is not pooled across cards.";
        if (models.Count == 0)
            return $"Compatibility=N/D (no installed model or local Ollama API unavailable). License=REVIEW_REQUIRED until explicit user acknowledgement. {caveat}";
        if (!gpu.FreeBytes.HasValue)
            return $"Compatibility=N/D (GPU/available VRAM not detected). License=REVIEW_REQUIRED until explicit user acknowledgement. {caveat}";

        var estimates = new string[models.Count];
        for (var index = 0; index < models.Count; index++)
        {
            var model = models[index];
            estimates[index] = $"{model.Name}={EstimateModelCompatibility(model.SizeBytes, gpu.FreeBytes.Value)}";
        }
        return $"{string.Join("; ", estimates)}. License=REVIEW_REQUIRED until explicit user acknowledgement. {caveat}";
    }

    private static string EstimateModelCompatibility(long modelBytes, long freeVramBytes)
    {
        if (modelBytes <= 0) return "N/D_MODEL_SIZE";
        if (freeVramBytes < modelBytes) return "VRAM_SHORT_CPU_OFFLOAD_POSSIBLE";
        var reserve = Math.Max(GiB / 2, (long)Math.Ceiling(modelBytes * 0.30d));
        if (freeVramBytes >= modelBytes && freeVramBytes - modelBytes >= reserve)
            return "LIKELY_FITS_HEURISTIC";
        return "BORDERLINE_HEURISTIC";
    }

    private static long? GetOllamaModelsFreeSpace()
    {
        try
        {
            var configured = Environment.GetEnvironmentVariable("OLLAMA_MODELS");
            var target = string.IsNullOrWhiteSpace(configured)
                ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".ollama", "models")
                : Environment.ExpandEnvironmentVariables(configured.Trim().Trim('"'));

            if (string.IsNullOrWhiteSpace(target) || !Path.IsPathRooted(target))
                return null;

            var existing = FindExistingDirectory(target);
            if (existing is null)
                return null;

            var root = Path.GetPathRoot(existing);
            if (string.IsNullOrWhiteSpace(root))
                return null;

            var drive = new DriveInfo(root);
            return drive.IsReady ? drive.AvailableFreeSpace : null;
        }
        catch (Exception ex) when (ex is ArgumentException or IOException or UnauthorizedAccessException or System.Security.SecurityException or NotSupportedException)
        {
            return null;
        }
    }

    private static string? FindExistingDirectory(string target)
    {
        var current = target;
        try
        {
            if (File.Exists(current)) current = Path.GetDirectoryName(current) ?? current;
            while (!string.IsNullOrWhiteSpace(current))
            {
                if (Directory.Exists(current)) return Path.GetFullPath(current);
                var parent = Path.GetDirectoryName(current.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
                if (string.IsNullOrWhiteSpace(parent) || string.Equals(parent, current, StringComparison.OrdinalIgnoreCase))
                    break;
                current = parent;
            }
        }
        catch (Exception ex) when (ex is ArgumentException or IOException or UnauthorizedAccessException or NotSupportedException)
        {
            return null;
        }

        return null;
    }

    private static string? FindToolPath(ToolKind tool)
    {
        var executableName = tool switch
        {
            ToolKind.Python => "python.exe",
            ToolKind.Git => "git.exe",
            _ => "ollama.exe"
        };

        var fromPath = FindExecutableOnPath(executableName);
        if (fromPath is not null) return fromPath;

        foreach (var candidate in GetCommonCandidates(tool))
        {
            var found = ExistingExecutable(candidate);
            if (found is not null) return found;
        }

        foreach (var candidate in GetUninstallRegistryCandidates(tool))
        {
            var found = ExistingExecutable(candidate);
            if (found is not null) return found;
        }

        return null;
    }

    private static IEnumerable<string> GetCommonCandidates(ToolKind tool)
    {
        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        var programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        var userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        var programData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

        if (tool == ToolKind.Python)
        {
            foreach (var root in new[] { Path.Combine(local, "Programs", "Python"), programFiles, programFilesX86 })
            {
                foreach (var dir in EnumerateDirectories(root, "Python*"))
                    yield return Path.Combine(dir, "python.exe");
            }
            foreach (var root in new[]
            {
                Path.Combine(userProfile, "miniconda3"), Path.Combine(userProfile, "anaconda3"),
                Path.Combine(programData, "Miniconda3"), Path.Combine(programData, "Anaconda3")
            })
                yield return Path.Combine(root, "python.exe");
        }
        else if (tool == ToolKind.Git)
        {
            foreach (var root in new[]
            {
                Path.Combine(programFiles, "Git"), Path.Combine(programFilesX86, "Git"),
                Path.Combine(local, "Programs", "Git")
            })
            {
                yield return Path.Combine(root, "cmd", "git.exe");
                yield return Path.Combine(root, "bin", "git.exe");
                yield return Path.Combine(root, "git.exe");
            }
        }
        else
        {
            yield return Path.Combine(local, "Programs", "Ollama", "ollama.exe");
            yield return Path.Combine(programFiles, "Ollama", "ollama.exe");
        }
    }

    private static IEnumerable<string> EnumerateDirectories(string root, string pattern)
    {
        if (string.IsNullOrWhiteSpace(root) || !Directory.Exists(root))
            yield break;

        string[] directories;
        try { directories = Directory.GetDirectories(root, pattern, SearchOption.TopDirectoryOnly); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException)
        {
            directories = Array.Empty<string>();
        }

        foreach (var directory in directories)
            yield return directory;
    }

    private static IReadOnlyList<string> GetUninstallRegistryCandidates(ToolKind tool)
    {
        var candidates = new List<string>(8);
        foreach (var hive in UninstallRegistryHives)
        foreach (var view in UninstallRegistryViews)
        {
            RegistryKey? baseKey = null;
            RegistryKey? uninstallRoot = null;
            try
            {
                baseKey = RegistryKey.OpenBaseKey(hive, view);
                uninstallRoot = baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", writable: false);
                if (uninstallRoot is null) continue;

                foreach (var childName in uninstallRoot.GetSubKeyNames())
                {
                    using var appKey = uninstallRoot.OpenSubKey(childName, writable: false);
                    if (appKey is null) continue;

                    var displayName = ReadRegistryString(appKey, "DisplayName");
                    if (!MatchesToolName(tool, displayName)) continue;

                    var installLocation = ReadRegistryString(appKey, "InstallLocation");
                    var displayIcon = ReadRegistryString(appKey, "DisplayIcon");
                    foreach (var sourcePath in new[] { displayIcon, installLocation })
                    {
                        var normalized = NormalizeRegistryPath(sourcePath);
                        if (normalized is null) continue;
                        foreach (var candidate in CandidatesFromInstallPath(tool, normalized))
                            candidates.Add(candidate);
                    }
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Security.SecurityException or ArgumentException or PlatformNotSupportedException)
            {
                // Registry inventory is best-effort; PATH and common locations remain available.
            }
            finally
            {
                uninstallRoot?.Dispose();
                baseKey?.Dispose();
            }
        }

        return candidates;
    }

    private static string? ReadRegistryString(RegistryKey key, string valueName)
    {
        try
        {
            return key.GetValue(valueName, null, RegistryValueOptions.DoNotExpandEnvironmentNames) as string;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Security.SecurityException)
        {
            return null;
        }
    }

    private static bool MatchesToolName(ToolKind tool, string? displayName)
    {
        if (string.IsNullOrWhiteSpace(displayName)) return false;
        return tool switch
        {
            ToolKind.Python => displayName.StartsWith("Python ", StringComparison.OrdinalIgnoreCase),
            ToolKind.Git => string.Equals(displayName, "Git", StringComparison.OrdinalIgnoreCase) ||
                            displayName.StartsWith("Git version", StringComparison.OrdinalIgnoreCase) ||
                            displayName.Contains("Git for Windows", StringComparison.OrdinalIgnoreCase),
            _ => displayName.Contains("Ollama", StringComparison.OrdinalIgnoreCase)
        };
    }

    private static string? NormalizeRegistryPath(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var path = value.Trim();
        if (path.StartsWith('"'))
        {
            var closingQuote = path.IndexOf('"', 1);
            path = closingQuote > 1 ? path[1..closingQuote] : path.Trim('"');
        }
        else
        {
            var comma = path.IndexOf(',');
            if (comma >= 0) path = path[..comma];
        }

        path = Environment.ExpandEnvironmentVariables(path.Trim().Trim('"'));
        try
        {
            return Path.IsPathRooted(path) ? Path.GetFullPath(path) : null;
        }
        catch (Exception ex) when (ex is ArgumentException or IOException or NotSupportedException)
        {
            return null;
        }
    }

    private static IEnumerable<string> CandidatesFromInstallPath(ToolKind tool, string path)
    {
        if (string.Equals(Path.GetFileName(path), ExecutableName(tool), StringComparison.OrdinalIgnoreCase))
        {
            yield return path;
            yield break;
        }

        if (tool == ToolKind.Git)
        {
            yield return Path.Combine(path, "cmd", "git.exe");
            yield return Path.Combine(path, "bin", "git.exe");
            yield return Path.Combine(path, "git.exe");
        }
        else
        {
            yield return Path.Combine(path, ExecutableName(tool));
        }
    }

    private static string? FindExecutableOnPath(string executableName)
    {
        var pathValue = Environment.GetEnvironmentVariable("PATH");
        if (string.IsNullOrWhiteSpace(pathValue)) return null;
        foreach (var segment in pathValue.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            var directory = segment.Trim().Trim('"');
            if (string.IsNullOrWhiteSpace(directory)) continue;
            var candidate = ExistingExecutable(Path.Combine(directory, executableName));
            if (candidate is not null) return candidate;
        }

        return null;
    }

    private static string? FindWingetPath()
    {
        return FindExecutableOnPath("winget.exe") ??
               ExistingExecutable(Path.Combine(
                   Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                   "Microsoft", "WindowsApps", "winget.exe"));
    }

    private static string? ExistingExecutable(string candidate)
    {
        try
        {
            return File.Exists(candidate) ? Path.GetFullPath(candidate) : null;
        }
        catch (Exception ex) when (ex is ArgumentException or IOException or UnauthorizedAccessException or NotSupportedException)
        {
            return null;
        }
    }

    private static string ExecutableName(ToolKind tool) => tool switch
    {
        ToolKind.Python => "python.exe",
        ToolKind.Git => "git.exe",
        _ => "ollama.exe"
    };

    private static string? ReadString(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value)) return null;
        return value.ValueKind == JsonValueKind.String ? value.GetString() : null;
    }

    private static string? ReadFirstString(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value)) return null;
        if (value.ValueKind == JsonValueKind.String) return value.GetString();
        if (value.ValueKind != JsonValueKind.Array) return null;
        foreach (var entry in value.EnumerateArray())
            if (entry.ValueKind == JsonValueKind.String) return entry.GetString();
        return null;
    }

    private static long? ReadInt64(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value)) return null;
        if (value.ValueKind == JsonValueKind.Number && value.TryGetInt64(out var number)) return number;
        if (value.ValueKind == JsonValueKind.String && long.TryParse(value.GetString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out number)) return number;
        return null;
    }

    private static string NormalizeSha256(string? digest)
    {
        if (string.IsNullOrWhiteSpace(digest)) return NotDetermined;
        var value = digest.Trim();
        var hex = value.StartsWith("sha256:", StringComparison.OrdinalIgnoreCase) ? value[7..] : value;
        return hex.Length == 64 && hex.All(Uri.IsHexDigit) ? "sha256:" + hex.ToLowerInvariant() : NotDetermined;
    }

    private enum ToolKind { Python, Ollama, Git }
    private const uint DigcfPresent = 0x00000002;
    private const uint SpdrpDeviceDescription = 0x00000000;
    private const uint SpdrpFriendlyName = 0x0000000C;
    private static readonly IntPtr InvalidHandleValue = new(-1);

    [StructLayout(LayoutKind.Sequential)]
    private struct SpDevInfoData
    {
        public uint CbSize;
        public Guid ClassGuid;
        public uint DevInst;
        public IntPtr Reserved;
    }

    [DllImport("setupapi.dll", EntryPoint = "SetupDiGetClassDevsW", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr SetupDiGetClassDevs(ref Guid classGuid, string? enumerator, IntPtr parentWindow, uint flags);

    [DllImport("setupapi.dll", EntryPoint = "SetupDiEnumDeviceInfo", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiEnumDeviceInfo(IntPtr deviceInfoSet, uint memberIndex, ref SpDevInfoData deviceInfoData);

    [DllImport("setupapi.dll", EntryPoint = "SetupDiGetDeviceRegistryPropertyW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiGetDeviceRegistryPropertyW(
        IntPtr deviceInfoSet,
        ref SpDevInfoData deviceInfoData,
        uint property,
        out uint propertyRegDataType,
        IntPtr propertyBuffer,
        uint propertyBufferSize,
        out uint requiredSize);

    [DllImport("setupapi.dll", EntryPoint = "SetupDiDestroyDeviceInfoList", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetupDiDestroyDeviceInfoList(IntPtr deviceInfoSet);

    private sealed record OllamaProbe(bool Ready, IReadOnlyList<InstalledModel> Models);
    private sealed record GpuDevice(string Name, long? TotalBytes, long? FreeBytes);
    private sealed record GpuProbe(string Name, long? TotalBytes, long? FreeBytes, string Status)
    {
        public static GpuProbe NotAvailable { get; } = new(NotDetermined, null, null, NotDetermined);
    }
    private sealed record ProcessResult(int ExitCode, string StandardOutput, string StandardError, bool TimedOut);

    [StructLayout(LayoutKind.Sequential)]
    private struct MemoryStatusEx
    {
        public uint Length;
        public uint MemoryLoad;
        public ulong TotalPhys;
        public ulong AvailablePhys;
        public ulong TotalPageFile;
        public ulong AvailablePageFile;
        public ulong TotalVirtual;
        public ulong AvailableVirtual;
        public ulong AvailableExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatusEx buffer);
}

public sealed record PreflightSnapshot(
    string PythonPath,
    string OllamaPath,
    string GitPath,
    string WingetPath,
    bool OllamaReady,
    IReadOnlyList<InstalledModel> InstalledModels,
    long? FreeDiskBytes,
    long? VramTotalBytes,
    long? VramFreeBytes,
    string GpuName,
    string VramStatus,
    string CompatibilityNote,
    string WindowsVersion,
    int ProcessorCount,
    long? RamTotalBytes,
    long? RamFreeBytes,
    string WebView2RuntimeVersion,
    IReadOnlyList<NetworkEndpointSnapshot> NetworkEndpoints,
    IReadOnlyList<InstalledComponent> InstalledComponents,
    IReadOnlyList<RequiredLibrarySnapshot> RequiredLibraries)
{
    /// <summary>Remains REVIEW_REQUIRED until the user explicitly acknowledges model licensing.</summary>
    public string LicenseStatus { get; init; } = "REVIEW_REQUIRED";
}

/// <summary>Ollama /api/tags metadata; Digest is the server-reported SHA-256, not a local rehash.</summary>
public sealed record InstalledModel(
    string Name,
    long SizeBytes,
    string Digest,
    string Format,
    string Family,
    string ParameterSize,
    string QuantizationLevel);

public sealed record NetworkEndpointSnapshot(string Name, string Host, int Port, string Status, string Check);

public sealed record InstalledComponent(string Name, string Status, string Path, string Version);

public sealed record RequiredLibrarySnapshot(string Name, string Status, string VersionOrEvidence);
