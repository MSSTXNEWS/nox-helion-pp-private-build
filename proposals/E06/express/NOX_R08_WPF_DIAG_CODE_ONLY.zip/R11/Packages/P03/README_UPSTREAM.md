# NOX HELION — исполнитель 03

Standalone WPF Model Center candidate for Windows. It provides Ollama model downloads, a durable queue, read-only PC diagnostics, a fixed WinGet component allowlist, local GGUF review/import, and hash-checked backup/restore. The UI uses the NOX graphite/amber palette and does not edit or replace the executor 01 shell.

## Build

On Windows with the .NET 8 SDK, run `Scripts/Build-Windows.ps1`. Open the returned WPF window through `ModelCenterLauncher.CreateWindow()` from the host. See `worker-window/WINDOWS_ACCEPTANCE.md` before any acceptance run.

## Safety and truth in status

- Ollama pulls call only the local loopback API. Progress is byte-based when the API sends totals; otherwise the UI is indeterminate.
- The catalog contains 24 official Ollama library entries. License review, runtime size, external checksum, and VRAM estimates remain `REVIEW_REQUIRED` or `N/D` unless backed by source evidence. User acknowledgement does not replace license review.
- Ollama import is limited to GGUF. The candidate is rehashed; the selected license text, file path/SHA, format/compatibility review, rights attestation, and a separate import confirmation are required. `.safetensors`, ONNX, and other recognized formats can be scanned and hashed but remain unsupported for Ollama import. The separate staging action only copies the file; it does not install or execute it.
- Component changes use a fixed WinGet package ID allowlist, visible result events, and explicit operation and agreement confirmation.
- Backup archives include a SHA-256 manifest. Restore validates paths and file hashes before writing and asks for confirmation.
- This workspace has no Windows/.NET SDK, so Windows build and runtime acceptance are **PENDING / N/D**. This source package is not an EXE and does not establish product release acceptance.

## Entry points

- `ModelCenterLauncher.CreateWindow()` — host integration.
- `ModelCenterEventHub` — local structured events for progress, results, and errors.
- `DownloadQueueStore` — persistent FIFO queue under LocalAppData.
- `OllamaPullService` — streaming `/api/pull` and installed `/api/tags` readback.
- `ComponentInstaller`, `LocalModelFileScanner`, `OllamaGgufImporter`, `BackupRestoreService` — bounded component operations.

