using System.Diagnostics;
using System.Text.RegularExpressions;

namespace NOX.P01.ModelCenter;

/// <summary>
/// Installs the optional Windows x64 / NVIDIA training profile into a private
/// NOX virtual environment. It never changes the global Python installation.
/// Direct package versions are pinned below; the GPU wheel comes from
/// PyTorch's official cu128 wheel index.
/// </summary>
public sealed class TrainingRuntimeInstaller
{
    private const string ComponentId = "NOX.TrainingRuntime.NVIDIA.CUDA128";
    private const string TorchWheelIndex = "https://download.pytorch.org/whl/cu128";
    private static readonly string[] TorchPackages = ["torch==2.11.0"];
    private static readonly string[] TrainingPackages =
    [
        "transformers==5.20.2",
        "trl==1.16.0",
        "peft==0.21.2",
        "accelerate==1.15.0",
        "datasets==5.1.0",
        "bitsandbytes==0.50.2",
        "safetensors==0.8.0"
    ];
    private static readonly SemaphoreSlim InstallGate = new(1, 1);
    private readonly IModelCenterEventSink? _events;

    public TrainingRuntimeInstaller(IModelCenterEventSink? events = null) => _events = events;

    public string EnvironmentPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "NOX_HELION", "P01", "training", "venv-nvidia-cu128");

    /// <summary>
    /// Installs the user-selected local NVIDIA profile. Both confirmation flags
    /// must be set by UI after showing the exact profile and package sources.
    /// </summary>
    public async Task InstallNvidiaCuda128Async(
        string pythonExecutable,
        bool userConfirmedProfile,
        bool userAcceptedPackageTerms,
        CancellationToken cancellationToken = default)
    {
        if (!OperatingSystem.IsWindows() || !Environment.Is64BitOperatingSystem)
            throw new PlatformNotSupportedException("The selected training profile requires 64-bit Windows.");
        if (!userConfirmedProfile)
            throw new UnauthorizedAccessException("Explicit user confirmation is required to download the training profile.");
        if (!userAcceptedPackageTerms)
            throw new UnauthorizedAccessException("Review and accept the upstream package terms before installing this profile.");
        if (string.IsNullOrWhiteSpace(pythonExecutable) || !File.Exists(pythonExecutable))
            throw new FileNotFoundException("Select an installed Python 3.12 executable first.");

        await InstallGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            var python = Path.GetFullPath(pythonExecutable);
            await RequirePython312Async(python, cancellationToken).ConfigureAwait(false);
            var root = Path.GetDirectoryName(EnvironmentPath)!;
            Directory.CreateDirectory(root);
            if (Directory.Exists(EnvironmentPath))
                throw new IOException("The NOX training environment already exists. Remove it through the training-runtime action before reinstalling.");

            Publish(ModelCenterEventKind.InstallStarted, "RUNNING", "NVIDIA training runtime installation started after explicit confirmation.");
            var environmentCreated = false;
            try
            {
                environmentCreated = true;
                await RunAsync(python, ["-m", "venv", EnvironmentPath], "Creating the isolated NOX Python environment.", cancellationToken).ConfigureAwait(false);
                var venvPython = Path.Combine(EnvironmentPath, "Scripts", "python.exe");
                if (!File.Exists(venvPython)) throw new InvalidOperationException("Python did not create the expected isolated interpreter.");

                await RunAsync(venvPython,
                    ["-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--index-url", TorchWheelIndex, .. TorchPackages],
                    "Installing the pinned PyTorch CUDA 12.8 runtime.", cancellationToken).ConfigureAwait(false);
                await RunAsync(venvPython,
                    ["-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--index-url", "https://pypi.org/simple", .. TrainingPackages],
                    "Installing the pinned Hugging Face training modules.", cancellationToken).ConfigureAwait(false);

                cancellationToken.ThrowIfCancellationRequested();
                Publish(ModelCenterEventKind.InstallCompleted, "COMPLETED", "Pinned NVIDIA training runtime installed in the private NOX environment.");
            }
            catch (OperationCanceledException)
            {
                if (environmentCreated) TryRemoveCreatedEnvironment();
                Publish(ModelCenterEventKind.InstallFailed, "STOPPED", "Training runtime installation was stopped; the partial NOX environment was removed.", "CANCELLED");
                throw;
            }
            catch (Exception ex)
            {
                if (environmentCreated) TryRemoveCreatedEnvironment();
                Publish(ModelCenterEventKind.InstallFailed, "ERROR", SafeError(ex), "TRAINING_RUNTIME_INSTALL_FAILED");
                throw;
            }
        }
        finally
        {
            InstallGate.Release();
        }
    }

    /// <summary>Removes only this NOX-owned environment, after explicit consent.</summary>
    public void RemoveNvidiaCuda128(bool userConfirmedRemoval)
    {
        if (!userConfirmedRemoval)
            throw new UnauthorizedAccessException("Explicit user confirmation is required to remove the NOX training environment.");
        if (!Directory.Exists(EnvironmentPath)) return;
        var expectedRoot = Path.GetFullPath(Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NOX_HELION", "P01", "training"));
        var actual = Path.GetFullPath(EnvironmentPath);
        if (!actual.StartsWith(expectedRoot + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Refusing to remove a path outside the NOX training directory.");
        TryRemoveCreatedEnvironment();
        Publish(ModelCenterEventKind.RemoveCompleted, "COMPLETED", "NOX training environment removed.");
    }

    private static async Task RequirePython312Async(string python, CancellationToken token)
    {
        var result = await CaptureAsync(python,
            ["-c", "import platform,struct; print(platform.python_version()+':'+str(struct.calcsize('P')*8))"], token).ConfigureAwait(false);
        var match = Regex.Match(result, @"^(?<major>\d+)\.(?<minor>\d+)[^:]*:(?<bits>\d+)\s*$", RegexOptions.CultureInvariant);
        if (!match.Success || match.Groups["major"].Value != "3" || match.Groups["minor"].Value != "12" || match.Groups["bits"].Value != "64")
            throw new InvalidOperationException("This locked NVIDIA profile requires Python 3.12 x64.");
    }

    private async Task RunAsync(string executable, IReadOnlyList<string> arguments, string stage, CancellationToken token)
    {
        Publish(ModelCenterEventKind.ComponentProgress, "RUNNING", stage);
        await CaptureAsync(executable, arguments, token).ConfigureAwait(false);
    }

    private static async Task<string> CaptureAsync(string executable, IReadOnlyList<string> arguments, CancellationToken token)
    {
        var start = new ProcessStartInfo
        {
            FileName = executable,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            WorkingDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
        };
        foreach (var argument in arguments) start.ArgumentList.Add(argument);

        using var process = new Process { StartInfo = start };
        if (!process.Start()) throw new InvalidOperationException("The selected Python process could not be started.");
        var stdout = process.StandardOutput.ReadToEndAsync(token);
        var stderr = process.StandardError.ReadToEndAsync(token);
        try
        {
            await process.WaitForExitAsync(token).ConfigureAwait(false);
            await Task.WhenAll(stdout, stderr).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
            throw;
        }

        if (process.ExitCode != 0)
            throw new InvalidOperationException($"Python package operation failed with exit code {process.ExitCode}.");
        var output = await stdout.ConfigureAwait(false);
        return output.Length > 2000 ? output[..2000] : output;
    }

    private void TryRemoveCreatedEnvironment()
    {
        try
        {
            if (Directory.Exists(EnvironmentPath)) Directory.Delete(EnvironmentPath, recursive: true);
        }
        catch
        {
            Publish(ModelCenterEventKind.Error, "HOLD", "Could not remove the partial NOX training environment; use the remove-runtime action.", "ROLLBACK_INCOMPLETE");
        }
    }

    private static string SafeError(Exception exception)
    {
        var text = exception.GetType().Name;
        return text.Length <= 120 ? text : text[..120];
    }

    private void Publish(ModelCenterEventKind kind, string state, string message, string? code = null) =>
        _events?.Publish(new ModelCenterEvent
        {
            Kind = kind,
            ComponentId = ComponentId,
            State = state,
            Message = message,
            ErrorCode = code
        });
}
