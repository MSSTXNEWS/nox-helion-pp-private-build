using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;

namespace NoxP01.WorkerCatalog;

/// <summary>Immutable catalog metadata for one exact Ollama model tag.</summary>
public sealed record ModelCatalogEntry
{
    public const string NotDetermined = "N/D";
    public const string ReviewRequired = "REVIEW_REQUIRED";

    public string Tag { get; }
    public string DisplayTitle { get; }
    public string Category { get; }
    public string LibrarySlug { get; }
    public string LibraryUrl { get; }
    public string LicenseUrl { get; }
    public string LicenseReviewStatus { get; }
    public string ParameterSize { get; }
    public string RuntimeSize { get; }
    public string RuntimeSizeSource { get; }
    public string Sha256 { get; }
    public string Sha256Source { get; }
    public string VramEstimate { get; }
    public string VramEstimateSource { get; }
    // Compatibility aliases used by the shared ModelCenter API.
    public string Title => DisplayTitle;
    public string ModelPageUrl => LibraryUrl;
    public string LicenseStatus => LicenseReviewStatus;
    public string SizeSourceStatus => RuntimeSizeSource;
    private readonly double? _estimatedMinVramGiB;
    public double? EstimatedMinVramGiB => _estimatedMinVramGiB;

    public ModelCatalogEntry(
        string tag,
        string displayTitle,
        string category,
        string librarySlug,
        string licenseReviewStatus = ReviewRequired,
        string runtimeSize = NotDetermined,
        string runtimeSizeSource = NotDetermined,
        string sha256 = NotDetermined,
        string sha256Source = NotDetermined,
        string vramEstimate = NotDetermined,
        string vramEstimateSource = NotDetermined)
    {
        RequireText(tag, nameof(tag));
        RequireText(displayTitle, nameof(displayTitle));
        RequireText(category, nameof(category));
        RequireText(librarySlug, nameof(librarySlug));
        RequireText(licenseReviewStatus, nameof(licenseReviewStatus));
        RequireText(runtimeSize, nameof(runtimeSize));
        RequireText(runtimeSizeSource, nameof(runtimeSizeSource));
        RequireText(sha256, nameof(sha256));
        RequireText(sha256Source, nameof(sha256Source));
        RequireText(vramEstimate, nameof(vramEstimate));
        RequireText(vramEstimateSource, nameof(vramEstimateSource));

        if (!string.Equals(tag, librarySlug, StringComparison.OrdinalIgnoreCase) &&
            !tag.StartsWith(librarySlug + ":", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("The library slug must match the tag's model name.", nameof(librarySlug));
        if (runtimeSize == NotDetermined && runtimeSizeSource != NotDetermined)
            throw new ArgumentException("An unknown runtime size cannot claim a source.", nameof(runtimeSizeSource));
        if (sha256 == NotDetermined && sha256Source != NotDetermined)
            throw new ArgumentException("An unknown digest cannot claim a source.", nameof(sha256Source));
        if (sha256 != NotDetermined &&
            (sha256.Length != 64 || sha256.Any(character => !Uri.IsHexDigit(character))))
            throw new ArgumentException("SHA-256 must be N/D or exactly 64 hexadecimal characters.", nameof(sha256));
        if (vramEstimate == NotDetermined && vramEstimateSource != NotDetermined)
            throw new ArgumentException("An unknown VRAM estimate cannot claim a source.", nameof(vramEstimateSource));
        if (vramEstimate != NotDetermined &&
            !vramEstimateSource.StartsWith("ESTIMATE:", StringComparison.Ordinal))
            throw new ArgumentException("A VRAM estimate must identify its estimation source.", nameof(vramEstimateSource));

        Tag = tag;
        DisplayTitle = displayTitle;
        Category = category;
        LibrarySlug = librarySlug;
        LibraryUrl = $"https://ollama.com/library/{librarySlug}";
        LicenseUrl = LibraryUrl;
        LicenseReviewStatus = licenseReviewStatus;
        ParameterSize = ParseParameterSize(tag);
        RuntimeSize = runtimeSize;
        RuntimeSizeSource = runtimeSizeSource;
        Sha256 = sha256;
        Sha256Source = sha256Source;
        VramEstimate = vramEstimate;
        VramEstimateSource = vramEstimateSource;
        _estimatedMinVramGiB = ParseVramEstimate(vramEstimate);
    }

    private static void RequireText(string value, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("A non-empty value is required.", parameterName);
    }

    private static string ParseParameterSize(string tag)
    {
        var separator = tag.LastIndexOf(':');
        if (separator < 0) return NotDetermined;

        var suffix = tag[(separator + 1)..];
        if (suffix.Length < 2 || char.ToLowerInvariant(suffix[^1]) != 'b') return NotDetermined;
        var number = suffix[..^1];
        var dotCount = 0;
        foreach (var character in number)
        {
            if (character == '.') { dotCount++; continue; }
            if (!char.IsAsciiDigit(character)) return NotDetermined;
        }
        if (number.Length == 0 || number[0] == '.' || number[^1] == '.' || dotCount > 1)
            return NotDetermined;
        return number + "B";
    }

    private static double? ParseVramEstimate(string value)
    {
        if (string.Equals(value, NotDetermined, StringComparison.OrdinalIgnoreCase))
            return null;
        var span = value.AsSpan();
        var length = 0;
        while (length < span.Length && (char.IsAsciiDigit(span[length]) || span[length] == '.'))
            length++;
        if (length == 0 ||
            !double.TryParse(span[..length], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var parsed) ||
            !double.IsFinite(parsed) || parsed <= 0)
            return null;
        return parsed;
    }
}

public static class ModelCatalog
{
    private static readonly IReadOnlyList<ModelCatalogEntry> Entries = Array.AsReadOnly(new[]
    {
        new ModelCatalogEntry("qwen3:0.6b", "Qwen3 0.6B", "Light", "qwen3"),
        new ModelCatalogEntry("qwen3:1.7b", "Qwen3 1.7B", "Light", "qwen3"),
        new ModelCatalogEntry("qwen3:4b", "Qwen3 4B", "Core", "qwen3"),
        new ModelCatalogEntry("llama3.2:1b", "Llama 3.2 1B", "Light", "llama3.2"),
        new ModelCatalogEntry("llama3.2:3b", "Llama 3.2 3B", "Light", "llama3.2"),
        new ModelCatalogEntry("gemma3:1b", "Gemma3 1B", "Light", "gemma3"),
        new ModelCatalogEntry("qwen3:8b", "Qwen3 8B", "Core", "qwen3"),
        new ModelCatalogEntry("qwen3:14b", "Qwen3 14B", "Core", "qwen3"),
        new ModelCatalogEntry("deepseek-r1:1.5b", "DeepSeek R1 1.5B", "Reasoning", "deepseek-r1"),
        new ModelCatalogEntry("deepseek-r1:7b", "DeepSeek R1 7B", "Reasoning", "deepseek-r1"),
        new ModelCatalogEntry("deepseek-r1:14b", "DeepSeek R1 14B", "Reasoning", "deepseek-r1"),
        new ModelCatalogEntry("phi4:14b", "Phi4 14B", "Reasoning", "phi4"),
        new ModelCatalogEntry("mistral:7b", "Mistral 7B", "Core", "mistral"),
        new ModelCatalogEntry("qwen2.5-coder:3b", "Coder 3B", "Code", "qwen2.5-coder"),
        new ModelCatalogEntry("qwen2.5-coder:7b", "Coder 7B", "Code", "qwen2.5-coder"),
        new ModelCatalogEntry("starcoder2:3b", "StarCoder2 3B", "Code", "starcoder2"),
        new ModelCatalogEntry("gemma3:4b", "Gemma3 4B", "Multimodal", "gemma3"),
        new ModelCatalogEntry("llava:7b", "LLaVA 7B", "Multimodal", "llava"),
        new ModelCatalogEntry("qwen2.5vl:3b", "Qwen VL 3B", "Multimodal", "qwen2.5vl"),
        new ModelCatalogEntry("nomic-embed-text", "Nomic", "Embeddings", "nomic-embed-text"),
        new ModelCatalogEntry("mxbai-embed-large", "MxBAI", "Embeddings", "mxbai-embed-large"),
        new ModelCatalogEntry("all-minilm", "MiniLM", "Embeddings", "all-minilm"),
        new ModelCatalogEntry("bge-m3", "BGE-M3", "Embeddings", "bge-m3"),
        new ModelCatalogEntry("embeddinggemma", "EmbeddingGemma", "Embeddings", "embeddinggemma"),
    });

    private static readonly IReadOnlyDictionary<string, ModelCatalogEntry> EntriesByTag;

    static ModelCatalog()
    {
        if (Entries.Count != 24)
            throw new InvalidOperationException("The R7 source catalog must contain exactly 24 entries.");

        var uniqueTags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var byTag = new Dictionary<string, ModelCatalogEntry>(Entries.Count, StringComparer.OrdinalIgnoreCase);
        foreach (var entry in Entries)
        {
            if (!uniqueTags.Add(entry.Tag))
                throw new InvalidOperationException($"Duplicate Ollama model tag: {entry.Tag}");
            if (entry.LicenseReviewStatus != ModelCatalogEntry.ReviewRequired)
                throw new InvalidOperationException($"License review is required before use: {entry.Tag}");
            byTag.Add(entry.Tag, entry);
        }
        EntriesByTag = byTag;
    }

    public static IReadOnlyList<ModelCatalogEntry> GetAll() => Entries;

    public static bool TryGetByTag(string? tag, out ModelCatalogEntry entry)
    {
        if (tag is not null && EntriesByTag.TryGetValue(tag, out var found))
        {
            entry = found;
            return true;
        }
        entry = null!;
        return false;
    }
}
