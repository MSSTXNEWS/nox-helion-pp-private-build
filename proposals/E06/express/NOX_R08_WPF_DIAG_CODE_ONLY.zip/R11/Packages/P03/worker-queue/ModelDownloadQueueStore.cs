using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using NoxP01.WorkerCatalog;

namespace NOX.P01.ModelCenter;

/// <summary>Durable states used by the model download FIFO.</summary>
public enum DownloadQueueState
{
    QUEUED,
    DOWNLOADING,
    PAUSED,
    FAILED,
    COMPLETED,
    CANCELLED
}

public sealed class DownloadQueueWarningEventArgs(string code, string message, string archivePath) : EventArgs
{
    public Guid EventId { get; } = Guid.NewGuid();
    public string Code { get; } = code;
    public string Message { get; } = message;
    public string ArchivePath { get; } = archivePath;
}

public sealed class DownloadQueueItemStateChangedEventArgs(
    string itemId,
    string tag,
    string? previousState,
    string state,
    long stopGeneration) : EventArgs
{
    public string ItemId { get; } = itemId;
    public string Tag { get; } = tag;
    public string? PreviousState { get; } = previousState;
    public string State { get; } = state;
    public long StopGeneration { get; } = stopGeneration;
}

/// <summary>
/// A bindable queue row. Setters are internal so UI code can observe changes without
/// bypassing the store's durable, atomic update path.
/// </summary>
public sealed class DownloadQueueItem : INotifyPropertyChanged
{
    private string _state = DownloadQueueState.QUEUED.ToString();
    private int _attempts;
    private long _bytesCompleted;
    private long _bytesTotal;
    private string? _sha256Digest;
    private string? _observedDigest;
    private string? _lastError;
    private DateTimeOffset _updatedAt;

    public string Id { get; internal set; } = string.Empty;
    public string Tag { get; internal set; } = string.Empty;
    public string Title { get; internal set; } = string.Empty;
    public string Category { get; internal set; } = string.Empty;
    public string ModelPageUrl { get; internal set; } = string.Empty;
    public string LicenseUrl { get; internal set; } = string.Empty;
    public string LicenseStatus { get; internal set; } = string.Empty;
    public double? EstimatedMinVramGiB { get; internal set; }
    public string SizeSourceStatus { get; internal set; } = string.Empty;
    public string RuntimeSize { get; internal set; } = string.Empty;
    public string VramEstimate { get; internal set; } = string.Empty;
    public string CatalogSha256 { get; internal set; } = string.Empty;
    public string CatalogSha256Source { get; internal set; } = string.Empty;
    public bool LicenseAcknowledged { get; internal set; }
    public DateTimeOffset? LicenseAcknowledgedAt { get; internal set; }

    public string State
    {
        get => _state;
        internal set => Set(ref _state, value);
    }

    public int Attempts
    {
        get => _attempts;
        internal set => Set(ref _attempts, value);
    }

    public long BytesCompleted
    {
        get => _bytesCompleted;
        internal set => Set(ref _bytesCompleted, value);
    }

    public long BytesTotal
    {
        get => _bytesTotal;
        internal set => Set(ref _bytesTotal, value);
    }

    public string? Sha256Digest
    {
        get => _sha256Digest;
        internal set => Set(ref _sha256Digest, value);
    }

    /// <summary>Last digest reported by the pull stream; not a verified model digest.</summary>
    public string? ObservedDigest
    {
        get => _observedDigest;
        internal set => Set(ref _observedDigest, value);
    }

    public string? LastError
    {
        get => _lastError;
        internal set => Set(ref _lastError, value);
    }

    public DateTimeOffset CreatedAt { get; internal set; }
    public DateTimeOffset? LastAttemptAt { get; internal set; }
    public DateTimeOffset? StartedAt { get; internal set; }
    public DateTimeOffset? CompletedAt { get; internal set; }
    public int? DownloaderProcessId { get; internal set; }
    public DateTimeOffset? DownloaderProcessStartUtc { get; internal set; }
    public Guid? DownloaderLeaseId { get; internal set; }
    public long StopGeneration { get; internal set; }
    public long AcknowledgedStopGeneration { get; internal set; }
    public long? InstalledSizeBytes { get; internal set; }
    public bool HashVerified { get; internal set; }

    public DateTimeOffset UpdatedAt
    {
        get => _updatedAt;
        internal set => Set(ref _updatedAt, value);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    internal DownloadQueueItem Copy() => new()
    {
        Id = Id,
        Tag = Tag,
        Title = Title,
        Category = Category,
        ModelPageUrl = ModelPageUrl,
        LicenseUrl = LicenseUrl,
        LicenseStatus = LicenseStatus,
        EstimatedMinVramGiB = EstimatedMinVramGiB,
        SizeSourceStatus = SizeSourceStatus,
        RuntimeSize = RuntimeSize,
        VramEstimate = VramEstimate,
        CatalogSha256 = CatalogSha256,
        CatalogSha256Source = CatalogSha256Source,
        LicenseAcknowledged = LicenseAcknowledged,
        LicenseAcknowledgedAt = LicenseAcknowledgedAt,
        State = State,
        Attempts = Attempts,
        BytesCompleted = BytesCompleted,
        BytesTotal = BytesTotal,
        Sha256Digest = Sha256Digest,
        ObservedDigest = ObservedDigest,
        LastError = LastError,
        CreatedAt = CreatedAt,
        LastAttemptAt = LastAttemptAt,
        StartedAt = StartedAt,
        CompletedAt = CompletedAt,
        DownloaderProcessId = DownloaderProcessId,
        DownloaderProcessStartUtc = DownloaderProcessStartUtc,
        DownloaderLeaseId = DownloaderLeaseId,
        StopGeneration = StopGeneration,
        AcknowledgedStopGeneration = AcknowledgedStopGeneration,
        InstalledSizeBytes = InstalledSizeBytes,
        HashVerified = HashVerified,
        UpdatedAt = UpdatedAt
    };

    internal void CopyFrom(DownloadQueueItem other)
    {
        Id = other.Id;
        Tag = other.Tag;
        Title = other.Title;
        Category = other.Category;
        ModelPageUrl = other.ModelPageUrl;
        LicenseUrl = other.LicenseUrl;
        LicenseStatus = other.LicenseStatus;
        EstimatedMinVramGiB = other.EstimatedMinVramGiB;
        SizeSourceStatus = other.SizeSourceStatus;
        RuntimeSize = other.RuntimeSize;
        VramEstimate = other.VramEstimate;
        CatalogSha256 = other.CatalogSha256;
        CatalogSha256Source = other.CatalogSha256Source;
        LicenseAcknowledged = other.LicenseAcknowledged;
        LicenseAcknowledgedAt = other.LicenseAcknowledgedAt;
        State = other.State;
        Attempts = other.Attempts;
        BytesCompleted = other.BytesCompleted;
        BytesTotal = other.BytesTotal;
        Sha256Digest = other.Sha256Digest;
        ObservedDigest = other.ObservedDigest;
        LastError = other.LastError;
        CreatedAt = other.CreatedAt;
        LastAttemptAt = other.LastAttemptAt;
        StartedAt = other.StartedAt;
        CompletedAt = other.CompletedAt;
        DownloaderProcessId = other.DownloaderProcessId;
        DownloaderProcessStartUtc = other.DownloaderProcessStartUtc;
        DownloaderLeaseId = other.DownloaderLeaseId;
        StopGeneration = other.StopGeneration;
        AcknowledgedStopGeneration = other.AcknowledgedStopGeneration;
        InstalledSizeBytes = other.InstalledSizeBytes;
        HashVerified = other.HashVerified;
        UpdatedAt = other.UpdatedAt;
    }

    private void Set<T>(ref T field, T value, [System.Runtime.CompilerServices.CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}

/// <summary>
/// Durable FIFO for model downloads. The JSON file is written in the same directory
/// as its temporary file and atomically replaced after its bytes are flushed to disk.
/// </summary>
public sealed class DownloadQueueStore : INotifyPropertyChanged, IDisposable
{
    private const int CurrentSchemaVersion = 1;
    private const string QueueFileName = "queue.json";
    private const long MaxQueueFileBytes = 2 * 1024 * 1024;
    private const int MaxQueueRows = 512;
    private const string InterruptedMessage = "Download was interrupted by application shutdown. Resume it to continue.";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        MaxDepth = 16,
        AllowTrailingCommas = false,
        ReadCommentHandling = JsonCommentHandling.Disallow,
        Converters = { new JsonStringEnumConverter() }
    };

    private readonly object _gate = new();
    private readonly string _directory;
    private readonly string _filePath;
    private readonly string _mutexName;
    private readonly Dispatcher? _dispatcher;
    private readonly int _currentProcessId;
    private readonly DateTimeOffset _currentProcessStartUtc;
    private readonly ObservableCollection<DownloadQueueItem> _mutableItems = new();
    private readonly ReadOnlyObservableCollection<DownloadQueueItem> _items;
    private readonly Timer _refreshTimer;
    private List<DownloadQueueItem> _records = new();
    private long _revision;
    private long _publishedRevision = -1;
    private DownloadQueueWarningEventArgs? _pendingWarning;
    private Guid? _publishedWarningId;
    private string? _lastWarning;
    private int _disposed;

    /// <param name="baseDir">Optional queue directory override. By default the queue is stored under LocalAppData.</param>
    public DownloadQueueStore(string? baseDir = null)
    {
        _directory = Path.GetFullPath(string.IsNullOrWhiteSpace(baseDir)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NOX_HELION_Integrator", "downloads")
            : baseDir);
        _filePath = Path.Combine(_directory, QueueFileName);
        var mutexSuffix = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(_filePath))).ToLowerInvariant();
        _mutexName = @"Local\NOX_HELION_ModelDownloadQueue_" + mutexSuffix;
        _dispatcher = Application.Current?.Dispatcher;
        using (var process = Process.GetCurrentProcess())
        {
            _currentProcessId = process.Id;
            _currentProcessStartUtc = new DateTimeOffset(process.StartTime.ToUniversalTime());
        }
        _items = new ReadOnlyObservableCollection<DownloadQueueItem>(_mutableItems);
        _refreshTimer = new Timer(RefreshTimerTick, null, TimeSpan.FromMilliseconds(500), TimeSpan.FromMilliseconds(500));
    }

    /// <summary>Rows in FIFO order. Call Load once before binding or scheduling downloads.</summary>
    public ReadOnlyObservableCollection<DownloadQueueItem> Items => _items;

    /// <summary>Latest recovery warning for status binding.</summary>
    public string? LastWarning => _lastWarning;

    public event PropertyChangedEventHandler? PropertyChanged;
    public event EventHandler<DownloadQueueWarningEventArgs>? WarningRaised;
    public event EventHandler<DownloadQueueItemStateChangedEventArgs>? StateChanged;

    public void Dispose()
    {
        if (Interlocked.Exchange(ref _disposed, 1) != 0) return;
        _refreshTimer.Dispose();
        GC.SuppressFinalize(this);
    }

    /// <summary>Loads the durable queue and recovers interrupted downloads to PAUSED.</summary>
    public ReadOnlyObservableCollection<DownloadQueueItem> Load()
    {
        Snapshot snapshot = default!;
        WithStoreLock(() =>
        {
            EnsureLoadedLocked();
            snapshot = CreateSnapshotLocked();
            return 0;
        });
        Publish(snapshot);
        return _items;
    }

    /// <summary>Adds one model at the tail of the FIFO after explicit license acknowledgement.</summary>
    public DownloadQueueItem Enqueue(ModelCatalogEntry model, bool licenseAcknowledged)
    {
        ArgumentNullException.ThrowIfNull(model);
        if (!licenseAcknowledged)
            throw new InvalidOperationException("The model license must be acknowledged before enqueueing.");

        var tag = NormalizeRequired(model.Tag, nameof(model.Tag), 512);
        var title = NormalizeRequired(model.Title, nameof(model.Title), 512);
        if (model.EstimatedMinVramGiB is double vram && (!double.IsFinite(vram) || vram < 0))
            throw new ArgumentOutOfRangeException(nameof(model.EstimatedMinVramGiB), "Estimated VRAM must be finite and non-negative.");
        var now = DateTimeOffset.UtcNow;
        var item = new DownloadQueueItem
        {
            Id = Guid.NewGuid().ToString("N"),
            Tag = tag,
            Title = title,
            Category = NormalizeOptional(model.Category),
            ModelPageUrl = NormalizeOptional(model.ModelPageUrl),
            LicenseUrl = NormalizeOptional(model.LicenseUrl),
            LicenseStatus = NormalizeOptional(model.LicenseStatus),
            EstimatedMinVramGiB = model.EstimatedMinVramGiB,
            SizeSourceStatus = NormalizeOptional(model.SizeSourceStatus),
            RuntimeSize = NormalizeOptional(model.RuntimeSize),
            VramEstimate = NormalizeOptional(model.VramEstimate),
            CatalogSha256 = NormalizeOptional(model.Sha256),
            CatalogSha256Source = NormalizeOptional(model.Sha256Source),
            LicenseAcknowledged = true,
            LicenseAcknowledgedAt = now,
            State = StateName(DownloadQueueState.QUEUED),
            CreatedAt = now,
            UpdatedAt = now
        };

        Snapshot snapshot = default!;
        WithStoreLock(() =>
        {
            EnsureLoadedLocked();
            EnsureNoActiveTagLocked(tag, null);
            var next = _records.Select(x => x.Copy()).ToList();
            next.Add(item.Copy());
            PersistLocked(next);
            _records = next;
            _revision++;
            snapshot = CreateSnapshotLocked();
            return 0;
        });
        Publish(snapshot);
        return item.Copy();
    }

    /// <summary>Stores the latest byte counts and observed digest from the pull engine.</summary>
    public DownloadQueueItem UpdateProgress(string id, PullProgress progress)
        => throw new InvalidOperationException("Pull progress must include the active stop generation and owner lease.");

    /// <summary>Stores progress only when it still belongs to the active pull owner.</summary>
    public DownloadQueueItem UpdateProgress(string id, PullProgress progress, long expectedStopGeneration, Guid expectedLeaseId)
        => UpdateProgressCore(id, progress, expectedStopGeneration, expectedLeaseId);

    private DownloadQueueItem UpdateProgressCore(string id, PullProgress progress, long expectedStopGeneration, Guid expectedLeaseId)
    {
        ArgumentNullException.ThrowIfNull(progress);
        return Mutate(id, item =>
        {
            // Pull callbacks can be queued by the dispatcher just as Pause/Cancel wins.
            // Only the persisted active row accepts progress; late callbacks cannot
            // move a paused, failed, completed, or cancelled row forward.
            if (item.State != StateName(DownloadQueueState.DOWNLOADING)) return;
            if (item.StopGeneration != expectedStopGeneration ||
                item.AcknowledgedStopGeneration != expectedStopGeneration ||
                item.DownloaderLeaseId != expectedLeaseId)
                return;

            // Treat an aggregate total as authoritative even while aggregate
            // completed bytes are still zero; otherwise per-layer bytes can be
            // incorrectly recorded as whole-model progress.
            var hasAggregateTotal = progress.AggregateTotalBytes > 0;
            var completed = hasAggregateTotal
                ? progress.AggregateCompletedBytes
                : progress.CompletedBytes > 0 ? progress.CompletedBytes : item.BytesCompleted;
            var total = hasAggregateTotal
                ? progress.AggregateTotalBytes
                : progress.TotalBytes > 0 ? progress.TotalBytes : item.BytesTotal;
            item.BytesCompleted = Math.Max(0, completed);
            item.BytesTotal = Math.Max(0, total);
            if (item.BytesTotal > 0 && item.BytesCompleted > item.BytesTotal)
                item.BytesCompleted = item.BytesTotal;

            var digest = FirstNonEmpty(progress.InstalledDigest, progress.Digest);
            if (digest is not null) item.ObservedDigest = NormalizeOptional(digest);
            if (progress.InstalledSizeBytes is > 0) item.InstalledSizeBytes = progress.InstalledSizeBytes;
        });
    }

    /// <summary>Applies a validated state transition. COMPLETED requires a verified PullResult.</summary>
    public DownloadQueueItem SetState(string id, string state, string? error = null, PullResult? result = null)
    {
        var target = ParseState(state);
        if (target == DownloadQueueState.COMPLETED)
            throw new InvalidOperationException("Pull completion must include the current stop generation and owner lease.");
        return Mutate(id, item =>
        {
            if (target == DownloadQueueState.FAILED && item.State == StateName(DownloadQueueState.DOWNLOADING))
                throw new InvalidOperationException("An active pull failure must include the current stop generation and owner lease.");
            ApplyState(item, target, error, result);
        });
    }

    /// <summary>Atomically starts the current FIFO head, returning a fresh row when the caller's view was stale.</summary>
    public bool TryStartDownload(string id, out DownloadQueueItem item)
    {
        Snapshot snapshot = default!;
        DownloadQueueItem result = default!;
        var started = false;
        WithStoreLock(() =>
        {
            EnsureLoadedLocked();
            var index = FindIndexLocked(id);
            var candidate = _records[index].Copy();
            if (!CanStartLocked(candidate))
            {
                result = candidate.Copy();
                snapshot = CreateSnapshotLocked();
                return 0;
            }

            ApplyState(candidate, DownloadQueueState.DOWNLOADING, error: null, result: null);
            candidate.UpdatedAt = DateTimeOffset.UtcNow;
            CommitItemLocked(index, candidate);
            result = candidate.Copy();
            snapshot = CreateSnapshotLocked();
            started = true;
            return 0;
        });
        Publish(snapshot);
        item = result;
        return started;
    }

    /// <summary>
    /// Commits a pull result only if it still belongs to the current owner lease and
    /// no durable stop request has arrived since that pull started.
    /// </summary>
    public DownloadQueueItem SetState(
        string id,
        string state,
        long expectedStopGeneration,
        Guid expectedLeaseId,
        string? error = null,
        PullResult? result = null)
    {
        var target = ParseState(state);
        return Mutate(id, item =>
        {
            if (target is not (DownloadQueueState.COMPLETED or DownloadQueueState.FAILED))
                throw new ArgumentException("Expected lease tokens are supported only for pull completion or failure.", nameof(state));
            if (item.State != StateName(DownloadQueueState.DOWNLOADING) ||
                item.StopGeneration != expectedStopGeneration ||
                item.AcknowledgedStopGeneration != expectedStopGeneration ||
                item.DownloaderLeaseId != expectedLeaseId)
                return;

            ApplyState(item, target, error, result);
        });
    }

    public DownloadQueueItem SetState(
        string id,
        DownloadQueueState state,
        long expectedStopGeneration,
        Guid expectedLeaseId,
        string? error = null,
        PullResult? result = null) =>
        SetState(id, StateName(state), expectedStopGeneration, expectedLeaseId, error, result);

    /// <summary>Releases this pull's owner lease after a durable Pause/Cancel request has stopped it.</summary>
    public DownloadQueueItem AcknowledgePullStopped(string id, long observedStopGeneration, Guid leaseId)
    {
        return Mutate(id, item =>
        {
            if (item.DownloaderLeaseId != leaseId || item.StopGeneration <= observedStopGeneration)
                return;
            if (item.State == StateName(DownloadQueueState.DOWNLOADING))
                throw new InvalidOperationException("The active pull cannot acknowledge a stop request while still marked DOWNLOADING.");

            item.DownloaderProcessId = null;
            item.DownloaderProcessStartUtc = null;
            item.DownloaderLeaseId = null;
            item.AcknowledgedStopGeneration = item.StopGeneration;
        });
    }

    public DownloadQueueItem SetState(string id, DownloadQueueState state, string? error = null, PullResult? result = null) =>
        SetState(id, StateName(state), error, result);

    /// <summary>Requeues a failed download from the beginning; attempt count advances on the next DOWNLOADING transition.</summary>
    public DownloadQueueItem Retry(string id)
    {
        Snapshot snapshot = default!;
        DownloadQueueItem result = default!;
        WithStoreLock(() =>
        {
            EnsureLoadedLocked();
            var index = FindIndexLocked(id);
            var candidate = _records[index].Copy();
            if (candidate.State != StateName(DownloadQueueState.FAILED))
                throw new InvalidOperationException("Only a FAILED download can be retried.");
            if (HasPullOwner(candidate))
                throw new InvalidOperationException("Retry is waiting for the previous pull owner to release its lease.");
            EnsureNoActiveTagLocked(candidate.Tag, candidate.Id);
            candidate.State = StateName(DownloadQueueState.QUEUED);
            candidate.BytesCompleted = 0;
            candidate.Sha256Digest = null;
            candidate.ObservedDigest = null;
            candidate.LastError = null;
            candidate.CompletedAt = null;
            candidate.DownloaderProcessId = null;
            candidate.DownloaderProcessStartUtc = null;
            candidate.DownloaderLeaseId = null;
            candidate.AcknowledgedStopGeneration = candidate.StopGeneration;
            candidate.InstalledSizeBytes = null;
            candidate.HashVerified = false;
            candidate.UpdatedAt = DateTimeOffset.UtcNow;
            CommitItemLocked(index, candidate, moveToTail: true);
            result = candidate.Copy();
            snapshot = CreateSnapshotLocked();
            return 0;
        });
        Publish(snapshot);
        return result;
    }

    /// <summary>Moves an in-flight download to PAUSED while preserving its current progress.</summary>
    public DownloadQueueItem Pause(string id) => Mutate(id, item =>
    {
        RequireState(item, DownloadQueueState.DOWNLOADING);
        item.State = StateName(DownloadQueueState.PAUSED);
        item.StopGeneration = checked(item.StopGeneration + 1);
        item.LastError = null;
    });

    /// <summary>Returns a paused download to the FIFO; its byte offset is retained for resume.</summary>
    public DownloadQueueItem Resume(string id)
    {
        Snapshot snapshot = default!;
        DownloadQueueItem result = default!;
        WithStoreLock(() =>
        {
            EnsureLoadedLocked();
            var index = FindIndexLocked(id);
            var candidate = _records[index].Copy();
            RequireState(candidate, DownloadQueueState.PAUSED);
            if (HasPullOwner(candidate))
                throw new InvalidOperationException("Resume is waiting for the active pull owner to acknowledge that it stopped.");
            EnsureNoActiveTagLocked(candidate.Tag, candidate.Id);
            candidate.State = StateName(DownloadQueueState.QUEUED);
            candidate.DownloaderProcessId = null;
            candidate.DownloaderProcessStartUtc = null;
            candidate.DownloaderLeaseId = null;
            candidate.AcknowledgedStopGeneration = candidate.StopGeneration;
            candidate.LastError = null;
            candidate.UpdatedAt = DateTimeOffset.UtcNow;
            CommitItemLocked(index, candidate);
            result = candidate.Copy();
            snapshot = CreateSnapshotLocked();
            return 0;
        });
        Publish(snapshot);
        return result;
    }

    /// <summary>Cancels a queued, downloading, paused, or failed item. Completed items are immutable.</summary>
    public DownloadQueueItem Cancel(string id) => Mutate(id, item =>
    {
        if (item.State == StateName(DownloadQueueState.COMPLETED))
            throw new InvalidOperationException("A completed download cannot be cancelled.");
        if (item.State == StateName(DownloadQueueState.CANCELLED)) return;
        if (item.State == StateName(DownloadQueueState.DOWNLOADING))
            item.StopGeneration = checked(item.StopGeneration + 1);
        item.State = StateName(DownloadQueueState.CANCELLED);
        if (!HasPullOwner(item))
        {
            item.DownloaderProcessId = null;
            item.DownloaderProcessStartUtc = null;
            item.DownloaderLeaseId = null;
            item.AcknowledgedStopGeneration = item.StopGeneration;
        }
        item.LastError = null;
        item.CompletedAt = null;
    });

    private DownloadQueueItem Mutate(string id, Action<DownloadQueueItem> change)
    {
        Snapshot? snapshot = null;
        DownloadQueueItem result = default!;
        WithStoreLock(() =>
        {
            EnsureLoadedLocked();
            var index = FindIndexLocked(id);
            var original = _records[index];
            var candidate = original.Copy();
            change(candidate);
            if (EquivalentContent(candidate, original))
            {
                result = original.Copy();
                if (_pendingWarning is not null) snapshot = CreateSnapshotLocked();
                return 0;
            }
            candidate.UpdatedAt = DateTimeOffset.UtcNow;
            CommitItemLocked(index, candidate);
            result = candidate.Copy();
            snapshot = CreateSnapshotLocked();
            return 0;
        });
        if (snapshot is not null) Publish(snapshot);
        return result;
    }

    private void ApplyState(DownloadQueueItem item, DownloadQueueState target, string? error, PullResult? result)
    {
        var nextState = StateName(target);
        if (item.State == nextState)
        {
            if (target == DownloadQueueState.DOWNLOADING)
                throw new InvalidOperationException($"Queue item '{item.Id}' is already DOWNLOADING; a second pull cannot be started.");
            return;
        }
        if (!CanTransition(item.State, target))
            throw new InvalidOperationException($"Invalid download transition: {item.State} -> {nextState}.");

        if (target == DownloadQueueState.DOWNLOADING)
        {
            EnsureCanStartLocked(item);
            item.Attempts = checked(item.Attempts + 1);
            item.LastAttemptAt = DateTimeOffset.UtcNow;
            item.StartedAt ??= item.LastAttemptAt;
            item.DownloaderProcessId = _currentProcessId;
            item.DownloaderProcessStartUtc = _currentProcessStartUtc;
            item.DownloaderLeaseId = Guid.NewGuid();
            item.AcknowledgedStopGeneration = item.StopGeneration;
        }
        else
        {
            item.DownloaderProcessId = null;
            item.DownloaderProcessStartUtc = null;
            item.DownloaderLeaseId = null;
            item.AcknowledgedStopGeneration = item.StopGeneration;
        }

        if (target == DownloadQueueState.COMPLETED)
        {
            if (result is null || !result.HashVerified || string.IsNullOrWhiteSpace(result.Digest))
                throw new InvalidOperationException("Completion requires a PullResult with a verified digest.");
            if (!string.Equals(result.Tag, item.Tag, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Pull result tag '{result.Tag}' does not match queued model '{item.Tag}'.");
            if (result.SizeBytes <= 0)
                throw new InvalidOperationException("A completed model must have a positive installed size.");
            var verifiedDigest = NormalizeSha256(result.Digest);
            var expectedDigest = NormalizeExpectedSha256(item.CatalogSha256);
            if (expectedDigest is not null && !string.Equals(expectedDigest, verifiedDigest, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("The installed model digest does not match the catalog SHA-256.");
            item.Sha256Digest = verifiedDigest;
            item.ObservedDigest = verifiedDigest;
            item.HashVerified = true;
            item.InstalledSizeBytes = result.SizeBytes;
            item.BytesTotal = result.SizeBytes;
            item.BytesCompleted = result.SizeBytes;
            item.CompletedAt = DateTimeOffset.UtcNow;
            item.LastError = null;
        }
        else if (target == DownloadQueueState.FAILED)
        {
            item.LastError = NormalizeError(error);
            item.CompletedAt = null;
        }
        else
        {
            item.LastError = target == DownloadQueueState.CANCELLED ? NormalizeError(error) : null;
            if (target != DownloadQueueState.CANCELLED) item.CompletedAt = null;
        }

        item.State = nextState;
    }

    private void EnsureLoadedLocked()
    {
        Directory.CreateDirectory(_directory);
        if (!File.Exists(_filePath))
        {
            _records = new List<DownloadQueueItem>();
            _revision++;
            return;
        }

        try
        {
            var loaded = ReadAndValidateQueueLocked();
            var normalized = false;
            foreach (var item in loaded)
            {
                if (item.State == StateName(DownloadQueueState.DOWNLOADING))
                {
                    if (IsProcessOwnerAlive(item.DownloaderProcessId, item.DownloaderProcessStartUtc)) continue;
                    item.State = StateName(DownloadQueueState.PAUSED);
                    item.DownloaderProcessId = null;
                    item.DownloaderProcessStartUtc = null;
                    item.DownloaderLeaseId = null;
                    item.StopGeneration = checked(item.StopGeneration + 1);
                    item.AcknowledgedStopGeneration = item.StopGeneration;
                    if (string.IsNullOrWhiteSpace(item.LastError)) item.LastError = InterruptedMessage;
                    item.UpdatedAt = DateTimeOffset.UtcNow;
                    normalized = true;
                }
                else if (item.DownloaderProcessId is not null || item.DownloaderProcessStartUtc is not null)
                {
                    if (!IsProcessOwnerAlive(item.DownloaderProcessId, item.DownloaderProcessStartUtc))
                    {
                        item.DownloaderProcessId = null;
                        item.DownloaderProcessStartUtc = null;
                        item.DownloaderLeaseId = null;
                        item.AcknowledgedStopGeneration = item.StopGeneration;
                        item.UpdatedAt = DateTimeOffset.UtcNow;
                        normalized = true;
                    }
                }
            }

            _records = loaded;
            if (normalized) PersistLocked(_records);
            _revision++;
        }
        catch (Exception ex) when (IsRecoverableQueueError(ex))
        {
            var archivePath = ArchiveCorruptQueueLocked();
            var emptyQueue = new List<DownloadQueueItem>();
            PersistLocked(emptyQueue);
            _records = emptyQueue;
            _revision++;
            var message = $"The saved model download queue was invalid ({ex.Message}). Its original bytes were preserved at '{archivePath}', and a new empty queue is ready.";
            _pendingWarning = new DownloadQueueWarningEventArgs("QUEUE_CORRUPT_RECOVERED", message, archivePath);
        }
    }

    private void RefreshTimerTick(object? state)
    {
        if (Volatile.Read(ref _disposed) != 0) return;
        Snapshot? snapshot = null;
        try
        {
            WithStoreLock(() =>
            {
                var before = _records.Select(x => x.Copy()).ToList();
                EnsureLoadedLocked();
                if (!EquivalentQueue(before, _records) || _pendingWarning is not null)
                    snapshot = CreateSnapshotLocked();
                return 0;
            });
            if (snapshot is not null && Volatile.Read(ref _disposed) == 0) Publish(snapshot);
        }
        catch
        {
            // Transient file or mutex failures are retried on the next refresh tick.
        }
    }

    private static bool EquivalentQueue(IReadOnlyList<DownloadQueueItem> left, IReadOnlyList<DownloadQueueItem> right)
    {
        if (left.Count != right.Count) return false;
        for (var index = 0; index < left.Count; index++)
        {
            if (!string.Equals(left[index].Id, right[index].Id, StringComparison.Ordinal) ||
                !EquivalentContent(left[index], right[index]))
                return false;
        }
        return true;
    }

    private static bool IsProcessOwnerAlive(int? processId, DateTimeOffset? processStartUtc)
    {
        if (processId is null or <= 0 || processStartUtc is null) return false;
        try
        {
            using var owner = Process.GetProcessById(processId.Value);
            if (owner.HasExited) return false;
            var observedStart = new DateTimeOffset(owner.StartTime.ToUniversalTime());
            return Math.Abs((observedStart - processStartUtc.Value).TotalSeconds) <= 2;
        }
        catch (ArgumentException) { return false; }
        catch (InvalidOperationException) { return false; }
        catch (System.ComponentModel.Win32Exception) { return true; }
        catch { return true; }
    }

    private List<DownloadQueueItem> ReadAndValidateQueueLocked()
    {
        using var stream = new FileStream(_filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length <= 0 || stream.Length > MaxQueueFileBytes)
            throw new InvalidDataException($"Queue JSON size must be between 1 byte and {MaxQueueFileBytes} bytes.");

        var document = JsonSerializer.Deserialize<PersistedQueue>(stream, JsonOptions);
        if (document is null || document.SchemaVersion < 1 || document.Items is null)
            throw new InvalidDataException("The model download queue schema is missing or unsupported.");
        if (document.SchemaVersion > CurrentSchemaVersion)
            throw new NotSupportedException($"Queue schema {document.SchemaVersion} is newer than supported schema {CurrentSchemaVersion}; the original queue was left untouched.");
        if (document.UpdatedAt == default)
            throw new InvalidDataException("The model download queue document is missing its update timestamp.");
        if (document.Items.Count > MaxQueueRows)
            throw new InvalidDataException($"The model download queue has more than {MaxQueueRows} rows.");

        var loaded = new List<DownloadQueueItem>(document.Items.Count);
        var rowIds = new HashSet<string>(StringComparer.Ordinal);
        var activeTags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var persisted in document.Items)
        {
            if (persisted is null)
                throw new InvalidDataException("The model download queue contains a null row.");

            var item = FromPersisted(persisted);
            if (!rowIds.Add(item.Id))
                throw new InvalidDataException("The persisted download queue contains duplicate row ids.");
            if ((IsActive(item.State) || HasPullOwner(item)) && !activeTags.Add(item.Tag))
                throw new InvalidDataException($"The persisted download queue contains multiple active rows for model tag '{item.Tag}'.");
            loaded.Add(item);
        }
        return loaded;
    }

    private string ArchiveCorruptQueueLocked()
    {
        var stamp = DateTimeOffset.UtcNow.ToString("yyyyMMdd'T'HHmmssfff'Z'", CultureInfo.InvariantCulture);
        var archivePath = Path.Combine(_directory, $"{QueueFileName}.corrupt-{stamp}-{Guid.NewGuid():N}");
        var tempPath = archivePath + ".tmp";
        try
        {
            byte[] sourceHash;
            long sourceLength;
            using (var source = new FileStream(_filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                sourceLength = source.Length;
                sourceHash = SHA256.HashData(source);
                source.Position = 0;
                using var destination = new FileStream(tempPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 64 * 1024, FileOptions.WriteThrough);
                source.CopyTo(destination);
                destination.Flush(flushToDisk: true);
            }

            using (var archivedCopy = new FileStream(tempPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (archivedCopy.Length != sourceLength || !CryptographicOperations.FixedTimeEquals(sourceHash, SHA256.HashData(archivedCopy)))
                    throw new IOException("The quarantined queue copy failed its byte-for-byte SHA-256 check.");
            }

            File.Move(tempPath, archivePath);
            return archivePath;
        }
        finally
        {
            try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { /* preserve the primary archive error */ }
        }
    }

    private static bool IsRecoverableQueueError(Exception exception) =>
        exception is JsonException or InvalidDataException or ArgumentException or FormatException;

    private void CommitItemLocked(int index, DownloadQueueItem candidate, bool moveToTail = false)
    {
        // Mutations already pass a private candidate copy; preserve unchanged rows
        // by reference instead of deep-copying the entire queue on every commit.
        var next = new List<DownloadQueueItem>(_records);
        var replacement = candidate;
        if (moveToTail && index < next.Count - 1)
        {
            next.RemoveAt(index);
            next.Add(replacement);
        }
        else
        {
            next[index] = replacement;
        }
        PersistLocked(next);
        _records = next;
        _revision++;
    }

    private void PersistLocked(IReadOnlyList<DownloadQueueItem> records)
    {
        if (records.Count > MaxQueueRows)
            throw new InvalidOperationException($"The model download queue is limited to {MaxQueueRows} rows.");
        Directory.CreateDirectory(_directory);
        var persistedItems = new List<PersistedItem>(records.Count);
        foreach (var record in records) persistedItems.Add(ToPersisted(record));
        var document = new PersistedQueue
        {
            SchemaVersion = CurrentSchemaVersion,
            UpdatedAt = DateTimeOffset.UtcNow,
            Items = persistedItems
        };
        var tempPath = Path.Combine(_directory, ".queue." + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using (var stream = new FileStream(tempPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 16 * 1024, FileOptions.WriteThrough))
            {
                JsonSerializer.Serialize(stream, document, JsonOptions);
                stream.Flush(flushToDisk: true);
                if (stream.Length > MaxQueueFileBytes)
                    throw new InvalidOperationException($"The model download queue JSON exceeds the {MaxQueueFileBytes}-byte storage limit.");
            }

            if (File.Exists(_filePath))
            {
                try
                {
                    File.Replace(tempPath, _filePath, null, ignoreMetadataErrors: true);
                }
                catch (PlatformNotSupportedException)
                {
                    File.Move(tempPath, _filePath, overwrite: true);
                }
            }
            else
            {
                File.Move(tempPath, _filePath);
            }
        }
        finally
        {
            try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { /* preserve the primary persistence error */ }
        }
    }

    private Snapshot CreateSnapshotLocked()
    {
        var warning = _pendingWarning;
        var items = new List<DownloadQueueItem>(_records.Count);
        foreach (var item in _records) items.Add(item.Copy());
        return new Snapshot(_revision, items, warning);
    }

    private void Publish(Snapshot snapshot)
    {
        void Apply()
        {
            if (snapshot.Revision <= _publishedRevision) return;
            _publishedRevision = snapshot.Revision;

            var wanted = snapshot.Items;
            var existingById = new Dictionary<string, DownloadQueueItem>(_mutableItems.Count, StringComparer.Ordinal);
            foreach (var item in _mutableItems) existingById.Add(item.Id, item);
            var stateChanges = new List<DownloadQueueItemStateChangedEventArgs>(wanted.Count);
            for (var i = 0; i < wanted.Count; i++)
            {
                var desired = wanted[i];
                if (existingById.TryGetValue(desired.Id, out var existing))
                {
                    var previousState = existing.State;
                    var previousStopGeneration = existing.StopGeneration;
                    existing.CopyFrom(desired);
                    if (previousState != desired.State || previousStopGeneration != desired.StopGeneration)
                        stateChanges.Add(new DownloadQueueItemStateChangedEventArgs(
                            desired.Id, desired.Tag, previousState, desired.State, desired.StopGeneration));
                    var currentIndex = _mutableItems.IndexOf(existing);
                    if (currentIndex != i) _mutableItems.Move(currentIndex, i);
                }
                else
                {
                    _mutableItems.Insert(i, desired.Copy());
                    stateChanges.Add(new DownloadQueueItemStateChangedEventArgs(
                        desired.Id, desired.Tag, null, desired.State, desired.StopGeneration));
                }
            }

            while (_mutableItems.Count > wanted.Count)
                _mutableItems.RemoveAt(_mutableItems.Count - 1);

            var stateHandlers = StateChanged;
            if (stateHandlers is not null)
            {
                foreach (var change in stateChanges)
                {
                    foreach (EventHandler<DownloadQueueItemStateChangedEventArgs> handler in stateHandlers.GetInvocationList())
                    {
                        try { handler(this, change); }
                        catch { /* observers cannot roll back a durable state transition */ }
                    }
                }
            }

            if (snapshot.Warning is not null && _publishedWarningId != snapshot.Warning.EventId)
            {
                _lastWarning = snapshot.Warning.Message;
                _publishedWarningId = snapshot.Warning.EventId;
                var propertyHandlers = PropertyChanged;
                if (propertyHandlers is not null)
                {
                    var changed = new PropertyChangedEventArgs(nameof(LastWarning));
                    foreach (PropertyChangedEventHandler handler in propertyHandlers.GetInvocationList())
                    {
                        try { handler(this, changed); }
                        catch { /* observer failures must not undo queue recovery */ }
                    }
                }
                var handlers = WarningRaised;
                if (handlers is not null)
                {
                    foreach (EventHandler<DownloadQueueWarningEventArgs> handler in handlers.GetInvocationList())
                    {
                        try { handler(this, snapshot.Warning); }
                        catch { /* observer failures must not undo queue recovery */ }
                    }
                }
                lock (_gate)
                {
                    if (ReferenceEquals(_pendingWarning, snapshot.Warning)) _pendingWarning = null;
                }
            }
        }

        if (_dispatcher is not null && !_dispatcher.CheckAccess())
        {
            if (!_dispatcher.HasShutdownStarted && !_dispatcher.HasShutdownFinished)
                _dispatcher.BeginInvoke(DispatcherPriority.DataBind, new Action(Apply));
        }
        else if (_dispatcher is null || (!_dispatcher.HasShutdownStarted && !_dispatcher.HasShutdownFinished))
            Apply();
    }

    private T WithStoreLock<T>(Func<T> action)
    {
        lock (_gate)
        {
            using var mutex = new Mutex(initiallyOwned: false, name: _mutexName);
            var ownsMutex = false;
            try
            {
                try
                {
                    ownsMutex = mutex.WaitOne(TimeSpan.FromSeconds(15));
                }
                catch (AbandonedMutexException)
                {
                    ownsMutex = true;
                }

                if (!ownsMutex) throw new TimeoutException("Timed out waiting for the model download queue lock.");
                return action();
            }
            finally
            {
                if (ownsMutex) mutex.ReleaseMutex();
            }
        }
    }

    private void EnsureNoActiveTagLocked(string tag, string? exceptId)
    {
        for (var index = 0; index < _records.Count; index++)
        {
            var item = _records[index];
            if (string.Equals(item.Id, exceptId, StringComparison.Ordinal) ||
                !string.Equals(item.Tag, tag, StringComparison.OrdinalIgnoreCase) ||
                !(IsActive(item.State) || HasPullOwner(item)))
                continue;

            throw new InvalidOperationException($"Model tag '{tag}' already has an active queue item ({item.Id}).");
        }
    }

    private void EnsureCanStartLocked(DownloadQueueItem candidate)
    {
        if (candidate.State != StateName(DownloadQueueState.QUEUED))
            throw new InvalidOperationException("A download must be QUEUED before it can start; use Resume to requeue a paused item.");

        DownloadQueueItem? active = null;
        DownloadQueueItem? head = null;
        DownloadQueueItem? duplicateTag = null;
        foreach (var item in _records)
        {
            if (head is null && item.State == StateName(DownloadQueueState.QUEUED)) head = item;
            if (string.Equals(item.Id, candidate.Id, StringComparison.Ordinal)) continue;

            if (active is null &&
                (item.State == StateName(DownloadQueueState.DOWNLOADING) || HasPullOwner(item)))
                active = item;
            if (duplicateTag is null &&
                string.Equals(item.Tag, candidate.Tag, StringComparison.OrdinalIgnoreCase) &&
                (IsActive(item.State) || HasPullOwner(item)))
                duplicateTag = item;
        }

        if (active is not null)
            throw new InvalidOperationException($"Only one model may download at a time; '{active.Tag}' is already DOWNLOADING.");
        if (head is not null && !string.Equals(head.Id, candidate.Id, StringComparison.Ordinal))
            throw new InvalidOperationException($"FIFO order requires '{head.Tag}' to start before '{candidate.Tag}'.");
        if (duplicateTag is not null)
            throw new InvalidOperationException($"Model tag '{candidate.Tag}' already has an active queue item ({duplicateTag.Id}).");
    }

    private bool CanStartLocked(DownloadQueueItem candidate)
    {
        if (candidate.State != StateName(DownloadQueueState.QUEUED)) return false;

        string? firstQueuedId = null;
        var otherPullActive = false;
        var duplicateTagActive = false;
        foreach (var item in _records)
        {
            if (firstQueuedId is null && item.State == StateName(DownloadQueueState.QUEUED))
                firstQueuedId = item.Id;
            if (string.Equals(item.Id, candidate.Id, StringComparison.Ordinal)) continue;

            if (item.State == StateName(DownloadQueueState.DOWNLOADING) || HasPullOwner(item))
                otherPullActive = true;
            if (!duplicateTagActive &&
                string.Equals(item.Tag, candidate.Tag, StringComparison.OrdinalIgnoreCase) &&
                (IsActive(item.State) || HasPullOwner(item)))
                duplicateTagActive = true;
        }

        return !otherPullActive &&
               (firstQueuedId is null || string.Equals(firstQueuedId, candidate.Id, StringComparison.Ordinal)) &&
               !duplicateTagActive;
    }

    private int FindIndexLocked(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) throw new ArgumentException("A queue item id is required.", nameof(id));
        for (var index = 0; index < _records.Count; index++)
        {
            if (string.Equals(_records[index].Id, id, StringComparison.Ordinal)) return index;
        }
        throw new KeyNotFoundException($"No model download queue item exists with id '{id}'.");
    }

    private static bool CanTransition(string current, DownloadQueueState target)
    {
        var source = ParseState(current);
        return source switch
        {
            DownloadQueueState.QUEUED => target is DownloadQueueState.DOWNLOADING or DownloadQueueState.FAILED or DownloadQueueState.CANCELLED,
            DownloadQueueState.DOWNLOADING => target is DownloadQueueState.PAUSED or DownloadQueueState.FAILED or DownloadQueueState.COMPLETED or DownloadQueueState.CANCELLED,
            DownloadQueueState.PAUSED => target is DownloadQueueState.QUEUED or DownloadQueueState.FAILED or DownloadQueueState.CANCELLED,
            DownloadQueueState.FAILED => target is DownloadQueueState.QUEUED or DownloadQueueState.CANCELLED,
            DownloadQueueState.COMPLETED or DownloadQueueState.CANCELLED => false,
            _ => false
        };
    }

    private static void RequireState(DownloadQueueItem item, DownloadQueueState expected)
    {
        if (item.State != StateName(expected))
            throw new InvalidOperationException($"Expected {StateName(expected)} but queue item '{item.Id}' is {item.State}.");
    }

    private static bool IsActive(string state) => state is "QUEUED" or "DOWNLOADING" or "PAUSED";
    private static bool HasPullOwner(DownloadQueueItem item) =>
        item.DownloaderProcessId is > 0 && item.DownloaderProcessStartUtc is not null;
    private static string StateName(DownloadQueueState state) => state.ToString().ToUpperInvariant();

    private static DownloadQueueState ParseState(string? value)
    {
        if (!Enum.TryParse<DownloadQueueState>(value, ignoreCase: true, out var state) || !Enum.IsDefined(state))
            throw new ArgumentOutOfRangeException(nameof(value), value, "Unknown model download queue state.");
        return state;
    }

    private static string NormalizeRequired(string? value, string name, int maxLength)
    {
        var normalized = NormalizeOptional(value);
        if (string.IsNullOrWhiteSpace(normalized)) throw new ArgumentException("A non-empty value is required.", name);
        if (normalized.Length > maxLength) throw new ArgumentException($"Value exceeds {maxLength} characters.", name);
        return normalized;
    }

    private static string NormalizeOptional(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var normalized = value.Trim();
        if (normalized.Any(char.IsControl)) throw new ArgumentException("Control characters are not allowed in queue metadata.");
        return normalized;
    }

    private static string? NormalizeError(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var normalized = value.Trim();
        if (normalized.Length > 8192) normalized = normalized[..8192];
        if (normalized.Any(c => char.IsControl(c) && c is not ('\r' or '\n' or '\t')))
            throw new ArgumentException("The error contains unsupported control characters.", nameof(value));
        return normalized;
    }

    private static string NormalizeSha256(string value)
    {
        var digest = value.Trim();
        if (digest.StartsWith("sha256:", StringComparison.OrdinalIgnoreCase)) digest = digest[7..];
        if (digest.Length != 64 || digest.Any(character => !Uri.IsHexDigit(character)))
            throw new InvalidOperationException("The verified model digest is not a 64-character SHA-256 value.");
        return digest.ToLowerInvariant();
    }

    private static string? NormalizeExpectedSha256(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) || string.Equals(value.Trim(), ModelCatalogEntry.NotDetermined, StringComparison.OrdinalIgnoreCase))
            return null;
        return NormalizeSha256(value);
    }

    private static bool EquivalentContent(DownloadQueueItem left, DownloadQueueItem right) =>
        left.State == right.State &&
        left.Attempts == right.Attempts &&
        left.BytesCompleted == right.BytesCompleted &&
        left.BytesTotal == right.BytesTotal &&
        left.Sha256Digest == right.Sha256Digest &&
        left.ObservedDigest == right.ObservedDigest &&
        left.LastError == right.LastError &&
        left.LastAttemptAt == right.LastAttemptAt &&
        left.StartedAt == right.StartedAt &&
        left.CompletedAt == right.CompletedAt &&
        left.InstalledSizeBytes == right.InstalledSizeBytes &&
        left.HashVerified == right.HashVerified &&
        left.DownloaderProcessId == right.DownloaderProcessId &&
        left.DownloaderProcessStartUtc == right.DownloaderProcessStartUtc &&
        left.DownloaderLeaseId == right.DownloaderLeaseId &&
        left.StopGeneration == right.StopGeneration &&
        left.AcknowledgedStopGeneration == right.AcknowledgedStopGeneration;

    private static string? FirstNonEmpty(params string?[] values) => values.FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));

    private static PersistedQueueItem ToPersisted(DownloadQueueItem item) => new()
    {
        Id = item.Id,
        Tag = item.Tag,
        Title = item.Title,
        Category = item.Category,
        ModelPageUrl = item.ModelPageUrl,
        LicenseUrl = item.LicenseUrl,
        LicenseStatus = item.LicenseStatus,
        EstimatedMinVramGiB = item.EstimatedMinVramGiB,
        SizeSourceStatus = item.SizeSourceStatus,
        RuntimeSize = item.RuntimeSize,
        VramEstimate = item.VramEstimate,
        CatalogSha256 = item.CatalogSha256,
        CatalogSha256Source = item.CatalogSha256Source,
        LicenseAcknowledged = item.LicenseAcknowledged,
        LicenseAcknowledgedAt = item.LicenseAcknowledgedAt,
        State = item.State,
        Attempts = item.Attempts,
        BytesCompleted = item.BytesCompleted,
        BytesTotal = item.BytesTotal,
        Sha256Digest = item.Sha256Digest,
        ObservedDigest = item.ObservedDigest,
        LastError = item.LastError,
        CreatedAt = item.CreatedAt,
        LastAttemptAt = item.LastAttemptAt,
        StartedAt = item.StartedAt,
        CompletedAt = item.CompletedAt,
        DownloaderProcessId = item.DownloaderProcessId,
        DownloaderProcessStartUtc = item.DownloaderProcessStartUtc,
        DownloaderLeaseId = item.DownloaderLeaseId,
        StopGeneration = item.StopGeneration,
        AcknowledgedStopGeneration = item.AcknowledgedStopGeneration,
        InstalledSizeBytes = item.InstalledSizeBytes,
        HashVerified = item.HashVerified,
        UpdatedAt = item.UpdatedAt
    };

    private static DownloadQueueItem FromPersisted(PersistedQueueItem item)
    {
        if (string.IsNullOrWhiteSpace(item.Id) || string.IsNullOrWhiteSpace(item.Tag) || string.IsNullOrWhiteSpace(item.Title))
            throw new InvalidDataException("A persisted download queue row is missing its id, model tag, or title.");
        var state = ParseState(item.State);
        if (item.Attempts < 0 || item.BytesCompleted < 0 || item.BytesTotal < 0 || item.InstalledSizeBytes < 0)
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' has a negative counter.");
        if (item.DownloaderProcessId is <= 0)
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' has an invalid owner process id.");
        if ((item.DownloaderProcessId is null) != (item.DownloaderProcessStartUtc is null) ||
            (item.DownloaderLeaseId is not null && (item.DownloaderProcessId is null || item.DownloaderLeaseId == Guid.Empty)))
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' has incomplete owner lease metadata.");
        if (item.StopGeneration < 0 || item.AcknowledgedStopGeneration < 0 || item.AcknowledgedStopGeneration > item.StopGeneration)
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' has invalid stop generations.");
        if (item.Id.Length > 64 || item.Tag.Length > 512 || item.Title.Length > 512 ||
            item.Category?.Length > 256 || item.ModelPageUrl?.Length > 2048 || item.LicenseUrl?.Length > 2048 ||
            item.LicenseStatus?.Length > 256 || item.SizeSourceStatus?.Length > 512 ||
            item.RuntimeSize?.Length > 256 || item.VramEstimate?.Length > 256 ||
            item.CatalogSha256?.Length > 128 || item.CatalogSha256Source?.Length > 512 ||
            item.Sha256Digest?.Length > 128 || item.ObservedDigest?.Length > 128 || item.LastError?.Length > 8192)
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' exceeds a metadata field limit.");
        if (!item.LicenseAcknowledged || item.LicenseAcknowledgedAt is null)
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' has no license acknowledgement.");
        if (item.EstimatedMinVramGiB is double vram && (!double.IsFinite(vram) || vram < 0))
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' has an invalid VRAM estimate.");
        if (item.CreatedAt == default || item.UpdatedAt == default)
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' is missing timestamps.");
        try { _ = NormalizeExpectedSha256(item.CatalogSha256); }
        catch (InvalidOperationException ex) { throw new InvalidDataException($"Persisted row '{item.Id}' has invalid catalog SHA-256 metadata.", ex); }
        if (item.HashVerified && state != DownloadQueueState.COMPLETED)
            throw new InvalidDataException($"Persisted download queue row '{item.Id}' claims a hash verification outside COMPLETED.");
        if (state == DownloadQueueState.COMPLETED &&
            (!item.HashVerified || item.CompletedAt is null || item.InstalledSizeBytes is not > 0 || string.IsNullOrWhiteSpace(item.Sha256Digest)))
            throw new InvalidDataException($"Persisted completed row '{item.Id}' is missing verified model evidence.");
        if (item.BytesTotal > 0 && item.BytesCompleted > item.BytesTotal)
            item.BytesCompleted = item.BytesTotal;

        string? finalDigest = item.Sha256Digest;
        string? observedDigest = item.ObservedDigest;
        if (item.HashVerified)
        {
            try { finalDigest = NormalizeSha256(item.Sha256Digest!); }
            catch (InvalidOperationException ex) { throw new InvalidDataException($"Persisted row '{item.Id}' has an invalid SHA-256 digest.", ex); }
            try
            {
                var expected = NormalizeExpectedSha256(item.CatalogSha256);
                if (expected is not null && !string.Equals(expected, finalDigest, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException($"Persisted row '{item.Id}' does not match its catalog SHA-256.");
            }
            catch (InvalidOperationException ex) { throw new InvalidDataException($"Persisted row '{item.Id}' has invalid catalog SHA-256 metadata.", ex); }
        }
        else if (state != DownloadQueueState.COMPLETED && !string.IsNullOrWhiteSpace(finalDigest))
        {
            // Earlier queue versions stored the pull stream's current layer digest in
            // Sha256Digest. Preserve it as an observation, never as verified evidence.
            if (string.IsNullOrWhiteSpace(observedDigest)) observedDigest = finalDigest;
            finalDigest = null;
        }

        return new DownloadQueueItem
        {
            Id = NormalizeRequired(item.Id, nameof(item.Id), 64),
            Tag = NormalizeRequired(item.Tag, nameof(item.Tag), 512),
            Title = NormalizeRequired(item.Title, nameof(item.Title), 512),
            Category = NormalizeOptional(item.Category),
            ModelPageUrl = NormalizeOptional(item.ModelPageUrl),
            LicenseUrl = NormalizeOptional(item.LicenseUrl),
            LicenseStatus = NormalizeOptional(item.LicenseStatus),
            EstimatedMinVramGiB = item.EstimatedMinVramGiB,
            SizeSourceStatus = NormalizeOptional(item.SizeSourceStatus),
            RuntimeSize = NormalizeOptional(item.RuntimeSize),
            VramEstimate = NormalizeOptional(item.VramEstimate),
            CatalogSha256 = NormalizeOptional(item.CatalogSha256),
            CatalogSha256Source = NormalizeOptional(item.CatalogSha256Source),
            LicenseAcknowledged = item.LicenseAcknowledged,
            LicenseAcknowledgedAt = item.LicenseAcknowledgedAt,
            State = StateName(state),
            Attempts = item.Attempts,
            BytesCompleted = item.BytesCompleted,
            BytesTotal = item.BytesTotal,
            Sha256Digest = finalDigest is null ? null : NormalizeOptional(finalDigest),
            ObservedDigest = observedDigest is null ? null : NormalizeOptional(observedDigest),
            LastError = NormalizeError(item.LastError),
            CreatedAt = item.CreatedAt,
            LastAttemptAt = item.LastAttemptAt,
            StartedAt = item.StartedAt,
            CompletedAt = item.CompletedAt,
            DownloaderProcessId = item.DownloaderProcessId,
            DownloaderProcessStartUtc = item.DownloaderProcessStartUtc,
            DownloaderLeaseId = item.DownloaderLeaseId,
            StopGeneration = item.StopGeneration,
            AcknowledgedStopGeneration = item.AcknowledgedStopGeneration,
            InstalledSizeBytes = item.InstalledSizeBytes,
            HashVerified = item.HashVerified,
            UpdatedAt = item.UpdatedAt
        };
    }

    private sealed record Snapshot(long Revision, List<DownloadQueueItem> Items, DownloadQueueWarningEventArgs? Warning);

    private sealed class PersistedQueue
    {
        public int SchemaVersion { get; set; }
        public DateTimeOffset UpdatedAt { get; set; }
        public List<PersistedQueueItem>? Items { get; set; }
    }

    private sealed class PersistedQueueItem
    {
        public string Id { get; set; } = string.Empty;
        public string Tag { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string? Category { get; set; }
        public string? ModelPageUrl { get; set; }
        public string? LicenseUrl { get; set; }
        public string? LicenseStatus { get; set; }
        public double? EstimatedMinVramGiB { get; set; }
        public string? SizeSourceStatus { get; set; }
        public string? RuntimeSize { get; set; }
        public string? VramEstimate { get; set; }
        public string? CatalogSha256 { get; set; }
        public string? CatalogSha256Source { get; set; }
        public bool LicenseAcknowledged { get; set; }
        public DateTimeOffset? LicenseAcknowledgedAt { get; set; }
        public string State { get; set; } = StateName(DownloadQueueState.QUEUED);
        public int Attempts { get; set; }
        public long BytesCompleted { get; set; }
        public long BytesTotal { get; set; }
        public string? Sha256Digest { get; set; }
        public string? ObservedDigest { get; set; }
        public string? LastError { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
        public DateTimeOffset? LastAttemptAt { get; set; }
        public DateTimeOffset? StartedAt { get; set; }
        public DateTimeOffset? CompletedAt { get; set; }
        public int? DownloaderProcessId { get; set; }
        public DateTimeOffset? DownloaderProcessStartUtc { get; set; }
        public Guid? DownloaderLeaseId { get; set; }
        public long StopGeneration { get; set; }
        public long AcknowledgedStopGeneration { get; set; }
        public long? InstalledSizeBytes { get; set; }
        public bool HashVerified { get; set; }
        public DateTimeOffset UpdatedAt { get; set; }
    }
}
