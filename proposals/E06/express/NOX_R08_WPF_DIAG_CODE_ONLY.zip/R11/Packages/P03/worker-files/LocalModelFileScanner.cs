using System;
using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace NOX.P01.ModelCenter;

/// <summary>
/// Locates candidate model and model-metadata files only beneath a folder
/// explicitly selected by the user. The scanner never deserializes, loads,
/// or executes a discovered file and makes no assertion about its license.
/// </summary>
public sealed class LocalModelFileScanner
{
    private const int IoBufferSize = 1024 * 1024;
    // Bounded parallelism overlaps file reads and SHA-256 work without
    // creating an unbounded number of concurrent readers on large models.
    private const int MaxConcurrentFileInspections = 2;
    private const int MaximumSafeTensorsHeaderBytes = 16 * 1024 * 1024;
    private const int MaximumStandaloneJsonBytes = 4 * 1024 * 1024;
    private const int MaximumNameCollisionAttempts = 1024;

    private static readonly HashSet<string> CandidateExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".gguf", ".safetensors", ".onnx", ".pt", ".pth", ".bin", ".json"
    };

    /// <summary>
    /// Scans one selected folder. Recursion is opt-in and bounded; filesystem
    /// roots and reparse points are rejected or skipped to avoid a broad scan.
    /// </summary>
    public async Task<LocalModelScanBatch> ScanAsync(
        string userSelectedFolder,
        LocalModelScanOptions? options = null,
        IProgress<LocalModelScanProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(userSelectedFolder);
        options ??= new LocalModelScanOptions();
        options.Validate();

        var root = Path.GetFullPath(userSelectedFolder);
        if (!Directory.Exists(root))
        {
            throw new DirectoryNotFoundException("Выбранная папка не найдена.");
        }

        if (IsFileSystemRoot(root))
        {
            throw new ArgumentException(
                "Выберите папку с моделями, а не корень диска.",
                nameof(userSelectedFolder));
        }

        var rootAttributes = File.GetAttributes(root);
        if ((rootAttributes & FileAttributes.ReparsePoint) != 0)
        {
            throw new ArgumentException(
                "Выбранная папка является ссылкой или точкой соединения; выберите её конечную папку.",
                nameof(userSelectedFolder));
        }

        var issues = new List<LocalModelScanIssue>();
        var paths = new List<string>(Math.Min(options.MaxFiles, 1024));

        foreach (var path in EnumerateCandidateFiles(root, options, issues, cancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (paths.Count >= options.MaxFiles)
            {
                issues.Add(new LocalModelScanIssue(
                    root,
                    $"Достигнут лимит {options.MaxFiles} файлов. Уточните папку или задайте больший лимит явно."));
                break;
            }
            paths.Add(path);
        }

        // Inspect/hash a small bounded number of independent files at once.
        // This reduces wall time for folders with many model artifacts while
        // retaining the same user-selected root, per-file validation, hashes,
        // cancellation behavior, and bounded MaxFiles policy.
        var candidates = new LocalModelCandidate?[paths.Count];
        var scanIssues = new ConcurrentQueue<LocalModelScanIssue>();
        var completedInspections = 0;
        var progressSync = new object();
        await Parallel.ForEachAsync(
            Enumerable.Range(0, paths.Count),
            new ParallelOptions
            {
                CancellationToken = cancellationToken,
                MaxDegreeOfParallelism = MaxConcurrentFileInspections
            },
            async (index, token) =>
            {
                var path = paths[index];
                try
                {
                    var candidate = await InspectCandidateAsync(root, path, token).ConfigureAwait(false);
                    candidates[index] = candidate;
                    lock (progressSync)
                    {
                        var completed = ++completedInspections;
                        progress?.Report(new LocalModelScanProgress(
                            completed,
                            candidate.FileName,
                            candidate.SizeBytes,
                            candidate.Sha256,
                            candidate.Status));
                    }
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or System.Security.SecurityException or JsonException)
                {
                    scanIssues.Enqueue(new LocalModelScanIssue(
                        path,
                        $"Файл пропущен: {SafeExceptionMessage(exception)}"));
                    lock (progressSync) completedInspections++;
                }
            }).ConfigureAwait(false);

        issues.AddRange(scanIssues.OrderBy(issue => issue.Path, StringComparer.Ordinal));
        var inspectedFiles = paths.Count;

        return new LocalModelScanBatch(
            root,
            candidates.Where(candidate => candidate is not null).Select(candidate => candidate!).ToArray(),
            issues.AsReadOnly(),
            inspectedFiles);
    }

    /// <summary>
    /// Records the user's explicit format/compatibility acceptance and
    /// rights attestation. This records an attestation only; it does not
    /// verify ownership, license terms, or permission independently.
    /// </summary>
    public static LocalModelCandidate AcknowledgeReview(
        LocalModelCandidate candidate,
        bool userReviewedLicense,
        bool formatAndCompatibilityAccepted,
        bool userRightsAttested)
    {
        ArgumentNullException.ThrowIfNull(candidate);

        if (candidate.Status == LocalModelImportStatus.UNSUPPORTED_IMPORT || !candidate.FormatVerified)
        {
            return candidate with
            {
                Status = LocalModelImportStatus.UNSUPPORTED_IMPORT,
                UserLicenseReviewed = false,
                FormatAndCompatibilityAccepted = false,
                UserRightsAttested = false
            };
        }

        if (!userReviewedLicense || !formatAndCompatibilityAccepted || !userRightsAttested)
        {
            return candidate with
            {
                Status = LocalModelImportStatus.REVIEW_REQUIRED_LICENSE,
                UserLicenseReviewed = false,
                FormatAndCompatibilityAccepted = false,
                UserRightsAttested = false
            };
        }

        return candidate with
        {
            Status = LocalModelImportStatus.VERIFIED_FORMAT,
            UserLicenseReviewed = true,
            FormatAndCompatibilityAccepted = true,
            UserRightsAttested = true
        };
    }

    /// <summary>
    /// Copies a candidate into an explicitly supplied staging folder only
    /// after format/compatibility acceptance, rights attestation, and a
    /// separate copy-consent flag. The source is never modified or removed.
    /// Existing destination files are never overwritten.
    /// </summary>
    public async Task<LocalModelStageResult> StageAsync(
        LocalModelCandidate candidate,
        string userSelectedDestination,
        LocalModelImportAuthorization authorization,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(candidate);
        ArgumentNullException.ThrowIfNull(authorization);
        ArgumentException.ThrowIfNullOrWhiteSpace(userSelectedDestination);

        if (candidate.Status != LocalModelImportStatus.VERIFIED_FORMAT ||
            !candidate.FormatVerified ||
            !candidate.UserLicenseReviewed ||
            !candidate.FormatAndCompatibilityAccepted ||
            !candidate.UserRightsAttested ||
            !authorization.UserReviewedLicense ||
            !authorization.FormatAndCompatibilityAccepted ||
            !authorization.UserRightsAttested ||
            !authorization.UserConfirmedCopy)
        {
            return LocalModelStageResult.NotStaged(
                candidate,
                candidate.FormatVerified
                    ? LocalModelImportStatus.REVIEW_REQUIRED_LICENSE
                    : LocalModelImportStatus.UNSUPPORTED_IMPORT,
                "Нужны проверка лицензии и совместимости, явное подтверждение прав и отдельное согласие на копирование.");
        }

        var sourcePath = Path.GetFullPath(candidate.SourcePath);
        var sourceRoot = Path.GetFullPath(candidate.SelectedRoot);
        if (!IsPathWithinRoot(sourceRoot, sourcePath))
        {
            return LocalModelStageResult.NotStaged(
                candidate,
                LocalModelImportStatus.UNSUPPORTED_IMPORT,
                "Исходный путь больше не находится внутри выбранной папки.");
        }

        var destinationDirectory = Path.GetFullPath(userSelectedDestination);
        if (IsPathWithinRoot(sourceRoot, destinationDirectory))
        {
            return LocalModelStageResult.NotStaged(
                candidate,
                LocalModelImportStatus.UNSUPPORTED_IMPORT,
                "Выберите отдельную папку назначения вне папки исходных файлов.");
        }

        cancellationToken.ThrowIfCancellationRequested();
        Directory.CreateDirectory(destinationDirectory);

        var originalName = Path.GetFileName(sourcePath);
        var temporaryPath = Path.Combine(destinationDirectory, $".nox-stage-{Guid.NewGuid():N}.partial");
        string? committedPath = null;

        try
        {
            var copiedHash = await CopyToTemporaryAndHashAsync(
                sourcePath,
                temporaryPath,
                candidate.SizeBytes,
                cancellationToken).ConfigureAwait(false);

            if (!string.Equals(copiedHash, candidate.Sha256, StringComparison.OrdinalIgnoreCase))
            {
                return LocalModelStageResult.NotStaged(
                    candidate,
                    LocalModelImportStatus.UNSUPPORTED_IMPORT,
                    "Контрольная сумма изменилась во время подготовки; временная копия удаляется.");
            }

            for (var suffix = 0; suffix < MaximumNameCollisionAttempts; suffix++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var target = GetNonOverwritingPath(destinationDirectory, originalName, suffix);
                try
                {
                    File.Move(temporaryPath, target, overwrite: false);
                    committedPath = target;
                    break;
                }
                catch (IOException) when (File.Exists(target))
                {
                    // A concurrent import selected the same name. Retry with a new suffix.
                }
            }

            if (committedPath is null)
            {
                return LocalModelStageResult.NotStaged(
                    candidate,
                    LocalModelImportStatus.UNSUPPORTED_IMPORT,
                    $"Не удалось выбрать свободное имя файла без перезаписи за {MaximumNameCollisionAttempts} попыток.");
            }

            var stagedCandidate = candidate with
            {
                Status = LocalModelImportStatus.STAGED,
                StagedPath = committedPath
            };
            return new LocalModelStageResult(
                stagedCandidate,
                true,
                committedPath,
                "Файл скопирован в выбранную папку; исходник сохранён.");
        }
        finally
        {
            TryDeleteTemporaryFile(temporaryPath);
        }
    }

    private static async Task<LocalModelCandidate> InspectCandidateAsync(
        string selectedRoot,
        string path,
        CancellationToken cancellationToken)
    {
        var attributes = File.GetAttributes(path);
        if ((attributes & FileAttributes.ReparsePoint) != 0)
        {
            throw new IOException("Файл является ссылкой и пропущен.");
        }

        var before = new FileInfo(path);
        var lengthBefore = before.Length;
        var lastWriteBefore = before.LastWriteTimeUtc;
        var extension = Path.GetExtension(path);

        await using var stream = new FileStream(
            path,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            IoBufferSize,
            FileOptions.Asynchronous | FileOptions.SequentialScan);

        var inspection = await InspectFormatAsync(stream, extension, cancellationToken).ConfigureAwait(false);
        stream.Position = 0;
        var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, cancellationToken).ConfigureAwait(false));

        var after = new FileInfo(path);
        if (stream.Length != lengthBefore || after.Length != lengthBefore || after.LastWriteTimeUtc != lastWriteBefore)
        {
            throw new IOException("Файл изменился во время проверки.");
        }

        var status = inspection.FormatVerified
            ? LocalModelImportStatus.REVIEW_REQUIRED_LICENSE
            : LocalModelImportStatus.UNSUPPORTED_IMPORT;

        return new LocalModelCandidate(
            selectedRoot,
            path,
            Path.GetFileName(path),
            lengthBefore,
            hash,
            inspection.Format,
            status,
            inspection.FormatVerified,
            inspection.Note,
            lastWriteBefore,
            UserLicenseReviewed: false,
            UserRightsAttested: false,
            FormatAndCompatibilityAccepted: false,
            StagedPath: null);
    }

    private static async Task<FormatInspection> InspectFormatAsync(
        FileStream stream,
        string extension,
        CancellationToken cancellationToken)
    {
        if (stream.Length <= 0)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.Unknown, "Пустой файл.");
        }

        switch (extension.ToLowerInvariant())
        {
            case ".gguf":
                return await InspectGgufAsync(stream, cancellationToken).ConfigureAwait(false);
            case ".safetensors":
                return await InspectSafeTensorsAsync(stream, cancellationToken).ConfigureAwait(false);
            case ".onnx":
                return InspectOnnx(stream, cancellationToken);
            case ".pt":
            case ".pth":
            case ".bin":
                return InspectTorchZip(stream);
            case ".json":
                return await InspectJsonMetadataAsync(stream, cancellationToken).ConfigureAwait(false);
            default:
                return FormatInspection.Unsupported(LocalModelFileFormat.Unknown, "Расширение не поддерживается.");
        }
    }

    private static async Task<FormatInspection> InspectGgufAsync(FileStream stream, CancellationToken cancellationToken)
    {
        if (stream.Length < 8)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.Gguf, "Файл короче заголовка GGUF.");
        }

        stream.Position = 0;
        var header = new byte[8];
        await stream.ReadExactlyAsync(header, cancellationToken).ConfigureAwait(false);
        var version = BinaryPrimitives.ReadUInt32LittleEndian(header.AsSpan(4, 4));
        if (!header.AsSpan(0, 4).SequenceEqual("GGUF"u8) || version == 0)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.Gguf, "Не найден допустимый GGUF magic/version.");
        }

        return FormatInspection.Verified(
            LocalModelFileFormat.Gguf,
            $"GGUF magic/version распознаны (версия {version}); содержимое модели не загружается.");
    }

    private static async Task<FormatInspection> InspectSafeTensorsAsync(FileStream stream, CancellationToken cancellationToken)
    {
        if (stream.Length < 10)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.SafeTensors, "Заголовок SafeTensors отсутствует или усечён.");
        }

        stream.Position = 0;
        var lengthBytes = new byte[sizeof(ulong)];
        await stream.ReadExactlyAsync(lengthBytes, cancellationToken).ConfigureAwait(false);
        var headerLength = BinaryPrimitives.ReadUInt64LittleEndian(lengthBytes);
        if (headerLength < 2 || headerLength > MaximumSafeTensorsHeaderBytes || headerLength > (ulong)(stream.Length - sizeof(ulong)))
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.SafeTensors, "Размер метаданных SafeTensors выходит за допустимые границы.");
        }

        var header = new byte[(int)headerLength];
        await stream.ReadExactlyAsync(header, cancellationToken).ConfigureAwait(false);

        using var document = JsonDocument.Parse(header);
        if (document.RootElement.ValueKind != JsonValueKind.Object)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.SafeTensors, "Метаданные SafeTensors должны быть JSON-объектом.");
        }

        var tensorCount = 0;
        var dataLength = stream.Length - sizeof(ulong) - (long)headerLength;
        foreach (var property in document.RootElement.EnumerateObject())
        {
            if (string.Equals(property.Name, "__metadata__", StringComparison.Ordinal))
            {
                if (property.Value.ValueKind != JsonValueKind.Object)
                {
                    return FormatInspection.Unsupported(LocalModelFileFormat.SafeTensors, "Поле __metadata__ имеет неверный тип.");
                }
                continue;
            }

            if (!TryValidateSafeTensorEntry(property.Value, dataLength))
            {
                return FormatInspection.Unsupported(LocalModelFileFormat.SafeTensors, "Запись тензора имеет некорректные dtype/shape/offsets.");
            }

            tensorCount++;
        }

        return tensorCount > 0
            ? FormatInspection.Verified(LocalModelFileFormat.SafeTensors, $"SafeTensors JSON-заголовок и {tensorCount} запись(и) распознаны; тензоры не загружаются.")
            : FormatInspection.Unsupported(LocalModelFileFormat.SafeTensors, "В заголовке не найдены записи тензоров.");
    }

    private static bool TryValidateSafeTensorEntry(JsonElement value, long dataLength)
    {
        if (value.ValueKind != JsonValueKind.Object ||
            !value.TryGetProperty("dtype", out var dtype) || dtype.ValueKind != JsonValueKind.String ||
            string.IsNullOrWhiteSpace(dtype.GetString()) ||
            !value.TryGetProperty("shape", out var shape) || shape.ValueKind != JsonValueKind.Array ||
            !value.TryGetProperty("data_offsets", out var offsets) || offsets.ValueKind != JsonValueKind.Array || offsets.GetArrayLength() != 2)
        {
            return false;
        }

        if (!offsets[0].TryGetInt64(out var start) || !offsets[1].TryGetInt64(out var end) ||
            start < 0 || end < start || end > dataLength)
        {
            return false;
        }

        foreach (var dimension in shape.EnumerateArray())
        {
            if (!dimension.TryGetInt64(out var dimensionLength) || dimensionLength < 0)
            {
                return false;
            }
        }

        return true;
    }

    private static FormatInspection InspectOnnx(FileStream stream, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        stream.Position = 0;
        var hasIrVersion = false;
        var hasGraph = false;

        try
        {
            // ONNX uses protobuf without a fixed magic prefix. This bounded
            // top-level walk validates only ModelProto's ir_version and graph
            // fields; it never parses tensor payloads or executes operators.
            while (stream.Position < stream.Length && !(hasIrVersion && hasGraph))
            {
                cancellationToken.ThrowIfCancellationRequested();
                var tag = ReadVarint(stream);
                if (tag == 0)
                {
                    return FormatInspection.Unsupported(LocalModelFileFormat.Onnx, "Некорректный protobuf tag.");
                }

                var rawFieldNumber = tag >> 3;
                var wireType = (int)(tag & 7);
                if (rawFieldNumber == 0 || rawFieldNumber > int.MaxValue)
                {
                    return FormatInspection.Unsupported(LocalModelFileFormat.Onnx, "Некорректный номер protobuf-поля.");
                }

                var fieldNumber = (int)rawFieldNumber;
                if (fieldNumber == 1 && wireType == 0)
                {
                    hasIrVersion = ReadVarint(stream) > 0;
                }
                else if (fieldNumber == 7 && wireType == 2)
                {
                    var length = ReadVarint(stream);
                    if (length <= 0 || length > (ulong)(stream.Length - stream.Position))
                    {
                        return FormatInspection.Unsupported(LocalModelFileFormat.Onnx, "Некорректная длина ONNX graph-поля.");
                    }

                    hasGraph = true;
                    stream.Position += (long)length;
                }
                else if (!SkipProtobufField(stream, wireType))
                {
                    return FormatInspection.Unsupported(LocalModelFileFormat.Onnx, "Не удалось проверить protobuf-структуру ONNX.");
                }
            }
        }
        catch (InvalidDataException)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.Onnx, "Файл не прошёл ограниченную проверку ONNX protobuf.");
        }

        return hasIrVersion && hasGraph
            ? FormatInspection.Verified(LocalModelFileFormat.Onnx, "Проверены ir_version и верхнеуровневый graph; модель не загружается.")
            : FormatInspection.Unsupported(LocalModelFileFormat.Onnx, "Не найдены ожидаемые поля ONNX ModelProto.");
    }

    private static bool SkipProtobufField(Stream stream, int wireType)
    {
        switch (wireType)
        {
            case 0:
                _ = ReadVarint(stream);
                return true;
            case 1:
                return SkipBytes(stream, 8);
            case 2:
                var length = ReadVarint(stream);
                return length <= long.MaxValue && SkipBytes(stream, (long)length);
            case 5:
                return SkipBytes(stream, 4);
            default:
                return false;
        }
    }

    private static bool SkipBytes(Stream stream, long count)
    {
        if (count < 0 || count > stream.Length - stream.Position)
        {
            return false;
        }

        stream.Position += count;
        return true;
    }

    private static ulong ReadVarint(Stream stream)
    {
        ulong result = 0;
        for (var index = 0; index < 10; index++)
        {
            var next = stream.ReadByte();
            if (next < 0)
            {
                throw new InvalidDataException("Unexpected end of protobuf stream.");
            }

            var bits = (byte)next;
            if (index == 9 && bits > 1)
            {
                throw new InvalidDataException("Protobuf varint exceeds UInt64.");
            }

            result |= (ulong)(bits & 0x7F) << (index * 7);
            if ((bits & 0x80) == 0)
            {
                return result;
            }
        }

        throw new InvalidDataException("Protobuf varint exceeds ten bytes.");
    }

    private static FormatInspection InspectTorchZip(FileStream stream)
    {
        stream.Position = 0;
        if (stream.Length < 4)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.PyTorchCheckpoint, "Файл слишком мал для контейнера checkpoint.");
        }

        Span<byte> magic = stackalloc byte[4];
        var read = stream.Read(magic);
        if (read < 4 || magic[0] != (byte)'P' || magic[1] != (byte)'K')
        {
            return FormatInspection.Unsupported(
                LocalModelFileFormat.PyTorchCheckpoint,
                "Небезопасная pickle-структура не разбирается; требуется отдельный проверенный импортёр.");
        }

        try
        {
            stream.Position = 0;
            using var archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: true);
            var hasDataPickle = archive.Entries.Any(entry => IsTorchArchiveEntry(entry.FullName, "data.pkl"));
            var hasVersion = archive.Entries.Any(entry => IsTorchArchiveEntry(entry.FullName, "version"));
            if (hasDataPickle && hasVersion)
            {
                return FormatInspection.Verified(
                    LocalModelFileFormat.PyTorchCheckpoint,
                    "ZIP-контейнер checkpoint распознан по именам записей; pickle-данные не открываются и не исполняются.");
            }

            return FormatInspection.Unsupported(LocalModelFileFormat.PyTorchCheckpoint, "ZIP-контейнер не содержит ожидаемую структуру PyTorch checkpoint.");
        }
        catch (InvalidDataException)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.PyTorchCheckpoint, "Некорректный ZIP-контейнер checkpoint.");
        }
    }

    private static bool IsTorchArchiveEntry(string entryName, string expectedName)
    {
        var normalized = entryName.Replace('\\', '/').TrimEnd('/');
        return string.Equals(normalized, expectedName, StringComparison.Ordinal) ||
               normalized.EndsWith("/" + expectedName, StringComparison.Ordinal);
    }

    private static async Task<FormatInspection> InspectJsonMetadataAsync(FileStream stream, CancellationToken cancellationToken)
    {
        if (stream.Length > MaximumStandaloneJsonBytes)
        {
            return FormatInspection.Unsupported(LocalModelFileFormat.JsonMetadata, "JSON-файл превышает лимит проверки метаданных.");
        }

        stream.Position = 0;
        using var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken).ConfigureAwait(false);
        var isObject = document.RootElement.ValueKind == JsonValueKind.Object;
        return isObject
            ? FormatInspection.Unsupported(LocalModelFileFormat.JsonMetadata, "JSON-метаданные распознаны, но отдельный JSON-файл не является импортируемыми весами.")
            : FormatInspection.Unsupported(LocalModelFileFormat.JsonMetadata, "JSON должен быть объектом метаданных; импорт отдельно не поддерживается.");
    }

    private static async Task<string> CopyToTemporaryAndHashAsync(
        string sourcePath,
        string temporaryPath,
        long expectedLength,
        CancellationToken cancellationToken)
    {
        if ((File.GetAttributes(sourcePath) & FileAttributes.ReparsePoint) != 0)
        {
            throw new IOException("Символьная ссылка вместо локального исходного файла не принимается.");
        }

        await using var source = new FileStream(
            sourcePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            IoBufferSize,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
        if (source.Length != expectedLength)
        {
            throw new IOException("Исходный файл изменил размер перед копированием.");
        }

        await using var target = new FileStream(
            temporaryPath,
            FileMode.CreateNew,
            FileAccess.Write,
            FileShare.None,
            IoBufferSize,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var buffer = new byte[IoBufferSize];
        long copied = 0;

        while (true)
        {
            var bytesRead = await source.ReadAsync(buffer.AsMemory(), cancellationToken).ConfigureAwait(false);
            if (bytesRead == 0)
            {
                break;
            }

            hash.AppendData(buffer, 0, bytesRead);
            await target.WriteAsync(buffer.AsMemory(0, bytesRead), cancellationToken).ConfigureAwait(false);
            copied += bytesRead;
        }

        await target.FlushAsync(cancellationToken).ConfigureAwait(false);
        if (copied != expectedLength)
        {
            throw new IOException("Число скопированных байтов не совпало с размером, полученным при сканировании.");
        }

        return Convert.ToHexString(hash.GetHashAndReset());
    }

    private static IEnumerable<string> EnumerateCandidateFiles(
        string selectedRoot,
        LocalModelScanOptions options,
        List<LocalModelScanIssue> issues,
        CancellationToken cancellationToken)
    {
        var pending = new Stack<(string Path, int Depth)>();
        pending.Push((selectedRoot, 0));
        var enumerationOptions = new EnumerationOptions
        {
            // Keep denied paths observable so the batch reports what it skipped.
            IgnoreInaccessible = false,
            ReturnSpecialDirectories = false,
            RecurseSubdirectories = false,
            AttributesToSkip = FileAttributes.ReparsePoint
        };

        while (pending.Count > 0)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var (currentDirectory, depth) = pending.Pop();

            IEnumerable<string> files;
            try
            {
                files = Directory.EnumerateFiles(currentDirectory, "*", enumerationOptions)
                    .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                    .ThenBy(path => path, StringComparer.Ordinal)
                    .ToArray();
            }
            catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or System.Security.SecurityException)
            {
                issues.Add(new LocalModelScanIssue(currentDirectory, $"Папка пропущена: {SafeExceptionMessage(exception)}"));
                continue;
            }

            foreach (var file in files)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (!CandidateExtensions.Contains(Path.GetExtension(file)))
                {
                    continue;
                }

                var isRegularFile = false;
                try
                {
                    isRegularFile = (File.GetAttributes(file) & FileAttributes.ReparsePoint) == 0;
                }
                catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or System.Security.SecurityException)
                {
                    issues.Add(new LocalModelScanIssue(file, $"Файл не удалось проверить: {SafeExceptionMessage(exception)}"));
                }

                if (isRegularFile)
                {
                    yield return file;
                }
            }

            if (!options.IncludeSubdirectories || depth >= options.MaxDepth)
            {
                continue;
            }

            IEnumerable<string> directories;
            try
            {
                directories = Directory.EnumerateDirectories(currentDirectory, "*", enumerationOptions)
                    .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                    .ThenBy(path => path, StringComparer.Ordinal)
                    .ToArray();
            }
            catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or System.Security.SecurityException)
            {
                issues.Add(new LocalModelScanIssue(currentDirectory, $"Подпапки пропущены: {SafeExceptionMessage(exception)}"));
                continue;
            }

            // Stack is LIFO; push in reverse so traversal still visits the
            // ordinal-sorted directories in ascending order.
            foreach (var directory in directories.Reverse())
            {
                try
                {
                    if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) == 0)
                    {
                        pending.Push((directory, depth + 1));
                    }
                }
                catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or System.Security.SecurityException)
                {
                    issues.Add(new LocalModelScanIssue(directory, $"Подпапка пропущена: {SafeExceptionMessage(exception)}"));
                }
            }
        }
    }

    private static string GetNonOverwritingPath(string directory, string originalName, int suffix)
    {
        var stem = Path.GetFileNameWithoutExtension(originalName);
        var extension = Path.GetExtension(originalName);
        var fileName = suffix == 0 ? originalName : $"{stem} ({suffix}){extension}";
        return Path.Combine(directory, fileName);
    }

    private static bool IsPathWithinRoot(string root, string path)
    {
        var normalizedRoot = Path.TrimEndingDirectorySeparator(Path.GetFullPath(root));
        var normalizedPath = Path.GetFullPath(path);
        var relative = Path.GetRelativePath(normalizedRoot, normalizedPath);
        return !Path.IsPathRooted(relative) &&
               !string.Equals(relative, "..", PathComparison) &&
               !relative.StartsWith(".." + Path.DirectorySeparatorChar, PathComparison) &&
               !relative.StartsWith(".." + Path.AltDirectorySeparatorChar, PathComparison);
    }

    private static bool IsFileSystemRoot(string path)
    {
        var fullPath = Path.GetFullPath(path);
        var root = Path.GetPathRoot(fullPath);
        return !string.IsNullOrEmpty(root) &&
               string.Equals(Path.TrimEndingDirectorySeparator(fullPath), Path.TrimEndingDirectorySeparator(root), PathComparison);
    }

    private static string SafeExceptionMessage(Exception exception)
    {
        return exception switch
        {
            UnauthorizedAccessException => "нет доступа",
            FileNotFoundException => "файл уже отсутствует",
            DirectoryNotFoundException => "папка уже отсутствует",
            _ => "ошибка чтения"
        };
    }

    private static void TryDeleteTemporaryFile(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }
        catch (IOException)
        {
            // A leftover .partial file is never treated as a staged model.
        }
        catch (UnauthorizedAccessException)
        {
            // Do not alter or retry any source file as cleanup.
        }
    }

    private static StringComparison PathComparison => OperatingSystem.IsWindows()
        ? StringComparison.OrdinalIgnoreCase
        : StringComparison.Ordinal;

    private sealed record FormatInspection(LocalModelFileFormat Format, bool FormatVerified, string Note)
    {
        public static FormatInspection Verified(LocalModelFileFormat format, string note) => new(format, true, note);
        public static FormatInspection Unsupported(LocalModelFileFormat format, string note) => new(format, false, note);
    }
}

public enum LocalModelImportStatus
{
    VERIFIED_FORMAT,
    REVIEW_REQUIRED_LICENSE,
    UNSUPPORTED_IMPORT,
    STAGED
}

public enum LocalModelFileFormat
{
    Unknown,
    Gguf,
    SafeTensors,
    Onnx,
    PyTorchCheckpoint,
    JsonMetadata
}

public sealed record LocalModelCandidate(
    string SelectedRoot,
    string SourcePath,
    string FileName,
    long SizeBytes,
    string Sha256,
    LocalModelFileFormat Format,
    LocalModelImportStatus Status,
    bool FormatVerified,
    string InspectionNote,
    DateTime LastWriteTimeUtc,
    bool UserLicenseReviewed,
    bool UserRightsAttested,
    bool FormatAndCompatibilityAccepted,
    string? StagedPath);

public sealed record LocalModelScanIssue(string Path, string Message);

public sealed record LocalModelScanProgress(
    int FilesInspected,
    string CurrentFile,
    long CurrentFileSizeBytes,
    string CurrentSha256,
    LocalModelImportStatus CurrentStatus);

public sealed record LocalModelScanBatch(
    string SelectedRoot,
    IReadOnlyList<LocalModelCandidate> Candidates,
    IReadOnlyList<LocalModelScanIssue> Issues,
    int FilesInspected);

public sealed record LocalModelImportAuthorization(
    bool UserConfirmedCopy,
    bool UserReviewedLicense,
    bool FormatAndCompatibilityAccepted,
    bool UserRightsAttested);

public sealed record LocalModelStageResult(
    LocalModelCandidate Candidate,
    bool Staged,
    string? StagedPath,
    string Message)
{
    public static LocalModelStageResult NotStaged(
        LocalModelCandidate candidate,
        LocalModelImportStatus status,
        string message) => new(
            candidate with { Status = status, StagedPath = null },
            false,
            null,
            message);
}

public sealed record LocalModelScanOptions(
    bool IncludeSubdirectories = false,
    int MaxDepth = 3,
    int MaxFiles = 500)
{
    internal void Validate()
    {
        if (MaxDepth < 0 || MaxDepth > 16)
        {
            throw new ArgumentOutOfRangeException(nameof(MaxDepth), "Глубина сканирования должна быть от 0 до 16.");
        }

        if (MaxFiles < 1 || MaxFiles > 100_000)
        {
            throw new ArgumentOutOfRangeException(nameof(MaxFiles), "Лимит файлов должен быть от 1 до 100000.");
        }
    }
}
