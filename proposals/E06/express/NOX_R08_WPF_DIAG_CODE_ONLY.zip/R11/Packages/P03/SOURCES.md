# Source and licensing notes

This module adapts the user-provided NOX R6 installer and NOX V6 model hub references, plus the later R7 source inventory, without modifying the Executor 01 shell. The V6 reference is a Windows binary and was not executed. The R6/R7 GUI model lists informed the catalog; this package uses the local Ollama API and a persistent queue instead of separate CMD pulls.

- User R6 Installer source: https://drive.google.com/file/d/1hZM59TOnXgNnxvlDPc-8SFXWCJ11QdmX/view
- User V6 Model Hub reference (binary, not run): https://drive.google.com/file/d/1AW9IbgOco4m1PkGPu8_9D2Ie6ldk8rtG/view

## Runtime source links

- Ollama API pull: https://docs.ollama.com/api/pull
- Ollama installed-model metadata: https://docs.ollama.com/api/tags
- Official Ollama model library: https://ollama.com/library
- WinGet usage and package operations: https://learn.microsoft.com/windows/package-manager/winget/
- WinGet package manifests: https://github.com/microsoft/winget-pkgs
- WebView2 WPF NuGet package (pinned at 1.0.4314.35): https://www.nuget.org/packages/Microsoft.Web.WebView2/
- Python licensing: https://docs.python.org/3/license.html
- Git licensing: https://git-scm.com/about/free-and-open-source
- Ollama source license: https://github.com/ollama/ollama/blob/main/LICENSE
- WebView2 runtime detection: https://learn.microsoft.com/dotnet/api/microsoft.web.webview2.core.corewebview2environment.getavailablebrowserversionstring

## Catalog and size policy

All 24 model tags point to `https://ollama.com/library/{slug}`. The local categories are a UI taxonomy, not Ollama metadata. `gemma3:4b` is categorized as multimodal because its official tag page lists text and image input; `gemma3:1b` is text-only. License terms are not inferred from model names; all entries remain `REVIEW_REQUIRED` until a user reviews the model card and applicable license. The catalog size column reports `Локально не измерен до загрузки`; it reports a measured local size only when the local Ollama `/api/tags` response provides it, and displays `Локальный размер N/D` when an installed model has no confirmed size. Mutable tag sizes are not promoted to pinned catalog values. VRAM fit and catalog SHA-256 remain `N/D` unless supported by evidence. A successful pull's digest and size read back from `/api/tags` are an Ollama integrity receipt, not proof that installed bytes match a separately pinned catalog checksum.

## Package contents and queue ownership

The ZIP contains active source files from `module/` and all `worker-*` lanes, plus the assembled root project, build script, acceptance contract, and this source note. The root project is the packaging entry point and retains `EnableWindowsTargeting=true`; the module project is included as lane source. Queue progress and terminal transitions are bound to the persisted owner lease and stop generation. Pause/Cancel retain the lease until the pull stops and acknowledges the stop; Resume and subsequent pulls wait for release. The manifest covers every packaged file except itself.

The shared event baseline is the V5 `nox.events.v3` contract stored at `Contracts/events.v3.json`. `ModelCenterEventsV3Adapter` maps the P03 event model to the required envelope and allowed states. Unknown states and missing measurements remain `N/D`/null; a pull-stream `success` is still `RUNNING`, and `DownloadCompleted` becomes `SUCCESS` only after digest/size verification and installed-model readback. Download events share their durable queue-row `operation_id`; import, component, backup, and restore streams each use one stable operation ID; event IDs and UTC timestamps are preserved. The `source_sha256` field is emitted only for local-file scan events, never populated with Ollama's installed manifest digest. This is a P03 event adapter exposed to the host, not a claim that R11/P01–P05 have an end-to-end bridge or accepted progress. R11's source archive and `events.v2` remain unchanged.

The stale-callback guard discards an old progress callback without cancelling a newer lease on the same queue row; a stop callback cancels only its matching active stop generation. This path has source-level review only; native Windows/Ollama behavior remains unverified.

No build, tests, or Windows runtime acceptance were performed for this packaging refresh; Windows acceptance remains pending.

## WEB V1.2 progress and telemetry boundary

The ten WEB group weights, in order, are 12%, 12%, 9%, 15%, 8%, 11%, 12%, 7%, 9%, and 5%, totaling 100%, plus the weighted overall progress. Accepted group and overall progress may be reported only from MAIN state and confirmed WEB receipts. Where evidence is absent, report `N/D`, not 0. Local tests, source completion, and Windows PP are not accepted WEB progress. WEB progress and EXE acceptance are separate tracks; this WPF source package does not advance either. System telemetry requires user consent and must provide STOP and revoke controls.

## Web-release boundary

Browser delivery does not imply Windows EXE acceptance. PC control is optional and must remain local, consent-based, stoppable, and revocable. This WPF candidate does not establish WEB progress or product acceptance status.
