using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;

namespace NOX.P01.ModelCenter;

/// <summary>
/// Consent is bound to the exact candidate path and SHA-256 shown to the user.
/// ReviewedLicenseText is the exact text shown for review; this class only hashes
/// the text and records the user's attestation, it does not determine legal rights.
/// </summary>
public sealed record OllamaGgufImportAuthorization(
    string ReviewedSourcePath,
    string ReviewedSourceSha256,
    string ReviewedLicenseReference,
    string ReviewedLicenseText,
    bool UserReviewedExactLicense,
    bool FormatAndCompatibilityAccepted,
    bool UserRightsAttested,
    bool SeparateImportConfirmed);

public sealed record OllamaGgufImportResult(
    string State,
    string Tag,
    string SourceSha256,
    string LicenseTextSha256,
    string? InstalledDigest,
    long? InstalledSizeBytes,
    int? ProcessExitCode,
    IReadOnlyList<string> ProcessOutput,
    string Message);

/// <summary>
/// Imports one reviewed local GGUF through the installed Ollama CLI. It never
/// executes or deserializes SafeTensors, ONNX, PyTorch, archive, or metadata files.
/// </summary>
public sealed class OllamaGgufImporter : IDisposable
{
    public const string ImportedVerified = "IMPORTED_VERIFIED";
    public const string ImportedUnverified = "IMPORTED_UNVERIFIED";
    public const string ImportFailed = "IMPORT_FAILED";
    public const string ImportBlocked = "IMPORT_BLOCKED";
    public const string HashVerificationSource = "ollama.exe create success + /api/tags manifest digest/size + unchanged scanner SHA-256";

    private static readonly Uri OllamaRoot = new("http://127.0.0.1:11434/", UriKind.Absolute);
    private static readonly UTF8Encoding StrictUtf8 = new(false, true);
    private static readonly string[] ProxyEnvironmentKeys =
        { "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy" };
    private static readonly SemaphoreSlim ImportGate = new(1, 1);
    private const int MaxLicenseTextChars = 1_000_000;
    private const int MaxApiResponseBytes = 4 * 1024 * 1024;
    private const int MaxProcessOutputLines = 512;
    private const int MaxProcessOutputChars = 256 * 1024;
    private const int MaxProcessLineChars = 2_048;
    private static readonly TimeSpan TagReadbackTimeout = TimeSpan.FromSeconds(15);
    private static readonly TimeSpan TagObservationTimeout = TimeSpan.FromSeconds(15);
    private static readonly System.Text.RegularExpressions.Regex SecretPattern = new(
        @"(?i)(token|password|secret|api[_-]?key|authorization)\s*[:=]\s*[^\s]+",
        System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.CultureInvariant);

    private readonly IModelCenterEventSink? _events;
    private readonly HttpClient _httpClient;
    private bool _disposed;

    public OllamaGgufImporter(IModelCenterEventSink? events = null)
    {
        _events = events;
        var handler = new SocketsHttpHandler
        {
            AllowAutoRedirect = false,
            UseProxy = false,
            ConnectTimeout = TimeSpan.FromSeconds(5)
        };
        _httpClient = new HttpClient(handler, disposeHandler: true)
        {
            BaseAddress = OllamaRoot,
            Timeout = Timeout.InfiniteTimeSpan
        };
    }

    public async Task<OllamaGgufImportResult> ImportAsync(
        LocalModelCandidate candidate,
        string tag,
        OllamaGgufImportAuthorization authorization,
        CancellationToken cancellationToken = default)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        ArgumentNullException.ThrowIfNull(candidate);
        ArgumentNullException.ThrowIfNull(authorization);
        var operationId = Guid.NewGuid().ToString("N");

        LocalModelCandidate reviewedCandidate;
        try { reviewedCandidate = ValidateReview(candidate, tag, authorization); }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or UnauthorizedAccessException or IOException or NotSupportedException)
        {
            PublishEvent(ModelCenterEventKind.FileImportBlocked, ImportBlocked, SafeMessage(ex.Message), tag ?? string.Empty,
                operationId: operationId);
            throw;
        }
        cancellationToken.ThrowIfCancellationRequested();

        var sourcePath = Path.GetFullPath(reviewedCandidate.SourcePath);
        var sourceHash = reviewedCandidate.Sha256.ToLowerInvariant();
        var licenseTextHash = ComputeTextSha256(authorization.ReviewedLicenseText);
        var output = new ProcessOutputCollector(_events, tag, operationId);
        FileStream? sourceLock = null;
        Process? process = null;
        string? temporaryDirectory = null;
        string? linkedModelPath = null;
        string? modelfilePath = null;
        FileStream? modelfileLock = null;
        var temporaryDirectoryCreated = false;
        var linkedModelCreated = false;
        var modelfileCreated = false;
        var processExitCode = (int?)null;
        var importGateHeld = false;

        try
        {
            await ImportGate.WaitAsync(cancellationToken).ConfigureAwait(false);
            importGateHeld = true;
            EnsureCandidatePath(reviewedCandidate, sourcePath);
            sourceLock = new FileStream(
                sourcePath,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read,
                bufferSize: 1024 * 1024,
                options: FileOptions.Asynchronous | FileOptions.SequentialScan);

            if (sourceLock.Length != reviewedCandidate.SizeBytes)
                throw new InvalidDataException("GGUF size changed after scanning; scan the file again.");

            var initialHash = await ComputeSha256Async(sourceLock, cancellationToken).ConfigureAwait(false);
            if (!FixedTimeHexEquals(initialHash, sourceHash))
                throw new InvalidDataException("GGUF SHA-256 changed after scanning; scan the file again.");

            await VerifyGgufHeaderAsync(sourceLock, cancellationToken).ConfigureAwait(false);

            var before = await GetTagObservationAsync(tag, cancellationToken).ConfigureAwait(false);
            if (before.Exists)
                throw new InvalidOperationException("The selected Ollama tag already exists; import will not overwrite it.");

            cancellationToken.ThrowIfCancellationRequested();
            temporaryDirectory = CreateUniqueTemporaryDirectory(Path.GetDirectoryName(sourcePath)!);
            temporaryDirectoryCreated = true;
            linkedModelPath = Path.Combine(temporaryDirectory, "model.gguf");
            modelfilePath = Path.Combine(temporaryDirectory, "Modelfile");

            CreateLocalHardLink(linkedModelPath, sourcePath);
            linkedModelCreated = true;
            modelfileLock = await WriteModelfileAsync(modelfilePath, cancellationToken).ConfigureAwait(false);
            modelfileCreated = true;

            // Recheck as close as possible to process launch. ImportGate prevents
            // concurrent calls through this service from racing each other.
            if ((await GetTagObservationAsync(tag, cancellationToken).ConfigureAwait(false)).Exists)
                throw new InvalidOperationException("The selected Ollama tag appeared before import; overwrite is refused.");

            PublishEvent(ModelCenterEventKind.InstallStarted, "RUNNING", "GGUF import started after explicit review and confirmation.", tag,
                operationId: operationId);
            var ollamaExe = FindAllowlistedOllamaExe();
            var startInfo = CreateStartInfo(ollamaExe, tag, modelfilePath, temporaryDirectory);
            process = new Process { StartInfo = startInfo, EnableRaisingEvents = true };
            process.OutputDataReceived += (_, args) => output.Add("stdout", args.Data);
            process.ErrorDataReceived += (_, args) => output.Add("stderr", args.Data);

            if (!process.Start())
                throw new InvalidOperationException("The allowlisted local ollama.exe did not start.");

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            try
            {
                await process.WaitForExitAsync(cancellationToken).ConfigureAwait(false);
                process.WaitForExit();
            }
            catch (OperationCanceledException)
            {
                TryKill(process);
                await WaitForExitAfterKillAsync(process).ConfigureAwait(false);
                throw;
            }

            processExitCode = process.ExitCode;
            var postImportHash = await ComputeSha256Async(sourceLock, CancellationToken.None).ConfigureAwait(false);
            var sourceUnchanged = FixedTimeHexEquals(postImportHash, sourceHash);

            TagObservation? after = null;
            string? verificationIssue = null;
            try
            {
                // Verification read is allowed to finish after the CLI exits, even if
                // the caller cancels immediately after process completion, but is bounded.
                using var readbackTimeout = new CancellationTokenSource(TagReadbackTimeout);
                after = await GetTagObservationAsync(tag, readbackTimeout.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException) { verificationIssue = "Ollama /api/tags readback timed out."; }
            catch (Exception ex) when (ex is HttpRequestException or IOException or JsonException or InvalidDataException or OllamaApiException or TimeoutException)
            {
                verificationIssue = SafeMessage(ex.Message);
            }

            var verified = processExitCode == 0 && sourceUnchanged &&
                           after is { Exists: true, DigestIsValid: true, SizeBytes: > 0 };
            var observed = after is { Exists: true };
            var state = verified
                ? ImportedVerified
                : (processExitCode == 0 || observed ? ImportedUnverified : ImportFailed);

            var message = state switch
            {
                ImportedVerified => "Ollama create completed; /api/tags returned a valid SHA-256 manifest digest and size, and source bytes stayed unchanged.",
                ImportedUnverified when !sourceUnchanged => "The import may exist, but the source file changed during the operation; verification is withheld.",
                ImportedUnverified when verificationIssue is not null => "Ollama create completed, but /api/tags could not verify the installed model: " + verificationIssue,
                ImportedUnverified when !observed => "Ollama create exited successfully, but the installed tag was not observed in /api/tags.",
                ImportedUnverified when processExitCode != 0 => "The tag is present, but ollama create returned a nonzero exit code; verification is withheld.",
                ImportedUnverified => "The model tag was observed, but its manifest digest or size was invalid.",
                _ => "Ollama create failed and the selected tag was not observed."
            };

            var result = new OllamaGgufImportResult(
                state,
                tag,
                sourceHash,
                licenseTextHash,
                after?.Digest,
                after?.SizeBytes,
                processExitCode,
                output.Snapshot(),
                message);

            PublishEvent(
                state == ImportedVerified ? ModelCenterEventKind.FileImported :
                state == ImportFailed ? ModelCenterEventKind.InstallFailed : ModelCenterEventKind.FileImported,
                state,
                message,
                tag,
                totalBytes: processExitCode == 0 && sourceUnchanged && after?.SizeBytes is > 0
                    ? after.SizeBytes
                    : null,
                completedBytes: processExitCode == 0 && sourceUnchanged && after?.SizeBytes is > 0
                    ? after.SizeBytes
                    : null,
                digest: after?.Digest,
                progressPercent: processExitCode == 0 && sourceUnchanged ? 100 : null,
                operationId: operationId);
            return result;
        }
        catch (OperationCanceledException)
        {
            if (process is not null) TryKill(process);
            PublishEvent(ModelCenterEventKind.InstallFailed, "CANCELLED", "GGUF import was cancelled; temporary files will be removed.", tag,
                operationId: operationId);
            throw;
        }
        catch (Exception ex)
        {
            var safeMessage = SafeMessage(ex.Message);
            PublishEvent(ModelCenterEventKind.FileImportBlocked, ImportBlocked, safeMessage, tag, operationId: operationId);
            throw;
        }
        finally
        {
            if (process is not null)
            {
                if (!HasExited(process))
                {
                    // Do not remove the hard link or Modelfile while a started
                    // CLI may still be reading them on an exceptional exit path.
                    TryKill(process);
                    await WaitForExitAfterKillAsync(process).ConfigureAwait(false);
                }
                process.Dispose();
            }

            sourceLock?.Dispose();
            modelfileLock?.Dispose();
            if (modelfileCreated) CleanupTemporaryFile(modelfilePath);
            if (linkedModelCreated) CleanupTemporaryFile(linkedModelPath);
            if (temporaryDirectoryCreated) CleanupTemporaryDirectory(temporaryDirectory);
            if (importGateHeld) ImportGate.Release();
        }
    }

    private static LocalModelCandidate ValidateReview(
        LocalModelCandidate candidate,
        string tag,
        OllamaGgufImportAuthorization authorization)
    {
        ValidateTag(tag);

        if (candidate.Format != LocalModelFileFormat.Gguf ||
            !candidate.FormatVerified ||
            candidate.Status == LocalModelImportStatus.UNSUPPORTED_IMPORT ||
            !string.Equals(Path.GetExtension(candidate.SourcePath), ".gguf", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Only a scanner-verified GGUF candidate can be imported.");

        if (!IsSha256(candidate.Sha256) || !IsSha256(authorization.ReviewedSourceSha256) ||
            !string.Equals(candidate.Sha256, authorization.ReviewedSourceSha256, StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("Review approval is not bound to the candidate's scanned SHA-256.");

        var sourcePath = Path.GetFullPath(candidate.SourcePath);
        if (string.IsNullOrWhiteSpace(authorization.ReviewedSourcePath) ||
            !PathsEqual(sourcePath, Path.GetFullPath(authorization.ReviewedSourcePath)))
            throw new UnauthorizedAccessException("Review approval is not bound to the exact scanned file path.");

        if (string.IsNullOrWhiteSpace(authorization.ReviewedLicenseReference) ||
            authorization.ReviewedLicenseReference.Length > 2048 ||
            ContainsControl(authorization.ReviewedLicenseReference) ||
            !Uri.TryCreate(authorization.ReviewedLicenseReference, UriKind.Absolute, out var licenseUri) ||
            licenseUri.Scheme != Uri.UriSchemeHttps ||
            string.IsNullOrWhiteSpace(licenseUri.Host) ||
            licenseUri.UserInfo.Length != 0)
            throw new UnauthorizedAccessException("A specific license reference must be presented for review.");

        if (string.IsNullOrWhiteSpace(authorization.ReviewedLicenseText) ||
            authorization.ReviewedLicenseText.Length > MaxLicenseTextChars)
            throw new UnauthorizedAccessException("The exact reviewed license text is missing or exceeds the review limit.");

        if (!authorization.UserReviewedExactLicense ||
            !authorization.FormatAndCompatibilityAccepted ||
            !authorization.UserRightsAttested ||
            !authorization.SeparateImportConfirmed)
            throw new UnauthorizedAccessException("License review, format/compatibility acceptance, rights attestation, and separate import confirmation are all required.");

        var reviewed = LocalModelFileScanner.AcknowledgeReview(
            candidate,
            userReviewedLicense: authorization.UserReviewedExactLicense,
            formatAndCompatibilityAccepted: authorization.FormatAndCompatibilityAccepted,
            userRightsAttested: authorization.UserRightsAttested);
        if (reviewed.Status != LocalModelImportStatus.VERIFIED_FORMAT ||
            !reviewed.UserLicenseReviewed ||
            !reviewed.FormatAndCompatibilityAccepted ||
            !reviewed.UserRightsAttested)
            throw new UnauthorizedAccessException("The scanner did not accept the complete review record.");

        return reviewed;
    }

    private static void ValidateTag(string tag)
    {
        if (string.IsNullOrWhiteSpace(tag) || tag.Length > 128)
            throw new ArgumentException("Model tag must be a non-empty, bounded Ollama name.", nameof(tag));
        foreach (var character in tag)
        {
            if (char.IsControl(character) || char.IsWhiteSpace(character))
                throw new ArgumentException("Model tag must be a non-empty, bounded Ollama name.", nameof(tag));
        }

        var tagSpan = tag.AsSpan();
        var separator = tagSpan.IndexOf(':');
        var modelPath = separator < 0 ? tagSpan : tagSpan[..separator];
        var version = separator < 0 ? ReadOnlySpan<char>.Empty : tagSpan[(separator + 1)..];
        if ((separator >= 0 && version.IndexOf(':') >= 0) ||
            !IsValidModelPath(modelPath) ||
            (separator >= 0 && !IsValidNameSegment(version)))
            throw new ArgumentException("Model tag contains unsupported characters or an invalid namespace/tag.", nameof(tag));
    }

    private static bool IsValidModelPath(ReadOnlySpan<char> value)
    {
        var separator = value.IndexOf('/');
        if (separator < 0) return IsValidNameSegment(value);
        var remainder = value[(separator + 1)..];
        return remainder.IndexOf('/') < 0 &&
               IsValidNameSegment(value[..separator]) &&
               IsValidNameSegment(remainder);
    }

    private static bool IsValidNameSegment(ReadOnlySpan<char> value)
    {
        if (value.Length == 0 || !IsAsciiAlphaNumeric(value[0]) || !IsAsciiAlphaNumeric(value[^1])) return false;
        for (var i = 1; i < value.Length; i++)
        {
            var c = value[i];
            if (!IsAsciiAlphaNumeric(c) && c is not '.' and not '_' and not '-') return false;
        }
        return true;
    }

    private static bool IsAsciiAlphaNumeric(char c) =>
        c is >= 'a' and <= 'z' or >= 'A' and <= 'Z' or >= '0' and <= '9';

    private static void EnsureCandidatePath(LocalModelCandidate candidate, string sourcePath)
    {
        if (candidate.SizeBytes <= 0 || candidate.SelectedRoot.Length == 0)
            throw new InvalidDataException("Scanner candidate is missing its root or positive source size.");

        var selectedRoot = Path.GetFullPath(candidate.SelectedRoot);
        var rootAttributes = File.GetAttributes(selectedRoot);
        if (!Directory.Exists(selectedRoot) ||
            (rootAttributes & FileAttributes.ReparsePoint) != 0 || IsFileSystemRoot(selectedRoot))
            throw new InvalidDataException("Scanner-selected root is no longer a regular directory.");

        if (!IsWithinRoot(selectedRoot, sourcePath))
            throw new InvalidDataException("GGUF source path is outside the scanner-selected folder.");
        if (!File.Exists(sourcePath))
            throw new FileNotFoundException("Scanned GGUF source file no longer exists.");

        var sourceAttributes = File.GetAttributes(sourcePath);
        if ((sourceAttributes & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("GGUF source is now a symbolic link or reparse point.");

        var currentDirectory = Path.GetDirectoryName(sourcePath)
                               ?? throw new InvalidDataException("GGUF source has no containing directory.");
        while (true)
        {
            if (!PathsEqual(currentDirectory, selectedRoot) && !IsWithinRoot(selectedRoot, currentDirectory))
                throw new InvalidDataException("GGUF source directory escaped the selected folder.");
            var attributes = File.GetAttributes(currentDirectory);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("GGUF path now contains a symbolic link or reparse point.");
            if (PathsEqual(currentDirectory, selectedRoot)) break;
            var parent = Directory.GetParent(currentDirectory)?.FullName;
            if (parent is null) throw new InvalidDataException("GGUF path escaped the selected folder.");
            currentDirectory = parent;
        }
    }

    private static async Task VerifyGgufHeaderAsync(FileStream stream, CancellationToken cancellationToken)
    {
        if (stream.Length < 8) throw new InvalidDataException("GGUF candidate is shorter than its header.");
        stream.Position = 0;
        var header = new byte[8];
        await stream.ReadExactlyAsync(header, cancellationToken).ConfigureAwait(false);
        var version = BinaryPrimitives.ReadUInt32LittleEndian(header.AsSpan(4, 4));
        if (!header.AsSpan(0, 4).SequenceEqual("GGUF"u8) || version == 0)
            throw new InvalidDataException("GGUF magic/version no longer matches the scanner result.");
    }

    private async Task<TagObservation> GetTagObservationAsync(string requestedTag, CancellationToken cancellationToken)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TagObservationTimeout);
        try
        {
            return await GetTagObservationCoreAsync(requestedTag, timeout.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException("Ollama /api/tags request timed out.");
        }
    }

    private async Task<TagObservation> GetTagObservationCoreAsync(string requestedTag, CancellationToken cancellationToken)
    {
        var latestTag = requestedTag.IndexOf(':') < 0 ? requestedTag + ":latest" : null;
        using var request = new HttpRequestMessage(HttpMethod.Get, new Uri(OllamaRoot, "api/tags"));
        using var response = await _httpClient.SendAsync(
            request,
            HttpCompletionOption.ResponseHeadersRead,
            cancellationToken).ConfigureAwait(false);
        EnsureLoopback(response.RequestMessage?.RequestUri ?? request.RequestUri!);

        var body = await ReadBoundedBodyAsync(
            response.Content,
            MaxApiResponseBytes,
            cancellationToken,
            rejectAtLimit: response.IsSuccessStatusCode).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
            throw new OllamaApiException(response.StatusCode, ExtractApiError(body));

        JsonDocument document;
        try { document = JsonDocument.Parse(body, new JsonDocumentOptions { MaxDepth = 32 }); }
        catch (JsonException ex) { throw new InvalidDataException("Ollama /api/tags returned invalid JSON.", ex); }

        using (document)
        {
            if (!document.RootElement.TryGetProperty("models", out var models) || models.ValueKind != JsonValueKind.Array)
                throw new InvalidDataException("Ollama /api/tags did not contain a models array.");

            foreach (var item in models.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.Object) continue;
                var name = ReadString(item, "name");
                var model = ReadString(item, "model");
                if (!TagMatches(requestedTag, latestTag, name) && !TagMatches(requestedTag, latestTag, model)) continue;

                var digest = ReadString(item, "digest");
                long size = 0;
                var hasSize = item.TryGetProperty("size", out var sizeElement) &&
                              sizeElement.ValueKind == JsonValueKind.Number &&
                              sizeElement.TryGetInt64(out size) && size > 0;
                var validDigest = IsSha256Digest(digest);
                return new TagObservation(
                    Exists: true,
                    DigestIsValid: validDigest,
                    Digest: validDigest ? digest!.ToLowerInvariant() : null,
                    SizeBytes: hasSize ? size : null);
            }
        }

        return new TagObservation(false, false, null, null);
    }

    private static bool TagMatches(string requested, string? latestTag, string? installed)
    {
        if (string.IsNullOrEmpty(installed)) return false;
        return string.Equals(requested, installed, StringComparison.OrdinalIgnoreCase) ||
               (latestTag is not null && string.Equals(latestTag, installed, StringComparison.OrdinalIgnoreCase));
    }

    private static ProcessStartInfo CreateStartInfo(string executable, string tag, string modelfilePath, string workingDirectory)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = executable,
            WorkingDirectory = workingDirectory,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = false
        };
        startInfo.ArgumentList.Add("create");
        startInfo.ArgumentList.Add(tag);
        startInfo.ArgumentList.Add("-f");
        startInfo.ArgumentList.Add(modelfilePath);
        startInfo.Environment["OLLAMA_HOST"] = "http://127.0.0.1:11434";
        foreach (var proxyKey in ProxyEnvironmentKeys)
            startInfo.Environment.Remove(proxyKey);
        startInfo.Environment["NO_PROXY"] = "127.0.0.1,localhost,::1";
        startInfo.Environment["no_proxy"] = "127.0.0.1,localhost,::1";
        return startInfo;
    }

    private static string FindAllowlistedOllamaExe()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("Local GGUF import through ollama.exe is supported only on Windows.");

        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        var candidates = new[]
        {
            string.IsNullOrWhiteSpace(local) ? string.Empty : Path.Combine(local, "Programs", "Ollama", "ollama.exe"),
            string.IsNullOrWhiteSpace(programFiles) ? string.Empty : Path.Combine(programFiles, "Ollama", "ollama.exe")
        };

        foreach (var candidate in candidates)
        {
            if (string.IsNullOrWhiteSpace(candidate) || !Path.IsPathFullyQualified(candidate) || !File.Exists(candidate)) continue;
            var fullPath = Path.GetFullPath(candidate);
            var attributes = File.GetAttributes(fullPath);
            if ((attributes & FileAttributes.ReparsePoint) != 0 ||
                !string.Equals(Path.GetFileName(fullPath), "ollama.exe", StringComparison.OrdinalIgnoreCase))
                continue;
            return fullPath;
        }

        throw new FileNotFoundException("Allowlisted local Ollama installation was not found.");
    }

    private static async Task<FileStream> WriteModelfileAsync(string path, CancellationToken cancellationToken)
    {
        var content = new UTF8Encoding(false).GetBytes("FROM ./model.gguf\n");
        try
        {
            await using (var file = new FileStream(
                             path,
                             FileMode.CreateNew,
                             FileAccess.Write,
                             FileShare.None,
                             bufferSize: 4096,
                             options: FileOptions.Asynchronous | FileOptions.WriteThrough))
            {
                await file.WriteAsync(content, cancellationToken).ConfigureAwait(false);
                await file.FlushAsync(cancellationToken).ConfigureAwait(false);
            }

            // Reopen and verify the exact generated bytes, then keep a read lock
            // through process exit so the safe relative FROM path cannot be
            // replaced or edited before ollama.exe consumes it.
            var readLock = new FileStream(
                path,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read,
                bufferSize: 4096,
                options: FileOptions.Asynchronous | FileOptions.SequentialScan);
            try
            {
                if (readLock.Length != content.Length)
                    throw new InvalidDataException("Temporary Ollama Modelfile changed before import.");
                var readBack = new byte[content.Length];
                await readLock.ReadExactlyAsync(readBack, cancellationToken).ConfigureAwait(false);
                if (!readBack.AsSpan().SequenceEqual(content))
                    throw new InvalidDataException("Temporary Ollama Modelfile changed before import.");
                readLock.Position = 0;
                return readLock;
            }
            catch
            {
                await readLock.DisposeAsync().ConfigureAwait(false);
                throw;
            }
        }
        catch
        {
            // The caller only marks the Modelfile created after this method
            // returns. Remove a partial file here so cancellation/write errors
            // cannot strand the otherwise-empty temporary import directory.
            CleanupTemporaryFile(path);
            throw;
        }
    }

    private static string CreateUniqueTemporaryDirectory(string parentDirectory)
    {
        for (var attempt = 0; attempt < 8; attempt++)
        {
            var candidate = Path.Combine(parentDirectory, ".nox-ollama-import-" + Guid.NewGuid().ToString("N"));
            if (Directory.Exists(candidate) || File.Exists(candidate)) continue;
            Directory.CreateDirectory(candidate);
            return candidate;
        }
        throw new IOException("Could not allocate a unique temporary import directory.");
    }

    private static void CreateLocalHardLink(string linkPath, string sourcePath)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("A local Windows hard link is required to avoid copying a GGUF model.");
        if (!CreateHardLinkW(linkPath, sourcePath, IntPtr.Zero))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not create the temporary local GGUF hard link.");
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "CreateHardLinkW")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CreateHardLinkW(string fileName, string existingFileName, IntPtr securityAttributes);

    private static async Task<string> ComputeSha256Async(FileStream stream, CancellationToken cancellationToken)
    {
        stream.Position = 0;
        var hash = await SHA256.HashDataAsync(stream, cancellationToken).ConfigureAwait(false);
        stream.Position = 0;
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static string ComputeTextSha256(string text) =>
        Convert.ToHexString(SHA256.HashData(StrictUtf8.GetBytes(text))).ToLowerInvariant();

    private static bool FixedTimeHexEquals(string actual, string expected)
    {
        if (!IsSha256(actual) || !IsSha256(expected)) return false;
        return CryptographicOperations.FixedTimeEquals(
            Convert.FromHexString(actual),
            Convert.FromHexString(expected));
    }

    private static bool ContainsControl(string value)
    {
        foreach (var character in value) if (char.IsControl(character)) return true;
        return false;
    }

    private static bool IsSha256(string? value)
    {
        if (value is null || value.Length != 64) return false;
        for (var i = 0; i < value.Length; i++)
            if (!Uri.IsHexDigit(value[i])) return false;
        return true;
    }

    private static bool IsSha256Digest(string? value) =>
        value is { Length: 71 } &&
        value.StartsWith("sha256:", StringComparison.OrdinalIgnoreCase) &&
        IsSha256(value[7..]);

    private static string? ReadString(JsonElement element, string name) =>
        element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    private static string ExtractApiError(string body)
    {
        if (string.IsNullOrWhiteSpace(body)) return "Ollama /api/tags request failed.";
        try
        {
            using var document = JsonDocument.Parse(body, new JsonDocumentOptions { MaxDepth = 16 });
            if (document.RootElement.ValueKind == JsonValueKind.Object &&
                document.RootElement.TryGetProperty("error", out var error))
            {
                var text = error.ValueKind == JsonValueKind.String ? error.GetString() : error.ToString();
                if (!string.IsNullOrWhiteSpace(text)) return SafeMessage(text);
            }
        }
        catch (JsonException) { }
        return SafeMessage(body);
    }

    private static async Task<string> ReadBoundedBodyAsync(
        HttpContent content,
        int maxBytes,
        CancellationToken cancellationToken,
        bool rejectAtLimit = false)
    {
        ArgumentNullException.ThrowIfNull(content);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(maxBytes);
        var declaredLength = content.Headers.ContentLength;
        if (rejectAtLimit && declaredLength is > 0 && declaredLength.Value >= maxBytes)
            throw new InvalidDataException("Ollama API response reached the configured size limit.");

        await using var stream = await content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        var initialCapacity = declaredLength is > 0
            ? (int)Math.Min(maxBytes, Math.Min(declaredLength.Value, 16 * 1024))
            : Math.Min(maxBytes, 16 * 1024);
        using var buffer = new MemoryStream(initialCapacity);
        var chunk = new byte[8192];
        while (buffer.Length < maxBytes)
        {
            var remaining = maxBytes - (int)buffer.Length;
            var read = await stream.ReadAsync(chunk.AsMemory(0, Math.Min(chunk.Length, remaining)), cancellationToken)
                .ConfigureAwait(false);
            if (read == 0) break;
            buffer.Write(chunk, 0, read);
        }

        // Never read beyond the cap just to detect EOF: a loopback server may
        // keep the response open after sending the limit-sized body.
        var reachedLimit = buffer.Length == maxBytes;
        if (reachedLimit && rejectAtLimit)
            throw new InvalidDataException("Ollama API response reached the configured size limit.");

        string text;
        try { text = StrictUtf8.GetString(buffer.GetBuffer(), 0, (int)buffer.Length); }
        catch (DecoderFallbackException) { throw new InvalidDataException("Ollama API response was not valid UTF-8."); }
        return reachedLimit ? text + " [truncated at configured limit]" : text;
    }

    private static void EnsureLoopback(Uri uri)
    {
        if (!uri.IsAbsoluteUri || uri.Scheme != Uri.UriSchemeHttp || !uri.IsLoopback ||
            !string.Equals(uri.Host, "127.0.0.1", StringComparison.OrdinalIgnoreCase) ||
            uri.Port != 11434 || uri.UserInfo.Length != 0)
            throw new InvalidOperationException("Ollama API access is restricted to local 127.0.0.1:11434.");
    }

    private static bool IsWithinRoot(string root, string path)
    {
        var normalizedRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                            + Path.DirectorySeparatorChar;
        var normalizedPath = Path.GetFullPath(path);
        return normalizedPath.StartsWith(normalizedRoot, PathComparison);
    }

    private static bool IsFileSystemRoot(string path) =>
        string.Equals(Path.GetPathRoot(Path.GetFullPath(path)), Path.GetFullPath(path), PathComparison);

    private static bool PathsEqual(string left, string right) =>
        string.Equals(Path.GetFullPath(left).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
            Path.GetFullPath(right).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), PathComparison);

    private static StringComparison PathComparison => OperatingSystem.IsWindows()
        ? StringComparison.OrdinalIgnoreCase
        : StringComparison.Ordinal;

    private static string SafeMessage(string message)
    {
        var builder = new StringBuilder(Math.Min(message.Length, 2048));
        foreach (var c in message)
        {
            if (char.IsControl(c) && c is not '\t') continue;
            builder.Append(c);
            if (builder.Length >= 2048) break;
        }
        return builder.ToString();
    }

    private void PublishEvent(
        ModelCenterEventKind kind,
        string state,
        string message,
        string tag,
        long? totalBytes = null,
        long? completedBytes = null,
        string? digest = null,
        double? progressPercent = null,
        string? operationId = null)
    {
        try
        {
            _events?.Publish(new ModelCenterEvent
            {
                Kind = kind,
                ComponentId = "ollama.gguf.import",
                State = state,
                Message = SafeMessage($"{tag}: {message}"),
                ProgressPercent = progressPercent,
                BytesTotal = totalBytes,
                BytesCompleted = completedBytes,
                Sha256Digest = digest,
                OperationId = operationId
            });
        }
        catch
        {
            // Event sinks are observational; they must not interrupt an authorized import.
        }
    }

    private static bool HasExited(Process process)
    {
        try { return process.HasExited; }
        catch (InvalidOperationException) { return true; }
    }

    private static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited) process.Kill(entireProcessTree: false);
        }
        catch (InvalidOperationException) { }
        catch (System.ComponentModel.Win32Exception) { }
        catch (NotSupportedException) { }
    }

    private static async Task WaitForExitAfterKillAsync(Process process)
    {
        try { await process.WaitForExitAsync(CancellationToken.None).ConfigureAwait(false); }
        catch (InvalidOperationException) { }
        catch (System.ComponentModel.Win32Exception) { }
    }

    private static void CleanupTemporaryFile(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        try { if (File.Exists(path)) File.Delete(path); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private static void CleanupTemporaryDirectory(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        try { if (Directory.Exists(path)) Directory.Delete(path, recursive: false); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private sealed record TagObservation(bool Exists, bool DigestIsValid, string? Digest, long? SizeBytes);

    private sealed class ProcessOutputCollector
    {
        private readonly object _gate = new();
        private readonly List<string> _lines = new();
        private readonly IModelCenterEventSink? _events;
        private readonly string _tag;
        private readonly string _operationId;
        private int _totalChars;
        private bool _truncated;

        public ProcessOutputCollector(IModelCenterEventSink? events, string tag, string operationId)
        {
            _events = events;
            _tag = tag;
            _operationId = operationId;
        }

        public void Add(string streamName, string? line)
        {
            if (string.IsNullOrWhiteSpace(line)) return;
            var safeLine = SafeMessage(line);
            if (safeLine.Length > MaxProcessLineChars) safeLine = safeLine[..MaxProcessLineChars] + " [truncated]";
            safeLine = SecretPattern.Replace(safeLine, "$1=[redacted]");

            var entry = $"[{streamName}] {safeLine}";
            var keep = false;
            var eventEntry = entry;
            lock (_gate)
            {
                if (_lines.Count < MaxProcessOutputLines - 1 && _totalChars + entry.Length <= MaxProcessOutputChars)
                {
                    _lines.Add(entry);
                    _totalChars += entry.Length;
                    keep = true;
                }
                else if (!_truncated)
                {
                    _lines.Add("[output] additional output omitted after the capture limit");
                    _truncated = true;
                    keep = true;
                    eventEntry = "[output] additional output omitted after the capture limit";
                }
            }

            if (!keep) return;
            try
            {
                _events?.Publish(new ModelCenterEvent
                {
                    Kind = ModelCenterEventKind.InstallOutput,
                    ComponentId = "ollama.gguf.import",
                    State = "RUNNING",
                    Message = SafeMessage($"{_tag}: {eventEntry}"),
                    OperationId = _operationId
                });
            }
            catch { }
        }

        public IReadOnlyList<string> Snapshot()
        {
            lock (_gate) return _lines.ToArray();
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
    }
}
