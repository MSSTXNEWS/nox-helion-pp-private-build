CANON V11 · MERGED SOURCE ONLY

Status: SOURCE_INTEGRATION_CANDIDATE / RELEASE BLOCKED.
Source-run regression suite: 20/20 PASS (standard-library tests, HTML parser, and JavaScript syntax only).
Windows/.NET build: NOT RUN (`dotnet` unavailable in this environment).
Live local Ollama chat and STOP: NOT VERIFIED on this merged source.
OpenAI API stream and STOP: NOT VERIFIED on this merged source.
Model download/import/rollback: NOT VERIFIED on this merged source.
QLoRA training and saved adapter: NOT RUN; no trained weights are included.
P04 ECO/BALANCED/INTENSIVE profiles and selected-GPU thermal-stop path: SOURCE-VERIFIED BY TESTS ONLY; actual GPU/eGPU sensor and thermal behavior NOT RUN.
RAG, attachments, SQLite, full event-to-Drive sync: NOT IMPLEMENTED/NOT VERIFIED.
Independent same-BuildID/SHA acceptance: NOT RUN.

Existing QA result files are historical and refer to earlier source states. Their PASS labels do not apply to this candidate.
