﻿# NOX HELION Windows Express Integrator - local user scope
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$base=Join-Path $env:LOCALAPPDATA 'NOX_HELION_Integrator'
$app=Join-Path $base 'app'
$logdir=Join-Path $base 'logs'
New-Item -ItemType Directory -Force -Path $logdir | Out-Null
$logfile=Join-Path $logdir 'integrator.log'
function Write-Log([string]$s){ $line='['+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+'] '+$s; Add-Content -LiteralPath $logfile -Value $line -Encoding UTF8; if($script:bottom -and -not $script:bottom.IsDisposed){$script:bottom.AppendText($line+[Environment]::NewLine)} }
function Confirm([string]$s){ return ([System.Windows.Forms.MessageBox]::Show($s,'NOX HELION — Подтверждение','YesNo','Question') -eq 'Yes') }
function Locate-Python {
  foreach($exe in @('py','python')) { $c=Get-Command $exe -ErrorAction SilentlyContinue; if($c){try { $v=(& $c.Source --version 2>&1 | Out-String); if($v -match 'Python 3\.(1[0-9]|[2-9][0-9])'){return $c.Source} } catch {}} }
  foreach($dir in @((Join-Path $env:LOCALAPPDATA 'Programs\Python'),(Join-Path $env:ProgramFiles 'Python312'))){if(Test-Path $dir){$candidate=Get-ChildItem $dir -Filter python.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1;if($candidate){return $candidate.FullName}}}
  return $null
}
function Detect {
  $py=Locate-Python; $ollama=$null; $o=Get-Command 'ollama' -ErrorAction SilentlyContinue; if($o){$ollama=$o.Source}
  if(-not $ollama){$ollama=Ollama-Exe}
  $alive=$false; $models=@()
  try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2; $alive=$true; $models=@($r.models | ForEach-Object {$_.name}) } catch {}
  if($script:status){$script:status.Text="Python: $(if($py){'найден'}else{'не найден'})   |   Ollama: $(if($alive){'ONLINE'}elseif($ollama){'установлен, OFFLINE'}else{'не найден'})   |   Моделей: $($models.Count)"
  }
  Write-Log "Диагностика: Python=$([bool]$py), Ollama=$alive, Models=$($models.Count), App=$([bool](Test-Path (Join-Path $app 'server.py')))"
}
function Install-Tool([string]$id,[string]$label){
  if(-not (Get-Command winget -ErrorAction SilentlyContinue)){ Write-Log 'winget отсутствует. Открой Microsoft App Installer из Store.'; return }
  if(-not (Confirm "Установить $label через официальный каталог winget? Будет скачано ПО из интернета; возможны запросы Windows.")){return}
  Write-Log "Запуск winget install $id в отдельном окне"; Start-Process -FilePath 'cmd.exe' -ArgumentList @('/k','winget install --id '+$id+' -e --source winget --accept-package-agreements --accept-source-agreements'); Write-Log 'Дождись завершения установки в открытом окне, затем нажми ОБНОВИТЬ.'
}
function Install-App {
  $src=Join-Path $base 'NOX_APP_R9.zip'
  if(-not (Test-Path $src)){Write-Log 'Нет встроенного архива приложения.';return}
  if(Test-Path $app){if(-not (Confirm 'Обновить файлы приложения? База диалогов будет сохранена; исходники будут скопированы поверх.')){return}}
  New-Item -ItemType Directory -Force -Path $app | Out-Null
  $backup=Join-Path $base 'backup'
  if(Test-Path (Join-Path $app 'nox.sqlite3')) {New-Item -ItemType Directory -Force -Path $backup|Out-Null; Copy-Item (Join-Path $app 'nox.sqlite3') (Join-Path $backup ('nox-'+(Get-Date -Format yyyyMMddHHmmss)+'.sqlite3'))}
  Expand-Archive -LiteralPath $src -DestinationPath $app -Force
  Write-Log 'NOX R9 установлен локально; это кандидат сборки, не принятый релиз.'
}
function Start-App {
  $py=Locate-Python
  if(-not $py){Write-Log 'Нужен Python 3.10+; используй кнопку установки.';return}
  if(-not (Test-Path (Join-Path $app 'server.py'))){Write-Log 'Сначала нажми Установить NOX.';return}
  $tokenfile=Join-Path $base 'token.txt'
  if(-not (Test-Path $tokenfile)){$token=([guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N'));Set-Content -LiteralPath $tokenfile -Value $token -NoNewline -Encoding ASCII}
  $token=(Get-Content -LiteralPath $tokenfile -Raw).Trim()
  $env:NOX_G02_AUTH_TOKEN=$token
  $env:NOX_PORT='8765'
  $env:NOX_OLLAMA='http://127.0.0.1:11434'
  $already=Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue
  if($already){Write-Log 'Порт 8765 уже занят. Не запускаю второй экземпляр.';return}
  $out=Join-Path $logdir 'server-out.log';$err=Join-Path $logdir 'server-err.log'
  $p=Start-Process -FilePath $py -ArgumentList @('server.py') -WorkingDirectory $app -PassThru -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err
  Set-Content -LiteralPath (Join-Path $base 'server.pid') -Value $p.Id
  Write-Log "NOX server запущен, PID=$($p.Id), адрес http://127.0.0.1:8765"
}
function Stop-App {
  $pidfile=Join-Path $base 'server.pid';if(-not(Test-Path $pidfile)){Write-Log 'PID-файл отсутствует.';return}
  $serverId=[int](Get-Content $pidfile -Raw)
  $p=Get-Process -Id $serverId -ErrorAction SilentlyContinue
  if($p -and $p.ProcessName -match 'python|py'){Stop-Process -Id $serverId -Force;Write-Log "Остановлен сервер PID=$serverId"} else {Write-Log 'Процесс уже завершён или PID принадлежит другой программе.'}
  Remove-Item $pidfile -ErrorAction SilentlyContinue
}
function Run-Tests {
  $py=Locate-Python;if(-not $py){Write-Log 'Python не найден';return}
  if(-not (Test-Path $app)){Write-Log 'Сначала установи NOX';return}
  Write-Log 'Выполняю локальные unit tests; они не заменяют WEB acceptance.'
  $testlog=Join-Path $logdir 'tests.txt'
  $cmd="Set-Location -LiteralPath '$($app.Replace("'","''"))'; & '$($py.Replace("'","''"))' -m unittest discover -v *>&1 | Out-File -LiteralPath '$($testlog.Replace("'","''"))' -Encoding utf8"
  & powershell.exe -NoProfile -Command $cmd
  if(Test-Path $testlog){Write-Log ((Get-Content $testlog -Tail 3) -join ' | ')}
}
. (Join-Path $base 'ai_lab_v4.ps1')
# CINEMATIC CONTROL — approved HOME/MENU/CORE images extracted from bundled source
[System.Windows.Forms.Application]::EnableVisualStyles()
$gold=[System.Drawing.Color]::FromArgb(223,166,79)
$bg=[System.Drawing.Color]::FromArgb(8,10,14)
$panel=[System.Drawing.Color]::FromArgb(19,21,26)
$muted=[System.Drawing.Color]::FromArgb(151,160,168)

$preview=@{}
function Load-Assets {
 $z=Join-Path $base 'NOX_APP_R9.zip'
 if(-not(Test-Path $z)){Write-Log 'SOURCE_HOLD: no embedded approved assets';return}
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $folder=Join-Path $base 'preview';New-Item -ItemType Directory -Force -Path $folder|Out-Null
 $arc=[System.IO.Compression.ZipFile]::OpenRead($z)
 try {foreach($n in @('home','menu','core01')){
   $e=$arc.GetEntry('assets/'+$n+'.png')
   if($e){$target=Join-Path $folder ($n+'.png');$stream=$e.Open();$file=[System.IO.File]::Create($target)
    try{$stream.CopyTo($file)}finally{$stream.Dispose();$file.Dispose()};$preview[$n]=$target}
 }}finally{$arc.Dispose()}
}
function Show-Report {
 $d=Join-Path $base 'reports';New-Item -ItemType Directory -Force -Path $d|Out-Null
 $report=Join-Path $d 'REPORT_GATE.txt'
 @('NOX HELION WEB','Accepted progress: N/D','VERIFIED/540: not independently measured','DEMO/RELEASE: BLOCKED','10 groups weights: 12,12,9,15,8,11,12,7,9,5') | Set-Content -LiteralPath $report -Encoding UTF8
 Start-Process notepad.exe -ArgumentList ('"'+$report+'"')
 Write-Log ('Отчёт: '+$report)
}
