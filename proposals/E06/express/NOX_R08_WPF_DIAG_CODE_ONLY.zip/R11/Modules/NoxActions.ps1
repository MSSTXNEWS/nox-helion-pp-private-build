﻿param([ValidateSet('check','install','start','stop','open')][string]$Action='check')
$ErrorActionPreference='Stop'
# Installer-only module: no WEB release acceptance implied.

$base=Join-Path $env:LOCALAPPDATA 'NOX_HELION_Integrator'
$app=Join-Path $base 'app'
$logs=Join-Path $base 'logs'
New-Item -ItemType Directory -Force -Path $logs | Out-Null
function Log([string]$msg) { Add-Content -LiteralPath (Join-Path $logs 'native-actions.log') -Value ('['+(Get-Date -Format o)+'] '+$msg) }
function FindPython {
  foreach($n in @('python.exe','py.exe')) {
    $c=Get-Command $n -ErrorAction SilentlyContinue
    if($c){ try { $v=(& $c.Source --version 2>&1 | Out-String); if($v -match '^Python 3\.(1[0-9]|[2-9][0-9])') {return $c.Source} } catch {} }
  }
  return $null
}
try {
 switch($Action){
 'check' {
   $py=FindPython
   $o=Get-Command ollama.exe -ErrorAction SilentlyContinue
   $ready=$false
   try{$response=Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2;$ready=$true}catch{}
   $state=@{python=($null -ne $py);ollamaInstalled=($null -ne $o);ollamaReady=$ready;appInstalled=(Test-Path (Join-Path $app 'server.py'))}
   $state | ConvertTo-Json -Compress; Log ('CHECK '+($state | ConvertTo-Json -Compress))
 }
 'install' {
   $archive=Join-Path $PSScriptRoot 'NOX_APP_R9.zip'
   if(-not(Test-Path $archive)){throw 'Approved source package missing'}
   $temp=Join-Path $base ('stage-'+[guid]::NewGuid().ToString('N'))
   New-Item -ItemType Directory -Force -Path $temp | Out-Null
   try {
     Expand-Archive -LiteralPath $archive -DestinationPath $temp -Force
     if(-not(Test-Path (Join-Path $temp 'server.py'))){throw 'server.py not found in source package'}
     if(Test-Path $app){$backup=Join-Path $base ('backup-'+(Get-Date -Format yyyyMMddHHmmss));Copy-Item -LiteralPath $app -Destination $backup -Recurse -Force}
     New-Item -ItemType Directory -Force -Path $app | Out-Null
     Copy-Item -Path (Join-Path $temp '*') -Destination $app -Recurse -Force
     Log 'INSTALL success';'Installed NOX source locally'
   } finally {Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue}
 }
 'start' {
   $py=FindPython;if(-not $py){throw 'Python 3.10+ not found'}
   if(-not(Test-Path (Join-Path $app 'server.py'))){throw 'Install NOX first'}
   $tokenfile=Join-Path $base 'token.txt'
   if(-not(Test-Path $tokenfile)){[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N') | Set-Content -LiteralPath $tokenfile -Encoding Ascii}
   $env:NOX_G02_AUTH_TOKEN=(Get-Content -LiteralPath $tokenfile -Raw).Trim()
   $env:NOX_PORT='8765';$env:NOX_OLLAMA='http://127.0.0.1:11434'
   $port=Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue
   if($port){throw 'Port 8765 already in use; refusing duplicate start'}
   $p=Start-Process -FilePath $py -ArgumentList @('server.py') -WorkingDirectory $app -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'server-out.log') -RedirectStandardError (Join-Path $logs 'server-err.log')
   $p.Id | Set-Content -LiteralPath (Join-Path $base 'server.pid')
   $ready=$false
   for($attempt=0;$attempt -lt 15;$attempt++) {
     Start-Sleep -Milliseconds 500
     if($p.HasExited){break}
     try { $response=Invoke-WebRequest -Uri 'http://127.0.0.1:8765/' -UseBasicParsing -TimeoutSec 2; if($response.StatusCode -eq 200){$ready=$true;break} } catch {}
   }
   if(-not $ready) {Log 'START health check FAILED';throw 'NOX server did not become ready; inspect server-err.log'}
   Log ('START_READY pid='+$p.Id);'Started NOX server, health check PASS, pid='+$p.Id
 }
 'stop' {
   $pidfile=Join-Path $base 'server.pid';if(-not(Test-Path $pidfile)){throw 'No managed server PID'}
   $serverId=[int](Get-Content -LiteralPath $pidfile -Raw)
   $p=Get-Process -Id $serverId -ErrorAction SilentlyContinue
   if($p -and $p.ProcessName -match '^python(w)?$'){Stop-Process -Id $serverId -Force;Log ('STOP pid='+$serverId)} else {Log 'STOP process absent or PID reused'}
   Remove-Item -LiteralPath $pidfile -Force -ErrorAction SilentlyContinue;'Stopped managed NOX process'
 }
 'open' {
   $url='http://127.0.0.1:8765/'
   try{Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 3 | Out-Null}catch{throw 'NOX server not responding'}
   Start-Process $url;Log 'OPEN_WEB';'Opened local NOX web'
 }
 }
} catch { Log ('ERROR '+$Action+' '+$_.Exception.Message); [Console]::Error.WriteLine($_.Exception.Message);exit 1 }
