﻿# NOX AI LAB V3 - opt-in tools, no automatic downloads or weight-training claims
$models=@(
 @{tag='qwen3:0.6b';title='Qwen3 0.6B'},
 @{tag='qwen3:1.7b';title='Qwen3 1.7B'},
 @{tag='qwen3:4b';title='Qwen3 4B'},
 @{tag='llama3.2:1b';title='Llama 3.2 1B'},
 @{tag='llama3.2:3b';title='Llama 3.2 3B'},
 @{tag='gemma3:1b';title='Gemma3 1B'},
 @{tag='qwen3:8b';title='Qwen3 8B'},
 @{tag='qwen3:14b';title='Qwen3 14B'},
 @{tag='deepseek-r1:1.5b';title='DeepSeek R1 1.5B'},
 @{tag='deepseek-r1:7b';title='DeepSeek R1 7B'},
 @{tag='deepseek-r1:14b';title='DeepSeek R1 14B'},
 @{tag='phi4:14b';title='Phi4 14B'},
 @{tag='mistral:7b';title='Mistral 7B'},
 @{tag='qwen2.5-coder:3b';title='Coder 3B'},
 @{tag='qwen2.5-coder:7b';title='Coder 7B'},
 @{tag='starcoder2:3b';title='StarCoder2 3B'},
 @{tag='gemma3:4b';title='Gemma3 4B'},
 @{tag='llava:7b';title='LLaVA 7B'},
 @{tag='qwen2.5vl:3b';title='Qwen VL 3B'},
 @{tag='nomic-embed-text';title='Nomic'},
 @{tag='mxbai-embed-large';title='MxBAI'},
 @{tag='all-minilm';title='MiniLM'},
 @{tag='bge-m3';title='BGE-M3'},
 @{tag='embeddinggemma';title='EmbeddingGemma'}
)

function Ollama-Exe {
 $o=Get-Command ollama -ErrorAction SilentlyContinue
 if($o){return $o.Source}
 foreach($p in @((Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),(Join-Path $env:ProgramFiles 'Ollama\ollama.exe'))){if(Test-Path $p){return $p}}
 return $null
}
function Get-Gpu {
    $cmd = Get-Command 'nvidia-smi' -ErrorAction SilentlyContinue
    if ($null -eq $cmd) {
        return @{available=$false;reason='nvidia-smi not found';data=@()}
    }
    try {
        $args = @('--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu','--format=csv,noheader,nounits')
        $lines = @(& $cmd.Source @args 2>&1)
        if ($LASTEXITCODE -ne 0) {
            return @{available=$false;reason='nvidia-smi returned an error';data=@()}
        }
        return @{available=$true;reason='';data=$lines}
    }
    catch {
        return @{available=$false;reason=$_.Exception.Message;data=@()}
    }
}
function Update-Local {
 $inventory=Join-Path $base 'inventory';New-Item -ItemType Directory -Force $inventory|Out-Null
 $folder=Join-Path $env:USERPROFILE 'Downloads';$ext=@('.gguf','.safetensors','.onnx','.zip','.pt','.pth','.json')
 $found=@();if(Test-Path $folder){$found=@(Get-ChildItem $folder -File -ErrorAction SilentlyContinue | Where-Object {$_.Extension.ToLowerInvariant() -in $ext} | ForEach-Object {@{name=$_.Name;path=$_.FullName;size=$_.Length;status='DISCOVERED_NOT_MOVED'}})}
 $installed=@();try{$installed=@((Invoke-RestMethod 'http://127.0.0.1:11434/api/tags' -TimeoutSec 3).models|ForEach-Object{$_.name})}catch{}
 $report=@{time=(Get-Date -Format s);download_candidates=$found;installed_models=$installed;gpu=(Get-Gpu);note='No files moved or executed; manual review required.'}
 $target=Join-Path $inventory 'inventory.json';$report|ConvertTo-Json -Depth 7|Set-Content -LiteralPath $target -Encoding UTF8
 Write-Log ('Обновление: '+$found.Count+' файлов в Downloads, '+$installed.Count+' моделей Ollama. Манифест: '+$target)
 Detect
}
function Pull-Official([string]$tag){
 if($tag -notin @($models|ForEach-Object{$_.tag})){Write-Log 'Неизвестный тег';return}
 $ollama=Ollama-Exe;if(-not $ollama){Write-Log 'Ollama отсутствует. Установи Ollama.';return}
 if(-not(Confirm "Скачать модель $tag из Ollama? Это может занять несколько гигабайт.")){return}
 $command='"'+$ollama+'" pull '+$tag
 Start-Process cmd.exe -ArgumentList @('/k',$command)|Out-Null
 Write-Log ('Открыта загрузка '+$tag+' в отдельном окне. После загрузки нажми ОБНОВИТЬ.')
}
function Start-Knowledge {
 $py=Locate-Python;if(-not $py){Write-Log 'Нужен Python';return}
 $gpu=Get-Gpu;if(-not $gpu.available){Write-Log 'GPU HOLD: нет NVIDIA телеметрии; GPU-задание не запущено.';return}
 $installed=@();try{$installed=@((Invoke-RestMethod 'http://127.0.0.1:11434/api/tags' -TimeoutSec 3).models|ForEach-Object{$_.name})}catch{}
 if('nomic-embed-text' -notin $installed){Write-Log 'Скачай nomic-embed-text и запусти Ollama.';return}
 $pick=New-Object System.Windows.Forms.FolderBrowserDialog;$pick.Description='Выбери папку с разрешёнными для индексации документами'
 if($pick.ShowDialog() -ne 'OK'){return}
 if(-not(Confirm ('Индексировать '+$pick.SelectedPath+' в фоне? Это RAG/память, НЕ изменение весов. Порог паузы GPU 60%, VRAM 65%, гарантия абсолютных 70% невозможна.'))){return}
 $dir=Join-Path $base 'learning';New-Item -ItemType Directory -Force $dir|Out-Null
 $worker=Join-Path $base 'nox_learning_worker.py';if(-not(Test-Path $worker)){Write-Log 'Worker отсутствует';return}
 $args='"'+$worker+'" --base "'+$dir+'" --source "'+$pick.SelectedPath+'"'
 $p=Start-Process -FilePath $py -ArgumentList $args -WindowStyle Hidden -PassThru
 Set-Content (Join-Path $dir 'worker.pid') $p.Id
 Write-Log ('Начата фоновая индексация PID='+$p.Id+'; смотри learning.jsonl.')
}
function Stop-Knowledge {
 $dir=Join-Path $base 'learning';New-Item -ItemType Directory -Force $dir|Out-Null
 Set-Content (Join-Path $dir 'STOP_LEARNING') 'STOP'
 Write-Log 'Запрошена безопасная остановка после текущего фрагмента.'
}

function Organize-Downloads {
 $download=Join-Path $env:USERPROFILE 'Downloads'
 if(-not(Test-Path $download)){Write-Log 'Downloads отсутствует';return}
 $dest=Join-Path $base 'imported';$allowed=@{'.gguf'='GGUF';'.safetensors'='WEIGHTS';'.onnx'='ONNX';'.zip'='ARCHIVES';'.json'='MANIFESTS'}
 $files=@(Get-ChildItem -LiteralPath $download -File -ErrorAction SilentlyContinue|Where-Object{$allowed.ContainsKey($_.Extension.ToLowerInvariant())})
 if(-not $files.Count){Write-Log 'Нет подходящих файлов для импорта';return}
 if(-not(Confirm "Скопировать $($files.Count) найденных файлов из Downloads в локальные папки NOX? Исходные файлы останутся на месте; исполняемые файлы не запускаются.")){return}
 $copied=0
 foreach($f in $files){
  $sub=$allowed[$f.Extension.ToLowerInvariant()];$dir=Join-Path $dest $sub;New-Item -ItemType Directory -Force $dir|Out-Null
  $target=Join-Path $dir $f.Name
  if(Test-Path $target){Write-Log ('Пропуск: '+$f.Name+' уже существует');continue}
  try{Copy-Item -LiteralPath $f.FullName -Destination $target -ErrorAction Stop;$copied++}
  catch{Write-Log ('Ошибка копирования '+$f.Name+': '+$_.Exception.Message)}
 }
 Write-Log ('Импортировано '+$copied+' файлов; оригиналы сохранены. Модели GGUF не устанавливаются автоматически.')
 Update-Local
}

function Open-AILab {
 $win=New-Object System.Windows.Forms.Form;$win.Text='NOX HELION · MODEL HUB / AI LAB';$win.Size=New-Object System.Drawing.Size(890,720);$win.StartPosition='CenterParent';$win.BackColor=$bg;$win.ForeColor=[System.Drawing.Color]::White
 $h=New-Object System.Windows.Forms.Label;$h.Text='NOX  /  AI MODEL HUB';$h.Font=New-Object System.Drawing.Font('Segoe UI',18,[System.Drawing.FontStyle]::Bold);$h.ForeColor=$gold;$h.SetBounds(24,18,830,44);$win.Controls.Add($h)
 $sub=New-Object System.Windows.Forms.Label;$sub.Text='Публичные модели Ollama. Загрузка по выбору; после установки нажми ОБНОВИТЬ.';$sub.SetBounds(24,68,820,30);$win.Controls.Add($sub)
 $y=110
 foreach($m in $models){
   $lbl=New-Object System.Windows.Forms.Label;$lbl.Text=$m.title+'    ['+$m.tag+']';$lbl.SetBounds(25,$y+8,575,28);$win.Controls.Add($lbl)
   $btn=New-Object System.Windows.Forms.Button;$btn.Text='СКАЧАТЬ';$btn.SetBounds(630,$y,200,37);$btn.FlatStyle='Flat';$btn.BackColor=$panel;$btn.ForeColor=$gold
   $tag=$m.tag;$btn.Add_Click({Pull-Official $tag}.GetNewClosure());$win.Controls.Add($btn);$y+=55
 }
 $actions=@(
  @{title='ОБНОВИТЬ / НАЙТИ';act={Update-Local}},
  @{title='GPU ДИАГНОСТИКА';act={Write-Log ((Get-Gpu)|ConvertTo-Json -Compress)}},
  @{title='НАЧАТЬ ПАМЯТЬ';act={Start-Knowledge}},
  @{title='STOP ОБУЧЕНИЯ';act={Stop-Knowledge}},
  @{title='РАЗЛОЖИТЬ ФАЙЛЫ';act={Organize-Downloads}},
  @{title='LoRA / ИНСТРУКЦИИ';act={Start-Process 'https://huggingface.co/docs/peft/quicktour'}}
 )
 for($i=0;$i -lt $actions.Count;$i++){
   $a=$actions[$i];$b=New-Object System.Windows.Forms.Button;$b.Text=$a.title;$b.SetBounds((25+($i%3)*273),(466+[math]::Floor($i/3)*53),250,43);$b.FlatStyle='Flat';$b.BackColor=$panel;$b.ForeColor=$gold;$act=$a.act;$b.Add_Click({try{& $act}catch{Write-Log ('Ошибка AI LAB: '+$_.Exception.Message)}}.GetNewClosure());$win.Controls.Add($b)
 }
 $foot=New-Object System.Windows.Forms.Label;$foot.Text='Индексация = память, не LoRA. NVIDIA guard: пауза при >60% GPU, >65% VRAM; абсолютный лимит мощности не гарантирован.';$foot.SetBounds(25,594,825,55);$foot.ForeColor=$muted;$win.Controls.Add($foot)
 [void]$win.ShowDialog($form)
}
