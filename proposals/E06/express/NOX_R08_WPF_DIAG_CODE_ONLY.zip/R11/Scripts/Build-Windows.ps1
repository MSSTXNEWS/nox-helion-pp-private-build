$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
$report=Join-Path (Get-Location) 'WINDOWS_BUILD_RESULT.txt'
try {
  if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Missing .NET 8 SDK' }
  dotnet restore .\NOX.P01.Shell.csproj
  if ($LASTEXITCODE -ne 0) { throw 'dotnet restore failed' }
  dotnet build .\NOX.P01.Shell.csproj -c Release --no-restore
  if ($LASTEXITCODE -ne 0) { throw 'dotnet build failed' }
  ('BUILD_OK '+(Get-Date -Format o)) | Set-Content $report
  Write-Host 'BUILD_OK; still requires Windows visual/functional acceptance.'
} catch {
  ('BUILD_FAILED '+(Get-Date -Format o)+' '+$_) | Set-Content $report
  Write-Error $_
  exit 1
}
