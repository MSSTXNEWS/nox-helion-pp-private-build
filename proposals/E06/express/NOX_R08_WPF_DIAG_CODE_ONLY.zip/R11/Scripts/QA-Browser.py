import json
from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
root=Path(__file__).resolve().parents[1]
results=[]
html=(root/'Assets/index.html').read_text(encoding='utf-8')
for asset in ('home.png','menu.png','core01.png','menu_sections.png'):
    data='data:image/png;base64,'+base64.b64encode((root/'Assets'/asset).read_bytes()).decode()
    html=html.replace(asset,data)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
 for w,h in [(1920,1080),(1440,900),(1280,720),(800,600),(760,520),(390,844)]:
  page=b.new_page(viewport={'width':w,'height':h}, device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load');page.wait_for_timeout(100)
  nav=page.locator('[data-screen]');assert nav.count()==4
  for name in ['home','menu','core','status']:
   page.locator('[data-screen="'+name+'"]').click()
   assert page.locator('#'+name).evaluate('(el)=>el.classList.contains("active")')
  buttons=page.locator('#tiles button');assert buttons.count()==8
  images=page.locator('img');all_images=all(images.nth(i).evaluate('(e)=>e.complete && e.naturalWidth>0') for i in range(images.count()))
  overflow=page.evaluate('document.documentElement.scrollWidth > window.innerWidth')
  page.locator('#native-diagnostics').click();fallback='нативный WebView2 не запущен' in page.locator('#hostmessage').inner_text()
  results.append({'viewport':f'{w}x{h}','navigation':'PASS','images':'PASS' if all_images else 'FAIL','horizontal_overflow':overflow,'menu_enabled':sum(not buttons.nth(i).is_disabled() for i in range(8)),'host_fallback':'PASS' if fallback else 'FAIL','js_errors':errors})
  page.close()
 b.close()
(root/'QA_BROWSER_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
