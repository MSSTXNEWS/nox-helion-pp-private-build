$ErrorActionPreference='Continue'
$root=Split-Path $PSScriptRoot -Parent
$logs=Join-Path $env:LOCALAPPDATA 'NOX_HELION\P01\logs\shell.log'
$results=[ordered]@{ timestamp=(Get-Date).ToString('o'); dotnet_sdk=($null -ne (Get-Command dotnet -ErrorAction SilentlyContinue)); source_html=(Test-Path (Join-Path $root 'Assets\index.html')); assets=@{}; log_exists=(Test-Path $logs); webview2_runtime='NOT_TESTED'; dpi_100_200='NOT_TESTED'; keyboard='NOT_TESTED'; product_gate='BLOCKED' }
foreach($name in @('home.png','menu.png','core01.png','menu_sections.png')){$results.assets[$name]=(Test-Path (Join-Path $root ('Assets\'+$name)))}
$path=Join-Path $root 'WINDOWS_PRECHECK.json'
$results | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $path -Encoding UTF8
Write-Host "Saved $path"; Read-Host 'Press Enter' | Out-Null
