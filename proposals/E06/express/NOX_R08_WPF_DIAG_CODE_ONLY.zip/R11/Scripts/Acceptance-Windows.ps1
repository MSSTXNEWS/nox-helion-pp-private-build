﻿# NOX P01 Windows acceptance runner: never marks owner approval automatically.
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$report = Join-Path $root 'P01_WINDOWS_ACCEPTANCE.json'
$checks = [ordered]@{ utc=(Get-Date).ToString('o'); source_hashes='PENDING'; restore='NOT_RUN'; build='NOT_RUN'; exe_launch='MANUAL_HOLD'; webview2='MANUAL_HOLD'; dpi_100='MANUAL_HOLD'; dpi_125='MANUAL_HOLD'; dpi_150='MANUAL_HOLD'; dpi_200='MANUAL_HOLD'; fullscreen_f11='MANUAL_HOLD'; escape_restore='MANUAL_HOLD'; menu_visual_parity='INDEPENDENT_HOLD'; installer_handlers='PRESENT_UNVERIFIED'; accepted_progress=$null; release_allowed=$false }
try {
  $manifest = Get-Content (Join-Path $root 'SOURCE_MANIFEST_SHA256.json') -Raw | ConvertFrom-Json
  $assets = @('home.png','menu.png','core01.png','menu_sections.png')
  foreach ($a in $assets) { if (-not (Test-Path (Join-Path $root ('Assets\'+$a)))) { throw ('Missing asset: '+$a) } }
  $assetHashes = [ordered]@{}
  foreach ($a in $assets) {
    $assetHashes[$a] = (Get-FileHash -LiteralPath (Join-Path $root ('Assets\'+$a)) -Algorithm SHA256).Hash.ToLowerInvariant()
  }
  $checks.asset_sha256 = $assetHashes
  $checks.source_hashes='RECORDED_UNVERIFIED_CANON'
  if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Missing dotnet SDK: install .NET 8 SDK' }
  & dotnet restore (Join-Path $root 'NOX.P01.Shell.csproj') 2>&1 | Out-File (Join-Path $root 'P01_RESTORE.log')
  if ($LASTEXITCODE -ne 0) { throw 'dotnet restore failed' }
  $checks.restore='PASS'
  & dotnet build (Join-Path $root 'NOX.P01.Shell.csproj') -c Release --no-restore 2>&1 | Out-File (Join-Path $root 'P01_BUILD.log')
  if ($LASTEXITCODE -ne 0) { throw 'dotnet build failed' }
  $checks.build='PASS'
  $checks.install_module_present = (Test-Path (Join-Path $root 'Modules\NoxActions.ps1'))
  $checks.approved_source_archive_present = (Test-Path (Join-Path $root 'Modules\NOX_APP_R9.zip'))
  if (-not $checks.install_module_present -or -not $checks.approved_source_archive_present) { throw 'Installer modules missing' }
  $checks.installer_handlers='SOURCE_PRESENT_WINDOWS_RUNTIME_HOLD'
  $checks.native_runtime='MANUAL_HOLD'
  $checks.release_allowed=$false
  $checks.approved_source_archive_present = (Test-Path (Join-Path $root 'Modules\NOX_APP_R9.zip'))
} catch { $checks.error=$_.ToString() }
$checks | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $report -Encoding UTF8
Write-Host "Saved $report; PRODUCT GATE remains BLOCKED until independent Windows acceptance."
