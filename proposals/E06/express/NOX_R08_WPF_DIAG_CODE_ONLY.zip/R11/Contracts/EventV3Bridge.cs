using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using NOX.P01.ModelCenter;

namespace NoxP01;

public sealed record InstallerEventV3(
    [property: JsonPropertyName("schema")] string Schema,
    [property: JsonPropertyName("run_id")] string RunId,
    [property: JsonPropertyName("event_id")] string EventId,
    [property: JsonPropertyName("event_type")] string EventType,
    [property: JsonPropertyName("task_id")] string TaskId,
    [property: JsonPropertyName("package_id")] string PackageId,
    [property: JsonPropertyName("action_id")] string ActionId,
    [property: JsonPropertyName("timestamp_utc")] DateTimeOffset TimestampUtc,
    [property: JsonPropertyName("state")] string State,
    [property: JsonPropertyName("source")] string Source,
    [property: JsonPropertyName("message")] string Message,
    [property: JsonPropertyName("numerator")] long? Numerator,
    [property: JsonPropertyName("denominator")] long? Denominator,
    [property: JsonPropertyName("evidence_verified")] bool EvidenceVerified);

public sealed record EventV3PublishResult(InstallerEventV3 Event, bool JournalWritten);

/// <summary>
/// Append-only bridge from P03's local event hub to the shared V3 envelope.
/// This bridge records runtime activity; it never promotes that activity to
/// package acceptance or an independently verified receipt.
/// </summary>
public sealed class EventV3Bridge
{
    private const string Schema = "NOX-INSTALLER-EVENT-v3";
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    private static readonly Regex SecretPattern = new(
        @"(?i)(token|password|secret|api[_-]?key|authorization)\s*[:=]\s*[^\s]+",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private static readonly Regex WindowsPathPattern = new(
        "(?<![A-Za-z0-9])[A-Za-z]:\\\\[^\\s<>\\\"']+",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private static readonly Regex UrlPattern = new(
        "https?://[^\\s<>\\\"']+",
        RegexOptions.Compiled | RegexOptions.CultureInvariant | RegexOptions.IgnoreCase);

    // Shared process-wide with the host writer because both append to the same journal file.
    public static object ProcessJournalLock { get; } = new();
    private static readonly Mutex CrossProcessJournalMutex = new(false, @"Local\NOX_HELION_EVENTS_V3_JOURNAL");
    private readonly string _journalPath;

    public EventV3Bridge(string dataDirectory, string? runId = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(dataDirectory);
        RunId = string.IsNullOrWhiteSpace(runId) ? Guid.NewGuid().ToString("N") : runId;
        _journalPath = Path.Combine(dataDirectory, "logs", "events.v3.jsonl");
    }

    public string RunId { get; }
    public string JournalPath => _journalPath;

    public static void WithJournalLock(Action write)
    {
        ArgumentNullException.ThrowIfNull(write);
        lock (ProcessJournalLock)
        {
            var acquired = false;
            try
            {
                try { acquired = CrossProcessJournalMutex.WaitOne(TimeSpan.FromSeconds(15)); }
                catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) throw new TimeoutException("Timed out waiting for the shared events.v3 journal mutex.");
                write();
            }
            finally
            {
                if (acquired) CrossProcessJournalMutex.ReleaseMutex();
            }
        }
    }

    public EventV3PublishResult PublishModelCenter(ModelCenterEvent sourceEvent)
    {
        ArgumentNullException.ThrowIfNull(sourceEvent);

        var (eventType, state) = Map(sourceEvent.Kind);
        var total = sourceEvent.BytesTotal is > 0 ? sourceEvent.BytesTotal : null;
        var completed = total.HasValue && sourceEvent.BytesCompleted is >= 0
            ? Math.Min(sourceEvent.BytesCompleted.Value, total.Value)
            : null;
        var payload = new InstallerEventV3(
            Schema,
            RunId,
            sourceEvent.EventId == Guid.Empty ? Guid.NewGuid().ToString("N") : sourceEvent.EventId.ToString("N"),
            eventType,
            string.IsNullOrWhiteSpace(sourceEvent.OperationId)
                ? (sourceEvent.EventId == Guid.Empty ? "P03-" + Guid.NewGuid().ToString("N") : "P03-" + sourceEvent.EventId.ToString("N"))
                : "P03-" + Regex.Replace(sourceEvent.OperationId, "[^A-Za-z0-9_.-]", "_")[..Math.Min(96, sourceEvent.OperationId.Length)],
            "P03",
            ToSnakeCase(sourceEvent.Kind.ToString()),
            sourceEvent.TimestampUtc.ToUniversalTime(),
            state,
            "P03.ModelCenter",
            SafeMessage(sourceEvent.Message, sourceEvent.Kind, state),
            completed,
            total,
            EvidenceVerified: false);

        return Append(payload);
    }

    private EventV3PublishResult Append(InstallerEventV3 payload)
    {
        try
        {
            var line = JsonSerializer.Serialize(payload, JsonOptions) + "\n";
            WithJournalLock(() =>
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_journalPath)!);
                using var stream = new FileStream(_journalPath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
                using var writer = new StreamWriter(stream, new UTF8Encoding(false));
                writer.Write(line);
                writer.Flush();
                stream.Flush(flushToDisk: true);
            });
            return new EventV3PublishResult(payload, JournalWritten: true);
        }
        catch
        {
            return new EventV3PublishResult(payload, JournalWritten: false);
        }
    }

    private static (string EventType, string State) Map(ModelCenterEventKind kind) => kind switch
    {
        ModelCenterEventKind.DownloadQueued => ("task.started", "QUEUED"),
        ModelCenterEventKind.InstallStarted or ModelCenterEventKind.UpdateStarted or
        ModelCenterEventKind.RemoveStarted or ModelCenterEventKind.FileScanStarted or
        ModelCenterEventKind.FileImportStarted or ModelCenterEventKind.BackupStarted or
        ModelCenterEventKind.RestoreStarted => ("task.started", "RUNNING"),
        ModelCenterEventKind.DownloadProgress or ModelCenterEventKind.ComponentProgress or
        ModelCenterEventKind.InstallOutput or
        ModelCenterEventKind.FileScanProgress or ModelCenterEventKind.BackupProgress or
        ModelCenterEventKind.RestoreProgress => ("task.progress", "RUNNING"),
        ModelCenterEventKind.DownloadPaused => ("task.progress", "PAUSED"),
        ModelCenterEventKind.DownloadResumed => ("task.progress", "QUEUED"),
        ModelCenterEventKind.DownloadRetry => ("task.started", "QUEUED"),
        // This confirms the local pull task stopped; Ollama's remote model state is unknown.
        ModelCenterEventKind.DownloadCancelled => ("task.progress", "STOPPED"),
        ModelCenterEventKind.FileScanCancelled => ("task.failed", "STOPPED"),
        ModelCenterEventKind.FileImportBlocked => ("task.failed", "HOLD"),
        ModelCenterEventKind.DownloadFailed or ModelCenterEventKind.InstallFailed or
        ModelCenterEventKind.FileImportFailed or ModelCenterEventKind.Error => ("task.failed", "ERROR"),
        ModelCenterEventKind.SystemProbe or ModelCenterEventKind.ComponentDetected => ("task.completed", "COMPLETED"),
        ModelCenterEventKind.DownloadCompleted or ModelCenterEventKind.InstallCompleted or
        ModelCenterEventKind.UpdateCompleted or ModelCenterEventKind.RemoveCompleted or
        ModelCenterEventKind.FileScanCompleted or
        ModelCenterEventKind.FileImported or ModelCenterEventKind.BackupCompleted or
        ModelCenterEventKind.RestoreCompleted => ("task.completed", "COMPLETED"),
        ModelCenterEventKind.FileFound => ("task.progress", "RUNNING"),
        _ => ("task.progress", "N_D")
    };

    private static string SafeMessage(string? message, ModelCenterEventKind kind, string state)
    {
        var value = string.IsNullOrWhiteSpace(message) ? $"{kind}: {state}" : message.Trim();
        value = SecretPattern.Replace(value, "$1=[REDACTED]");
        value = WindowsPathPattern.Replace(value, "[LOCAL_PATH]");
        value = UrlPattern.Replace(value, "[URL]");
        value = Regex.Replace(value, @"[\r\n\t]+", " ").Trim();
        return value.Length <= 240 ? value : value[..240];
    }

    private static string ToSnakeCase(string value) =>
        Regex.Replace(value, "(?<!^)([A-Z])", "_$1").ToLowerInvariant();
}
