using System.Windows;
namespace NoxP01;
public partial class App : Application { }
