# R6 · P04 training intensity source delta

RunID: `NOX-EXE-SYNC-V12-CANON-V11-R6-P04-INTENSITY-20261026T192431Z`  
Base: R5 MANIFEST-FIX1 source ZIP `69867a0b1a2f23cfa68ec1de94f5d2bce3349e2531a1d2ebe9c382ddfa01152d`.

## Source changes

- Added an accessible range control to the existing QLoRA card. The control selects only `ECO`, `BALANCED`, or `INTENSIVE`, saves the value through the allowlisted WebView2 host action, restores it on startup, and is disabled during `RUNNING` or `STOP_REQUESTED`.
- The worker binds those presets to 20, 40, or 60 optimizer steps, with the existing 1024-token maximum and batch/gradient-accumulation settings retained. The control selects bounded training work; it does not cap GPU utilization or power.
- Added a selected-GPU temperature guard using its NVIDIA UUID. It fails closed when `nvidia-smi` returns invalid/unavailable data or times out, checks at preflight/evaluation boundaries and optimizer-step intervals, requests a checkpoint before a thermal HOLD, and skips post-STOP/HOLD GPU evaluation. The application policy threshold is 83°C; this is not an OEM temperature or power limit.
- Host status now preserves the worker's `COMPLETED`, `STOPPED`, and `HOLD` result rather than treating any successful process exit as completed training.
- No new third-party package, asset, menu route, or WEB/540 control was introduced. Approved artwork remains unchanged.

## External source and integration record

Temperature polling adapts NVIDIA System Management Interface selective queries: https://docs.nvidia.com/deploy/nvidia-smi/index.html . NVIDIA documents UUID selection and the `temperature.gpu` reading; it also notes that unsupported sensor output can be `N/A` and recommends NVML/Python bindings for longer-lived tooling. This candidate retains the existing process adapter and does not bundle NVIDIA software. Driver/CLI version, redistribution license, Windows compatibility, and live sensor behavior remain `N/D`/HOLD until Windows acceptance. No new dependency lockfile or installed integration is claimed.

## Verification

- Standard-library source suite: 20/20 PASS (P01–P05 source contracts plus focused P04 profile/thermal tests).
- Python syntax: PASS. Inline JavaScript syntax: PASS. HTML parser: PASS.
- .NET/Windows build, WebView2 runtime, screen-reader, actual GPU query, training, and same-EXE acceptance: NOT RUN.
- P01–P05 accepted readiness and weighted total: N/D. Product gate: HOLD. EXE release: BLOCKED.

## Remaining P04 gaps

The three profiles are workload presets, not measured GPU utilization targets. The 83°C policy has no per-device owner approval. RAG/embeddings, trusted consent-signature verification, safe pause/resume, independently hashed resumable checkpoints, before/after evaluation after STOP/HOLD, and approved adapter merge remain absent or unverified. PEFT/Transformers/CUDA pins still lack complete license/compatibility evidence and wheel-lock hashes.

## C6 registry correction

Independent registry audit found the legacy `I08.adapter_source_sha256` did not match any file in the frozen tree. It now points to `Packages/P04/train_qlora.py` and matches the already-recorded worker SHA. I08 remains `SOURCE_ONLY_HOLD`; this corrects provenance metadata only and does not claim Transformers runtime compatibility or training acceptance.
