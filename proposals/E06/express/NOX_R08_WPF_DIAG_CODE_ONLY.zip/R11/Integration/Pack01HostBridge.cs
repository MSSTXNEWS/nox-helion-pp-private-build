// NOX E06 R06: additive dispatch into the EXISTING WPF/WebView2 host only.
// Status is a handler dispatch or a real source read, NEVER release acceptance.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using NoxP01.WorkerCatalog;

namespace NoxP01;
public partial class MainWindow
{
    private static readonly HashSet<string> SupportedPack01NativeRoutes = new(StringComparer.Ordinal)
    {
        "chat.model", "chat.stop", "chat.history", "models.catalog",
        "models.installed", "models.queue", "models.preflight",
        "models.licenses", "models.digest", "gpu.preflight", "training.start",
        "training.checkpoints", "system.backup", "models.pull", "models.gguf.import",
        "models.cancel", "models.retry", "system.telemetry"
    };
    private static readonly HashSet<string> Pack01ChatRoutes = new(StringComparer.Ordinal)
        { "chat.model", "chat.stop", "chat.history" };
    private static readonly HashSet<string> Pack01NativeNavigationRoutes = new(StringComparer.Ordinal)
        { "models.pull", "models.gguf.import", "models.cancel", "models.retry" };

    private void SendPack01Capabilities()
    {
        var capabilities = new Dictionary<string, object>(StringComparer.Ordinal);
        foreach (var route in SupportedPack01NativeRoutes)
            capabilities[route] = new {
                state = "AVAILABLE_HOST_ACTION", source = "R11_EXISTING_WEBVIEW2_HOST",
                requiresNativeConsent = route is "chat.history" or "training.checkpoints" or "system.backup",
                dispatchKind = Pack01NativeNavigationRoutes.Contains(route) ? "OWNER_WINDOW" : "EXISTING_METHOD",
                accepted = false
            };
        PostMessage(new { kind = "packCapabilities", runId = "NOX-V16-E06-R06-20261028",
            routes = capabilities, releaseAccepted = false });
    }

    // Caller is HandleMessage, whose WebView2 e.Source already enforces https://nox.local.
    // Never accept arbitrary file paths, action names, commands, or code from the page.
    private async Task DispatchPack01Async(JsonElement packet)
    {
        var route = GetString(packet, "routeId");
        var requestId = GetString(packet, "requestId");
        if (route is null || !SupportedPack01NativeRoutes.Contains(route) ||
            !Guid.TryParseExact(requestId, "D", out _))
        {
            PostMessage(new { kind="packResult", requestId, routeId=route, state="HOLD",
                message="Unapproved native route or invalid request ID" });
            return;
        }
        var chatId = GetString(packet, "chatId");
        if (Pack01ChatRoutes.Contains(route) && !Guid.TryParseExact(chatId, "D", out _))
        {
            PostMessage(new { kind="packResult", requestId, routeId=route, state="HOLD",
                message="Existing local chat ID required" });
            return;
        }
        try
        {
            switch (route)
            {
                case "chat.model":
                    await SendChatModelsAsync(chatId, requestId, route);
                    return;
                case "chat.stop":
                    StopChat(chatId);
                    break;
                case "chat.history":
                {
                    // This is native user consent, not a JavaScript checkbox or a page flag.
                    var decision = MessageBox.Show(this,
                        "Показать локально сохранённую историю этого диалога?",
                        "NOX HELION · Доступ к истории", MessageBoxButton.YesNo,
                        MessageBoxImage.Question, MessageBoxResult.No);
                    if (decision != MessageBoxResult.Yes)
                    {
                        PostMessage(new {kind="packResult",requestId,routeId=route,
                            state="CANCELLED",message="Доступ к локальной истории не подтверждён"});
                        return;
                    }
                    object[] messages;
                    lock (_chatLock)
                        messages = _chatConversations.TryGetValue(chatId!, out var conversation)
                            ? conversation.Messages.TakeLast(200)
                                .Select(m=>(object)new {role=m.Role,content=m.Content}).ToArray()
                            : Array.Empty<object>();
                    PostMessage(new {kind="packResult",requestId,routeId=route,state="COMPLETED",
                        message="Локальная история прочитана",history=messages,chatId});
                    return;
                }
                case "models.catalog":
                case "models.queue":
                    OpenModelCenter();
                    break;
                case "models.pull":
                case "models.gguf.import":
                case "models.cancel":
                case "models.retry":
                    // These operations have their OWN controls, licence/rights checks and
                    // queue-specific cancellation in the original ModelCenter window.
                    // This bridge opens that workflow; it never claims a download or import.
                    OpenModelCenter();
                    PostMessage(new {kind="packResult",requestId,routeId=route,
                        state="OWNER_WINDOW_OPEN_REQUESTED",
                        message="Откройте действие в штатном ModelCenter. Запуск/STOP выполняется там после проверки прав."});
                    return;
                case "models.installed":
                    // Existing Ollama /api/tags, not fabricated catalogue entries.
                    await SendChatModelsAsync(Guid.NewGuid().ToString("D"), requestId, route);
                    return;
                case "models.digest":
                {
                    using var timeout = new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(8));
                    using var response = await ChatHttp.GetAsync("http://127.0.0.1:11434/api/tags", timeout.Token);
                    if (!response.IsSuccessStatusCode || response.Content.Headers.ContentLength is > 2097152)
                        throw new InvalidOperationException("Ollama digest source unavailable or oversized");
                    using var document = JsonDocument.Parse(await response.Content.ReadAsStringAsync(timeout.Token));
                    if (!document.RootElement.TryGetProperty("models", out var entries) || entries.ValueKind != JsonValueKind.Array)
                        throw new InvalidOperationException("No installed Ollama manifest");
                    var models = entries.EnumerateArray().Take(100).Select(x => new {
                        name = x.TryGetProperty("name", out var tag) && tag.ValueKind == JsonValueKind.String ? tag.GetString() : null,
                        digest = x.TryGetProperty("digest", out var digest) && digest.ValueKind == JsonValueKind.String ? digest.GetString() : null,
                        sizeBytes = x.TryGetProperty("size", out var size) && size.ValueKind == JsonValueKind.Number && size.TryGetInt64(out var n) ? (long?)n : null
                    }).Where(x => x.name is not null).ToArray();
                    PostMessage(new {kind="packResult",requestId,routeId=route,state="COMPLETED",
                        models, evidence="OLLAMA_LOCAL_TAGS_ONLY",
                        message="Digest из локального Ollama, не независимая SHA-проверка файла модели"});
                    return;
                }
                case "models.preflight":
                    await RunDiagnosticsAsync(requestId);
                    return;
                case "models.licenses":
                {
                    // Existing 24 pinned original ModelCatalog entries, all remain REVIEW_REQUIRED.
                    var licenses = ModelCatalog.GetAll().Select(m => new {
                        tag=m.Tag, title=m.DisplayTitle, status=m.LicenseReviewStatus,
                        url=m.LicenseUrl, sha256=m.Sha256
                    }).ToArray();
                    PostMessage(new {kind="packResult",requestId,routeId=route,state="COMPLETED",
                        message="Оригинальные записи лицензий: проверка не означает разрешение на загрузку",
                        licenses});
                    return;
                }
                case "gpu.preflight":
                {
                    // Existing GpuGuardian, no second GPU service or fabricated CUDA readiness.
                    var sensors = await _gpuGuardian.ReadNvidiaAsync();
                    var available = sensors.Where(x => x.State == "READY")
                        .Select(x => new { x.Name, x.UtilizationPercent, x.TemperatureC,
                            x.MemoryTotalMiB, x.MemoryUsedMiB }).ToArray();
                    PostMessage(new {kind="packResult",requestId,routeId=route,
                        state=available.Length>0?"COMPLETED":"HOLD",gpus=available,
                        message=available.Length>0?"NVIDIA доступна. CUDA/права/датасет проверяются отдельно":"Нет подтверждённой NVIDIA"});
                    return;
                }
                case "training.checkpoints":
                {
                    var consent = MessageBox.Show(this,
                        "Показать только названия локальных запусков и количество сохранённых checkpoint?",
                        "NOX · Локальные checkpoint",MessageBoxButton.YesNo,MessageBoxImage.Question);
                    if (consent != MessageBoxResult.Yes)
                    {
                        PostMessage(new {kind="packResult",requestId,routeId=route,
                            state="CANCELLED",message="Просмотр checkpoint отменён"});
                        return;
                    }
                    var runsRoot = Path.Combine(_data, "training", "runs");
                    object[] runs = Directory.Exists(runsRoot)
                        ? Directory.EnumerateDirectories(runsRoot).Take(101)
                            .Where(p => (File.GetAttributes(p) & FileAttributes.ReparsePoint) == 0)
                            .Take(100).Select(p => new {
                                name = Path.GetFileName(p),
                                checkpoints = Directory.EnumerateDirectories(p, "checkpoint-*",SearchOption.TopDirectoryOnly)
                                    .Take(100).Count(),
                                hasReceipt = File.Exists(Path.Combine(p,"training-receipt.json")),
                                verification = "NOT_VALIDATED_FOR_RESUME"
                            }).Cast<object>().ToArray()
                        : Array.Empty<object>();
                    PostMessage(new {kind="packResult",requestId,routeId=route,
                        state="COMPLETED",runs,
                        message="Найдены локальные записи; checkpoint не подтверждены пригодными к RESUME"});
                    return;
                }
                case "system.backup":
                {
                    // Reuse ORIGINAL BackupRestoreService, no second archive tool.
                    // Trusted native SaveFileDialog chooses the destination; no JS paths.
                    var save = new Microsoft.Win32.SaveFileDialog {
                        Title="NOX · Сохранить резервную копию данных приложения",
                        Filter="ZIP (*.zip)|*.zip",DefaultExt=".zip",AddExtension=true,
                        FileName="NOX_P01_BACKUP_"+DateTime.UtcNow.ToString("yyyyMMdd_HHmmss")+".zip"
                    };
                    if (save.ShowDialog(this) != true)
                    {
                        PostMessage(new {kind="packResult",requestId,routeId=route,
                            state="CANCELLED",message="Выбор файла отменён"});
                        return;
                    }
                    if (!Directory.Exists(_data))
                        throw new DirectoryNotFoundException("NOX local data directory unavailable");
                    var approved=MessageBox.Show(this,
                        "Сохранить локальные данные NOX P01? Секреты и системные ссылки будут пропущены. " +
                        "Архив не включает все установленные модели Ollama. Продолжить?",
                        "NOX · Подтверждение резервной копии",MessageBoxButton.YesNo,MessageBoxImage.Warning);
                    if (approved != MessageBoxResult.Yes)
                    {
                        PostMessage(new {kind="packResult",requestId,routeId=route,
                            state="CANCELLED",message="Резервное копирование отменено"});
                        return;
                    }
                    var service = new NOX.P01.ModelCenter.BackupRestoreService(_modelCenterEvents);
                    var result = await service.CreateBackupAsync(save.FileName,
                        new [] { new NOX.P01.ModelCenter.BackupScope("nox-p01",_data) });
                    PostMessage(new {kind="packResult",requestId,routeId=route,state="COMPLETED",
                        archiveName=Path.GetFileName(result.ArchivePath),
                        fileCount=result.FileCount,sizeBytes=result.SizeBytes,sha256=result.Sha256,
                        message="Локальная ZIP-копия создана оригинальным BackupRestoreService"});
                    return;
                }
                case "training.start":
                {
                    var revision = GetString(packet, "modelRevision");
                    if (revision is null || !System.Text.RegularExpressions.Regex.IsMatch(revision,"^[0-9a-fA-F]{40}$"))
                    {
                        PostMessage(new {kind="packResult",requestId,routeId=route,
                            state="HOLD",message="Укажи immutable SHA модели в разделе обучения"});
                        return;
                    }
                    // This EXISTING worker validates rights, holdout, pinned model, GPU and
                    // asks fresh user confirmation in its native MessageBox before launching.
                    _ = StartTrainingAsync(revision);
                    PostMessage(new {kind="packResult",requestId,routeId=route,
                        state="DISPATCHED",message="Передано штатному QLoRA; итог только в trainingState/receipt"});
                    return;
                }
                case "system.telemetry":
                    await RefreshTelemetryAsync();
                    break;
            }
            PostMessage(new {kind="packResult",requestId,routeId=route,state="DISPATCHED",
                message="Штатный обработчик вызван; результат проверяется отдельно"});
        }
        catch (Exception ex)
        {
            WriteLog("PACK01_ERROR " + route + " " + ex.GetType().Name);
            PostMessage(new {kind="packResult",requestId,routeId=route,state="ERROR",
                message="Не удалось выполнить действие. Причина записана в локальный журнал."});
        }
    }
}
