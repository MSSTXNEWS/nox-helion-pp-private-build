# NOX P01 — installer only (not WEB release)

## P01 scope
WPF + native WebView2 window, responsive UI, F11/windowed, DPI-awareness, original HOME/MENU/CORE image assets, installer actions via Modules/NoxActions.ps1, persistent logs and visible errors.

## Out of scope for P01
540 WEB requirements, model training, full 24-model downloader, real AI chat, all CORE environments, production WEB deployment. These belong to other megablock tasks. No false product PASS.

## Evidence to close P01
1. Source presence, package CRC, asset hashes — local PASS.
2. HTML responsive/navigation checks — browser-only PASS per prior report.
3. Windows .NET 8 restore/build — requires Windows runner receipt.
4. Native WPF WebView2 launch with installed runtime — requires Windows receipt.
5. DPI 100/125/150/200 and F11/Escape screenshots — requires Windows receipt.
6. Buttons install/check/start/stop/open/cancel with result logs — requires Windows receipt.
7. Owner-approved visual comparison and independent signoff — requires reviewer receipt.

No EXE should be released before 3–7 PASS. Source prep does not imply 100% accepted.
