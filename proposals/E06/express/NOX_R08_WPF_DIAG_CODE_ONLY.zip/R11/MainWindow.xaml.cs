using System;
using System.Diagnostics;
using System.Net.Http;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Controls;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Core;
using NOX.P01.ModelCenter;
using NOX.P01.Packages.P02.OpenAI;
using NoxP05;
using NoxP04.GpuGuardian;

namespace NoxP01;
public partial class MainWindow : Window
{
    private readonly string _data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NOX_HELION", "P01");
    private string LogPath => Path.Combine(_data, "logs", "shell.log");
    private bool _fullScreen;
    private WindowState _previousState;
    private WindowStyle _previousStyle;
    private ResizeMode _previousResize;
    private bool _initialized;
    private CoreWebView2? _hookedWebViewCore;
    private bool _busy;
    private readonly object _logLock = new();
    private Process? _actionProcess;
    private volatile bool _actionCancelRequested;
    private readonly SemaphoreSlim _actionGate = new(1, 1);
    private readonly ModelCenterEventHub _modelCenterEvents = new();
    private ModelDownloaderWindow? _modelCenterWindow;
    private readonly EventV3Bridge _eventV3Bridge;
    private readonly GpuGuardian _gpuGuardian;
    private readonly TrainingRuntimeInstaller _trainingRuntimeInstaller;
    private readonly WindowsCredentialSecretProvider _openAiSecrets = new();
    private readonly OpenAiResponsesProvider _openAiProvider;
    private static readonly HttpClient ChatHttp = new(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = Timeout.InfiniteTimeSpan };
    private readonly object _chatLock = new();
    private readonly Dictionary<string, ChatConversation> _chatConversations = new(StringComparer.Ordinal);
    private readonly Dictionary<string, CancellationTokenSource> _activeChats = new(StringComparer.Ordinal);
    private readonly HashSet<string> _userStoppedChats = new(StringComparer.Ordinal);
    private readonly Dictionary<string, string> _activeOpenAiRequestIds = new(StringComparer.Ordinal);
    private readonly object _chatUsageLock = new();
    private readonly Dictionary<string, long> _ollamaTokenCounts = new(StringComparer.Ordinal);
    private string? _trainingTrainPath;
    private string? _trainingHoldoutPath;
    private string? _trainingManifestPath;
    private string? _trainingModelRevision;
    private string _trainingIntensity = "BALANCED";
    private NoxManagedWorker? _trainingWorker;
    private string? _trainingCancelMarker;
    private CancellationTokenSource? _trainingMonitorCts;
    private readonly SemaphoreSlim _trainingGate = new(1, 1);
    private string ChatHistoryPath => Path.Combine(_data, "chat-history.json");
    public MainWindow()
    {
        InitializeComponent();
        Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);
        _eventV3Bridge = new EventV3Bridge(_data);
        LoadTrainingIntensity();
        _gpuGuardian = new GpuGuardian(_eventV3Bridge.RunId);
        _gpuGuardian.EventRaised += AppendGuardianEvent;
        _trainingRuntimeInstaller = new TrainingRuntimeInstaller(_modelCenterEvents);
        _openAiProvider = new OpenAiResponsesProvider(_openAiSecrets);
        LoadChatConversations();
        _modelCenterEvents.EventRaised += OnModelCenterEvent;
        Loaded += async (_, _) => await InitializeAsync();
        PreviewKeyDown += OnKeyDown;
        Closing += (_, _) => WriteLog("CLOSE");
        Closing += (_, _) => { _openAiProvider.Dispose(); _trainingMonitorCts?.Cancel(); };
        Application.Current.DispatcherUnhandledException += (_, e) => { WriteLog("UI_EXCEPTION " + e.Exception); StartupMessage.Text = "Ошибка интерфейса. Журнал: " + LogPath; StartupOverlay.Visibility = Visibility.Visible; e.Handled = true; };
    }
    private void WriteLog(string message)
    {
        try { lock (_logLock) File.AppendAllText(LogPath, $"[{DateTimeOffset.Now:O}] {message}{Environment.NewLine}"); } catch { }
    }
    private async Task InitializeAsync()
    {
        if (_initialized) return;
        try
        {
            WriteLog("INIT_BEGIN");
            var userData = Path.Combine(_data, "webview2");
            Directory.CreateDirectory(userData);
            var env = await CoreWebView2Environment.CreateAsync(null, userData);
            await View.EnsureCoreWebView2Async(env);
            var core = View.CoreWebView2;
            core.Settings.IsWebMessageEnabled = true;
            core.Settings.IsGeneralAutofillEnabled = false;
            core.Settings.IsPasswordAutosaveEnabled = false;
            core.Settings.AreHostObjectsAllowed = false;
            core.Settings.IsScriptEnabled = true;
            core.Settings.AreDevToolsEnabled = false;
            core.Settings.AreDefaultContextMenusEnabled = false;
            core.Settings.IsStatusBarEnabled = false;
            if (!ReferenceEquals(_hookedWebViewCore, core))
            {
                core.WebMessageReceived += HandleMessage;
                core.ProcessFailed += (_, e) => { WriteLog("WEBVIEW_PROCESS_FAILED " + e.ProcessFailedKind); StartupMessage.Text = "Сбой процесса WebView2. Журнал: " + LogPath; StartupOverlay.Visibility = Visibility.Visible; StartupRetryButton.IsEnabled = true; };
                core.NavigationCompleted += (_, e) =>
                {
                    if (e.IsSuccess) { StartupOverlay.Visibility = Visibility.Collapsed; StartupRetryButton.IsEnabled = false; WriteLog("NAV_OK"); }
                    else { StartupMessage.Text = "Не удалось загрузить графическую оболочку. Откройте журнал или повторите запуск."; StartupRetryButton.IsEnabled = true; WriteLog("NAV_FAIL " + e.WebErrorStatus); }
                };
                core.NavigationStarting += (_, e) =>
                {
                    if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out var target) || !string.Equals(target.Host, "nox.local", StringComparison.OrdinalIgnoreCase) || target.Scheme != "https")
                    { e.Cancel = true; WriteLog("BLOCK_NAV " + e.Uri); }
                };
                core.NewWindowRequested += (_, e) => { e.Handled = true; WriteLog("BLOCK_POPUP"); };
                _hookedWebViewCore = core;
            }
            var assets = Path.Combine(AppContext.BaseDirectory, "Assets");
            if (!File.Exists(Path.Combine(assets, "index.html"))) throw new FileNotFoundException("Missing approved HTML asset");
            core.SetVirtualHostNameToFolderMapping("nox.local", assets, CoreWebView2HostResourceAccessKind.DenyCors);
            _initialized = true;
            core.Navigate("https://nox.local/index.html");
            WriteLog("NAV_START");
        }
        catch (Exception ex)
        {
            StartupMessage.Text = "NOX не запустился: " + ex.Message + "\nЖурнал: " + LogPath;
            StartupRetryButton.IsEnabled = true;
            WriteLog("INIT_ERROR " + ex);
        }
    }
    private async void RetryStartup_Click(object sender, RoutedEventArgs e)
    {
        StartupRetryButton.IsEnabled = false;
        StartupMessage.Text = "Повторная попытка запуска…";
        try
        {
            if (_initialized && View.CoreWebView2 is { } core)
            {
                try
                {
                    core.Navigate("https://nox.local/index.html");
                    WriteLog("NAV_RETRY");
                    return;
                }
                catch (Exception ex)
                {
                    _initialized = false;
                    WriteLog("NAV_RETRY_REINITIALIZE " + ex.GetType().Name);
                }
            }
            _initialized = false;
            await InitializeAsync();
        }
        catch (Exception ex)
        {
            StartupMessage.Text = "Повторный запуск не удался. Откройте журнал: " + LogPath;
            StartupRetryButton.IsEnabled = true;
            WriteLog("INIT_RETRY_ERROR " + ex);
        }
    }

    private void HandleMessage(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        if (!Uri.TryCreate(e.Source, UriKind.Absolute, out var source) || source.Scheme != "https" || !string.Equals(source.Host, "nox.local", StringComparison.OrdinalIgnoreCase)) return;
        try
        {
            using var json = JsonDocument.Parse(e.WebMessageAsJson);
            if (!json.RootElement.TryGetProperty("action", out var action)) return;
            var type = action.GetString();
            switch (type)
            {
                case "toggleFullscreen": ToggleFullscreen(); break;
                case "setFullscreen": if (json.RootElement.TryGetProperty("value", out var value) && (value.ValueKind == JsonValueKind.True || value.ValueKind == JsonValueKind.False)) SetFullscreen(value.GetBoolean()); break;
                case "report": _ = SaveReportAsync(); break;
                case "openLog": OpenLog(); break;
                case "status": SendStatus(); break;
                case "refreshTelemetry": _ = RefreshTelemetryAsync(); break;
                case "readMainSnapshot": ReadMainSnapshot(); break;
                case "diagnostics": _ = RunDiagnosticsAsync(); break;
                case "openData": OpenDataFolder(); break;
                case "installApp": _ = RunActionAsync("install"); break;
                case "startApp": _ = RunActionAsync("start"); break;
                case "stopApp": _ = RunActionAsync("stop"); break;
                case "checkDeps": _ = RunActionAsync("check"); break;
                case "openWeb": _ = RunActionAsync("open"); break;
                case "cancelAction": CancelAction(); break;
                case "openModelCenter": OpenModelCenter(); break;
                case "chatModels": _ = SendChatModelsAsync(GetString(json.RootElement, "chatId")); break;
                case "chatStart": _ = StartChatAsync(json.RootElement.Clone()); break;
                case "chatStop": StopChat(GetString(json.RootElement, "chatId")); break;
                case "configureOpenAI": _ = ConfigureOpenAiAsync(); break;
                case "installTrainingRuntime": _ = InstallTrainingRuntimeAsync(); break;
                case "selectTrainingInput": SelectTrainingInput(GetString(json.RootElement, "inputKind")); break;
                case "setTrainingIntensity": SetTrainingIntensity(GetString(json.RootElement, "value")); break;
                case "startTraining": _ = StartTrainingAsync(GetString(json.RootElement, "modelRevision")); break;
                case "stopTraining": StopTraining(); break;
                case "packCapabilities": SendPack01Capabilities(); break;
                case "packInvoke": _ = DispatchPack01Async(json.RootElement.Clone()); break;
                default: WriteLog("UNSUPPORTED_ACTION " + type); break;
            }
        }
        catch (Exception ex) { WriteLog("MESSAGE_ERROR " + ex.Message); }
    }

    private static string? GetString(JsonElement root, string name) =>
        root.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    private string TrainingIntensitySettingsPath => Path.Combine(_data, "settings", "training-intensity.json");

    private static bool TryNormalizeTrainingIntensity(string? value, out string profile)
    {
        profile = value?.Trim().ToUpperInvariant() ?? string.Empty;
        return profile is "ECO" or "BALANCED" or "INTENSIVE";
    }

    private void LoadTrainingIntensity()
    {
        try
        {
            if (!File.Exists(TrainingIntensitySettingsPath)) return;
            using var document = JsonDocument.Parse(File.ReadAllText(TrainingIntensitySettingsPath));
            if (document.RootElement.TryGetProperty("profile", out var value) &&
                value.ValueKind == JsonValueKind.String &&
                TryNormalizeTrainingIntensity(value.GetString(), out var profile))
                _trainingIntensity = profile;
            else
                WriteLog("TRAINING_INTENSITY_SETTINGS_INVALID using BALANCED");
        }
        catch (Exception ex) { WriteLog("TRAINING_INTENSITY_SETTINGS_READ_FAILED " + ex.GetType().Name); }
    }

    private void SetTrainingIntensity(string? value)
    {
        if (!TryNormalizeTrainingIntensity(value, out var profile))
        {
            PostMessage(new { kind = "trainingIntensity", state = "REJECTED", profile = _trainingIntensity });
            return;
        }
        if (_trainingGate.CurrentCount == 0)
        {
            PostMessage(new { kind = "trainingIntensity", state = "BUSY", profile = _trainingIntensity });
            return;
        }
        try
        {
            var path = TrainingIntensitySettingsPath;
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            var temporary = path + ".tmp";
            File.WriteAllText(temporary, JsonSerializer.Serialize(new { profile, savedUtc = DateTimeOffset.UtcNow }));
            File.Move(temporary, path, overwrite: true);
            _trainingIntensity = profile;
            AppendRuntimeV3("task.progress", "P04-settings", "training_intensity", "COMPLETED",
                $"Saved {profile} for the next QLoRA run; active run settings are immutable.", "P04.Training", packageId: "P04");
            PostMessage(new { kind = "trainingIntensity", state = "SAVED", profile });
        }
        catch (Exception ex)
        {
            WriteLog("TRAINING_INTENSITY_SETTINGS_WRITE_FAILED " + ex.GetType().Name);
            PostMessage(new { kind = "trainingIntensity", state = "ERROR", profile = _trainingIntensity });
        }
    }

    private void LoadChatConversations()
    {
        try
        {
            if (!File.Exists(ChatHistoryPath)) return;
            var loaded = JsonSerializer.Deserialize<Dictionary<string, ChatConversation>>(
                File.ReadAllText(ChatHistoryPath), new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (loaded is null) return;
            foreach (var item in loaded.Take(100))
            {
                if (Guid.TryParse(item.Key, out _) && item.Value.Messages is not null)
                    _chatConversations[item.Key] = item.Value;
            }
        }
        catch (Exception ex) { WriteLog("CHAT_HISTORY_LOAD_FAILED " + ex.Message); }
    }

    private async Task SendChatModelsAsync(string? chatId, string? packRequestId = null, string? packRoute = null)
    {
        if (!Guid.TryParse(chatId, out _))
        {
            PostMessage(new { kind = "chatModels", state = "ERROR", chatId, models = Array.Empty<string>(), history = Array.Empty<object>(), message = "Некорректный ID чата." });
            if (packRequestId != null) PostMessage(new {kind="packResult",requestId=packRequestId,routeId=packRoute,state="HOLD",message="Invalid chat ID"});
            return;
        }

        try
        {
            using var requestTimeout = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            using var response = await ChatHttp.GetAsync("http://127.0.0.1:11434/api/tags", requestTimeout.Token);
            if (!response.IsSuccessStatusCode) throw new HttpRequestException("OLLAMA_HTTP_" + (int)response.StatusCode);
            using var document = JsonDocument.Parse(await response.Content.ReadAsStringAsync(requestTimeout.Token));
            var models = document.RootElement.TryGetProperty("models", out var array) && array.ValueKind == JsonValueKind.Array
                ? array.EnumerateArray().Where(x => x.TryGetProperty("name", out var n) && n.ValueKind == JsonValueKind.String)
                    .Select(x => x.GetProperty("name").GetString()!).Distinct(StringComparer.OrdinalIgnoreCase).ToArray()
                : Array.Empty<string>();

            object[] history;
            lock (_chatLock)
                history = _chatConversations.TryGetValue(chatId!, out var session)
                    ? session.Messages.Select(x => (object)new { role = x.Role, content = x.Content }).ToArray()
                    : Array.Empty<object>();
            PostMessage(new { kind = "chatModels", state = "ONLINE", chatId, models, history, message = models.Length == 0 ? "В Ollama нет установленных моделей." : "Локальные модели загружены." });
            if (packRequestId != null) PostMessage(new { kind="packResult", requestId=packRequestId,
                state="COMPLETED", routeId=packRoute,
                models, message="Ответ от локального Ollama /api/tags" });
        }
        catch (OperationCanceledException)
        {
            WriteLog("CHAT_MODELS_TIMEOUT");
            PostMessage(new { kind = "chatModels", state = "TIMEOUT", chatId, models = Array.Empty<string>(), history = Array.Empty<object>(), message = "Ollama не ответила за 10 секунд. Проверь локальный сервер и повтори запрос." });
            if (packRequestId != null) PostMessage(new {kind="packResult",requestId=packRequestId,routeId=packRoute,state="HOLD",message="Ollama timeout"});
        }
        catch (Exception ex)
        {
            WriteLog("CHAT_MODELS_FAILED " + ex.Message);
            PostMessage(new { kind = "chatModels", state = "OFFLINE", chatId, models = Array.Empty<string>(), history = Array.Empty<object>(), message = "Ollama недоступна на этом компьютере." });
            if (packRequestId != null) PostMessage(new {kind="packResult",requestId=packRequestId,routeId=packRoute,state="HOLD",message="Local Ollama offline"});
        }
    }

    private async Task StartChatAsync(JsonElement root)
    {
        var chatId = GetString(root, "chatId");
        var model = GetString(root, "model");
        var message = GetString(root, "message");
        var coreId = GetString(root, "coreId");
        var personaId = GetString(root, "personaId");
        var provider = string.Equals(GetString(root, "provider"), "OPENAI", StringComparison.OrdinalIgnoreCase) ? "OPENAI" : "OLLAMA";
        var allowedCores = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "consciousness", "persona", "atlas", "voice", "reflection", "core", "nexus", "forge" };
        var allowedPersonas = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "kairen", "adrian", "leon", "elina", "cassien" };

        if (!Guid.TryParse(chatId, out _) || string.IsNullOrWhiteSpace(model) || model.Length > (provider == "OPENAI" ? 120 : 180) ||
            !Regex.IsMatch(model, @"^[A-Za-z0-9_.:/-]+$", RegexOptions.CultureInvariant) ||
            string.IsNullOrWhiteSpace(message) || message.Length > 12000 ||
            string.IsNullOrWhiteSpace(coreId) || !allowedCores.Contains(coreId) ||
            string.IsNullOrWhiteSpace(personaId) || !allowedPersonas.Contains(personaId))
        {
            PostMessage(new { kind = "chatError", chatId, code = "INVALID_INPUT", message = "Проверь сообщение, модель, Core и Persona." });
            return;
        }

        if (provider == "OPENAI")
        {
            var consent = MessageBox.Show(this,
                "Сообщение и история выбранного диалога будут отправлены OpenAI API. Использование API может тарифицироваться отдельно. Продолжить?",
                "NOX · OpenAI API", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (consent != MessageBoxResult.Yes)
            {
                PostMessage(new { kind = "chatError", chatId, code = "REMOTE_SEND_DECLINED", message = "Отправка OpenAI API отменена." });
                return;
            }
            var credentialState = await _openAiProvider.GetConfigurationStateAsync();
            if (credentialState != "READY")
            {
                var configured = await ConfigureOpenAiAsync();
                if (!configured)
                {
                    PostMessage(new { kind = "chatError", chatId, code = "OPENAI_KEY_NOT_CONFIGURED", message = "OpenAI API не настроен." });
                    return;
                }
            }
        }

        var normalizedCore = coreId.ToLowerInvariant();
        var normalizedPersona = personaId.ToLowerInvariant();
        lock (_chatLock)
        {
            if (_chatConversations.TryGetValue(chatId!, out var existing) &&
                (!string.Equals(existing.CoreId, normalizedCore, StringComparison.Ordinal) || !string.Equals(existing.PersonaId, normalizedPersona, StringComparison.Ordinal)))
            {
                PostMessage(new { kind = "chatError", chatId, code = "CHAT_SCOPE_LOCKED", message = "Для другого Core или Persona создай новый чат." });
                return;
            }
            _chatConversations.TryAdd(chatId!, new ChatConversation { CoreId = normalizedCore, PersonaId = normalizedPersona });
            if (_activeChats.ContainsKey(chatId!))
            {
                PostMessage(new { kind = "chatError", chatId, code = "CHAT_BUSY", message = "В этом чате уже идёт ответ." });
                return;
            }
        }

        var cts = new CancellationTokenSource(TimeSpan.FromMinutes(3));
        var taskId = "P02-" + Guid.NewGuid().ToString("N");
        var requestId = Guid.NewGuid().ToString("N");
        lock (_chatLock)
        {
            _activeChats[chatId!] = cts;
            _userStoppedChats.Remove(chatId!);
            if (provider == "OPENAI") _activeOpenAiRequestIds[chatId!] = requestId;
        }
        var actionId = ChatActionId(provider, model!);
        AppendRuntimeV3("task.started", taskId, actionId, "RUNNING", provider == "OPENAI" ? "OpenAI API chat request started." : "Local Ollama chat request started.", "P02." + provider);
        var answer = new StringBuilder();

        try
        {
            List<ChatMessage> history;
            lock (_chatLock) history = _chatConversations[chatId!].Messages.TakeLast(24).ToList();
            if (provider == "OPENAI")
            {
                var apiMessages = history.Select(x => new OpenAiInputMessage(x.Role, x.Content)).ToList();
                apiMessages.Add(new OpenAiInputMessage("user", message!.Trim()));
                var request = new OpenAiResponsesRequest(requestId, model!, apiMessages,
                    $"You are NOX HELION CoreID {normalizedCore}, PersonaID {normalizedPersona}. Do not claim actions not performed.");
                var terminal = "INCOMPLETE";
                await foreach (var providerEvent in _openAiProvider.StreamAsync(request, cts.Token))
                {
                    if (providerEvent.State == "TOKEN" && !string.IsNullOrEmpty(providerEvent.Delta))
                    {
                        answer.Append(providerEvent.Delta);
                        PostMessage(new { kind = "chatToken", chatId, token = providerEvent.Delta });
                    }
                    else if (providerEvent.State is "COMPLETED" or "STOPPED" or "ERROR" or "INCOMPLETE" or "NOT_CONFIGURED")
                    {
                        terminal = providerEvent.State;
                        if (terminal is "ERROR" or "NOT_CONFIGURED")
                        {
                            AppendRuntimeV3("task.failed", taskId, actionId, "ERROR", "OpenAI API chat request failed.", "P02.OPENAI");
                            var code = providerEvent.ErrorCode ?? "PROVIDER_ERROR";
                            PostMessage(new { kind = "chatError", chatId, code, message = code == "OPENAI_API_KEY_MISSING" ? "Сохрани OpenAI API key через защищённое окно." : "OpenAI API не ответил. Проверь подключение и настройки." });
                            return;
                        }
                        break;
                    }
                }
                if (terminal == "STOPPED" || cts.IsCancellationRequested)
                {
                    AppendRuntimeV3("model.stopped", taskId, actionId, "STOPPED", "OpenAI API generation stopped.", "P02.OPENAI");
                    PostMessage(new { kind = "chatFinished", chatId, state = "STOPPED" });
                    return;
                }
                if (terminal != "COMPLETED")
                {
                    AppendRuntimeV3("task.failed", taskId, actionId, "ERROR", "OpenAI API stream ended before completion.", "P02.OPENAI");
                    PostMessage(new { kind = "chatError", chatId, code = "INCOMPLETE", message = "Поток OpenAI API завершился до конца." });
                    return;
                }
            }
            else
            {
                string[] installed;
                using (var tags = await ChatHttp.GetAsync("http://127.0.0.1:11434/api/tags", cts.Token))
                {
                    if (!tags.IsSuccessStatusCode) throw new HttpRequestException("OLLAMA_HTTP_" + (int)tags.StatusCode);
                    using var doc = JsonDocument.Parse(await tags.Content.ReadAsStringAsync(cts.Token));
                    installed = doc.RootElement.TryGetProperty("models", out var models) && models.ValueKind == JsonValueKind.Array
                        ? models.EnumerateArray().Where(x => x.TryGetProperty("name", out var n) && n.ValueKind == JsonValueKind.String)
                            .Select(x => x.GetProperty("name").GetString()!).ToArray()
                        : Array.Empty<string>();
                }
                if (!installed.Contains(model!, StringComparer.OrdinalIgnoreCase))
                    throw new InvalidOperationException("MODEL_NOT_INSTALLED");

                var messages = new List<object>
                {
                    new { role = "system", content = $"NOX HELION CoreID {normalizedCore}, PersonaID {normalizedPersona}. Do not claim actions not performed." }
                };
                messages.AddRange(history.Select(x => (object)new { role = x.Role, content = x.Content }));
                messages.Add(new { role = "user", content = message!.Trim() });
                using var request = new HttpRequestMessage(HttpMethod.Post, "http://127.0.0.1:11434/api/chat")
                {
                    Content = new StringContent(JsonSerializer.Serialize(new { model, messages, stream = true }), Encoding.UTF8, "application/json")
                };
                using var response = await ChatHttp.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cts.Token);
                if (!response.IsSuccessStatusCode) throw new HttpRequestException("OLLAMA_HTTP_" + (int)response.StatusCode);
                await using var stream = await response.Content.ReadAsStreamAsync(cts.Token);
                using var reader = new StreamReader(stream);
                var completed = false;
                long? tokenCount = null;
                while (true)
                {
                    var line = await reader.ReadLineAsync(cts.Token);
                    if (line is null) break;
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    using var chunk = JsonDocument.Parse(line);
                    var rootChunk = chunk.RootElement;
                    if (rootChunk.TryGetProperty("message", out var chunkMessage) && chunkMessage.TryGetProperty("content", out var tokenElement) && tokenElement.ValueKind == JsonValueKind.String)
                    {
                        var token = tokenElement.GetString();
                        if (!string.IsNullOrEmpty(token))
                        {
                            answer.Append(token);
                            PostMessage(new { kind = "chatToken", chatId, token });
                        }
                    }
                    if (rootChunk.TryGetProperty("done", out var done) && done.ValueKind == JsonValueKind.True)
                    {
                        completed = true;
                        if (rootChunk.TryGetProperty("eval_count", out var count) && count.ValueKind == JsonValueKind.Number && count.TryGetInt64(out var measured)) tokenCount = measured;
                        break;
                    }
                }
                if (cts.IsCancellationRequested)
                {
                    AppendRuntimeV3("model.stopped", taskId, actionId, "STOPPED", "Local Ollama generation stopped.", "P02.OLLAMA");
                    PostMessage(new { kind = "chatFinished", chatId, state = "STOPPED" });
                    return;
                }
                if (!completed) throw new InvalidDataException("OLLAMA_STREAM_INCOMPLETE");
                if (tokenCount.HasValue)
                    AppendRuntimeV3("model.tokens", taskId, actionId, "COMPLETED", "Provider reported generated token count.", "P02.OLLAMA", tokenCount.Value, null);
            }

            lock (_chatLock)
            {
                var session = _chatConversations[chatId!];
                session.Messages.Add(new ChatMessage { Role = "user", Content = message!.Trim() });
                session.Messages.Add(new ChatMessage { Role = "assistant", Content = answer.ToString() });
                if (session.Messages.Count > 40) session.Messages.RemoveRange(0, session.Messages.Count - 40);
                if (!SaveChatConversations())
                {
                    AppendRuntimeV3("task.failed", taskId, actionId, "ERROR", "The response was generated, but local chat history could not be saved.", "P02.CHAT_HISTORY");
                    PostMessage(new { kind = "chatFinished", chatId, state = "HISTORY_SAVE_FAILED" });
                    return;
                }
            }
            if (provider == "OPENAI") AppendRuntimeV3("task.completed", taskId, actionId, "COMPLETED", "OpenAI API chat request completed.", "P02.OPENAI");
            else AppendRuntimeV3("task.completed", taskId, actionId, "COMPLETED", "Local Ollama chat request completed and history saved.", "P02.OLLAMA");
            PostMessage(new { kind = "chatFinished", chatId, state = "COMPLETED" });
        }
        catch (OperationCanceledException)
        {
            bool userStopped;
            lock (_chatLock) userStopped = _userStoppedChats.Contains(chatId!);
            if (userStopped)
            {
                PersistStoppedChatTurn(chatId!, message!, answer.ToString());
                AppendRuntimeV3("model.stopped", taskId, actionId, "STOPPED", provider == "OPENAI" ? "User requested client stream cancellation." : "User requested local Ollama client stream cancellation.", "P02." + provider);
                PostMessage(new { kind = "chatFinished", chatId, state = "STOPPED" });
            }
            else
            {
                AppendRuntimeV3("task.failed", taskId, actionId, "ERROR", "Chat request exceeded its three-minute timeout.", "P02." + provider);
                PostMessage(new { kind = "chatFinished", chatId, state = "TIMEOUT" });
            }
        }
        catch (Exception ex)
        {
            var missingModel = ex is InvalidOperationException && ex.Message == "MODEL_NOT_INSTALLED";
            AppendRuntimeV3("task.failed", taskId, actionId, "ERROR", missingModel ? "Selected Ollama model is not installed." : "Chat provider request failed.", "P02." + provider);
            WriteLog("CHAT_REQUEST_FAILED " + (missingModel ? "MODEL_NOT_INSTALLED" : ex.GetType().Name));
            PostMessage(new { kind = "chatError", chatId, code = missingModel ? "MODEL_NOT_INSTALLED" : "PROVIDER_ERROR", message = missingModel ? "Сначала установи выбранную модель в центре моделей." : provider == "OPENAI" ? "OpenAI API не ответил. Проверь подключение и настройки." : "Локальный ИИ не ответил. Проверь Ollama и журнал." });
        }
        finally
        {
            lock (_chatLock)
            {
                if (_activeChats.TryGetValue(chatId!, out var active) && ReferenceEquals(active, cts)) _activeChats.Remove(chatId!);
                _userStoppedChats.Remove(chatId!);
                _activeOpenAiRequestIds.Remove(chatId!);
            }
            cts.Dispose();
        }
    }

    private void StopChat(string? chatId)
    {
        if (!Guid.TryParse(chatId, out _)) return;
        lock (_chatLock)
        {
            if (_activeChats.TryGetValue(chatId!, out var cts))
            {
                if (!cts.IsCancellationRequested) _userStoppedChats.Add(chatId!);
                if (_activeOpenAiRequestIds.TryGetValue(chatId!, out var requestId)) _openAiProvider.Stop(requestId);
                cts.Cancel();
                PostMessage(new { kind = "chatFinished", chatId, state = "STOP_REQUESTED" });
            }
            else PostMessage(new { kind = "chatFinished", chatId, state = "IDLE" });
        }
    }

    private static string ChatActionId(string provider, string model)
    {
        var safe = Regex.Replace(model.ToLowerInvariant(), "[^a-z0-9]+", "_").Trim('_');
        if (safe.Length > 70) safe = safe[..70];
        return "chat_" + (provider == "OPENAI" ? "openai" : "ollama") + "_" + (safe.Length == 0 ? "model" : safe);
    }

    private void AppendRuntimeV3(string eventType, string taskId, string actionId, string state,
        string safeMessage, string source, long? numerator = null, long? denominator = null,
        string packageId = "P02")
    {
        var record = new Dictionary<string, object?>
        {
            ["schema"] = "NOX-INSTALLER-EVENT-v3",
            ["run_id"] = _eventV3Bridge.RunId,
            ["event_id"] = Guid.NewGuid().ToString("N"),
            ["event_type"] = eventType,
            ["task_id"] = taskId,
            ["package_id"] = packageId,
            ["action_id"] = Regex.Replace(actionId, "[^A-Za-z0-9_.-]", "_")[..Math.Min(96, actionId.Length)],
            ["timestamp_utc"] = DateTimeOffset.UtcNow,
            ["state"] = state,
            ["source"] = source,
            ["message"] = safeMessage.Length <= 240 ? safeMessage : safeMessage[..240],
            ["numerator"] = numerator,
            ["denominator"] = denominator,
            ["evidence_verified"] = false
        };
        try
        {
            EventV3Bridge.WithJournalLock(() =>
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_eventV3Bridge.JournalPath)!);
                using var stream = new FileStream(_eventV3Bridge.JournalPath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
                using var writer = new StreamWriter(stream, new UTF8Encoding(false));
                writer.WriteLine(JsonSerializer.Serialize(record));
                writer.Flush();
                stream.Flush(flushToDisk: true);
            });
        }
        catch (Exception ex) { WriteLog("V3_RUNTIME_EVENT_WRITE_FAILED " + ex.GetType().Name); }
    }

    private void AppendGuardianEvent(GpuGuardianEvent sourceEvent)
    {
        var record = new Dictionary<string, object?>
        {
            ["schema"] = sourceEvent.Schema,
            ["run_id"] = _eventV3Bridge.RunId,
            ["event_id"] = sourceEvent.EventId,
            ["event_type"] = sourceEvent.EventType,
            ["task_id"] = sourceEvent.TaskId,
            ["package_id"] = sourceEvent.PackageId,
            ["action_id"] = sourceEvent.ActionId,
            ["timestamp_utc"] = sourceEvent.TimestampUtc,
            ["state"] = sourceEvent.State,
            ["source"] = sourceEvent.Source,
            ["message"] = sourceEvent.Message,
            ["numerator"] = sourceEvent.Numerator,
            ["denominator"] = sourceEvent.Denominator,
            ["evidence_verified"] = sourceEvent.EvidenceVerified
        };
        try
        {
            EventV3Bridge.WithJournalLock(() =>
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_eventV3Bridge.JournalPath)!);
                using var stream = new FileStream(_eventV3Bridge.JournalPath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
                using var writer = new StreamWriter(stream, new UTF8Encoding(false));
                writer.WriteLine(JsonSerializer.Serialize(record));
                writer.Flush();
                stream.Flush(flushToDisk: true);
            });
        }
        catch (Exception ex) { WriteLog("GPU_EVENT_WRITE_FAILED " + ex.GetType().Name); }
    }

    private async Task<bool> ConfigureOpenAiAsync(bool replace = false)
    {
        var state = await _openAiProvider.GetConfigurationStateAsync();
        if (!replace && state == "READY")
        {
            PostMessage(new { kind = "chatProviderState", state = "READY" });
            return true;
        }

        var dialog = new Window
        {
            Title = "NOX · OpenAI API key",
            Owner = this,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            SizeToContent = SizeToContent.WidthAndHeight,
            ResizeMode = ResizeMode.NoResize,
            Background = System.Windows.Media.Brushes.Black,
            Foreground = System.Windows.Media.Brushes.White,
            ShowInTaskbar = false
        };
        var panel = new StackPanel { Margin = new Thickness(22), Width = 430 };
        panel.Children.Add(new TextBlock { Text = "OpenAI API key будет сохранён в Windows Credential Manager. Он не передаётся WebView2, не записывается в журнал NOX и не включается в отчёты.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 12) });
        var password = new PasswordBox { MinWidth = 390, Margin = new Thickness(0, 0, 0, 12) };
        panel.Children.Add(password);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var cancel = new Button { Content = "ОТМЕНА", Padding = new Thickness(14, 8, 14, 8), Margin = new Thickness(0, 0, 8, 0) };
        var save = new Button { Content = "СОХРАНИТЬ В WINDOWS", Padding = new Thickness(14, 8, 14, 8) };
        buttons.Children.Add(cancel); buttons.Children.Add(save); panel.Children.Add(buttons);
        dialog.Content = panel;
        cancel.Click += (_, _) => { password.Clear(); dialog.DialogResult = false; };
        save.Click += async (_, _) =>
        {
            var entered = password.Password;
            if (entered.Length < 20 || entered.Length > 512 || entered.Any(char.IsControl))
            {
                password.Clear();
                MessageBox.Show(dialog, "Ключ имеет неподходящий формат. Проверь значение и введи его снова.", "NOX", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                await _openAiSecrets.StoreOpenAiApiKeyAsync(entered);
                password.Clear();
                dialog.DialogResult = true;
            }
            catch
            {
                password.Clear();
                MessageBox.Show(dialog, "Не удалось сохранить ключ в Windows Credential Manager.", "NOX", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        };
        var saved = dialog.ShowDialog() == true;
        if (saved) PostMessage(new { kind = "chatProviderState", state = "READY" });
        else PostMessage(new { kind = "chatProviderState", state = "CANCELLED" });
        return saved;
    }

    private void PersistStoppedChatTurn(string chatId, string userMessage, string partialAssistantMessage)
    {
        lock (_chatLock)
        {
            if (!_chatConversations.TryGetValue(chatId, out var session)) return;
            session.Messages.Add(new ChatMessage { Role = "user", Content = userMessage.Trim() });
            if (!string.IsNullOrEmpty(partialAssistantMessage))
                session.Messages.Add(new ChatMessage { Role = "assistant", Content = partialAssistantMessage });
            if (session.Messages.Count > 40) session.Messages.RemoveRange(0, session.Messages.Count - 40);
            SaveChatConversations();
        }
    }

    private bool SaveChatConversations()
    {
        var temporary = ChatHistoryPath + ".tmp";
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ChatHistoryPath)!);
            File.WriteAllText(temporary, JsonSerializer.Serialize(_chatConversations, new JsonSerializerOptions { WriteIndented = true }));
            File.Move(temporary, ChatHistoryPath, overwrite: true);
            return true;
        }
        catch (Exception ex)
        {
            WriteLog("CHAT_HISTORY_SAVE_FAILED " + ex.GetType().Name);
            try { if (File.Exists(temporary)) File.Delete(temporary); }
            catch (Exception cleanupError) { WriteLog("CHAT_HISTORY_TEMP_CLEANUP_FAILED " + cleanupError.GetType().Name); }
            return false;
        }
    }

    private sealed class ChatConversation
    {
        public string CoreId { get; set; } = "";
        public string PersonaId { get; set; } = "";
        public List<ChatMessage> Messages { get; set; } = new();
    }

    private sealed class ChatMessage
    {
        public string Role { get; set; } = "";
        public string Content { get; set; } = "";
    }

    private void OpenModelCenter()
    {
        if (_modelCenterWindow is { IsVisible: true })
        {
            if (_modelCenterWindow.WindowState == WindowState.Minimized)
                _modelCenterWindow.WindowState = WindowState.Normal;
            _modelCenterWindow.Activate();
            return;
        }

        try
        {
            _modelCenterWindow = (ModelDownloaderWindow)ModelCenterLauncher.CreateWindow(_modelCenterEvents);
            _modelCenterWindow.Owner = this;
            _modelCenterWindow.Closed += (_, _) => _modelCenterWindow = null;
            _modelCenterWindow.Show();
            WriteLog("MODEL_CENTER_OPENED");
        }
        catch (Exception ex)
        {
            WriteLog("MODEL_CENTER_OPEN_FAILED " + ex);
            PostMessage(new { kind = "modelCenter", state = "ERROR", message = "Не удалось открыть центр моделей; подробности в журнале." });
        }
    }

    private void SelectTrainingInput(string? inputKind)
    {
        var picker = new OpenFileDialog
        {
            CheckFileExists = true,
            Multiselect = false,
            Filter = inputKind == "manifest"
                ? "JSON manifest (*.json)|*.json"
                : "JSONL dataset (*.jsonl)|*.jsonl",
            Title = inputKind switch
            {
                "train" => "Выбери обучающую выборку",
                "holdout" => "Выбери holdout выборку",
                "manifest" => "Выбери манифест прав и согласия",
                _ => "Выбери входной файл обучения"
            }
        };
        if (picker.ShowDialog(this) != true) return;
        switch (inputKind)
        {
            case "train": _trainingTrainPath = picker.FileName; break;
            case "holdout": _trainingHoldoutPath = picker.FileName; break;
            case "manifest": _trainingManifestPath = picker.FileName; break;
            default: return;
        }
        PostMessage(new
        {
            kind = "trainingInput",
            inputKind,
            fileName = Path.GetFileName(picker.FileName)
        });
    }

    private async Task InstallTrainingRuntimeAsync()
    {
        if (!await _trainingGate.WaitAsync(0)) return;
        try
        {
            if (File.Exists(Path.Combine(_trainingRuntimeInstaller.EnvironmentPath, "Scripts", "python.exe")))
            {
                PostTrainingState("READY", "Изолированный профиль обучения уже установлен.");
                return;
            }

            var pythonPicker = new OpenFileDialog
            {
                CheckFileExists = true,
                Multiselect = false,
                Filter = "Python 3.12 x64 (python.exe)|python.exe",
                Title = "Выбери установленный Python 3.12 x64"
            };
            if (pythonPicker.ShowDialog(this) != true) return;
            var accepted = MessageBox.Show(this,
                "NOX создаст отдельную виртуальную среду и скачает закреплённые пакеты PyTorch CUDA 12.8, Transformers, TRL, PEFT, Accelerate, Datasets, bitsandbytes и Safetensors из официальных индексов. Ознакомься с лицензиями пакетов перед продолжением. Глобальный Python не изменяется.",
                "NOX · профиль обучения", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (accepted != MessageBoxResult.Yes) return;

            PostTrainingState("RUNNING", "Установка изолированного профиля обучения…");
            await _trainingRuntimeInstaller.InstallNvidiaCuda128Async(
                pythonPicker.FileName,
                userConfirmedProfile: true,
                userAcceptedPackageTerms: true);
            PostTrainingState("READY", "Профиль обучения установлен в отдельную среду NOX.");
        }
        catch (Exception ex)
        {
            WriteLog("TRAINING_RUNTIME_INSTALL_FAILED " + ex.GetType().Name);
            PostTrainingState("HOLD", "Профиль не установлен. Подробности доступны в журнале NOX.");
        }
        finally { _trainingGate.Release(); }
    }

    private async Task StartTrainingAsync(string? modelRevision)
    {
        if (!await _trainingGate.WaitAsync(0))
        {
            PostTrainingState("BUSY", "Обучение или установка профиля уже выполняется.");
            return;
        }

        try
        {
            if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
            if (_trainingTrainPath is null || _trainingHoldoutPath is null || _trainingManifestPath is null ||
                !File.Exists(_trainingTrainPath) || !File.Exists(_trainingHoldoutPath) || !File.Exists(_trainingManifestPath))
                throw new InvalidOperationException("Выбери train.jsonl, holdout.jsonl и manifest согласия.");
            if (!Regex.IsMatch(modelRevision ?? string.Empty, "^[0-9a-fA-F]{40}$", RegexOptions.CultureInvariant))
                throw new InvalidOperationException("Нужен immutable commit SHA модели из 40 символов.");
            var python = Path.Combine(_trainingRuntimeInstaller.EnvironmentPath, "Scripts", "python.exe");
            if (!File.Exists(python)) throw new InvalidOperationException("Сначала установи профиль обучения из блока QLoRA.");

            var confirmation = MessageBox.Show(this,
                $"Запустить локальное QLoRA-обучение Qwen3-0.6B · профиль {_trainingIntensity}? Датасет должен иметь права и согласие, подтверждённые выбранным manifest. Модель будет получена из Hugging Face; обучение требует совместимой NVIDIA GPU и свободного места на диске. Температурный STOP: 83°C, если датчик NVIDIA доступен. STOP пользователя обрабатывается на границе шага.",
                "NOX · подтверждение обучения", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (confirmation != MessageBoxResult.Yes) return;

            var runToken = Guid.NewGuid().ToString("N");
            var runRoot = Path.Combine(_data, "training", "runs");
            var eventRoot = Path.Combine(_data, "training", "worker-events");
            var cancelRoot = Path.Combine(_data, "training", "cancel");
            Directory.CreateDirectory(runRoot);
            Directory.CreateDirectory(eventRoot);
            Directory.CreateDirectory(cancelRoot);
            var output = Path.Combine(runRoot, DateTime.UtcNow.ToString("yyyyMMdd_HHmmss") + "_" + runToken);
            var workerEvents = Path.Combine(eventRoot, runToken + ".jsonl");
            var cancelMarker = Path.Combine(cancelRoot, runToken + ".stop");
            _trainingCancelMarker = cancelMarker;

            var script = Path.Combine(AppContext.BaseDirectory, "Packages", "P04", "train_qlora.py");
            if (!File.Exists(script)) throw new FileNotFoundException("QLoRA worker is missing from the installed files.");
            var startInfo = new ProcessStartInfo
            {
                FileName = python,
                WorkingDirectory = runRoot,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            startInfo.ArgumentList.Add(script);
            startInfo.ArgumentList.Add("--model-revision"); startInfo.ArgumentList.Add(modelRevision!);
            startInfo.ArgumentList.Add("--run-id"); startInfo.ArgumentList.Add(_eventV3Bridge.RunId);
            startInfo.ArgumentList.Add("--train-jsonl"); startInfo.ArgumentList.Add(_trainingTrainPath);
            startInfo.ArgumentList.Add("--holdout-jsonl"); startInfo.ArgumentList.Add(_trainingHoldoutPath);
            startInfo.ArgumentList.Add("--dataset-manifest"); startInfo.ArgumentList.Add(_trainingManifestPath);
            startInfo.ArgumentList.Add("--output-dir"); startInfo.ArgumentList.Add(output);
            startInfo.ArgumentList.Add("--events-jsonl"); startInfo.ArgumentList.Add(workerEvents);
            startInfo.ArgumentList.Add("--cancel-marker"); startInfo.ArgumentList.Add(cancelMarker);
            startInfo.ArgumentList.Add("--intensity-profile"); startInfo.ArgumentList.Add(_trainingIntensity);
            startInfo.ArgumentList.Add("--thermal-stop-c"); startInfo.ArgumentList.Add("83");
            startInfo.Environment["HF_HUB_DISABLE_TELEMETRY"] = "1";
            startInfo.Environment["NO_COLOR"] = "1";

            _trainingWorker = _gpuGuardian.StartNoxWorker("P04-" + runToken, startInfo, new TrainingWorkerControl(cancelMarker));
            PostTrainingState("RUNNING", "QLoRA работает. Шаги и receipt появятся в журнале после получения от worker.");

            var stdoutTask = _trainingWorker.ReadStandardOutputToEndAsync();
            var stderrTask = _trainingWorker.ReadStandardErrorToEndAsync();
            await _trainingWorker.WaitForExitAsync();
            var stdout = await stdoutTask;
            var stderr = await stderrTask;
            ImportTrainingEvents(workerEvents);

            var receiptPath = Path.Combine(output, "training-receipt.json");
            var workerState = ReadTrainingWorkerState(stdout) ?? ReadTrainingWorkerState(stderr);
            if (_trainingWorker.ExitCode == 0 && File.Exists(receiptPath) && workerState == "COMPLETED")
            {
                PostMessage(new { kind = "trainingFinished", state = "COMPLETED", receipt = receiptPath, output = stdout.Length > 500 ? stdout[..500] : stdout });
                PostTrainingState("COMPLETED", "Receipt сохранён локально; независимая проверка адаптера ещё нужна.");
            }
            else if (workerState is "HOLD" or "STOPPED")
            {
                PostMessage(new { kind = "trainingFinished", state = workerState, receipt = File.Exists(receiptPath) ? receiptPath : null });
                PostTrainingState(workerState, workerState == "HOLD"
                    ? "Обучение остановлено защитой; проверь температуру GPU и журнал."
                    : "Обучение остановлено; проверь checkpoint и журнал.");
            }
            else
            {
                PostMessage(new { kind = "trainingFinished", state = "ERROR" });
                PostTrainingState("ERROR", "Обучение завершилось без подтверждённого receipt; смотри локальный журнал.");
            }
        }
        catch (Exception ex)
        {
            WriteLog("TRAINING_RUN_FAILED " + ex.GetType().Name);
            AppendRuntimeV3("task.failed", "P04-" + Guid.NewGuid().ToString("N"), "qlora_qwen3_0_6b", "ERROR",
                "Training host could not start or complete the worker.", "P04.QLoRA", packageId: "P04");
            PostTrainingState("HOLD", "Обучение не запущено или остановилось. Проверь входные данные, GPU и журнал.");
        }
        finally
        {
            if (_trainingWorker is not null)
            {
                try { await _trainingWorker.DisposeAsync(); } catch { }
            }
            _trainingWorker = null;
            _trainingCancelMarker = null;
            _trainingGate.Release();
        }
    }

    private static string? ReadTrainingWorkerState(string output)
    {
        foreach (var line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Reverse())
        {
            try
            {
                using var document = JsonDocument.Parse(line);
                if (document.RootElement.TryGetProperty("status", out var status) && status.ValueKind == JsonValueKind.String)
                    return status.GetString();
            }
            catch (JsonException) { }
        }
        return null;
    }

    private async void StopTraining()
    {
        var marker = _trainingCancelMarker;
        var worker = _trainingWorker;
        if (marker is null || worker is null || worker.HasExited)
        {
            PostTrainingState("IDLE", "Активного обучения нет.");
            return;
        }
        try
        {
            await File.WriteAllTextAsync(marker, "STOP\n");
            PostTrainingState("STOP_REQUESTED", "STOP запрошен; worker завершит текущий шаг и сохранит checkpoint.");
        }
        catch (Exception ex)
        {
            WriteLog("TRAINING_STOP_FAILED " + ex.GetType().Name);
            PostTrainingState("HOLD", "Не удалось подтвердить STOP обучения; смотри журнал.");
        }
    }

    private void ImportTrainingEvents(string path)
    {
        if (!File.Exists(path)) return;
        foreach (var line in File.ReadLines(path))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            try
            {
                using var document = JsonDocument.Parse(line);
                var root = document.RootElement;
                if (GetString(root, "schema") != "NOX-INSTALLER-EVENT-v3" || GetString(root, "package_id") != "P04") continue;
                var eventType = GetString(root, "event_type");
                var allowed = new HashSet<string>(StringComparer.Ordinal)
                    { "task.started", "task.progress", "task.completed", "task.failed", "training.step", "checkpoint.saved", "model.stopped" };
                if (eventType is null || !allowed.Contains(eventType)) continue;
                var action = GetString(root, "action_id") ?? "training_event";
                var state = GetString(root, "state") ?? "N_D";
                var message = GetString(root, "message") ?? "QLoRA worker event.";
                long? numerator = root.TryGetProperty("numerator", out var n) && n.TryGetInt64(out var nv) ? nv : null;
                long? denominator = root.TryGetProperty("denominator", out var d) && d.TryGetInt64(out var dv) ? dv : null;
                AppendRuntimeV3(eventType, GetString(root, "task_id") ?? "P04-worker", action, state,
                    message, "P04.QLoRA", numerator, denominator, "P04");
            }
            catch (JsonException) { /* Ignore an incomplete final worker line. */ }
        }
    }

    private void PostTrainingState(string state, string message) =>
        PostMessage(new { kind = "trainingState", state, message });

    private sealed class TrainingWorkerControl(string cancelMarker) : INoxWorkerControl
    {
        public Task<bool> PauseAsync(CancellationToken cancellationToken) => Task.FromResult(false);
        public Task<bool> ResumeAsync(CancellationToken cancellationToken) => Task.FromResult(false);
        public async Task RequestStopAsync(CancellationToken cancellationToken)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(cancelMarker)!);
            await File.WriteAllTextAsync(cancelMarker, "STOP\n", cancellationToken);
        }
    }

    private void OnModelCenterEvent(object? sender, ModelCenterEvent sourceEvent)
    {
        var result = _eventV3Bridge.PublishModelCenter(sourceEvent);
        Dispatcher.BeginInvoke(() =>
        {
            PostMessage(new { kind = "installerEvent", result.Event, journalWritten = result.JournalWritten });
            if (!result.JournalWritten) WriteLog("EVENT_V3_JOURNAL_WRITE_FAILED");
        });
    }

    private void ReadMainSnapshot()
    {
        var path = Path.Combine(_data, "reports", "MAIN_ACCEPTANCE_SNAPSHOT.json");
        if (!File.Exists(path)) path = Path.Combine(AppContext.BaseDirectory, "Assets", "MAIN_ACCEPTANCE_SNAPSHOT.json");
        try
        {
            if (!File.Exists(path)) { PostMessage(new { kind = "mainSnapshot", result = new { snapshotUtc = (string?)null, acceptedProgress = (double?)null, verified = (int?)null } }); return; }
            using var doc = JsonDocument.Parse(File.ReadAllText(path));
            var root = doc.RootElement;
            if (!root.TryGetProperty("source", out var source) || source.GetString() != "MAIN_ACCEPTANCE") throw new InvalidDataException("Invalid snapshot source");
            if (!root.TryGetProperty("snapshotUtc", out var stamp) || !DateTimeOffset.TryParse(stamp.GetString(), out var parsedStamp)) throw new InvalidDataException("Invalid timestamp");
            if (DateTimeOffset.UtcNow - parsedStamp.ToUniversalTime() > TimeSpan.FromHours(24) || parsedStamp.ToUniversalTime() > DateTimeOffset.UtcNow.AddMinutes(5)) throw new InvalidDataException("Stale or future MAIN snapshot; accepted progress must remain N/D");
            PostMessage(new { kind = "mainSnapshot", result = root.Clone() });
        }
        catch (Exception ex) { WriteLog("MAIN_SNAPSHOT_ERROR " + ex.Message); PostMessage(new { kind = "mainSnapshot", result = new { snapshotUtc = (string?)null, acceptedProgress = (double?)null, verified = (int?)null } }); }
    }
    private async Task RefreshTelemetryAsync()
    {
        try
        {
            string state = "OFFLINE";
            int? count = null;
            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(3) };
            try
            {
                using var response = await http.GetAsync("http://127.0.0.1:11434/api/tags");
                if (response.IsSuccessStatusCode)
                {
                    using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
                    if (doc.RootElement.TryGetProperty("models", out var models) && models.ValueKind == JsonValueKind.Array)
                    { state = "ONLINE"; count = models.GetArrayLength(); }
                }
            }
            catch (HttpRequestException) { }
            catch (TaskCanceledException) { }
            var gpu = (await _gpuGuardian.ReadNvidiaAsync()).FirstOrDefault(x => x.State == "READY");
            string? gpuName = gpu?.Name;
            double? util = gpu?.UtilizationPercent;
            string? memory = gpu is { MemoryUsedMiB: not null, MemoryTotalMiB: not null }
                ? $"{gpu.MemoryUsedMiB} / {gpu.MemoryTotalMiB} MiB" : null;
            double? temp = gpu?.TemperatureC;
            PostMessage(new { kind = "telemetry", result = new { utc = DateTimeOffset.Now.ToString("HH:mm:ss"), ollama = new { state, modelCount = count, installed = FindCommand("ollama.exe") != null ? "FOUND" : "NOT_FOUND" }, python = new { state = FindCommand("python.exe") != null ? "FOUND" : "NOT_FOUND" }, gpu = new { name = gpuName, utilization = util, memory, temperature = temp } } });
        }
        catch (Exception ex) { WriteLog("TELEMETRY_ERROR " + ex); PostMessage(new { kind = "telemetry", result = new { utc = DateTimeOffset.Now.ToString("HH:mm:ss") } }); }
    }

    private void SendStatus()
    {
        var status = new { kind = "hostStatus", webview2 = View.CoreWebView2 == null ? "OFFLINE" : "READY", fullscreen = _fullScreen, acceptedProgress = (double?)null, productGate = "BLOCKED", reportGate = "PENDING", runtime = Environment.Version.ToString(), diagnostics = "AVAILABLE", trainingIntensity = _trainingIntensity };
        View.CoreWebView2?.PostWebMessageAsJson(JsonSerializer.Serialize(status));
    }
    private async Task RunDiagnosticsAsync(string? packRequestId = null)
    {
        if (_busy)
        {
            if (packRequestId != null) PostMessage(new {kind="packResult",requestId=packRequestId,routeId="models.preflight",state="HOLD",message="Diagnostics busy"});
            return;
        }
        _busy = true;
        PostMessage(new { kind = "diagnostics", state = "RUNNING" });
        try
        {
            // Read-only inventory: no package installations, no arbitrary shell commands.
            var browserVersion = View.CoreWebView2?.Environment.BrowserVersionString ?? "NOT_READY";
            var result = await Task.Run(() => new
            {
                utc = DateTimeOffset.UtcNow,
                windows = Environment.OSVersion.VersionString,
                cpu = Environment.ProcessorCount,
                dotnet = Environment.Version.ToString(),
                python = FindCommand("python.exe"),
                ollama = FindCommand("ollama.exe"),
                git = FindCommand("git.exe"),
                nvidiaSmi = FindCommand("nvidia-smi.exe"),
                webview2 = browserVersion,
                installedModules = new { python = FindCommand("python.exe") != null, ollama = FindCommand("ollama.exe") != null },
                acceptedWebProgress = (double?)null,
                releaseGate = "BLOCKED"
            });
            var dir = Path.Combine(_data, "reports");
            Directory.CreateDirectory(dir);
            var path = Path.Combine(dir, "P01_DIAGNOSTICS_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".json");
            File.WriteAllText(path, JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
            WriteLog("DIAGNOSTICS " + path);
            PostMessage(new { kind = "diagnostics", state = "SUCCESS", path, result });
            if (packRequestId != null) PostMessage(new {kind="packResult",requestId=packRequestId,routeId="models.preflight",state="COMPLETED",result, message="Read-only Windows prerequisites"});
        }
        catch (Exception ex)
        {
            WriteLog("DIAGNOSTICS_FAIL " + ex);
            PostMessage(new { kind = "diagnostics", state = "ERROR", error = ex.Message });
            if (packRequestId != null) PostMessage(new {kind="packResult",requestId=packRequestId,routeId="models.preflight",state="HOLD",message="Diagnostics unavailable"});
        }
        finally { _busy = false; }
    }
    private static string? FindCommand(string name)
    {
        var path = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var segment in path.Split(Path.PathSeparator))
        {
            try
            {
                var candidate = Path.Combine(segment.Trim('"'), name);
                if (File.Exists(candidate)) return candidate;
            }
            catch { }
        }
        return null;
    }
    private void PostMessage(object message)
    {
        try { View.CoreWebView2?.PostWebMessageAsJson(JsonSerializer.Serialize(message)); }
        catch (Exception ex) { WriteLog("POST_MESSAGE_FAIL " + ex.Message); }
    }
    private void OpenDataFolder()
    {
        try { Directory.CreateDirectory(_data); Process.Start(new ProcessStartInfo("explorer.exe", "\"" + _data + "\"") { UseShellExecute = true }); }
        catch (Exception ex) { WriteLog("OPEN_DATA_FAIL " + ex.Message); }
    }
    private async Task SaveReportAsync()
    {
        try
        {
            var reports = Path.Combine(_data, "reports");
            Directory.CreateDirectory(reports);
            var jsonl = File.Exists(_eventV3Bridge.JournalPath)
                ? await File.ReadAllTextAsync(_eventV3Bridge.JournalPath)
                : string.Empty;
            var snapshot = InstallerRunReportBuilder.CreateSnapshot(jsonl, _eventV3Bridge.RunId);
            var stem = "INSTALLER_RUN_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            var jsonPath = Path.Combine(reports, stem + ".json");
            var htmlPath = Path.Combine(reports, stem + ".html");
            var markdownPath = Path.Combine(reports, stem + ".md");
            await InstallerRunReportBuilder.WriteJsonAsync(snapshot, jsonPath);
            await InstallerRunReportBuilder.WriteHtmlAsync(snapshot, htmlPath);
            await InstallerRunReportBuilder.WriteMarkdownAsync(snapshot, markdownPath);
            WriteLog("INSTALLER_REPORT_SAVED " + stem);
            PostMessage(new { kind = "reportSaved", path = jsonPath, html = htmlPath, markdown = markdownPath, runId = snapshot.RunId, events = snapshot.SourceEventCount, acceptedProgress = snapshot.AcceptedReadinessPercent });
        }
        catch (Exception ex)
        {
            WriteLog("INSTALLER_REPORT_FAILED " + ex.GetType().Name);
            PostMessage(new { kind = "reportSaved", state = "ERROR", message = "Не удалось сформировать отчёт установщика." });
        }
    }

    private void CancelAction()
    {
        try { if (_actionProcess is { HasExited: false }) { _actionProcess.Kill(entireProcessTree: true); _actionCancelRequested = true; WriteLog("ACTION_STOP_REQUESTED"); PostMessage(new { kind="action", state="STOP_REQUESTED" }); } }
        catch (Exception ex) { WriteLog("CANCEL_FAIL " + ex.Message); }
    }
    private async Task RunActionAsync(string action)
    {
        if (!await _actionGate.WaitAsync(0)) { PostMessage(new { kind="action", state="BUSY" }); return; }
        var taskId = "P03-action-" + Guid.NewGuid().ToString("N");
        _actionCancelRequested = false;
        try
        {
            var script = Path.Combine(AppContext.BaseDirectory, "Modules", "NoxActions.ps1");
            if (!File.Exists(script)) throw new FileNotFoundException("Missing action module", script);
            PostMessage(new { kind="action", state="RUNNING", action });
            AppendRuntimeV3("task.started", taskId, action, "RUNNING", "Installer action started.", "P03.NoxActions");
            WriteLog("ACTION_START " + action);
            var psi = new ProcessStartInfo("powershell.exe") { UseShellExecute=false, CreateNoWindow=true, RedirectStandardOutput=true, RedirectStandardError=true };
            psi.ArgumentList.Add("-NoProfile"); psi.ArgumentList.Add("-NonInteractive"); psi.ArgumentList.Add("-ExecutionPolicy"); psi.ArgumentList.Add("Bypass"); psi.ArgumentList.Add("-File"); psi.ArgumentList.Add(script); psi.ArgumentList.Add("-Action"); psi.ArgumentList.Add(action);
            using var p = new Process { StartInfo=psi }; _actionProcess=p;
            if (!p.Start()) throw new InvalidOperationException("PowerShell failed to start");
            var stdout = p.StandardOutput.ReadToEndAsync(); var stderr = p.StandardError.ReadToEndAsync();
            await p.WaitForExitAsync();
            var output = await stdout; var error = await stderr;
            WriteLog($"ACTION_END {action} exit={p.ExitCode} stdout={output} stderr={error}");
            if (_actionCancelRequested)
                AppendRuntimeV3("model.stopped", taskId, action, "STOPPED", "Installer process exited after user cancellation.", "P03.NoxActions");
            else if (p.ExitCode == 0)
                AppendRuntimeV3("task.completed", taskId, action, "COMPLETED", "Installer action process completed.", "P03.NoxActions");
            else
                AppendRuntimeV3("task.failed", taskId, action, "ERROR", "Installer action process failed; details are in the protected local log.", "P03.NoxActions");
            var actionState = _actionCancelRequested ? "CANCELLED" : p.ExitCode == 0 ? "SUCCESS" : "ERROR";
            var actionMessage = _actionCancelRequested ? "Операция остановлена." : (p.ExitCode==0?output:error).Trim();
            PostMessage(new { kind="action", state=actionState, action, exitCode=p.ExitCode, message=actionMessage.Substring(0, Math.Min(400, actionMessage.Length)) });
        }
        catch (Exception ex) { AppendRuntimeV3("task.failed", taskId, action, "ERROR", "Installer action could not start; details are in the protected local log.", "P03.NoxActions"); WriteLog("ACTION_FAIL " + action + " " + ex); PostMessage(new { kind="action", state="ERROR", action, message=ex.Message }); }
        finally { _actionProcess=null; _actionCancelRequested=false; _actionGate.Release(); }
    }

    private void ToggleFullscreen() => SetFullscreen(!_fullScreen);
    private void SetFullscreen(bool enabled)
    {
        if (enabled == _fullScreen) return;
        if (enabled)
        {
            _previousState = WindowState; _previousStyle = WindowStyle; _previousResize = ResizeMode;
            WindowState = WindowState.Normal; WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize;
            WindowState = WindowState.Maximized; _fullScreen = true;
        }
        else
        {
            WindowState = WindowState.Normal; WindowStyle = _previousStyle; ResizeMode = _previousResize;
            WindowState = _previousState; _fullScreen = false;
        }
        WriteLog("FULLSCREEN " + _fullScreen);
        SendStatus();
    }
    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F11 || (e.Key == Key.Escape && _fullScreen)) { ToggleFullscreen(); e.Handled = true; }
    }
    private void OpenLog_Click(object sender, RoutedEventArgs e) => OpenLog();
    private void OpenLog()
    {
        try { Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + LogPath + "\"") { UseShellExecute = true }); }
        catch (Exception ex) { WriteLog("OPEN_LOG_FAIL " + ex.Message); }
    }
}
