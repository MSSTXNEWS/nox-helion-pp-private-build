#!/usr/bin/env bash
# ID: PV-04
# ЦЕЛЬ: навык «Сравни этот файл с ТЗ проекта»: предложил команду -> результат -> сохранил навык -> повтор на втором файле без вызова большой модели.
# СЕРВЕР: S2 (живой контур NOX на S2; исполнитель - TOOLS)
# ЗАВИСИМОСТИ: PV-02
# ГОТОВО: повтор на втором файле без вызова большой модели (счётчик вызовов в сценарии не вырос).
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА (не выдумываются): NOX_RESONANCE_URL; сценарий $NOX_ROOT/scenarios/PV-04.json с шагами-тегами: suggest,result,save_skill,repeat_second_file,zero_big_model_calls (формат - в шапке lib/nox_scenario.py).
#   Без сценария скрипт сохраняет openapi.json контура (если отдаётся) в $NOX_ROOT/discovery/ и честно отвечает BLOCKED. Это скрипт приёмки: он ПРОВЕРЯЕТ, а не меняет контур.
# ИСТОЧНИКИ:
#   Drive: WEB WOW 1ehfJwSO... (ID неполный; уточнить на Диске)
#   Интернет: нет
#   Генерируется: reports/PV-04.scenario.json (результат каждого шага)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_scen.sh"
nox_begin PV-04 S2 "$@"
NOX_PLAN="выполнить сценарий приёмки PV-04 (теги: suggest,result,save_skill,repeat_second_file,zero_big_model_calls) против $NOX_RESONANCE_URL"
nox_scenario_task PV-04 "suggest,result,save_skill,repeat_second_file,zero_big_model_calls"
