#!/usr/bin/env bash
# ID: P1-14
# ЦЕЛЬ: режимы GPU: persistence (-pm 1), power limit = max, фиксация частот (-lgc) если разрешено.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-05
# ГОТОВО: применено или записано "нет прав" (run/gpu_modes.json) для каждого параметра.
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: run/gpu_modes.json, бэкап прежних значений
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-14 S1 "$@"
NOX_PLAN="сохранить текущие pm/pl/lgc; применить -pm 1, -pl max, -lgc; при отказе записать 'нет прав'"
t_pre() { nox_need_cmd nvidia-smi python3; }
t_backup() { nvidia-smi --query-gpu=persistence_mode,power.limit,clocks.max.sm --format=csv,noheader >"$NOX_RUN_DIR/P1-14.prev"; }
t_do() {
  local res="" pmax cmax
  if nvidia-smi -pm 1 >>"$NOX_LOGFILE" 2>&1; then res+="pm=applied;"; else res+="pm=нет прав;"; fi
  pmax="$(nvidia-smi --query-gpu=power.max_limit --format=csv,noheader,nounits | head -1 | cut -d. -f1 | tr -d ' ')"
  if [ -n "$pmax" ] && nvidia-smi -pl "$pmax" >>"$NOX_LOGFILE" 2>&1; then res+="pl=$pmax;"; else res+="pl=нет прав;"; fi
  cmax="$(nvidia-smi --query-supported-clocks=gr --format=csv,noheader,nounits 2>/dev/null | sort -n | tail -1 | tr -d ' ')"
  if [ -n "$cmax" ] && nvidia-smi -lgc "${NOX_LGC_MIN:-$cmax},$cmax" >>"$NOX_LOGFILE" 2>&1; then res+="lgc=${NOX_LGC_MIN:-$cmax},$cmax;"; else res+="lgc=нет прав;"; fi
  printf '{"t":"%s","result":"%s"}\n' "$(date -u +%FT%TZ)" "$res" >"$NOX_RUN_DIR/gpu_modes.json"
}
t_rollback() { nvidia-smi -rgc >/dev/null 2>&1 || true; }
t_check() {
  nox_chk "gpu_modes.json записан" test -s "$NOX_RUN_DIR/gpu_modes.json"
  nox_chk "каждый параметр: применён или 'нет прав'" grep -Eq 'pm=(applied|нет прав);pl=([0-9]+|нет прав);lgc=' "$NOX_RUN_DIR/gpu_modes.json"
  nox_verdict
}
nox_run_task
