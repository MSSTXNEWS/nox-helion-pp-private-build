#!/usr/bin/env bash
# ID: P1-16
# ЦЕЛЬ: S2: сверка фактического стека обучения на V100 и фиксация окружения (lock); smoke forward+backward в fp16 на sm_70.
# СЕРВЕР: S2
# ЗАВИСИМОСТИ: P1-02
# ГОТОВО: torch импортируется, arch list содержит sm_70, CUDA-сборка не 13.x, TF32 выключен; fp16 forward+backward на GPU проходит без NaN; pip freeze сохранён с SHA в $NOX_ROOT/locks/s2_train.freeze. Версия torch записывается как факт (канон: конфликт "2.14.1 cu126" на Диске против установленного "2.6.0+cu124" - решает факт, а не документ).
# ИСТОЧНИКИ:
#   Drive: V4П часть 5 (программа 16.11): 1BlD1_gtzd7YKDdkM07i0Iubz-ZagYuIxchiSojy2Ce0 (справка, не обязательна)
#   Интернет: нет (ничего не устанавливается и не обновляется)
#   Генерируется: locks/s2_train.freeze, locks/s2_train.freeze.sha256, reports/P1-16_torch.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-16 S2 "$@"
NOX_PLAN="python: версии/arch list/TF32; fp16 fwd+bwd; pip freeze -> locks"
LOCK="$NOX_ROOT/locks/s2_train.freeze"
t_pre() { nox_need_cmd python3 pip3 nvidia-smi; python3 -c 'import torch' 2>/dev/null || nox_blocked "torch не установлен в python3" "окружение обучения S2 (путь к python/venv с torch)"; }
t_do() { mkdir -p "$(dirname "$LOCK")"; pip3 freeze >"$LOCK" && sha256sum "$LOCK" >"$LOCK.sha256"; }
t_check() {
  python3 -B - "$NOX_REPORT_DIR/P1-16_torch.json" <<'PY' || { nox_log NO "проверка torch не прошла"; NOX_NFAIL=$((NOX_NFAIL+1)); NOX_FAILS+="torch; "; return 1; }
import json, sys, torch
r = {"torch": torch.__version__, "cuda": torch.version.cuda, "arch_list": torch.cuda.get_arch_list(), "cuda_available": torch.cuda.is_available()}
r["tf32_matmul"] = torch.backends.cuda.matmul.allow_tf32
if r["cuda_available"]:
    r["capability"] = list(torch.cuda.get_device_capability(0))
    torch.manual_seed(0); m = torch.nn.Linear(256, 256).cuda(); x = torch.randn(64, 256, device="cuda")
    with torch.autocast("cuda", dtype=torch.float16):
        y = m(x).float().pow(2).mean()
    y.backward(); r["smoke_loss"] = float(y); r["smoke_grad_finite"] = bool(torch.isfinite(m.weight.grad).all())
json.dump(r, open(sys.argv[1], "w"), indent=1)
PY
  local j="$NOX_REPORT_DIR/P1-16_torch.json"; get() { python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get(sys.argv[2]))' "$j" "$1"; }
  nox_metric torch "$(get torch)"; nox_metric cuda_build "$(get cuda)"; nox_metric matches_program_16_11 "$([ "$(get torch)" = "2.6.0+cu124" ] && echo yes || echo no)"
  nox_chk "CUDA доступна" test "$(get cuda_available)" = True
  nox_chk "arch list содержит sm_70" python3 -c 'import json,sys;sys.exit(0 if "sm_70" in json.load(open(sys.argv[1]))["arch_list"] else 1)' "$j"
  nox_chk "capability 7.0" test "$(get capability)" = "[7, 0]"
  nox_chk "CUDA-сборка не 13.x" bash -c "[ \"\$(python3 -c 'import json;print(json.load(open(\"$j\"))[\"cuda\"])' | cut -d. -f1)\" != 13 ]"
  nox_chk "TF32 выключен" test "$(get tf32_matmul)" = False
  nox_chk "fp16 forward+backward без NaN" test "$(get smoke_grad_finite)" = True
  nox_chk "lock окружения записан" test -s "$LOCK"
  nox_verdict
}
nox_run_task
