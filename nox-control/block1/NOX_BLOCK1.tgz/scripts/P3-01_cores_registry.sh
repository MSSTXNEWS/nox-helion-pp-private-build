#!/usr/bin/env bash
# ID: P3-01
# ЦЕЛЬ: реестр ядер config/cores.yaml (C01-C08) с единым active_model_id и guard: второй активный endpoint главной модели = красное событие.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-11
# ГОТОВО: cores.yaml записан и проходит проверку; тест двух endpoint (синтетический реестр) обнаруживается; реальные процессы - один main endpoint; guard стоит в cron раз в минуту.
# ИСТОЧНИКИ:
#   Drive: нет (названия и назначение ядер - канон 2.2, зашиты в lib/nox_cores.py; уточнения FO/ЧК - решение исполнителя FORGE)
#   Интернет: нет
#   Генерируется: config/cores.yaml (JSON-совместимый YAML), /etc/cron.d/nox_endpoint_guard
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P3-01 S1 "$@"
NOX_PLAN="записать cores.yaml (main=GLM по run/llama_build/args, судья из fast_tier.json); selftest guard; check по живым процессам; cron"
REG="$NOX_ROOT/config/cores.yaml"
t_pre() { nox_need_receipt P1-11; nox_need_cmd python3; }
t_backup() { nox_backup "$REG" /etc/cron.d/nox_endpoint_guard; }
t_rollback() { nox_restore || true; }
t_do() {
  mkdir -p "$NOX_ROOT/config"
  local j=""; [ -s "$NOX_RUN_DIR/fast_tier.json" ] && j="http://$NOX_LLAMA_HOST:$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/fast_tier.json"))["ports"]["judge"])')"
  python3 -B "$NOX_LIB_DIR/nox_cores.py" write "$REG" "$NOX_LLAMA_URL" "glm-5.3-ud-q4_k_xl" $j
  command -v cron >/dev/null 2>&1 && printf '* * * * * root python3 -B %s check %s || true\n' "$NOX_LIB_DIR/nox_cores.py" "$REG" >/etc/cron.d/nox_endpoint_guard || nox_log WARN "cron отсутствует: guard запускать из watchdog/вручную"
}
t_check() {
  nox_chk "cores.yaml существует и парсится" python3 -c 'import json,sys;d=json.load(open(sys.argv[1]));assert len(d["cores"])==8 and d["active_model_id"]' "$REG"
  nox_chk "тест двух endpoint: нарушение обнаружено" python3 -B "$NOX_LIB_DIR/nox_cores.py" selftest
  if ! python3 -B "$NOX_LIB_DIR/nox_cores.py" check "$REG" >>"$NOX_LOGFILE" 2>&1; then nox_red_event "второй активный endpoint главной модели"; nox_log NO "реальные процессы нарушают единый endpoint"; NOX_NFAIL=$((NOX_NFAIL+1)); fi
  nox_metric live_main_ports "$(python3 -B -c 'import sys;sys.path.insert(0,"'"$NOX_LIB_DIR"'");import nox_cores;print(",".join(sorted(set(nox_cores.live_main_ports()))))')"
  nox_verdict
}
nox_run_task
