#!/usr/bin/env bash
# ID: P1-04
# ЦЕЛЬ: F1 - до скачивания 467 ГБ доказать, что 20 ГБ в RAM читаются через mmap без второй копии (/dev/shm+симлинк или memfd).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-03
# ГОТОВО: 20 блоков-ГиБ читаются через mmap, 0 битых блоков, рост Shmem при чтении < 1 ГиБ; режим (shm|memfd) записан. Провал -> менять инстанс.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет (python3 stdlib)
#   Генерируется: /dev/shm/t20.bin + /root/nox/t20.bin (удаляются после теста, чтобы не занимать 20 ГБ RAM)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-04 S1 "$@"
NOX_PLAN="если /dev/shm >= 22 ГБ: файл 20 ГиБ + симлинк, иначе memfd; чтение через mmap; сравнение Shmem до/после"
t_pre() { nox_need_cmd python3 df; nox_need_ram_free $((23*1024*1024*1024)); }
t_check() {
  local free mode out
  free="$(df -B1 --output=avail /dev/shm | tail -1 | tr -d ' ')"
  if [ "$free" -ge $((22*1024*1024*1024)) ]; then mode=shm; else mode=memfd; fi
  nox_log INFO "режим теста: $mode (свободно в /dev/shm: $((free/1000000000)) ГБ)"
  rm -f /dev/shm/t20.bin "$NOX_ROOT/t20.bin"
  out="$(python3 -B "$NOX_LIB_DIR/nox_memfd_test.py" "$mode" 20 /dev/shm/t20.bin "$NOX_ROOT/t20.bin")" || { nox_log NO "тест завершился ошибкой"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
  nox_log INFO "$out"
  local bad sh
  bad="$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["bad_blocks"])' "$out")"; sh="$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["shmem_delta_gib"])' "$out")"
  nox_metric mode "$mode"; nox_metric bad_blocks "$bad"; nox_metric shmem_delta_gib "$sh"
  nox_metric write_s "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["write_s"])' "$out")"
  nox_chk "0 битых блоков через mmap" test "$bad" -eq 0
  nox_chk "нет второй копии (Shmem delta < 1 ГиБ)" nox_le "$sh" 1
  [ "$mode" = shm ] || nox_log WARN "/dev/shm мал: основная загрузка пойдёт через memfd-держатель (P2-01), держатель нельзя убивать"
  nox_verdict
}
nox_run_task
