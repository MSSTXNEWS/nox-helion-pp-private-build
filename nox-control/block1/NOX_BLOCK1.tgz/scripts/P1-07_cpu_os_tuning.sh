#!/usr/bin/env bash
# ID: P1-07
# ЦЕЛЬ: governor=performance, numa_balancing=0 (если есть права), расчёт -t/-tb и наборов ядер для taskset; замер полосы RAM до/после.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-03
# ГОТОВО: параметры в журнале (применено или честно "нет прав"), $NOX_ROOT/run/cpu_plan.json, STREAM до/после (после не хуже 90% до).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: apt: linux-tools-generic (cpupower, необязательно), numactl (необязательно)
#   Генерируется: run/cpu_plan.json (t = физ.ядра-2, tb = vCPU, chat_cpus, fast_cpus), бэкап прежних значений sysctl/governor
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-07 S1 "$@"
NOX_PLAN="сохранить старые значения; governor=performance; kernel.numa_balancing=0; cpu_plan.json; STREAM до/после"
NB=/proc/sys/kernel/numa_balancing
t_pre() { nox_need_cmd lscpu gcc python3; }
t_backup() { { echo "numa_balancing=$(cat $NB 2>/dev/null || echo NA)"; for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do [ -r "$g" ] && echo "$g=$(cat "$g")"; done; } >"$NOX_RUN_DIR/P1-07.prev"
  nox_stream_gbs >"$NOX_RUN_DIR/P1-07.stream_before" || true; }
t_do() {
  if [ -w "$NB" ]; then echo 0 >"$NB" && nox_log INFO "numa_balancing=0 применено"; else nox_log WARN "numa_balancing: нет прав (пропуск без повторов)"; fi
  local g n=0 ok=0; for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do [ -w "$g" ] || continue; n=$((n+1)); echo performance >"$g" 2>/dev/null && ok=$((ok+1)); done
  [ "$n" -eq 0 ] && nox_log WARN "governor: интерфейс cpufreq недоступен/нет прав (пропуск)" || nox_log INFO "governor performance: $ok/$n ядер"
  python3 -B "$NOX_LIB_DIR/nox_cpuplan.py" "$NOX_RUN_DIR/cpu_plan.json" >>"$NOX_LOGFILE"
}
t_rollback() { local v; v="$(sed -n 's/^numa_balancing=//p' "$NOX_RUN_DIR/P1-07.prev" 2>/dev/null)"; [ -n "$v" ] && [ "$v" != NA ] && [ -w "$NB" ] && echo "$v" >"$NB" || true
  grep '^/sys' "$NOX_RUN_DIR/P1-07.prev" 2>/dev/null | while IFS="=" read -r f val; do [ -w "$f" ] && echo "$val" >"$f" || true; done; }
t_check() {
  nox_chk "cpu_plan.json существует" test -s "$NOX_RUN_DIR/cpu_plan.json"
  [ -s "$NOX_RUN_DIR/cpu_plan.json" ] || return 1
  local t tb a b nb gov
  t="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/cpu_plan.json"))["t"])')"; tb="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/cpu_plan.json"))["tb"])')"
  nb="$(cat $NB 2>/dev/null || echo NA)"; gov="$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo "нет cpufreq")"
  nox_metric t_threads "$t"; nox_metric tb_threads "$tb"; nox_metric numa_balancing "$nb"; nox_metric governor "$gov"
  a="$(cat "$NOX_RUN_DIR/P1-07.stream_before" 2>/dev/null || true)"; b="$(nox_stream_gbs)"
  nox_metric stream_before_gbs "${a:-NA}"; nox_metric stream_after_gbs "$b"
  [ -n "$a" ] && nox_chk "полоса после >= 90% до" nox_ge "$b" "$(awk -v a="$a" 'BEGIN{print a*0.9}')"
  nox_chk "t >= 1 и tb >= t" test "$t" -ge 1 -a "$tb" -ge "$t"
  nox_verdict
}
nox_run_task
