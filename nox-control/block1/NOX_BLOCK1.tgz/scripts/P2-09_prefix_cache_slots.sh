#!/usr/bin/env bash
# ID: P2-09
# ЦЕЛЬ: prefix-кэш и слоты: cache_prompt=true, фиксированный id_slot=0, --cache-reuse 256, сохранение/восстановление слота через /slots/0?action=save|restore.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-04, P4-04
# ГОТОВО: повторный запрос с тем же префиксом (~2000 ток) считает <= 5% префикса заново; после erase кэш пуст (prompt_n большой), после restore из файла слота снова <= 5%.
# ФАКТ С СЕРВЕРА: llama-server должен быть запущен с --slot-save-path (P2-04 это делает) и отдавать timings.cache_n; иначе BLOCKED.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: файл слота в $NOX_ROOT/slots/P2-09.bin (создаётся сервером)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-09 S1 "$@"
NOX_PLAN="префикс ~2000 ток; запрос 1 (прогрев) -> запрос 2 (хит) -> save -> erase -> запрос (промах) -> restore -> запрос (хит)"
t_pre() { nox_need_receipt P2-04 P4-04; nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "llama-server не отвечает" "запустить P2-04"
  grep -q -- '--slot-save-path' "$NOX_RUN_DIR/llama.args" || nox_blocked "сервер запущен без --slot-save-path" "перезапуск через P2-04"; }
t_check() {
  python3 -B - "$NOX_LLAMA_URL" "$NOX_TMP/res.json" <<'PY' || { nox_log NO "тест слотов завершился ошибкой"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
import json, os, sys
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_llm as L
url, out = sys.argv[1], sys.argv[2]
prefix = L.fill(url, 2000)
def ask(tail):
    r = L.post_json(url + "/completion", {"prompt": prefix + tail, "n_predict": 1, "cache_prompt": True, "id_slot": 0, "temperature": 0})
    tm = r["timings"]; return tm.get("prompt_n"), r.get("tokens_evaluated")
res = {"prefix_tokens": L.tokenize(url, prefix)}
res["warm"] = ask("\nВопрос А")
res["hit"] = ask("\nВопрос Б")
res["save"] = L.post_json(url + "/slots/0?action=save", {"filename": "P2-09.bin"})
res["erase"] = L.post_json(url + "/slots/0?action=erase", {})
res["miss"] = ask("\nВопрос В")
res["erase2"] = L.post_json(url + "/slots/0?action=erase", {})
res["restore"] = L.post_json(url + "/slots/0?action=restore", {"filename": "P2-09.bin"})
res["after_restore"] = ask("\nВопрос Г")
json.dump(res, open(out, "w"), ensure_ascii=False)
PY
  local k n; for k in hit miss after_restore; do n="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))[sys.argv[2]][0])' "$NOX_TMP/res.json" "$k")"; nox_metric "prompt_n_$k" "$n"; done
  local p; p="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["prefix_tokens"])' "$NOX_TMP/res.json")"; nox_metric prefix_tokens "$p"
  local lim; lim="$(awk -v p="$p" 'BEGIN{print p*0.05}')"
  nox_chk "повтор: пересчитано <= 5% префикса" nox_le "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["hit"][0])' "$NOX_TMP/res.json")" "$lim"
  nox_chk "после erase кэш пуст (пересчёт > 50% префикса)" nox_ge "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["miss"][0])' "$NOX_TMP/res.json")" "$(awk -v p="$p" 'BEGIN{print p*0.5}')"
  nox_chk "после restore: пересчитано <= 5% префикса" nox_le "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["after_restore"][0])' "$NOX_TMP/res.json")" "$lim"
  nox_verdict
}
nox_run_task
