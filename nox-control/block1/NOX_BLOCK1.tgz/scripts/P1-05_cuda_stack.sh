#!/usr/bin/env bash
# ID: P1-05
# ЦЕЛЬ: драйвер >= R570, CUDA >= 12.8, sm_120; реальная проверка компиляцией и запуском ядра под sm_120.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-03
# ГОТОВО: nvcc собирает и запускает тест-ядро с -arch=sm_120 на GPU (compute capability 12.0); при конфликте gcc подбирается gcc-14 (-ccbin).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: apt: gcc-14 g++-14 (только если конфликт с nvcc); CUDA toolkit >= 12.8 ставит владелец/образ (https://developer.nvidia.com/cuda-downloads)
#   Генерируется: $NOX_ROOT/run/cuda_ccbin (если нужен -ccbin)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-05 S1 "$@"
NOX_PLAN="nvidia-smi driver/cc; nvcc --version; сборка и запуск тест-ядра -arch=sm_120; gcc-14 при конфликте"
t_pre() { nox_need_cmd nvidia-smi nvcc gcc; }
build_test() { # $1=ccbin или ""
  cat >"$NOX_TMP/t.cu" <<'CU'
#include <cstdio>
__global__ void k(int*x){ x[threadIdx.x]=threadIdx.x*2; }
int main(){ int*d,h[32]; cudaMalloc(&d,128); k<<<1,32>>>(d); cudaMemcpy(h,d,128,cudaMemcpyDeviceToHost);
 cudaDeviceProp p; cudaGetDeviceProperties(&p,0); printf("%d.%d %d\n",p.major,p.minor,h[31]); return h[31]==62?0:1; }
CU
  if [ -n "$1" ]; then nvcc -arch=sm_120 -ccbin "$1" -o "$NOX_TMP/t" "$NOX_TMP/t.cu"; else nvcc -arch=sm_120 -o "$NOX_TMP/t" "$NOX_TMP/t.cu"; fi && "$NOX_TMP/t"
}
t_do() { nox_run apt-get install -y gcc-14 g++-14; }
t_check() {
  local drv ver cc out ccbin=""
  drv="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1 | cut -d. -f1)"
  ver="$(nvcc --version | sed -n 's/.*release \([0-9]*\.[0-9]*\).*/\1/p')"
  cc="$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader | head -1)"
  nox_metric driver_major "$drv"; nox_metric nvcc "$ver"; nox_metric compute_cap "$cc"; nox_metric gcc "$(gcc -dumpversion)"
  nox_chk "драйвер >= 570" nox_ge "$drv" 570
  nox_chk "CUDA >= 12.8" nox_ge "$ver" 12.8
  nox_chk "compute capability 12.0" test "$cc" = "12.0"
  if out="$(build_test "" 2>>"$NOX_LOGFILE")"; then nox_log OK "сборка+запуск sm_120: $out"
  elif command -v g++-14 >/dev/null 2>&1 && out="$(build_test g++-14 2>>"$NOX_LOGFILE")"; then ccbin="g++-14"; echo g++-14 >"$NOX_RUN_DIR/cuda_ccbin"; nox_metric ccbin g++-14; nox_log OK "с -ccbin g++-14: $out"
  else nox_log NO "тест-ядро sm_120 не собралось/не запустилось"; NOX_NFAIL=$((NOX_NFAIL+1)); NOX_FAILS+="sm_120 тест; "; fi
  nox_verdict
}
nox_run_task
