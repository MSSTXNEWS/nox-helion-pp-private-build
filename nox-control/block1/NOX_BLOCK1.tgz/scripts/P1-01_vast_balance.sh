#!/usr/bin/env bash
# ID: P1-01
# ЦЕЛЬ: проверить, что баланс Vast >= недельного расхода двух серверов и запас >= 10 ч; автопополнение подтверждено владельцем.
# СЕРВЕР: OWNER (выполняет владелец; проверка баланса делается через vastai CLI с любого хоста с API-ключом)
# ЗАВИСИМОСТИ: нет
# ГОТОВО: credit >= недельный расход (S1 $0.323/ч + S2 $0.181/ч, 168 ч) и запас >= 10 ч; файл подтверждения автопополнения.
# ДЕЙСТВИЯ ВЛАДЕЛЬЦА РУКАМИ: пополнить баланс и включить автопополнение в консоли Vast (скрипт не умеет и не должен).
#   Подтверждение: bash P1-01_vast_balance.sh --attest-autorecharge   (записывается как owner_attested, а не как проверенный факт)
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: pip: vastai (pip install vastai); ключ: https://cloud.vast.ai/cli/ -> `vastai set api-key <KEY>` или env VAST_API_KEY
#   Генерируется: $NOX_ROOT/owner/vast_autorecharge.attest
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-01 OWNER "$@"
NOX_PLAN="vastai show user -> credit; сравнить с недельным расходом; проверить файл подтверждения автопополнения"
RATE_S1=0.323; RATE_S2=0.181   # $/ч из канона 1.1
ATTEST="$NOX_ROOT/owner/vast_autorecharge.attest"
t_pre() {
  nox_need_cmd vastai python3
  if [[ " ${NOX_ARGS[*]:-} " == *" --attest-autorecharge "* ]] && [ "$DRY" != 1 ]; then
    mkdir -p "$(dirname "$ATTEST")"; date -u +%FT%TZ >"$ATTEST"; nox_log INFO "подтверждение автопополнения записано владельцем"
  fi
}
t_check() {
  local key=() out credit week hours
  nox_metric vastai_version "$(pip3 show vastai 2>/dev/null | sed -n 's/^Version: //p')"
  [ -n "${VAST_API_KEY:-}" ] && key=(--api-key "$VAST_API_KEY")
  out="$(vastai show user --raw "${key[@]}" 2>>"$NOX_LOGFILE")" || nox_blocked "vastai не вернул данные пользователя" "API-ключ Vast: vastai set api-key <KEY>"
  credit="$(python3 -c 'import json,sys;d=json.loads(sys.argv[1]);print(d.get("credit",d.get("balance","")))' "$out")"
  [ -n "$credit" ] || nox_blocked "в ответе vastai нет поля credit/balance" "формат ответа vastai show user --raw (смотри лог)"
  week="$(awk -v a=$RATE_S1 -v b=$RATE_S2 'BEGIN{printf "%.2f",(a+b)*168}')"
  hours="$(awk -v c="$credit" -v a=$RATE_S1 -v b=$RATE_S2 'BEGIN{printf "%.1f",c/(a+b)}')"
  nox_metric credit_usd "$credit"; nox_metric weekly_need_usd "$week"; nox_metric hours_left "$hours"
  nox_chk "баланс >= недельного расхода" nox_ge "$credit" "$week"
  nox_chk "запас >= 10 ч" nox_ge "$hours" 10
  if [ -s "$ATTEST" ]; then nox_metric autorecharge_owner_attested 1; else nox_metric autorecharge_owner_attested 0
    nox_chk "автопополнение подтверждено владельцем (--attest-autorecharge)" false; fi
  nox_verdict
}
nox_run_task
