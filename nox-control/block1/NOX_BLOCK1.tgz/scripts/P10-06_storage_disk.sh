#!/usr/bin/env bash
# ID: P10-06
# ЦЕЛЬ: решение Q12 выполнено: склад весов (внешний диск >= 2 ТБ либо Hetzner Storage Box BX21 5 ТБ, смонтированный) доступен для записи и достаточен.
# СЕРВЕР: OWNER (покупку и подключение делает владелец; скрипт проверяет результат на хосте, где смонтирован склад)
# ЗАВИСИМОСТИ: нет
# ГОТОВО: NOX_STORE_DIR - отдельная файловая система (не корневая), размер >= 2 ТБ, запись/чтение 64 МиБ с совпадением SHA256, свободно >= 700 ГБ (467 ГБ GLM + запас).
# РУКАМИ ВЛАДЕЛЬЦА: купить диск/тариф (Hetzner BX21 EUR 10.90/мес, канон 1.1), смонтировать (диск, либо `sshfs`/`rclone mount` Storage Box) и задать NOX_STORE_DIR.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: Hetzner Storage Box https://www.hetzner.com/storage/storage-box/ (BX21); rclone https://rclone.org/sftp/ (SFTP-remote для Hetzner)
#   Генерируется: временный файл проверки в $NOX_STORE_DIR/.nox_write_test (удаляется)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P10-06 OWNER "$@"
NOX_PLAN="df/stat: отдельная ФС, размер >= 2 ТБ, свободно >= 700 ГБ; запись+чтение 64 МиБ со сверкой sha256"
t_pre() { nox_need_var NOX_STORE_DIR; nox_need_file "$NOX_STORE_DIR" "смонтированный склад в $NOX_STORE_DIR"; }
t_check() {
  local sz av f="$NOX_STORE_DIR/.nox_write_test" a b
  sz="$(df -B1 --output=size "$NOX_STORE_DIR" | tail -1 | tr -d ' ')"; av="$(df -B1 --output=avail "$NOX_STORE_DIR" | tail -1 | tr -d ' ')"
  nox_metric size_tb "$(awk -v s="$sz" 'BEGIN{printf "%.2f",s/1e12}')"; nox_metric avail_gb "$((av/1000000000))"
  nox_chk "размер >= 2 ТБ" test "$sz" -ge 2000000000000
  nox_chk "свободно >= 700 ГБ" test "$av" -ge 700000000000
  nox_chk "отдельная файловая система (не корневая)" bash -c "[ \"\$(stat -c %d '$NOX_STORE_DIR')\" != \"\$(stat -c %d /)\" ]"
  head -c 67108864 /dev/urandom >"$NOX_TMP/w.bin"; a="$(sha256sum "$NOX_TMP/w.bin" | cut -d' ' -f1)"
  cp "$NOX_TMP/w.bin" "$f" && sync && b="$(sha256sum "$f" | cut -d' ' -f1)"; rm -f "$f"
  nox_chk "запись/чтение 64 МиБ: sha256 совпал" test "$a" = "${b:-x}"
  nox_verdict
}
nox_run_task
