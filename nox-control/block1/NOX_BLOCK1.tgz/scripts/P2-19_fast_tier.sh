#!/usr/bin/env bash
# ID: P2-19
# ЦЕЛЬ: размещение быстрого тира: младший судья 4-8B (GPU если влезает по P2-05, иначе отдельные ядра CPU через taskset), bge-m3 и реранкер (~1 ГБ).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-05
# ГОТОВО: ответ быстрого тира >= 30 ток/с в параллели с GLM; ток/с GLM падает не более чем на 10% (замер GLM без нагрузки и с непрерывной генерацией судьи).
# ФАКТЫ, КОТОРЫЕ НУЖНЫ (не выдумываются): NOX_JUDGE_GGUF (путь к GGUF младшего судьи 4-8B), NOX_BGE_GGUF (bge-m3), NOX_RERANK_GGUF (реранкер), порты NOX_JUDGE_PORT NOX_EMBED_PORT NOX_RERANK_PORT. Запрещено: старший судья на CPU S1, фон в слоте GLM.
# ИСТОЧНИКИ:
#   Drive: нет (веса судьи/эмбеддера лежат на складе, раздел 8.2; на S1 - диск 122 ГБ)
#   Интернет: (кандидаты; наличие репозитория и файла проверить HF API до скачивания, ревизию записать в квитанцию) HF https://huggingface.co/gpustack/bge-m3-GGUF (файл bge-m3-Q8_0.gguf), https://huggingface.co/gpustack/bge-reranker-v2-m3-GGUF; скачать: hf download <repo> <file> --revision <commit> --local-dir $NOX_ROOT/models; судья: модель выбирает REASON (4-8B), фактов о ней в каноне нет
#   Генерируется: services.d/judge.conf embed.conf rerank.conf, run/fast_tier.json, reports/P2-19_concurrency.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_llama_ctl.sh"
nox_begin P2-19 S1 "$@"
NOX_PLAN="решить GPU/CPU по vram_budget.json; поднять judge/embed/rerank через watchdog-конфиги; замер GLM без/с нагрузкой судьи; замер судьи ток/с"
t_pre() { nox_need_receipt P2-05; nox_need_var NOX_JUDGE_GGUF NOX_BGE_GGUF NOX_RERANK_GGUF NOX_JUDGE_PORT NOX_EMBED_PORT NOX_RERANK_PORT
  nox_need_file "$NOX_JUDGE_GGUF"; nox_need_file "$NOX_BGE_GGUF"; nox_need_file "$NOX_RERANK_GGUF"; nox_need_file "$NOX_RUN_DIR/vram_budget.json"; nox_need_file "$NOX_RUN_DIR/cpu_plan.json"
  nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "GLM не отвечает" "P2-04"; }
t_backup() { nox_backup "$NOX_ROOT/services.d/judge.conf" "$NOX_ROOT/services.d/embed.conf" "$NOX_ROOT/services.d/rerank.conf" "$NOX_RUN_DIR/fast_tier.json"; }
t_rollback() { rm -f "$NOX_ROOT/services.d/"{judge,embed,rerank}.conf; for p in "$LLAMA_WDST"/{judge,embed,rerank}.pid; do [ -s "$p" ] && kill "$(cat "$p")" 2>/dev/null || true; done; nox_restore || true; }
svc() { # NAME ORDER PORT ARGS...  (запуск через watchdog-конфиг; без watchdog - напрямую)
  local n="$1" o="$2" port="$3"; shift 3; local bin="${NOX_LLAMA_BIN:-${NOX_LLAMA_DIR:-$NOX_ROOT/llama.cpp}/build-sm120/bin/llama-server}" cmd
  cmd="$(printf '%q ' "$@" --host "$NOX_LLAMA_HOST" --port "$port")"; cmd="${NOX_PREFIX_CMD:-} $(printf '%q' "$bin") $cmd"
  printf 'NAME=%s\nORDER=%s\nCMD=%q\nHEALTH_URL=http://%s:%s\nMAX_RESTARTS=3\nWINDOW_S=1800\nGRACE_S=300\n' "$n" "$o" "$cmd" "$NOX_LLAMA_HOST" "$port" >"$NOX_ROOT/services.d/$n.conf"
  if ! { [ -s "$LLAMA_WDST/watchdog.pid" ] && kill -0 "$(cat "$LLAMA_WDST/watchdog.pid")" 2>/dev/null; }; then
    setsid nohup bash -c "exec $cmd" >>"$NOX_LOG_DIR/$n.service.log" 2>&1 & echo $! >"$LLAMA_WDST/$n.pid"; date +%s >"$LLAMA_WDST/$n.started"; fi
  nox_wait_health "http://$NOX_LLAMA_HOST:$port" 600; }
t_do() {
  mkdir -p "$NOX_ROOT/services.d" "$LLAMA_WDST"
  local jmib free place fast; jmib=$(( $(stat -L -c %s "$NOX_JUDGE_GGUF") / 1048576 )); free="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/vram_budget.json"))["free_mib_after_32k"])')"
  fast="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/cpu_plan.json"))["fast_cpus"])')"
  if [ "$free" -ge $((jmib + 1536 + 512)) ]; then place=gpu; else place=cpu; fi    # судья + ~1 ГБ bge/реранкер (канон) + запас под KV судьи
  nox_log INFO "судья $jmib МиБ, свободно VRAM $free МиБ -> $place"; nox_metric judge_placement "$place"; nox_metric judge_mib "$jmib"
  if [ "$place" = gpu ]; then svc judge 20 "$NOX_JUDGE_PORT" -m "$NOX_JUDGE_GGUF" -ngl 99 -c 8192 -np 1 -fa on --jinja
  else NOX_PREFIX_CMD="taskset -c $fast" svc judge 20 "$NOX_JUDGE_PORT" -m "$NOX_JUDGE_GGUF" -ngl 0 -c 8192 -np 1 --jinja -t "$(awk -F, '{print NF}' <<<"$fast")"; fi
  svc embed 21 "$NOX_EMBED_PORT" -m "$NOX_BGE_GGUF" -ngl 99 --embeddings --pooling cls -c 8192
  svc rerank 22 "$NOX_RERANK_PORT" -m "$NOX_RERANK_GGUF" -ngl 99 --reranking -c 8192
  printf '{"judge":"%s","placement":"%s","ports":{"judge":%s,"embed":%s,"rerank":%s}}\n' "$NOX_JUDGE_GGUF" "$place" "$NOX_JUDGE_PORT" "$NOX_EMBED_PORT" "$NOX_RERANK_PORT" >"$NOX_RUN_DIR/fast_tier.json"
}
t_check() {
  local u="http://$NOX_LLAMA_HOST:$NOX_JUDGE_PORT"
  nox_chk "судья отвечает" nox_health "$u"; nox_chk "bge-m3 отвечает" nox_health "http://$NOX_LLAMA_HOST:$NOX_EMBED_PORT"; nox_chk "реранкер отвечает" nox_health "http://$NOX_LLAMA_HOST:$NOX_RERANK_PORT"
  [ "$NOX_NFAIL" -eq 0 ] || return 1
  python3 -B - "$NOX_LLAMA_URL" "$u" "$NOX_REPORT_DIR/P2-19_concurrency.json" <<'PY' || { nox_log NO "замер конкурентности не выполнен"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
import json, os, subprocess, sys, threading
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_llm as L
glm, judge, out = sys.argv[1:4]
def glm_tps():
    ts = []
    for p in L.BENCH_PROMPTS:
        r = L.completion(glm, p[1], 64, {"cache_prompt": False, "temperature": 0, "seed": 1}); ts.append(r["timings"].get("predicted_per_second"))
    return L.pct(ts, .5)
base = glm_tps()
solo = L.completion(judge, "Расскажи подробно о принципах работы кэша процессора.", 128, {"temperature": 0})["timings"].get("predicted_per_second")
stop = threading.Event(); jt = []
def load():
    while not stop.is_set():
        r = L.completion(judge, "Расскажи подробно о принципах работы кэша процессора.", 128, {"temperature": 0}); jt.append(r["timings"].get("predicted_per_second"))
th = threading.Thread(target=load); th.start()
try: under = glm_tps()
finally: stop.set(); th.join()
json.dump({"glm_base_tps": base, "glm_under_load_tps": under, "glm_drop_pct": round((1 - under / base) * 100, 1), "judge_solo_tps": solo,
           "judge_tps_during_glm": L.pct(jt, .5)}, open(out, "w"), indent=1)
PY
  local r="$NOX_REPORT_DIR/P2-19_concurrency.json" k
  for k in glm_base_tps glm_under_load_tps glm_drop_pct judge_solo_tps judge_tps_during_glm; do nox_metric "$k" "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))[sys.argv[2]])' "$r" "$k")"; done
  nox_chk "судья >= 30 ток/с параллельно с GLM" nox_ge "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["judge_tps_during_glm"] or 0)' "$r")" 30
  nox_chk "падение GLM <= 10%" nox_le "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["glm_drop_pct"])' "$r")" 10
  nox_verdict
}
nox_run_task
