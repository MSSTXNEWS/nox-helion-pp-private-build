#!/usr/bin/env bash
# ID: P1-10
# ЦЕЛЬ: Tailscale в userspace-режиме на хосте; замер RTT (tailscale ping) и пропускной (SSH через `tailscale nc`) до пира.
# СЕРВЕР: S1,S2 (запускается на каждом из них; ПК владельца ставит клиент сам)
# ЗАВИСИМОСТИ: P1-02
# ГОТОВО: tailscale status = Running, RTT и МБ/с записаны в журнал/квитанцию. ACL "только S1-S2-ПК" задаёт владелец в консоли Tailscale (скрипт это НЕ проверяет и честно пишет acl=owner_manual).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: Tailscale https://tailscale.com/install.sh (или https://pkgs.tailscale.com/stable/ статический tgz); auth-key https://login.tailscale.com/admin/settings/keys (env TS_AUTHKEY, reusable+tagged)
#   Генерируется: run/tailscaled.sock/state; пир: NOX_TS_PEER (имя/IP в tailnet), NOX_TS_PEER_PORT (sshd пира, по умолчанию 22)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-10 S1,S2 "$@"
NOX_PLAN="tailscaled --tun=userspace-networking; tailscale up --authkey; ping -c 5 пира; 256 МиБ через ssh+tailscale nc"
SOCK="$NOX_RUN_DIR/tailscaled.sock"; TS=(tailscale --socket="$SOCK")
t_pre() { nox_need_cmd tailscale tailscaled ssh dd; nox_need_var NOX_TS_PEER; }
t_do() {
  if ! "${TS[@]}" status >/dev/null 2>&1; then
    setsid nohup tailscaled --tun=userspace-networking --state="$NOX_RUN_DIR/tailscaled.state" --socket="$SOCK" >>"$NOX_LOG_DIR/tailscaled.log" 2>&1 &
    sleep 3
  fi
  [ -n "${TS_AUTHKEY:-}" ] || nox_blocked "tailscale не авторизован" "TS_AUTHKEY (auth-key из админки Tailscale) в nox.env"
  "${TS[@]}" up --authkey "$TS_AUTHKEY" --hostname "nox-$(nox_detect_server | tr 'A-Z' 'a-z')" >>"$NOX_LOGFILE" 2>&1
}
t_check() {
  local st rtt mbs t0 t1 port="${NOX_TS_PEER_PORT:-22}" user="${NOX_TS_PEER_USER:-root}"
  nox_metric tailscale_version "$(tailscale version 2>/dev/null | head -1)"
  nox_chk "tailscale daemon отвечает" "${TS[@]}" status
  st="$("${TS[@]}" status --json 2>/dev/null | python3 -c 'import json,sys;print(json.load(sys.stdin).get("BackendState",""))' || true)"
  nox_metric backend_state "$st"; nox_chk "BackendState=Running" test "$st" = Running
  [ "$st" = Running ] || return 1
  rtt="$("${TS[@]}" ping -c 5 --timeout 10s "$NOX_TS_PEER" 2>&1 | sed -n 's/.* in \([0-9.]*\)ms.*/\1/p' | awk '{s+=$1;n++}END{if(n)printf "%.1f",s/n}')"
  nox_chk "RTT измерен" test -n "$rtt"; nox_metric rtt_ms "${rtt:-NA}"
  t0=$(date +%s.%N)
  # shellcheck disable=SC2046,SC2086
  dd if=/dev/zero bs=1M count=256 2>/dev/null | ssh $(nox_ssh_opts) -o ProxyCommand="tailscale --socket=$SOCK nc %h %p" -p "$port" "$user@$NOX_TS_PEER" 'cat >/dev/null' 2>>"$NOX_LOGFILE" \
    || nox_blocked "ssh к пиру через tailnet не удался" "sshd пира доступен по $NOX_TS_PEER:$port в tailnet, ключ добавлен (P1-02)"
  t1=$(date +%s.%N); mbs="$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.1f",256/(b-a)}')"
  nox_metric throughput_mb_s "$mbs"; nox_metric acl "owner_manual"
  nox_chk "пропускная > 0" nox_ge "$mbs" 0.1
  nox_verdict
}
nox_run_task
