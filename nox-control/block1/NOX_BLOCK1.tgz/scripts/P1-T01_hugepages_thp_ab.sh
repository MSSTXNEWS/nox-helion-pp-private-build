#!/usr/bin/env bash
# ID: P1-T01
# ЦЕЛЬ: A/B THP: always vs madvise (и наличие hugepages 2М/1Г) по полосе RAM (STREAM) — выбрать лучший и записать.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: нет
# ГОТОВО: run/thp_ab.json: оба варианта измерены, выбран и применён лучший, ЛИБО честная запись "нет прав" (контейнер Vast).
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: run/thp_ab.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-T01 S1 "$@"
TH=/sys/kernel/mm/transparent_hugepage/enabled
NOX_PLAN="STREAM x3 при THP=madvise и THP=always; выбрать лучший (>2% разницы, иначе madvise); применить; записать hugepages 2М/1Г"
t_pre() { nox_need_cmd gcc python3; }
cur() { sed 's/.*\[\(.*\)\].*/\1/' "$TH"; }
t_backup() { cur >"$NOX_RUN_DIR/P1-T01.prev"; nox_maint_begin 1800; }
best3() { local i b=0 v; for i in 1 2 3; do v="$(nox_stream_gbs)"; b="$(awk -v a="$b" -v v="$v" 'BEGIN{print (v>a)?v:a}')"; done; echo "$b"; }
t_do() {
  if [ ! -w "$TH" ]; then
    nox_log WARN "THP: нет прав писать $TH (контейнер) - честная запись, A/B невозможен"
    printf '{"t":"%s","status":"no_rights","current":"%s","nr_hugepages_2M":"%s","nr_hugepages_1G":"%s"}\n' "$(date -u +%FT%TZ)" "$(cur)" "$(cat /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages 2>/dev/null || echo NA)" "$(cat /sys/kernel/mm/hugepages/hugepages-1048576kB/nr_hugepages 2>/dev/null || echo NA)" >"$NOX_RUN_DIR/thp_ab.json"; nox_maint_end; return 0
  fi
  echo madvise >"$TH"; local a; a="$(best3)"
  echo always >"$TH"; local b; b="$(best3)"
  local pick=madvise; awk -v a="$a" -v b="$b" 'BEGIN{exit !(b>a*1.02)}' && pick=always
  echo "$pick" >"$TH"
  local h2 h1; h2="$(cat /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages 2>/dev/null || echo NA)"; h1="$(cat /sys/kernel/mm/hugepages/hugepages-1048576kB/nr_hugepages 2>/dev/null || echo NA)"
  printf '{"t":"%s","madvise_gbs":%s,"always_gbs":%s,"pick":"%s","nr_hugepages_2M":"%s","nr_hugepages_1G":"%s"}\n' "$(date -u +%FT%TZ)" "$a" "$b" "$pick" "$h2" "$h1" >"$NOX_RUN_DIR/thp_ab.json"
  nox_maint_end
}
t_rollback() { local p; p="$(cat "$NOX_RUN_DIR/P1-T01.prev" 2>/dev/null)"; [ -n "$p" ] && echo "$p" >"$TH" || true; nox_maint_end; }
t_check() {
  nox_chk "thp_ab.json есть" test -s "$NOX_RUN_DIR/thp_ab.json"
  [ -s "$NOX_RUN_DIR/thp_ab.json" ] || return 1
  if grep -q no_rights "$NOX_RUN_DIR/thp_ab.json"; then nox_metric thp "no_rights"; nox_log INFO "THP: нет прав - записано"; nox_verdict; return; fi
  local p; p="$(python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1]))["pick"])' "$NOX_RUN_DIR/thp_ab.json")"
  nox_metric thp_pick "$p"; nox_chk "применён выбранный режим THP ($p)" test "$(cur)" = "$p"
  nox_verdict
}
nox_run_task
