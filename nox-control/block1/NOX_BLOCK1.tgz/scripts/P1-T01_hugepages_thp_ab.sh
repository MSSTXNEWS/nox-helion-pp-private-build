#!/usr/bin/env bash
# ID: P1-T01
# ЦЕЛЬ: A/B THP: always vs madvise (и наличие hugepages 2М/1Г) по полосе RAM (STREAM) — выбрать лучший и записать.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: нет
# ГОТОВО: run/thp_ab.json: оба варианта измерены, выбран и применён лучший.
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: run/thp_ab.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-T01 S1 "$@"
TH=/sys/kernel/mm/transparent_hugepage/enabled
NOX_PLAN="STREAM x3 при THP=madvise и THP=always; выбрать лучший (>2% разницы, иначе madvise); применить; записать hugepages 2М/1Г"
t_pre() { nox_need_cmd gcc python3; [ -w "$TH" ] || nox_blocked "нет прав писать $TH" "root на S1 / привилегированный контейнер"; }
cur() { sed 's/.*\[\(.*\)\].*/\1/' "$TH"; }
t_backup() { cur >"$NOX_RUN_DIR/P1-T01.prev"; nox_maint_begin 1800; }
best3() { local i b=0 v; for i in 1 2 3; do v="$(nox_stream_gbs)"; b="$(awk -v a="$b" -v v="$v" 'BEGIN{print (v>a)?v:a}')"; done; echo "$b"; }
t_do() {
  echo madvise >"$TH"; local a; a="$(best3)"
  echo always >"$TH"; local b; b="$(best3)"
  local pick=madvise; awk -v a="$a" -v b="$b" 'BEGIN{exit !(b>a*1.02)}' && pick=always
  echo "$pick" >"$TH"
  local h2 h1; h2="$(cat /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages 2>/dev/null || echo NA)"; h1="$(cat /sys/kernel/mm/hugepages/hugepages-1048576kB/nr_hugepages 2>/dev/null || echo NA)"
  printf '{"t":"%s","madvise_gbs":%s,"always_gbs":%s,"pick":"%s","nr_hugepages_2M":"%s","nr_hugepages_1G":"%s"}\n' "$(date -u +%FT%TZ)" "$a" "$b" "$pick" "$h2" "$h1" >"$NOX_RUN_DIR/thp_ab.json"
  nox_maint_end
}
t_rollback() { local p; p="$(cat "$NOX_RUN_DIR/P1-T01.prev" 2>/dev/null)"; [ -n "$p" ] && echo "$p" >"$TH" || true; nox_maint_end; }
t_check() {
  nox_chk "thp_ab.json есть" test -s "$NOX_RUN_DIR/thp_ab.json"
  [ -s "$NOX_RUN_DIR/thp_ab.json" ] || return 1
  local p; p="$(python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1]))["pick"])' "$NOX_RUN_DIR/thp_ab.json")"
  nox_metric thp_pick "$p"; nox_chk "применён выбранный режим THP ($p)" test "$(cur)" = "$p"
  nox_verdict
}
nox_run_task
