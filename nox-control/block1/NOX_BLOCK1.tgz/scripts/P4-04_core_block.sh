#!/usr/bin/env bash
# ID: P4-04
# ЦЕЛЬ: core-блок (малый блок о создателе/целях, всегда в префиксе): <= 4000 токенов, пересборка ночью, неизменен в течение суток.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P4-02
# ГОТОВО: $NOX_ROOT/prefix/core.md собран из согласованного источника; токенов <= 4000 (измерено /tokenize сервера); sha в истории за последние 24 ч менялся не чаще, чем при ночной пересборке; cron пересборки установлен.
# ФАКТЫ/ФАЙЛЫ: NOX_CORE_SRC - согласованный текст core-блока (о создателе/целях; составляют MEM+SOUL и утверждает владелец; не выдумывается). Час пересборки NOX_CORE_REBUILD_HOUR (по умолчанию 4).
# ИСТОЧНИКИ:
#   Drive: материал для составления NOX_CORE_SRC - ЧК "Человечная концепция" 1l78m_lNYBmeAxpJpoLVLOqFRC9QzHRrlfS9pZibszgQ; ХИЩ 1CHfmc_Hf3fKLCZ7lZkEL-2negOGX4NJYehlttgusJNY; B26/B35 - канон 3.3a
#     скачать: lib/nox_fetch_drive.sh <ID> $NOX_SRC_DIR/<имя>.txt txt   (rclone remote gdrive либо gdown)
#   Интернет: нет
#   Генерируется: prefix/core.md, prefix/core.sha.log, /etc/cron.d/nox_core_rebuild
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P4-04 S1 "$@"
SRC="${NOX_CORE_SRC:-$NOX_SRC_DIR/core_src.md}"; OUT="$NOX_ROOT/prefix/core.md"; HIST="$NOX_ROOT/prefix/core.sha.log"; HOUR="${NOX_CORE_REBUILD_HOUR:-4}"
NOX_PLAN="core_src.md -> prefix/core.md (если изменился); токены через /tokenize; история sha; cron ежедневной пересборки"
t_pre() { nox_need_receipt P4-02; nox_need_file "$SRC" "согласованный текст core-блока (см. ФАЙЛЫ в шапке)"; nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "llama-server не отвечает (нужен /tokenize)" "P2-04"; }
t_backup() { nox_backup "$OUT" /etc/cron.d/nox_core_rebuild; }
t_rollback() { nox_restore || true; }
t_do() {
  mkdir -p "$(dirname "$OUT")"
  cmp -s "$SRC" "$OUT" || { cp -a "$SRC" "$OUT"; echo "$(date +%s) $(sha256sum "$OUT" | cut -d' ' -f1) rebuild" >>"$HIST"; }
  command -v cron >/dev/null 2>&1 && printf '0 %s * * * root cmp -s %q %q || { cp -a %q %q; echo "$(date +\\%%s) $(sha256sum %q | cut -d" " -f1) rebuild" >>%q; }\n' "$HOUR" "$SRC" "$OUT" "$SRC" "$OUT" "$OUT" "$HIST" >/etc/cron.d/nox_core_rebuild || nox_log WARN "cron отсутствует: ночная пересборка не настроена"
}
t_check() {
  nox_chk "core.md совпадает с источником" cmp -s "$SRC" "$OUT"
  [ -s "$OUT" ] || return 1
  local n; n="$(nox_llm tokenize --url "$NOX_LLAMA_URL" --file "$OUT" | python3 -c 'import json,sys;print(json.load(sys.stdin)["tokens"])')"
  nox_metric core_tokens "$n"; nox_chk "токенов в диапазоне 1..4000" test "$n" -ge 1 -a "$n" -le 4000
  local now since; now=$(date +%s); since=$((now-86400))
  nox_metric core_changes_24h "$(awk -v s="$since" '$1>=s' "$HIST" 2>/dev/null | wc -l)"
  nox_chk "в журнале пересборок не больше одной за 24 ч" test "$(awk -v s="$since" '$1>=s' "$HIST" 2>/dev/null | wc -l)" -le 1
  nox_chk "ночная пересборка установлена" test -s /etc/cron.d/nox_core_rebuild
  nox_input "$OUT"
  nox_verdict
}
nox_run_task
