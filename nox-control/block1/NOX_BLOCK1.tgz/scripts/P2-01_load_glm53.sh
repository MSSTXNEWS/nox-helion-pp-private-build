#!/usr/bin/env bash
# ID: P2-01
# ЦЕЛЬ: загрузить GLM-5.3 UD-Q4_K_XL (11 файлов, ~467 ГБ) с Hugging Face прямо в RAM S1 (/dev/shm если >= 490 ГБ, иначе memfd-держатель); 4 потока, докачка, SHA256; симлинки в /root/nox/glm53.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-04, P1-15
# ГОТОВО: 11 файлов, размеры и SHA256 = значениям HF (lfs.oid), время загрузки <= 40 мин (если загрузка была в этом прогоне), модель в RAM.
# ЗАПРЕТЫ: --no-mmap/--mlock не используются; drop_caches не вызывается; вторая главная модель в RAM не допускается (нужно >= 490 ГБ свободно).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: Hugging Face repo unsloth/GLM-5.3-GGUF, папка UD-Q4_K_XL/, ревизия = commit sha из https://huggingface.co/api/models/unsloth/GLM-5.3-GGUF (фиксируется в run/glm53_manifest.json; можно закрепить NOX_GLM_REV);
#             манифест: https://huggingface.co/api/models/unsloth/GLM-5.3-GGUF/tree/<rev>/UD-Q4_K_XL ; HF_TOKEN, если нужен
#   Генерируется: run/glm53_manifest.json, run/glm53_holder.json, /dev/shm/GLM-5.3-*.gguf или memfd, симлинки /root/nox/glm53/*.gguf
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-01 S1 "$@"
NOX_PLAN="манифест HF (имена/размеры/sha256); режим shm|memfd по размеру /dev/shm; glm53_holder.py (4 потока, Range-докачка); sha256 всех файлов"
OUT="$NOX_ROOT/glm53"; MAN="$NOX_RUN_DIR/glm53_manifest.json"; HOLD="$NOX_RUN_DIR/glm53_holder.json"
t_pre() {
  nox_need_cmd curl python3 sha256sum; nox_need_receipt P1-04 P1-15
  [ "$(nox_cg_mem_max)" -ge 520000000000 ] || nox_blocked "cgroup-лимит RAM < 520 ГБ" "другой инстанс/лимит (см. P1-03)"
}
manifest() {
  python3 - "$MAN" <<'PY'
import json, os, sys, urllib.request
repo = "unsloth/GLM-5.3-GGUF"; tok = os.environ.get("HF_TOKEN")
def get(u):
    r = urllib.request.Request(u)
    if tok: r.add_header("Authorization", "Bearer " + tok)
    return json.load(urllib.request.urlopen(r, timeout=60))
rev = os.environ.get("NOX_GLM_REV") or get("https://huggingface.co/api/models/%s" % repo)["sha"]
folder = os.environ.get("NOX_GLM_FOLDER", "UD-Q4_K_XL")
tree = get("https://huggingface.co/api/models/%s/tree/%s/%s" % (repo, rev, folder))
files = [{"path": t["path"], "size": t["lfs"]["size"], "sha256": t["lfs"]["oid"]} for t in tree if t["path"].endswith(".gguf")]
files.sort(key=lambda x: x["path"])
json.dump({"repo": repo, "sha": rev, "files": files}, open(sys.argv[1], "w"), indent=1)
print(len(files), sum(f["size"] for f in files))
PY
}
t_do() {
  local n tot mode shmfree; read -r n tot < <(manifest) || nox_blocked "не удалось получить манифест HF" "доступ к huggingface.co/api, HF_TOKEN"
  nox_log INFO "манифест: $n файлов, $((tot/1000000000)) ГБ"; [ "$n" -eq "${NOX_GLM_FILES:-11}" ] || nox_blocked "в манифесте $n файлов, ожидалось ${NOX_GLM_FILES:-11}" "актуальная структура unsloth/GLM-5.3-GGUF/UD-Q4_K_XL"
  nox_need_ram_free $((tot + 20*1024*1024*1024))
  shmfree="$(df -B1 --output=avail /dev/shm | tail -1 | tr -d ' ')"; if [ "$shmfree" -gt $((490*1024*1024*1024)) ]; then mode=shm; else mode=memfd; fi
  nox_log INFO "режим загрузки: $mode"; nox_metric load_mode "$mode"
  setsid nohup python3 -B "$NOX_LIB_DIR/glm53_holder.py" "$MAN" "$OUT" "$mode" 4 >>"$NOX_ROOT/glm53_load.log" 2>&1 &
  echo $! >"$NOX_RUN_DIR/glm53_holder.pid"
  until grep -q -E '^(ALL_DONE|INCOMPLETE)' "$NOX_ROOT/glm53_load.log" 2>/dev/null; do kill -0 "$(cat "$NOX_RUN_DIR/glm53_holder.pid")" 2>/dev/null || break; sleep 20; done
  grep -q '^ALL_DONE' "$NOX_ROOT/glm53_load.log"
}
t_rollback() { [ -s "$NOX_RUN_DIR/glm53_holder.pid" ] && kill "$(cat "$NOX_RUN_DIR/glm53_holder.pid")" 2>/dev/null || true; rm -f /dev/shm/GLM-5.3-*.gguf "$OUT"/*.gguf; }
t_check() {
  nox_chk "манифест есть" test -s "$MAN"; nox_chk "статус держателя есть" test -s "$HOLD"
  [ -s "$MAN" ] && [ -s "$HOLD" ] || return 1
  local list sha_bad=0 f size exp
  list="$(python3 -c 'import json;m=json.load(open("'"$MAN"'"));[print(x["path"].split("/")[-1],x["size"],x["sha256"]) for x in m["files"]]')"
  nox_input "$MAN"; nox_metric hf_rev "$(python3 -c 'import json;print(json.load(open("'"$MAN"'"))["sha"])')"
  while read -r f size exp; do
    nox_chk "$f: размер" bash -c "[ \"\$(stat -L -c %s '$OUT/$f')\" = '$size' ]"
  done <<<"$list"
  [ "$NOX_NFAIL" -eq 0 ] || return 1
  # SHA256 всех файлов (читается из RAM; 4 параллельно)
  echo "$list" | awk -v o="$OUT" '{print $3"  "o"/"$1}' >"$NOX_TMP/sums.txt"
  if ! (cd /; xargs -P 4 -L 1 bash -c 'echo "$0  $1" | sha256sum -c --quiet' <<<"$(awk '{print $1" "$2}' "$NOX_TMP/sums.txt")") >>"$NOX_LOGFILE" 2>&1; then nox_log NO "SHA256 не сошёлся"; NOX_NFAIL=$((NOX_NFAIL+1)); NOX_FAILS+="sha256; "; fi
  nox_chk "SHA256 всех 11 файлов сошёлся" test "$NOX_NFAIL" -eq 0
  local m; m="$(python3 -c 'import json;h=json.load(open("'"$HOLD"'"));print(round((h["t_end"]-h["t_start"])/60,1) if h.get("t_end") else "NA")')"
  nox_metric load_minutes "$m"; nox_metric mode "$(python3 -c 'import json;print(json.load(open("'"$HOLD"'"))["mode"])')"
  [ "$m" != NA ] && nox_chk "загрузка <= 40 мин" nox_le "$m" 40
  nox_verdict
}
nox_run_task
