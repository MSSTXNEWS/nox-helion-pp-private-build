#!/usr/bin/env bash
# ID: P3-06
# ЦЕЛЬ: двухтактный ответ (Talker-Reasoner): быстрая реплика судьи без фактов + итог GLM; NLI-проверка противоречия реплики и итога (T10.7).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-19, P3-03
# ГОТОВО: 50 диалогов: 0 противоречий реплика/итог, 0 пустых итогов. Покрыта содержательная часть; поток чанков и «тишина-токен» относятся к слою UI/прокси.
# ВНИМАНИЕ ПО ВРЕМЕНИ: GLM при 2-3 ток/с, лимит токенов на диалог NOX_TWOBEAT_MAX_TOKENS (обязателен, из бюджета режима Авто P2-15) x 50 диалогов = часы.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет (ConvFill, канон В4: фактология быстрого тира хуже, 5-8% противоречий - поэтому проверка обязательна)
#   Генерируется: reports/P3-06_two_beat.json (диалоги генерируются детерминированно в lib/nox_two_beat.py)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P3-06 S1 "$@"
NOX_PLAN="для 50 запросов: реплика судьи -> итог GLM (effort low) -> NLI судьёй -> подсчёт противоречий"
t_pre() { nox_need_receipt P2-19 P3-03; nox_need_var NOX_TWOBEAT_MAX_TOKENS; nox_need_file "$NOX_RUN_DIR/fast_tier.json"; nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "GLM не отвечает" "P2-04"; }
t_check() {
  local port r; port="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/fast_tier.json"))["ports"]["judge"])')"
  python3 -B "$NOX_LIB_DIR/nox_two_beat.py" --glm "$NOX_LLAMA_URL" --judge "http://$NOX_LLAMA_HOST:$port" --n 50 --max-tokens "$NOX_TWOBEAT_MAX_TOKENS" --out "$NOX_REPORT_DIR/P3-06_two_beat.json" >>"$NOX_LOGFILE" 2>&1 \
    || { nox_log NO "прогон диалогов не завершился"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
  for k in n contradictions empty_final talker_p95_s; do nox_metric "$k" "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))[sys.argv[2]])' "$NOX_REPORT_DIR/P3-06_two_beat.json" "$k")"; done
  nox_chk "50 диалогов" test "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["n"])' "$NOX_REPORT_DIR/P3-06_two_beat.json")" -eq 50
  nox_chk "0 противоречий" test "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["contradictions"])' "$NOX_REPORT_DIR/P3-06_two_beat.json")" -eq 0
  nox_chk "0 пустых итогов" test "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["empty_final"])' "$NOX_REPORT_DIR/P3-06_two_beat.json")" -eq 0
  nox_verdict
}
nox_run_task
