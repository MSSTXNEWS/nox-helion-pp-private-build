#!/usr/bin/env bash
# ID: P4-09
# ЦЕЛЬ: Evidence Gate и области доступа (владелец/проект/персона/диалог), SHA факта, отзыв; пустой поиск не есть отрицательный факт.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P4-01
# ГОТОВО: на реальной БД S03 (временные записи __nox_test_* удаляются): своя персона читает своё; чужая PersonaID и чужая область не читаются; отозванное скрыто, кэш инвалидируется; пустой поиск = NO_EVIDENCE (а не "факта нет").
# ИСТОЧНИКИ:
#   Drive: Evidence Gate 1JiSWC-mhg7y_RLehUgQZxNZNEHZzbwQ9ykYc4SHY5dE (D21, справка; реализация - lib/nox_s03.py); скачать при необходимости: lib/nox_fetch_drive.sh 1JiSWC-mhg7y_RLehUgQZxNZNEHZzbwQ9ykYc4SHY5dE $NOX_SRC_DIR/evidence_gate.txt txt
#   Интернет: нет
#   Генерируется: ничего постоянного
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P4-09 S1 "$@"
NOX_PLAN="evidence-test на NOX_S03_DB: 4 тестовые записи (persona A/B, project, owner); поиск от лица persona A; отзыв; кэш"
t_pre() { nox_need_receipt P4-01 P4-02; nox_need_var NOX_S03_DB; nox_need_file "$NOX_S03_DB"; }
t_check() {
  local r; r="$(python3 -B "$NOX_LIB_DIR/nox_s03.py" evidence-test "$NOX_S03_DB")" || { nox_log NO "evidence-test: $r"; NOX_NFAIL=$((NOX_NFAIL+1)); NOX_FAILS+="evidence-test; "; return 1; }
  nox_log INFO "$r"; nox_chk "все проверки Evidence Gate" python3 -c 'import json,sys;sys.exit(0 if all(json.loads(sys.argv[1]).values()) else 1)' "$r"
  nox_chk "тестовых записей не осталось" bash -c "[ \"\$(python3 -B '$NOX_LIB_DIR/nox_s03.py' sql '$NOX_S03_DB' \"SELECT count(*) FROM nox_mem WHERE id LIKE '__nox_test_%'\")\" = 0 ]"
  nox_verdict
}
nox_run_task
