#!/usr/bin/env bash
# ID: P1-12
# ЦЕЛЬ: независимый watchdog (lib/nox_watchdog.sh): перезапуск упавшего сервиса <=60 с, лимит рестартов с красным событием, нет рестарта при STOP, CONT по 9.7.
# СЕРВЕР: S1,S2
# ЗАВИСИМОСТИ: P1-06
# ГОТОВО: самотест на реальном процессе (python http.server под отдельным экземпляром watchdog): kill -9 -> поднят <=60 с; серия убийств -> halt + красное событие; STOP-флаг -> не рестартует.
#   Рабочий экземпляр запущен (run/wd/watchdog.pid) и подхватывает $NOX_ROOT/services.d/*.conf (llama.conf пишет P2-04). Тест на самом llama-server - в P2-04/P10-01 (до загрузки модели его нет).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: services.d/, run/wd/, events/red.jsonl, cron-строка раз в минуту "поднять watchdog, если не запущен"
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-12 S1,S2 "$@"
NOX_PLAN="запустить рабочий watchdog; самотест: kill -9, лимит рестартов, STOP-флаг (отдельный экземпляр с временными каталогами)"
WD="$NOX_LIB_DIR/nox_watchdog.sh"
t_pre() { nox_need_cmd python3 curl setsid; }
t_do() {
  mkdir -p "$NOX_ROOT/services.d"
  setsid nohup "$WD" >>"$NOX_LOG_DIR/watchdog.log" 2>&1 &
  command -v cron >/dev/null 2>&1 && printf '* * * * * root pgrep -f nox_watchdog.sh >/dev/null || setsid nohup %s >>%s/watchdog.log 2>&1 &\n' "$WD" "$NOX_LOG_DIR" >/etc/cron.d/nox_watchdog || nox_log WARN "cron отсутствует: подъём watchdog при его падении не настроен (P1-11 ставит cron)"
  sleep 2
}
t_rollback() { [ -s "$NOX_RUN_DIR/wd/watchdog.pid" ] && kill "$(cat "$NOX_RUN_DIR/wd/watchdog.pid")" 2>/dev/null || true; rm -f /etc/cron.d/nox_watchdog; }
selftest() {
  local T port wdpid svcpid t0 el n
  T="$(mktemp -d)"; mkdir -p "$T/conf" "$T/st"
  port="$(python3 -c 'import socket;s=socket.socket();s.bind(("127.0.0.1",0));print(s.getsockname()[1])')"
  printf "NAME=selftest\nCMD='python3 -m http.server %s --bind 127.0.0.1'\nHEALTH_URL=http://127.0.0.1:%s/\nMAX_RESTARTS=2\nWINDOW_S=300\nGRACE_S=2\n" "$port" "$port" >"$T/conf/selftest.conf"
  NOX_WD_CONF_DIR="$T/conf" NOX_WD_STATE="$T/st" NOX_WD_INTERVAL=1 NOX_STOP_FLAG="$T/STOP" NOX_MAINT_DIR="$T/maint" NOX_ROOT="$T/root" NOX_LOG_DIR="$T/log" NOX_RUN_DIR="$T/root/run" setsid "$WD" >"$T/wd.log" 2>&1 &
  wdpid=$!; sleep 4
  svcpid="$(cat "$T/st/selftest.pid" 2>/dev/null || true)"
  nox_chk "watchdog сам поднял сервис" bash -c "[ -n '$svcpid' ] && kill -0 $svcpid && curl -fsS --max-time 3 http://127.0.0.1:$port/ >/dev/null"
  kill -9 "$svcpid" 2>/dev/null || true; t0=$(date +%s)
  until curl -fsS --max-time 2 "http://127.0.0.1:$port/" >/dev/null 2>&1 || [ $(( $(date +%s) - t0 )) -gt 60 ]; do sleep 1; done; el=$(( $(date +%s) - t0 ))
  nox_metric restart_after_kill9_s "$el"; nox_chk "поднят за <= 60 с" test "$el" -le 60
  for n in 1 2 3; do sleep 3; kill -9 "$(cat "$T/st/selftest.pid")" 2>/dev/null || true; done; sleep 6
  nox_chk "лимит рестартов остановил цикл (halted)" test -e "$T/st/selftest.halted"
  nox_chk "красное событие записано" grep -q 'лимит рестартов' "$T/root/events/red.jsonl"
  rm -f "$T/st/selftest.halted"; : >"$T/st/selftest.restarts"; : >"$T/STOP"; kill -9 "$(cat "$T/st/selftest.pid")" 2>/dev/null || true; sleep 5
  nox_chk "при STOP не рестартует" bash -c "! curl -fsS --max-time 2 http://127.0.0.1:$port/ >/dev/null 2>&1"
  kill "$wdpid" 2>/dev/null || true; pkill -f "http.server $port" 2>/dev/null || true; rm -rf "$T"
}
t_check() {
  nox_chk "рабочий watchdog запущен" bash -c "[ -s '$NOX_RUN_DIR/wd/watchdog.pid' ] && kill -0 \$(cat '$NOX_RUN_DIR/wd/watchdog.pid')"
  selftest
  nox_verdict
}
nox_run_task
