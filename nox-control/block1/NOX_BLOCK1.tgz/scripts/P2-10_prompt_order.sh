#!/usr/bin/env bash
# ID: P2-10
# ЦЕЛЬ: неизменный префикс промпта: порядок душа -> инструкции режима -> core-память -> диалог; время/статусы только в конец. Измерить хит prefix-кэша на диалоге из 10 ходов.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-09
# ГОТОВО: средний хит (cache_n/(cache_n+prompt_n)) на ходах 2-10 >= 95%. Контроль: тот же диалог с временем В НАЧАЛЕ системного промпта - хит измеряется и должен быть ниже (доказывает, что тест различает порядок).
# ФАКТЫ/ФАЙЛЫ: NOX_SOUL_FILE (сжатый промпт души от SOUL; по умолчанию $NOX_SRC_DIR/soul_prompt.txt), NOX_MODE_FILE (инструкции режима, по умолчанию $NOX_SRC_DIR/mode_auto.txt), core-блок из P4-04 ($NOX_ROOT/prefix/core.md). Содержимое не выдумывается.
# ИСТОЧНИКИ:
#   Drive: SOUL LIVING UNIVERSE MEGA R1 1LuKHNr5S23eR9SwV8IjnLgiYTExhW8TAeJVz9Rl6njA -> $NOX_SRC_DIR/soul_r1.txt
#            скачать: lib/nox_fetch_drive.sh 1LuKHNr5S23eR9SwV8IjnLgiYTExhW8TAeJVz9Rl6njA $NOX_SRC_DIR/soul_r1.txt txt   (rclone remote gdrive; либо gdown --id ...)
#          NOX SOUL WEIGHTS "00_НАЧАТЬ_ЗДЕСЬ" 1OGzZGFN_rl2mG_vvOvVEIgTUwqilhR8-sfqcjAPQubc -> $NOX_SRC_DIR/soul_weights.txt (тем же способом)
#          Из них исполнитель SOUL готовит краткий soul_prompt.txt (G27: ядро персоны <= ~1000 знаков).
#   Интернет: нет
#   Генерируется: reports/P2-10_hits.csv
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-10 S1 "$@"
SOUL="${NOX_SOUL_FILE:-$NOX_SRC_DIR/soul_prompt.txt}"; MODE="${NOX_MODE_FILE:-$NOX_SRC_DIR/mode_auto.txt}"; CORE="$NOX_ROOT/prefix/core.md"
NOX_PLAN="собрать system = душа+режим+core; 10 ходов с фиксированными репликами (max_tokens=1); время/статус в конце последнего user; контроль с временем в начале"
t_pre() { nox_need_receipt P2-09
  nox_need_file "$SOUL" "SOUL готовит soul_prompt.txt из Drive-документов (см. SRC в шапке: soul_r1.txt, soul_weights.txt)"; nox_need_file "$MODE" "файл инструкций режима (Авто) от SOUL/REASON"; nox_need_file "$CORE" "core-блок из P4-04"
  nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "llama-server не отвечает" "P2-04"; }
t_check() {
  python3 -B - "$NOX_LLAMA_URL" "$SOUL" "$MODE" "$CORE" "$NOX_REPORT_DIR/P2-10_hits.csv" "$NOX_TMP/r.json" <<'PY' || nox_blocked "замер хита не выполнен (нет timings.cache_n или ошибка запроса, см. лог)" "версия llama-server, отдающая cache_n в timings"
import json, os, sys, time
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_llm as L
url, soul, mode, core, csvp, out = sys.argv[1:7]
rd = lambda p: open(p, encoding="utf-8").read().strip()
S, M, C = rd(soul), rd(mode), rd(core)
users = ["Привет, это проверка кэша %d." % i for i in range(1, 11)]
def run(time_first):
    hits, msgs = [], []
    for i, u in enumerate(users):
        tail = "\n[время: 12:%02d:%02d; статус: ok]" % (i, i * 7 % 60)
        sysm = (("[время: %s]\n" % time.time()) if time_first else "") + S + "\n\n" + M + "\n\n" + C
        cur = msgs + [{"role": "user", "content": u + (tail if not time_first else "")}]
        r = L.chat_sync(url, [{"role": "system", "content": sysm}] + cur, 1, {"cache_prompt": True, "id_slot": 0, "temperature": 0})
        h = L.hit_ratio(r)
        if h is None: sys.exit(3)
        hits.append(h); msgs += [{"role": "user", "content": u}, {"role": "assistant", "content": "Принято."}]
    return hits
good = run(False); L.post_json(url + "/slots/0?action=erase", {}); ctrl = run(True)
open(csvp, "w").write("turn,hit_good,hit_control\n" + "".join("%d,%.4f,%.4f\n" % (i + 1, good[i], ctrl[i]) for i in range(10)))
json.dump({"avg_good": sum(good[1:]) / 9, "avg_ctrl": sum(ctrl[1:]) / 9}, open(out, "w"))
PY
  local g c; g="$(python3 -c 'import json,sys;print(round(json.load(open(sys.argv[1]))["avg_good"],4))' "$NOX_TMP/r.json")"; c="$(python3 -c 'import json,sys;print(round(json.load(open(sys.argv[1]))["avg_ctrl"],4))' "$NOX_TMP/r.json")"
  nox_metric hit_avg_turns2_10 "$g"; nox_metric hit_control_time_first "$c"
  nox_chk "хит >= 95% на ходах 2-10" nox_ge "$g" 0.95
  nox_chk "контроль (время в начале) хуже эталона" nox_le "$c" "$g"
  nox_verdict
}
nox_run_task
