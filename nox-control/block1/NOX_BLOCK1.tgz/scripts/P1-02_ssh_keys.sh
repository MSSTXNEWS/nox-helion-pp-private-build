#!/usr/bin/env bash
# ID: P1-02
# ЦЕЛЬ: SSH-ключ ed25519 есть; вход без пароля на S1 и S2 (проверка, что за хостом именно тот сервер).
# СЕРВЕР: ANY (ПК владельца или S2 как исполнитель; ходит на S1 и S2)
# ЗАВИСИМОСТИ: P1-01
# ГОТОВО: ssh BatchMode на S1 и S2 выполняет `nvidia-smi -L` и видит RTX 5060 Ti / V100 соответственно.
# РУКАМИ ВЛАДЕЛЬЦА: вставить публичный ключ (скрипт его печатает) в Vast -> Keys; скрипт не может сделать это за него.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: apt: openssh-client
#   Генерируется: ~/.ssh/id_ed25519(.pub) (ssh-keygen -t ed25519 -N "")
#   Параметры: S1 по канону 24.2: -p 62281 root@174.88.252.223 (NOX_S1_SSH); S2: NOX_S2_SSH="-p <порт> root@<хост>" из Vast Connect
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-02 ANY "$@"
NOX_PLAN="создать ключ при отсутствии; ssh -o BatchMode=yes на S1 и S2; nvidia-smi -L"
KEY="$HOME/.ssh/id_ed25519"
S1="${NOX_S1_SSH:--p 62281 root@174.88.252.223}"
t_pre() { nox_need_cmd ssh ssh-keygen; nox_need_var NOX_S2_SSH; }
t_backup() { nox_backup "$KEY" "$KEY.pub"; }
t_do() { mkdir -p "$HOME/.ssh" && chmod 700 "$HOME/.ssh"; [ -f "$KEY" ] || ssh-keygen -t ed25519 -N "" -f "$KEY" -q; }
t_rollback() { nox_restore || true; }
t_check() {
  nox_chk "ключ $KEY существует" test -f "$KEY"
  [ -f "$KEY" ] || return 1
  local name tgt out
  for name in S1 S2; do
    if [ "$name" = S1 ]; then tgt="$S1"; else tgt="$NOX_S2_SSH"; fi
    # shellcheck disable=SC2046,SC2086
    if out="$(ssh $(nox_ssh_opts) $tgt 'nvidia-smi -L' 2>>"$NOX_LOGFILE")"; then
      case "$name:$out" in S1:*5060*|S2:*V100*) nox_log OK "$name: вход без пароля, GPU подтверждён";; *) nox_log NO "$name: ответил не тот сервер: $out"; NOX_NFAIL=$((NOX_NFAIL+1)); NOX_FAILS+="$name не тот сервер; ";; esac
    else
      nox_blocked "вход на $name без пароля не удался" "вставить в Vast -> Keys публичный ключ: $(cat "$KEY.pub" 2>/dev/null)"
    fi
  done
  nox_verdict
}
nox_run_task
