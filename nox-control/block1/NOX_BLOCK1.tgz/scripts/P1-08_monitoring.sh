#!/usr/bin/env bash
# ID: P1-08
# ЦЕЛЬ: запустить сэмплер метрик (GPU t°/VRAM, cgroup, PID/state/majflt llama-server, ток/с из /metrics) + дашборд; t° GPU <= 83.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-06
# ГОТОВО: monitor.csv обновляется (последняя строка < 30 с), dashboard.html есть, t° GPU <= 83. Замеры ток/с до/после рычагов делает P2-06 + lib/ab.sh (на S1 до загрузки модели скорости нет - не выдумывается).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: reports/monitor.csv, reports/dashboard.html, run/monitor.pid
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-08 S1 "$@"
NOX_PLAN="nohup lib/nox_monitor.sh (интервал ${NOX_MON_INTERVAL:-5} с); CSV + HTML дашборд; проверка свежести и температуры"
PIDF="$NOX_RUN_DIR/monitor.pid"
t_pre() { nox_need_cmd nvidia-smi python3 curl; }
t_do() { setsid nohup "$NOX_LIB_DIR/nox_monitor.sh" >>"$NOX_LOG_DIR/monitor.log" 2>&1 & echo $! >"$PIDF"; sleep $(( ${NOX_MON_INTERVAL:-5} * 2 + 2 )); }
t_rollback() { [ -s "$PIDF" ] && kill "$(cat "$PIDF")" 2>/dev/null || true; }
t_check() {
  local last age temp
  nox_chk "сэмплер жив" bash -c "[ -s '$PIDF' ] && kill -0 \$(cat '$PIDF')"
  nox_chk "monitor.csv есть" test -s "$NOX_REPORT_DIR/monitor.csv"
  [ -s "$NOX_REPORT_DIR/monitor.csv" ] || return 1
  last="$(tail -1 "$NOX_REPORT_DIR/monitor.csv" | cut -d, -f1)"; age=$(( $(date +%s) - $(date -d "$last" +%s) ))
  nox_metric csv_age_s "$age"; nox_chk "последняя строка < 30 с" test "$age" -lt 30
  nox_chk "dashboard.html есть" test -s "$NOX_REPORT_DIR/dashboard.html"
  temp="$(nox_gpu_temp)"; nox_metric gpu_temp_c "$temp"; nox_chk "t° GPU <= 83" nox_le "$temp" 83
  nox_metric sweep_bench_binary "$([ -x "${NOX_LLAMA_DIR:-$NOX_ROOT/llama.cpp}/build-sm120/bin/llama-sweep-bench" ] && echo yes || echo no)"
  nox_verdict
}
nox_run_task
