#!/usr/bin/env bash
# ID: P1-19
# ЦЕЛЬ: исключения autoclean для сервисов S2 (рабочий чат этапа А не должен удаляться чисткой).
# СЕРВЕР: S2
# ЗАВИСИМОСТИ: P1-02
# ГОТОВО: список исключений установлен; самотест: каталог сервиса не удалён после 2 циклов чистки, а мусор удалён.
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: $NOX_ROOT/bin/nox_autoclean.sh, $NOX_ROOT/etc/autoclean_exclude.txt
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-19 S2 "$@"
NOX_PLAN="установить nox_autoclean.sh с файлом исключений (S03, адаптеры, судьи, чат, логи, receipts, backups); самотест на песочнице"
t_pre() { nox_need_cmd find python3; }
t_do() {
  mkdir -p "$NOX_ROOT/bin" "$NOX_ROOT/etc"
  [ -s "$NOX_ROOT/etc/autoclean_exclude.txt" ] || cat >"$NOX_ROOT/etc/autoclean_exclude.txt" <<X
# маски каталогов/файлов, которые чистка не трогает никогда (по одной на строку)
s03
adapters
judges
chat
receipts
backups
logs
src
scripts
run
models
X
  [ -n "${NOX_S2_S03_PATH:-}" ] && { grep -qxF "$NOX_S2_S03_PATH" "$NOX_ROOT/etc/autoclean_exclude.txt" || echo "$NOX_S2_S03_PATH" >>"$NOX_ROOT/etc/autoclean_exclude.txt"; }
  cat >"$NOX_ROOT/bin/nox_autoclean.sh" <<'X'
#!/usr/bin/env bash
# nox_autoclean.sh [КАТАЛОГ] - удаляет файлы старше NOX_CLEAN_DAYS (7) в КАТАЛОГЕ (по умолчанию /tmp/nox_tmp), кроме масок из autoclean_exclude.txt.
set -u
ROOT="${NOX_ROOT:-/root/nox}"; D="${1:-/tmp/nox_tmp}"; DAYS="${NOX_CLEAN_DAYS:-7}"; EX="$ROOT/etc/autoclean_exclude.txt"
[ -d "$D" ] || exit 0
args=(); while IFS= read -r m; do case "$m" in ''|\#*) continue;; esac; args+=( -not -path "*/$m/*" -not -path "*/$m" ); done <"$EX"
find "$D" -mindepth 1 -type f -mtime +"$DAYS" "${args[@]}" -delete 2>/dev/null
exit 0
X
  chmod +x "$NOX_ROOT/bin/nox_autoclean.sh"
}
t_check() {
  nox_chk "nox_autoclean.sh и исключения установлены" test -x "$NOX_ROOT/bin/nox_autoclean.sh" -a -s "$NOX_ROOT/etc/autoclean_exclude.txt"
  [ -x "$NOX_ROOT/bin/nox_autoclean.sh" ] || return 1
  local T; T="$(mktemp -d)"; mkdir -p "$T/s03" "$T/other"
  echo db >"$T/s03/memory.sqlite3"; echo junk >"$T/other/old.tmp"
  touch -d '30 days ago' "$T/s03/memory.sqlite3" "$T/other/old.tmp"
  "$NOX_ROOT/bin/nox_autoclean.sh" "$T"; "$NOX_ROOT/bin/nox_autoclean.sh" "$T"
  nox_chk "сервисный файл не удалён после 2 циклов" test -f "$T/s03/memory.sqlite3"
  nox_chk "обычный старый мусор удалён" test ! -f "$T/other/old.tmp"
  rm -rf "${T:?}"
  nox_verdict
}
nox_run_task
