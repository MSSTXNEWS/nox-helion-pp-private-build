#!/usr/bin/env bash
# ID: P1-T05
# ЦЕЛЬ: потоки -t на S2 по квоте cgroup (cpu.max), иначе лишние потоки душат чат при обучении.
# СЕРВЕР: S2
# ЗАВИСИМОСТИ: нет
# ГОТОВО: run/s2_threads.json: t = floor(квота ядер) - 1 (>=1), tb = ceil(квота); A/B на exam20 (P1-09) >= +5% проверяется отдельно в P2-12 - здесь честно записывается статус ab=pending.
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: run/s2_threads.json (используют лаунчеры S2 через NOX_THREADS)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-T05 S2 "$@"
NOX_PLAN="прочитать cpu.max cgroup (или nproc); посчитать -t/-tb; записать run/s2_threads.json"
t_pre() { nox_need_cmd python3 nproc; }
quota() { local f=/sys/fs/cgroup/cpu.max q p; if [ -r "$f" ]; then read -r q p <"$f"; [ "$q" != max ] && { awk -v q="$q" -v p="$p" 'BEGIN{printf "%.2f", q/p}'; return; }; fi
  if [ -r /sys/fs/cgroup/cpu/cpu.cfs_quota_us ]; then q="$(cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us)"; p="$(cat /sys/fs/cgroup/cpu/cpu.cfs_period_us)"; [ "$q" -gt 0 ] && { awk -v q="$q" -v p="$p" 'BEGIN{printf "%.2f", q/p}'; return; }; fi
  nproc; }
t_do() {
  local c; c="$(quota)"
  python3 -I - "$NOX_RUN_DIR/s2_threads.json" "$c" "$(nproc)" <<'P'
import json,sys,math,time
f,c,n=sys.argv[1],float(sys.argv[2]),int(sys.argv[3])
eff=min(c,n); t=max(1,math.floor(eff)-1); tb=max(t,math.ceil(eff))
json.dump({"t":time.strftime("%FT%TZ",time.gmtime()),"cgroup_cores":c,"nproc":n,"t":t,"tb":tb,"ab":"pending (P2-12: exam20 >=+5%, TTFT без роста)"},open(f,"w"),indent=1)
P
}
t_check() {
  nox_chk "s2_threads.json есть" test -s "$NOX_RUN_DIR/s2_threads.json"
  [ -s "$NOX_RUN_DIR/s2_threads.json" ] || return 1
  local t c; t="$(python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1]))["t"])' "$NOX_RUN_DIR/s2_threads.json")"; c="$(python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1]))["cgroup_cores"])' "$NOX_RUN_DIR/s2_threads.json")"
  nox_metric threads_t "$t"; nox_metric cgroup_cores "$c"
  nox_chk "t не больше квоты cgroup и >=1" bash -c "awk -v t=$t -v c=$c 'BEGIN{exit !(t>=1 && t<=c)}'"
  nox_verdict
}
nox_run_task
