#!/usr/bin/env bash
# ID: P1-06
# ЦЕЛЬ: собрать llama.cpp master под sm_120 в отдельный каталог; зафиксировать хэш; убедиться, что glm-dsa и --moe-cache-mib есть.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-05
# ГОТОВО: llama-server --version печатает версию; хэш в $NOX_ROOT/run/llama_build.json; в исходниках glm-dsa; в --help есть --moe-cache-mib; CMakeCache: CUDA arch 120.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: GitHub https://github.com/ggml-org/llama.cpp ветка/тег NOX_LLAMA_REF (по умолчанию master; ревизию записывает в llama_build.json - для воспроизводимости зафиксируйте её в nox.env);
#             apt: git cmake build-essential
#   Патчи: scripts/patches/llama.cpp/*.patch (если есть; каждый с "# applies-to: <commit>"); применяется после git apply --check, неприменимый патч -> BLOCKED
#   Генерируется: $NOX_LLAMA_DIR/build-sm120, run/llama_build.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-06 S1 "$@"
NOX_PLAN="git clone/fetch ggml-org/llama.cpp; cmake -DGGML_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=120 -DGGML_NATIVE=ON; build; --version; проверка glm-dsa и --moe-cache-mib"
DIR="${NOX_LLAMA_DIR:-$NOX_ROOT/llama.cpp}"; B="$DIR/build-sm120"; REF="${NOX_LLAMA_REF:-master}"
t_pre() { nox_need_cmd git cmake nvcc; nox_need_ram_free $((8*1024*1024*1024)); }
t_backup() { [ -d "$B" ] && { rm -rf "$B.prev"; mv "$B" "$B.prev"; nox_log INFO "прежняя сборка -> $B.prev"; } || true; }
t_rollback() { [ -d "$B.prev" ] && { rm -rf "$B"; mv "$B.prev" "$B"; nox_log INFO "восстановлена прежняя сборка"; } || true; }
t_do() {
  [ -d "$DIR/.git" ] || git clone https://github.com/ggml-org/llama.cpp "$DIR" >>"$NOX_LOGFILE" 2>&1
  git -C "$DIR" fetch --tags origin >>"$NOX_LOGFILE" 2>&1
  git -C "$DIR" checkout -q "$REF" && { git -C "$DIR" merge -q --ff-only "origin/$REF" 2>/dev/null || true; }
  nox_patch_dir "$DIR" "$NOX_SCRIPTS_DIR/patches/llama.cpp"
  local cc=(); [ -s "$NOX_RUN_DIR/cuda_ccbin" ] && cc=(-DCMAKE_CUDA_HOST_COMPILER="$(command -v "$(cat "$NOX_RUN_DIR/cuda_ccbin")")")
  cmake -S "$DIR" -B "$B" -DGGML_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=120 -DGGML_NATIVE=ON -DCMAKE_BUILD_TYPE=Release "${cc[@]}" >>"$NOX_LOGFILE" 2>&1
  cmake --build "$B" -j "$(nproc)" >>"$NOX_LOGFILE" 2>&1
}
t_check() {
  nox_chk "llama-server собран" test -x "$B/bin/llama-server"
  [ -x "$B/bin/llama-server" ] || return 1
  local v h; v="$("$B/bin/llama-server" --version 2>&1 | tr '\n' ' ')"; h="$(git -C "$DIR" rev-parse HEAD)"
  nox_chk "--version печатает версию" test -n "$v"
  nox_chk "CMakeCache: CUDA arch 120" grep -q 'CMAKE_CUDA_ARCHITECTURES:.*=120' "$B/CMakeCache.txt"
  nox_chk "glm-dsa в исходниках" grep -rqs 'glm-dsa' "$DIR/src"
  nox_chk "--moe-cache-mib есть в --help" bash -c "'$B/bin/llama-server' --help 2>&1 | grep -q -- '--moe-cache-mib'"
  printf '{"commit":"%s","ref":"%s","version":"%s","build":"%s"}\n' "$h" "$REF" "$v" "$B" >"$NOX_RUN_DIR/llama_build.json"
  nox_metric commit "$h"; nox_metric version "$v"
  nox_verdict
}
nox_run_task
