#!/usr/bin/env bash
# ID: P1-T12
# ЦЕЛЬ: приоритетный менеджер ресурсов S1: чат > судья > фон; вытеснение (SIGSTOP только с замком паузы 9.7) и IDLE-гейт.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-03
# ГОТОВО: самотест: фон-пустышка получает nice 15; при активном чате gate=занят и evict ставит на паузу с замком; при IDLE снимает.
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: /root/nox/slots/nox_prio.py, run/prio_applied.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-T12 S1 "$@"
NOX_PLAN="установить /root/nox/slots/nox_prio.py; самотест на процессе nox_train_selftest: nice, gate, evict/resume с замком"
t_pre() { nox_need_cmd python3 pgrep ionice; }
t_do() { mkdir -p "$NOX_ROOT/slots"; install -m 755 "$NOX_LIB_DIR/nox_prio.py" "$NOX_ROOT/slots/nox_prio.py"; }
st() { sed 's/.*) //' "/proc/$1/stat" | cut -c1; }
t_check() {
  nox_chk "nox_prio.py установлен" test -x "$NOX_ROOT/slots/nox_prio.py"
  [ -x "$NOX_ROOT/slots/nox_prio.py" ] || return 1
  local P="$NOX_ROOT/slots/nox_prio.py" pid
  ( exec -a nox_train_selftest sleep 120 ) & pid=$!; sleep 0.5
  export NOX_IDLE_S=3 NOX_BG_PATTERNS=nox_train_selftest
  python3 "$P" apply >>"$NOX_LOGFILE" 2>&1 || true
  nox_chk "фон получил nice 15" test "$(ps -o ni= -p $pid | tr -d ' ')" = 15
  python3 "$P" touch
  nox_chk "gate: чат активен -> фон нельзя" bash -c "! python3 $P gate"
  python3 "$P" evict; sleep 0.3
  nox_chk "вытеснение: процесс остановлен, замок паузы есть" bash -c "[ \"$(st $pid)\" = T ] && [ -f \"${NOX_PAUSE_DIR:?}/${pid:?}.lock\" ]"
  sleep 4
  nox_chk "gate: IDLE -> фон можно" python3 "$P" gate
  python3 "$P" evict; sleep 0.3
  nox_chk "резюме при IDLE: процесс не T, замок снят" bash -c "[ \"$(st $pid)\" != T ] && [ ! -f \"${NOX_PAUSE_DIR:?}/${pid:?}.lock\" ]"
  kill -CONT "$pid" 2>/dev/null || true; kill "$pid" 2>/dev/null || true
  nox_verdict
}
nox_run_task
