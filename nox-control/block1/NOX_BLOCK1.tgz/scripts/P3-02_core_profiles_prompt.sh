#!/usr/bin/env bash
# ID: P3-02
# ЦЕЛЬ: профили ядер C01-C08 в стабильном префиксе промпта; переключение ядра указателем в хвосте по классу запроса (не ломает prefix-кэш).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P3-01, P2-10
# ГОТОВО: для 8 классов запросов лог запросов показывает активное ядро и один и тот же prefix_sha; при смене класса prefix-кэш сервера хитует >= 95%.
# ФАЙЛЫ: те же, что в P2-10 (душа, режим, core из P4-04).
# ИСТОЧНИКИ:
#   Drive: см. P2-10 (SOUL R1 1LuKHNr5S23eR9SwV8IjnLgiYTExhW8TAeJVz9Rl6njA, SOUL WEIGHTS 1OGzZGFN_rl2mG_vvOvVEIgTUwqilhR8-sfqcjAPQubc; команда: lib/nox_fetch_drive.sh <ID> <dest> txt)
#   Интернет: нет
#   Генерируется: logs/requests.jsonl (лог собранных запросов)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P3-02 S1 "$@"
SOUL="${NOX_SOUL_FILE:-$NOX_SRC_DIR/soul_prompt.txt}"; MODE="${NOX_MODE_FILE:-$NOX_SRC_DIR/mode_auto.txt}"; CORE="$NOX_ROOT/prefix/core.md"; RLOG="$NOX_LOG_DIR/requests.jsonl"
NOX_PLAN="assemble() для 8 классов; проверка лога; два запроса с разными ядрами -> хит кэша"
t_pre() { nox_need_receipt P3-01 P2-10; nox_need_file "$SOUL"; nox_need_file "$MODE"; nox_need_file "$CORE"; nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "llama-server не отвечает" "P2-04"; }
t_check() {
  : >"$NOX_TMP/req.jsonl"
  python3 -B - "$SOUL" "$MODE" "$CORE" "$NOX_TMP/req.jsonl" "$RLOG" "$NOX_LLAMA_URL" "$NOX_TMP/hit.txt" <<'PY' || { nox_log NO "сборка/запросы не прошли"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
import os, sys
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_cores as C, nox_llm as L
soul, mode, core, tmp, rlog, url, hitf = sys.argv[1:8]
rd = lambda p: open(p, encoding="utf-8").read()
last = None
for cls in C.CLASS_TO_CORE:
    m = C.assemble(rd(soul), rd(mode), rd(core), cls, "Проверка класса %s." % cls, "[статус: ok]", tmp)
    m2 = C.assemble(rd(soul), rd(mode), rd(core), cls, "Проверка класса %s." % cls, "[статус: ok]", rlog)
    last = m
a = C.assemble(rd(soul), rd(mode), rd(core), "chat", "Привет.", "[статус: ok]", tmp)
L.chat_sync(url, a, 1, {"cache_prompt": True, "id_slot": 0, "temperature": 0})
b = C.assemble(rd(soul), rd(mode), rd(core), "build", "Привет.", "[статус: ok]", tmp)
r = L.chat_sync(url, b, 1, {"cache_prompt": True, "id_slot": 0, "temperature": 0})
h = L.hit_ratio(r)
open(hitf, "w").write("" if h is None else "%.4f" % h)
PY
  nox_chk "в логе 8 разных активных ядер" test "$(python3 -c 'import json,sys;print(len({json.loads(l)["active_core"] for l in open(sys.argv[1])}))' "$RLOG")" -ge 8
  nox_chk "prefix_sha одинаков во всех запросах" test "$(python3 -c 'import json,sys;print(len({json.loads(l)["prefix_sha"] for l in open(sys.argv[1])}))' "$NOX_TMP/req.jsonl")" -eq 1
  [ -s "$NOX_TMP/hit.txt" ] || nox_blocked "сервер не отдаёт timings.cache_n" "версия llama-server с cache_n"
  nox_metric hit_after_core_switch "$(cat "$NOX_TMP/hit.txt")"; nox_chk "хит кэша при смене ядра >= 95%" nox_ge "$(cat "$NOX_TMP/hit.txt")" 0.95
  nox_verdict
}
nox_run_task
