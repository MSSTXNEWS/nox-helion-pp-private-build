#!/usr/bin/env bash
# ID: P2-08
# ЦЕЛЬ: батчи префилла: -b/-ub (4096/1024 против 4096/4096) и GGML_OP_OFFLOAD_MIN_BATCH (сетка NOX_OFFLOAD_GRID, по умолчанию "64 256"; значения сетки - экспериментальные, не факты); замер prefill т/с на ~5000-токенном промпте.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-06
# ГОТОВО: prefill т/с до/после в CSV; лучшая конфигурация применяется только при приросте >= 5%, иначе остаётся база (это PASS: измерение выполнено и решение записано).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет (G13/G14 канона 23: -b 4096 -ub 4096; GGML_OP_OFFLOAD_MIN_BATCH по умолчанию 32)
#   Генерируется: reports/P2-08_prefill.csv
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_llama_ctl.sh"
nox_begin P2-08 S1 "$@"
NOX_PLAN="варианты (ub, OFFLOAD_MIN_BATCH): рестарт + prefill-замер long5000 x2; выбрать лучший; применить если >=5%"
CSV="$NOX_REPORT_DIR/P2-08_prefill.csv"
t_pre() { nox_need_receipt P2-06; nox_need_file "$LLAMA_ARGS_FILE"; }
pf() { nox_llm bench --url "$NOX_LLAMA_URL" --repeats 2 --n 1 --only long5000 --out "$NOX_TMP/p.csv" | python3 -c 'import json,sys;print(json.load(sys.stdin)["prefill_tps_p50"])'; }
t_backup() { cp -a "$LLAMA_ARGS_FILE" "$NOX_RUN_DIR/llama.args.P2-08.orig"; nox_backup "$NOX_ROOT/services.d/llama.conf"; }
t_rollback() { cp -a "$NOX_RUN_DIR/llama.args.P2-08.orig" "$LLAMA_ARGS_FILE"; llama_args_load; llama_conf_write; llama_restart || true; nox_maint_end; }
t_do() {
  nox_maint_begin 14400; echo "ub,offload_min_batch,prefill_tps_p50" >"$CSV"
  local ub om best_ub best_om best base grid="unset ${NOX_OFFLOAD_GRID:-64 256}" tps env
  llama_args_load; base_ub="$(printf '%s\n' "${LLAMA_ARGS[@]}" | awk 'p{print;exit} $0=="-ub"{p=1}')"
  base="$(pf)"; echo "$base_ub,unset,$base" >>"$CSV"; best="$base"; best_ub="$base_ub"; best_om='unset'
  for ub in ${NOX_UB_LIST:-4096}; do
    for om in $grid; do
      [ "$ub" = "$base_ub" ] && [ "$om" = unset ] && continue
      llama_args_load; llama_flag_set -ub "$ub"; env=(); [ "$om" != unset ] && env=("GGML_OP_OFFLOAD_MIN_BATCH=$om")
      llama_stop; if ! llama_start "${env[@]}"; then nox_log WARN "ub=$ub om=$om: не поднялся (VRAM) - пропуск"; echo "$ub,$om,FAILED_START" >>"$CSV"; continue; fi
      tps="$(pf)"; echo "$ub,$om,$tps" >>"$CSV"
      if awk -v a="$tps" -v b="$best" 'BEGIN{exit !(a>b)}'; then best="$tps"; best_ub="$ub"; best_om="$om"; fi
    done
  done
  nox_metric prefill_before "$base"; nox_metric prefill_best "$best"; nox_metric best_ub "$best_ub"; nox_metric best_offload_min_batch "$best_om"
  local gain; gain="$(awk -v a="$best" -v b="$base" 'BEGIN{printf "%.1f",(a/b-1)*100}')"; nox_metric gain_pct "$gain"
  llama_args_load; env=()
  if awk -v g="$gain" 'BEGIN{exit !(g>=5)}'; then llama_flag_set -ub "$best_ub"; [ "$best_om" != unset ] && env=("GGML_OP_OFFLOAD_MIN_BATCH=$best_om"); nox_log INFO "применяется: ub=$best_ub om=$best_om"
  else llama_flag_set -ub "$base_ub"; nox_log INFO "прирост < 5%: остаётся база"; fi
  llama_args_save; llama_conf_write "${env[@]}"; llama_restart "${env[@]}"; nox_maint_end
}
t_check() {
  nox_chk "CSV замеров есть (>= 2 строки)" test "$(wc -l <"$CSV" 2>/dev/null || echo 0)" -ge 2
  nox_chk "сервер здоров" nox_health "$NOX_LLAMA_URL"
  nox_chk "в CSV есть замер базы" awk -F, 'NR==2&&$3+0>0{f=1}END{exit !f}' "$CSV"
  nox_verdict
}
nox_run_task
