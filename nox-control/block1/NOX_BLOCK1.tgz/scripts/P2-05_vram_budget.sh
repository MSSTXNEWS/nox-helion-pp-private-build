#!/usr/bin/env bash
# ID: P2-05
# ЦЕЛЬ: замер VRAM по потребителям после старта и после контекста ~32к токенов -> бюджет под moe-cache, младшего судью, bge-m3.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-04
# ГОТОВО: reports/P2-05_vram.csv (стадии: idle, after_32k; used/free/процесс llama-server); реально обработано >= 30000 токенов промпта.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: reports/P2-05_vram.csv, run/vram_budget.json (free_mib_after_32k для P2-19)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-05 S1 "$@"
NOX_PLAN="nvidia-smi после старта; префилл ~31000 токенов (n_predict=1); nvidia-smi снова; CSV"
CSV="$NOX_REPORT_DIR/P2-05_vram.csv"
t_pre() { nox_need_receipt P2-04; nox_need_cmd nvidia-smi python3; nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "llama-server не отвечает" "запустить P2-04"; }
row() { local pid; pid="$(nox_llama_pid)"
  echo "$1,$(nox_vram_used_mib),$(nox_vram_free_mib),$(nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader,nounits | awk -F, -v p="$pid" '$1+0==p+0{gsub(/ /,"",$2);print $2}' | head -1)" >>"$CSV"; }
t_check() {
  echo "stage,used_mib,free_mib,llama_server_mib" >"$CSV"; row idle
  local text r n
  text="$(python3 -B -c 'import sys;sys.path.insert(0,"'"$NOX_LIB_DIR"'");import nox_llm;print(nox_llm.fill("'"$NOX_LLAMA_URL"'",31000))')"
  r="$(python3 -B -c 'import sys,json;sys.path.insert(0,"'"$NOX_LIB_DIR"'");import nox_llm;r=nox_llm.completion("'"$NOX_LLAMA_URL"'",sys.stdin.read(),1,{"cache_prompt":False});print(json.dumps(r["timings"]))' <<<"$text")" || nox_blocked "префилл 31000 токенов не выполнился" "ответ llama-server (см. лог); возможно мал -c"
  n="$(python3 -c 'import json,sys;print(json.loads(sys.argv[1]).get("prompt_n",0))' "$r")"; nox_metric prompt_tokens "$n"
  nox_chk "обработано >= 30000 токенов контекста" test "$n" -ge 30000
  row after_32k
  local f; f="$(tail -1 "$CSV" | cut -d, -f3)"; nox_metric vram_free_after_32k_mib "$f"; nox_metric vram_used_after_32k_mib "$(tail -1 "$CSV" | cut -d, -f2)"
  nox_metric prefill_tps "$(python3 -c 'import json,sys;print(round(json.loads(sys.argv[1]).get("prompt_per_second",0),1))' "$r")"
  printf '{"free_mib_after_32k":%s,"total_mib":%s}\n' "$f" "$(nox_vram_total_mib)" >"$NOX_RUN_DIR/vram_budget.json"
  nox_chk "таблица содержит 2 стадии" test "$(wc -l <"$CSV")" -eq 3
  nox_verdict
}
nox_run_task
