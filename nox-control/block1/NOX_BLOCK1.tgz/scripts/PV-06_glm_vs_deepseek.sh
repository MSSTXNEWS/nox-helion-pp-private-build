#!/usr/bin/env bash
# ID: PV-06
# ЦЕЛЬ: испытание роли GLM в «Глубоко» и решение про «Авто»: одинаковые задания на GLM-5.3 (S1, effort high) и DeepSeek (S2): русский, код, файлы, вызов инструментов, длинный диалог.
# СЕРВЕР: S1 (DeepSeek на S2 достигается по tailnet)
# ЗАВИСИМОСТИ: P2-06 (внешняя справочная: P7-14 - экзамен второй волны; здесь используется собственный набор config/pv06_tasks.jsonl)
# ГОТОВО: таблица reports/PV-06_table.csv (по задаче и модели: время до первого содержательного текста, ток/с, верно/неверно), сводка reports/PV-06_decision.json с рекомендацией и пометкой decision=owner_Q. Решение "Авто" принимает владелец (Q).
# ПРАВИЛО РЕКОМЕНДАЦИИ (записывается в файл): GLM допускается в «Авто», только если p95 времени до содержательного текста <= NOX_AUTO_ETA_S и качество не ниже DeepSeek; иначе GLM остаётся для «Глубоко».
# ФАКТЫ (не выдумываются): NOX_DEEPSEEK_URL (OpenAI-совместимый API DeepSeek на S2, достижимый с S1), NOX_AUTO_ETA_S, лимит токенов: NOX_PV06_MAX_TOKENS либо deep.max_tokens из config/reasoning_modes.json (P2-15). S03-категория проверяется отдельно (P4-09/PV-03).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: reports/PV-06_table.csv, reports/PV-06_decision.json (задания: config/pv06_tasks.jsonl, составлены для NOX)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin PV-06 S1 "$@"
NOX_PLAN="11 заданий x 2 модели (GLM high / DeepSeek); таблица; сводка; правило рекомендации"
T="${NOX_PV06_TASKS:-$NOX_SCRIPTS_DIR/config/pv06_tasks.jsonl}"
t_pre() { nox_need_receipt P2-06; nox_need_var NOX_DEEPSEEK_URL NOX_AUTO_ETA_S; nox_need_file "$T"
  nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "GLM не отвечает" "P2-04"
  curl -fsS --max-time 10 "$NOX_DEEPSEEK_URL/v1/models" >/dev/null 2>&1 || nox_blocked "DeepSeek на S2 не отвечает на /v1/models" "адрес API DeepSeek (NOX_DEEPSEEK_URL), доступный с S1"; }
t_check() {
  local mt="${NOX_PV06_MAX_TOKENS:-}"
  [ -n "$mt" ] || mt="$(python3 -c 'import json;print(json.load(open("'"$NOX_ROOT"'/config/reasoning_modes.json"))["modes"]["deep"]["max_tokens"])' 2>/dev/null || true)"
  [ -n "$mt" ] || nox_blocked "нет лимита токенов" "NOX_PV06_MAX_TOKENS или reasoning_modes.json (P2-15)"
  python3 -B "$NOX_LIB_DIR/nox_pv06.py" --glm "$NOX_LLAMA_URL" --ds "$NOX_DEEPSEEK_URL" --tasks "$T" --max-tokens "$mt" --out-csv "$NOX_REPORT_DIR/PV-06_table.csv" --out-json "$NOX_TMP/s.json" >>"$NOX_LOGFILE" 2>&1 \
    || { nox_log NO "прогон не завершён"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
  python3 - "$NOX_TMP/s.json" "$NOX_REPORT_DIR/PV-06_decision.json" "$NOX_AUTO_ETA_S" <<'PY'
import json, sys
s = json.load(open(sys.argv[1])); eta = float(sys.argv[3]); g, d = s["GLM-5.3"], s["DeepSeek"]
auto_ok = g["t_content_p95"] is not None and g["t_content_p95"] <= eta and g["quality"] >= d["quality"]
json.dump({"summary": s, "auto_eta_s": eta, "recommendation": "GLM допустим в Авто" if auto_ok else "GLM только в Глубоко/Максимум, Авто - не отдавать вслепую",
           "decision": "owner_Q"}, open(sys.argv[2], "w"), ensure_ascii=False, indent=1)
PY
  local k m; for m in "GLM-5.3" "DeepSeek"; do for k in quality errors t_content_p95 tps_p50; do nox_metric "${m}_$k" "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))[sys.argv[2]][sys.argv[3]])' "$NOX_TMP/s.json" "$m" "$k")"; done; done
  nox_chk "таблица записана (22 строки)" test "$(( $(wc -l <"$NOX_REPORT_DIR/PV-06_table.csv") - 1 ))" -eq 22
  nox_chk "без транспортных ошибок у обеих моделей" python3 -c 'import json,sys;s=json.load(open(sys.argv[1]));sys.exit(0 if s["GLM-5.3"]["errors"]==0 and s["DeepSeek"]["errors"]==0 else 1)' "$NOX_TMP/s.json"
  nox_chk "решение для владельца записано" test -s "$NOX_REPORT_DIR/PV-06_decision.json"
  nox_verdict
}
nox_run_task
