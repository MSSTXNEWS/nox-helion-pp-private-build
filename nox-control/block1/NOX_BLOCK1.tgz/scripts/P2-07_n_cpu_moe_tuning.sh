#!/usr/bin/env bash
# ID: P2-07
# ЦЕЛЬ: подбор раскладки экспертов вручную: --cpu-moe заменяется на --n-cpu-moe (n_layer-k), k = число последних слоёв с экспертами в VRAM; шаг +1 слой, замер ток/с.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-06
# ГОТОВО: лучшая раскладка записана в run/llama.args и services.d/llama.conf; прирост decode p50 >= 5% к базе (иначе FAIL и откат на базовую раскладку).
# ОГРАНИЧЕНИЕ: k ограничено бюджетом VRAM из P2-05 (размер слоя = размер модели / n_layer); OOM при старте = конец перебора.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет (флаги llama.cpp: --n-cpu-moe, -ot; решение "small cards: tune by hand first" - канон В2)
#   Генерируется: reports/P2-07_sweep.csv, run/llama.best
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_llama_ctl.sh"
nox_begin P2-07 S1 "$@"
NOX_PLAN="для k=0..K: рестарт с --n-cpu-moe (n_layer-k), bench (3 короткие x3); выбрать лучший; применить; откат при провале"
CSV="$NOX_REPORT_DIR/P2-07_sweep.csv"
t_pre() { nox_need_receipt P2-06 P2-05; nox_need_file "$LLAMA_ARGS_FILE"; nox_need_file "$NOX_RUN_DIR/vram_budget.json"; }
measure() { nox_llm bench --url "$NOX_LLAMA_URL" --repeats 3 --n 64 --only short_en,ru,code --out "$NOX_TMP/b.csv" | python3 -c 'import json,sys;print(json.load(sys.stdin)["decode_tps_p50"])'; }
t_backup() { cp -a "$LLAMA_ARGS_FILE" "$NOX_RUN_DIR/llama.args.P2-07.orig"; nox_backup "$NOX_ROOT/services.d/llama.conf"; }
t_rollback() { cp -a "$NOX_RUN_DIR/llama.args.P2-07.orig" "$LLAMA_ARGS_FILE"; llama_args_load; llama_conf_write; llama_restart || true; nox_maint_end; }
t_do() {
  nox_maint_begin 14400; llama_args_load
  local nl total_mib free per kmax k best_k=0 best base tps; nl="$(llama_n_layer)"; [ -n "$nl" ] || nox_blocked "n_layer не найден в логе llama-server" "строка n_layer в $LLAMA_SVCLOG (запустите сервер с логом загрузки)"
  total_mib="$(python3 -c 'import json;print(sum(f["size"] for f in json.load(open("'"$NOX_RUN_DIR"'/glm53_manifest.json"))["files"])//2**20)')"
  free="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/vram_budget.json"))["free_mib_after_32k"])')"
  per=$((total_mib / nl)); kmax=$(( free * 9 / 10 / per )); [ -n "${NOX_OT_MAX_LAYERS:-}" ] && [ "$kmax" -gt "$NOX_OT_MAX_LAYERS" ] && kmax="$NOX_OT_MAX_LAYERS"
  nox_metric n_layer "$nl"; nox_metric layer_mib "$per"; nox_metric k_max "$kmax"
  echo "k,n_cpu_moe,decode_tps_p50" >"$CSV"
  base="$(measure)"; echo "0,cpu-moe,$base" >>"$CSV"; best="$base"; nox_metric base_tps "$base"
  for k in $(seq 1 "$kmax"); do
    llama_args_load; llama_flag_del --cpu-moe; llama_flag_set --n-cpu-moe "$((nl - k))"
    llama_stop
    if ! llama_start; then nox_log WARN "k=$k: сервер не поднялся (вероятно, нехватка VRAM) - перебор остановлен"; break; fi
    tps="$(measure)"; echo "$k,$((nl-k)),$tps" >>"$CSV"; nox_log INFO "k=$k tps=$tps"
    if awk -v a="$tps" -v b="$best" 'BEGIN{exit !(a>b)}'; then best="$tps"; best_k=$k; fi
  done
  nox_metric best_k "$best_k"; nox_metric best_tps "$best"; nox_metric gain_pct "$(awk -v a="$best" -v b="$base" 'BEGIN{printf "%.1f",(a/b-1)*100}')"
  llama_args_load; llama_flag_del --cpu-moe; llama_flag_del --n-cpu-moe 1
  if [ "$best_k" -gt 0 ]; then llama_flag_set --n-cpu-moe "$((nl - best_k))"; else llama_flag_set --cpu-moe; fi
  llama_args_save; llama_conf_write; echo "$best_k" >"$NOX_RUN_DIR/llama.best"
  llama_restart; nox_maint_end
}
t_check() {
  nox_chk "sweep CSV записан" test -s "$CSV"
  [ -s "$CSV" ] || return 1
  local base best gain; base="$(awk -F, 'NR==2{print $3}' "$CSV")"; best="$(awk -F, 'NR>1&&$3>m{m=$3}END{print m}' "$CSV")"
  gain="$(awk -v a="$best" -v b="$base" 'BEGIN{printf "%.1f",(a/b-1)*100}')"; nox_metric gain_pct "$gain"
  nox_chk "прирост >= 5%" nox_ge "$gain" 5
  nox_chk "сервер здоров с лучшей раскладкой" nox_health "$NOX_LLAMA_URL"
  nox_verdict
}
nox_run_task
