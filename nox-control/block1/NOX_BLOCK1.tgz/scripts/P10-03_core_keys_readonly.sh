#!/usr/bin/env bash
# ID: P10-03
# ЦЕЛЬ: неприкосновенное ядро и ключи (B56/9.3): ядро, сторож, бэкапы и ключи (SSH, токены S03/HF, пароль restic) недоступны для записи пользователю nox.
# СЕРВЕР: S1,S2
# ЗАВИСИМОСТИ: P1-11
# ГОТОВО: от имени nox запись/удаление/переименование в каждом защищённом пути запрещены; чтение разрешено только там, где это нужно сервису (ключи 0600 root - nox их не читает); перечень путей и права записаны в квитанцию.
# ФАКТЫ (не выдумываются): NOX_PROTECT_PATHS (ядро), NOX_KEYS_PATHS (каталоги/файлы ключей: например ~/.ssh, токены); токены/пароли из run/ и owner/ скрипт добавляет сам, если они существуют.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: права chown root:root, chmod go-w (для секретов 0600); бэкап прежних прав в run/P10-03.perms
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P10-03 S1,S2 "$@"
NOX_PLAN="chown root + chmod на ядро/сторож/бэкапы/ключи; тест от nox: touch/rm/mv запрещены"
SECRETS=(); for s in "$NOX_RUN_DIR/s03.token" "$NOX_ROOT/owner/restic.pass" "$NOX_ROOT/owner"; do [ -e "$s" ] && SECRETS+=("$s"); done
t_pre() { nox_need_var NOX_PROTECT_PATHS NOX_KEYS_PATHS; [ "$(id -u)" = 0 ] || nox_blocked "нужен root" "запуск от root"; id nox >/dev/null 2>&1 || nox_blocked "нет пользователя nox" "выполнить P1-11"; nox_need_receipt P1-11; }
t_backup() { stat -c '%n %U:%G %a' $NOX_PROTECT_PATHS $NOX_KEYS_PATHS "${SECRETS[@]}" "$NOX_BACKUP_DIR" "$NOX_LIB_DIR" >"$NOX_RUN_DIR/P10-03.perms" 2>/dev/null || true; }
t_rollback() { while read -r n o m; do [ -e "$n" ] && chown "${o}" "$n" && chmod "$m" "$n" || true; done <"$NOX_RUN_DIR/P10-03.perms"; }
t_do() {
  local p; for p in $NOX_PROTECT_PATHS "$NOX_BACKUP_DIR" "$NOX_LIB_DIR"; do chown -R root:root "$p"; chmod -R go-w "$p"; done
  for p in $NOX_KEYS_PATHS "${SECRETS[@]}"; do chown -R root:root "$p"; if [ -d "$p" ]; then chmod 700 "$p"; find "$p" -type f -exec chmod 600 {} +; else chmod 600 "$p"; fi; done
}
t_check() {
  local p all="$NOX_PROTECT_PATHS $NOX_KEYS_PATHS ${SECRETS[*]:-} $NOX_BACKUP_DIR $NOX_LIB_DIR"
  for p in $all; do
    if [ -d "$p" ]; then
      nox_chk "nox не создаёт файл в $p" bash -c "! su -s /bin/bash nox -c \"touch '$p/.nox_wtest'\" 2>/dev/null"; rm -f "$p/.nox_wtest"
      nox_chk "nox не переименовывает $p" bash -c "! su -s /bin/bash nox -c \"mv '$p' '$p.x'\" 2>/dev/null"
    else
      nox_chk "nox не пишет в $p" bash -c "! su -s /bin/bash nox -c \"echo x >> '$p'\" 2>/dev/null"
      nox_chk "nox не удаляет $p" bash -c "! su -s /bin/bash nox -c \"rm -f '$p'\" 2>/dev/null; [ -e '$p' ]"
    fi
  done
  nox_metric protected_paths "$(echo $all | wc -w)"
  for p in $NOX_KEYS_PATHS "${SECRETS[@]:-}"; do [ -e "$p" ] && nox_chk "секрет $p не читается пользователем nox" bash -c "! su -s /bin/bash nox -c \"cat '$p' >/dev/null 2>&1 || ls '$p' >/dev/null 2>&1\""; done
  nox_verdict
}
nox_run_task
