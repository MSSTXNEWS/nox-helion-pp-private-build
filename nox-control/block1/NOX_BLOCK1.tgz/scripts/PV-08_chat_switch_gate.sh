#!/usr/bin/env bash
# ID: PV-08
# ЦЕЛЬ: гейт переключения чата на S1: проверка условий PV-06, P4-03, P7-14, нагрузка обучения не поднимает TTFT чата S2 > 10% (против эталона P1-17) и подписанный владельцем чеклист.
# СЕРВЕР: S1 (S2 достигается по ssh/tailnet)
# ЗАВИСИМОСТИ: PV-06, P4-03, P1-11, P1-12, P4-04 (+ внешняя жёсткая: P7-14 - экзамен второй волны; пока её квитанции нет, скрипт честно отвечает BLOCKED)
# ГОТОВО: все квитанции PASS; TTFT S2 сейчас <= 1.10 x эталон P1-17; файл подписи владельца $NOX_ROOT/owner/PV-08.signed содержит sha256 текущего чеклиста.
# РУКАМИ ВЛАДЕЛЬЦА: прочитать reports/PV-08_checklist.md и подписать командой: bash PV-08_chat_switch_gate.sh --sign (записывает sha чеклиста и время; скрипт не подписывает за владельца).
# ФАКТЫ (не выдумываются): NOX_S2_CHAT_URL (достижим с S1), NOX_S2_SSH (чтение эталона P1-17 с S2: reports/P1-17_baseline.json).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: reports/PV-08_checklist.md, owner/PV-08.signed (владелец)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin PV-08 S1 "$@"
NOX_PLAN="проверить квитанции PV-06,P4-03,P7-14,P1-11,P1-12,P4-04; замер TTFT S2 против эталона; чеклист; подпись владельца"
SIGN="$NOX_ROOT/owner/PV-08.signed"; CL="$NOX_REPORT_DIR/PV-08_checklist.md"
t_pre() { nox_need_receipt PV-06 P4-03 P1-11 P1-12 P4-04 P7-14; nox_need_var NOX_S2_CHAT_URL NOX_S2_SSH
  if [[ " ${NOX_ARGS[*]:-} " == *" --sign "* ]] && [ "$DRY" != 1 ]; then [ -s "$CL" ] || nox_blocked "чеклиста ещё нет" "сначала запустите без --sign"; mkdir -p "$(dirname "$SIGN")"
    printf '%s %s\n' "$(sha256sum "$CL" | cut -d' ' -f1)" "$(date -u +%FT%TZ)" >"$SIGN"; nox_log INFO "подпись владельца записана"; fi; }
t_check() {
  local base now lim
  # shellcheck disable=SC2046,SC2086
  base="$(ssh $(nox_ssh_opts) $NOX_S2_SSH "cat '${NOX_S2_NOX_ROOT:-/root/nox}/reports/P1-17_baseline.json'" 2>>"$NOX_LOGFILE" | python3 -c 'import json,sys;print(json.load(sys.stdin)["ttft_p50"])')" \
    || nox_blocked "не удалось прочитать эталон P1-17 на S2" "выполнить P1-17 на S2 и доступ по ssh"
  now="$(python3 -B - "$NOX_S2_CHAT_URL" <<'PY'
import os, sys
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_llm as L
t = [L.chat(sys.argv[1], [{"role": "user", "content": p}], 48, {"temperature": 0})["ttft"] for p in ("Привет.", "Что такое RAM?", "Назови столицу Японии.", "Скажи слово: готов.", "Сколько будет 2+2?")]
print(L.pct(t, .5))
PY
)" || nox_blocked "замер TTFT чата S2 не удался" "доступность NOX_S2_CHAT_URL"
  lim="$(awk -v b="$base" 'BEGIN{print b*1.10}')"; nox_metric ttft_baseline_s "$base"; nox_metric ttft_now_s "$now"
  nox_chk "TTFT чата S2 не выше эталона более чем на 10%" nox_le "$now" "$lim"
  { echo "# Гейт PV-08: переключение чата на S1"; date -u +%FT%TZ; for d in PV-06 P4-03 P1-11 P1-12 P4-04 P7-14; do echo "- $d: $(nox_receipt_result $d)"; done
    echo "- TTFT S2: эталон $base с, сейчас $now с (лимит $lim)"; echo "- решение 'Авто' (PV-06): $(python3 -c 'import json;print(json.load(open("'"$NOX_REPORT_DIR"'/PV-06_decision.json"))["recommendation"])' 2>/dev/null)"; } >"$CL"
  if [ "$NOX_NFAIL" -eq 0 ] && ! { [ -s "$SIGN" ] && [ "$(cut -d' ' -f1 "$SIGN")" = "$(sha256sum "$CL" | cut -d' ' -f1)" ]; }; then
    nox_blocked "все условия гейта выполнены, ожидается подпись владельца" "владелец читает $CL и запускает: bash PV-08_chat_switch_gate.sh --sign"; fi
  nox_verdict
}
nox_run_task
