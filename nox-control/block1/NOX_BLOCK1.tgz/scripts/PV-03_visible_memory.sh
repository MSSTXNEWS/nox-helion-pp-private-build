#!/usr/bin/env bash
# ID: PV-03
# ЦЕЛЬ: «Что NOX вспомнил»: карточка памяти с источником, исправление/отзыв владельцем, изоляция проектов, сохранение после рестарта.
# СЕРВЕР: S2 (живой контур NOX на S2; исполнитель - MEM)
# ЗАВИСИМОСТИ: PV-01
# ГОТОВО: после рестарта правка на месте; чужой проект не виден; карточка содержит источник.
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА (не выдумываются): NOX_RESONANCE_URL; сценарий $NOX_ROOT/scenarios/PV-03.json с шагами-тегами: card_with_source,edit_or_revoke,project_isolation,persist_after_restart (формат - в шапке lib/nox_scenario.py).
#   Без сценария скрипт сохраняет openapi.json контура (если отдаётся) в $NOX_ROOT/discovery/ и честно отвечает BLOCKED. Это скрипт приёмки: он ПРОВЕРЯЕТ, а не меняет контур.
# ИСТОЧНИКИ:
#   Drive: Evidence Gate 1JiSWC-mhg7y_RLehUgQZxNZNEHZzbwQ9ykYc4SHY5dE (справка)
#   Интернет: нет
#   Генерируется: reports/PV-03.scenario.json (результат каждого шага)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_scen.sh"
nox_begin PV-03 S2 "$@"
NOX_PLAN="выполнить сценарий приёмки PV-03 (теги: card_with_source,edit_or_revoke,project_isolation,persist_after_restart) против $NOX_RESONANCE_URL"
nox_scenario_task PV-03 "card_with_source,edit_or_revoke,project_isolation,persist_after_restart"
