#!/usr/bin/env bash
# ID: P1-15
# ЦЕЛЬ: сеть и загрузки: aria2c + hf_transfer, BBR/буферы TCP (если sysctl разрешён), реальный тест скорости на 20 ГБ >= 1 Гбит/с.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-02
# ГОТОВО: скорость чтения первых 20 ГБ файла GLM-5.3 shard 1 с Hugging Face >= 125 МБ/с (1 Гбит/с); sysctl применён или честно "нет прав".
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: HF https://huggingface.co/unsloth/GLM-5.3-GGUF/resolve/main/UD-Q4_K_XL/GLM-5.3-UD-Q4_K_XL-00001-of-00011.gguf (ревизия: main, фактический commit sha берётся из https://huggingface.co/api/models/unsloth/GLM-5.3-GGUF и пишется в метрику hf_sha);
#             apt: aria2; pip: hf_transfer huggingface_hub[cli] (версии не закреплены, фактические пишутся в квитанцию: hf_transfer_version, aria2_version); HF_TOKEN (env, если репозиторий закрыт)
#   Генерируется: run/P1-15.sysctl.prev (прежние значения для отката)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-15 S1 "$@"
NOX_PLAN="установить aria2/hf_transfer; BBR+буферы (если права); curl -r 0-20GiB -> /dev/null со временем"
URL="https://huggingface.co/unsloth/GLM-5.3-GGUF/resolve/main/UD-Q4_K_XL/GLM-5.3-UD-Q4_K_XL-00001-of-00011.gguf"
SYS=(net.core.rmem_max net.core.wmem_max net.ipv4.tcp_congestion_control)
t_pre() { nox_need_cmd curl python3 pip3; }
t_backup() { for k in "${SYS[@]}"; do echo "$k=$(sysctl -n "$k" 2>/dev/null || echo NA)"; done >"$NOX_RUN_DIR/P1-15.sysctl.prev"; }
t_rollback() { while IFS="=" read -r k v; do [ "$v" != NA ] && sysctl -w "$k=$v" >/dev/null 2>&1 || true; done <"$NOX_RUN_DIR/P1-15.sysctl.prev"; }
t_do() {
  command -v aria2c >/dev/null || apt-get install -y aria2 >>"$NOX_LOGFILE" 2>&1
  pip3 install -q hf_transfer "huggingface_hub[cli]" >>"$NOX_LOGFILE" 2>&1 || nox_log WARN "pip hf_transfer не установился"
  if sysctl -w net.core.rmem_max=134217728 net.core.wmem_max=134217728 >>"$NOX_LOGFILE" 2>&1; then nox_log INFO "буферы TCP подняты"; else nox_log WARN "sysctl: нет прав (пропуск без повторов)"; fi
  grep -qw bbr /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null && sysctl -w net.ipv4.tcp_congestion_control=bbr >>"$NOX_LOGFILE" 2>&1 || nox_log WARN "BBR недоступен/нет прав"
}
t_check() {
  nox_chk "aria2c установлен" command -v aria2c
  nox_chk "hf_transfer импортируется" python3 -c 'import hf_transfer'
  nox_metric hf_transfer_version "$(pip3 show hf_transfer 2>/dev/null | sed -n 's/^Version: //p')"; nox_metric aria2_version "$(aria2c --version 2>/dev/null | head -1)"
  local h=() t0 t1 bytes mbs sha
  [ -n "${HF_TOKEN:-}" ] && h=(-H "Authorization: Bearer $HF_TOKEN")
  sha="$(curl -fsS "${h[@]}" https://huggingface.co/api/models/unsloth/GLM-5.3-GGUF | python3 -c 'import json,sys;print(json.load(sys.stdin).get("sha",""))' || true)"
  [ -n "$sha" ] || nox_blocked "HF API не отдал ревизию unsloth/GLM-5.3-GGUF" "доступность репозитория / HF_TOKEN"
  nox_metric hf_sha "$sha"
  t0=$(date +%s.%N)
  bytes="$(curl -fsSL "${h[@]}" -r 0-21474836479 -o /dev/null -w '%{size_download}' "$URL")" || nox_blocked "скачивание тестового диапазона не удалось" "доступ к $URL (HF_TOKEN, сеть)"
  t1=$(date +%s.%N); mbs="$(awk -v b="$bytes" -v a="$t0" -v c="$t1" 'BEGIN{printf "%.0f",b/(c-a)/1e6}')"
  nox_metric test_bytes "$bytes"; nox_metric speed_mb_s "$mbs"; nox_metric speed_gbit_s "$(awk -v m="$mbs" 'BEGIN{printf "%.2f",m*8/1000}')"
  nox_chk "скорость >= 125 МБ/с (1 Гбит/с)" nox_ge "$mbs" 125
  nox_metric tcp_cc "$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null || echo NA)"
  nox_verdict
}
nox_run_task
