#!/usr/bin/env bash
# ID: P2-15
# ЦЕЛЬ: reasoning_effort по режимам (Авто=low, Глубоко=high, Максимум=max) + clear_thinking=true + жёсткий лимит токенов; конфиг config/reasoning_modes.json.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-04
# ГОТОВО: (1) эффект параметра реально виден: токенов размышления low < high на одной и той же задаче; (2) Авто: 5 проб, все с непустым content, p95 времени ответа <= целевого ETA Авто.
# ФАКТЫ ОТ ВЛАДЕЛЬЦА (не выдумываются): NOX_AUTO_ETA_S, NOX_DEEP_ETA_S, NOX_MAX_ETA_S - целевое время ответа в секундах для трёх режимов. Бюджет токенов = ETA x измеренный ток/с (P2-06).
# Ограничения GLM-5.3 (канон 23, G01-G05): размышления отключить нельзя; effort передаётся per-request через chat_template_kwargs; рассуждение и ответ делят один max_tokens.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: https://docs.together.ai/docs/glm-5.3-quickstart (форма параметра reasoning_effort/clear_thinking, G02/G03); https://unsloth.ai/docs/models/glm-5.3
#   Генерируется: config/reasoning_modes.json, reports/P2-15_probes.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-15 S1 "$@"
NOX_PLAN="пробы low/high на одной задаче (число токенов размышления); 5 проб Авто (p95 времени, непустой content); записать reasoning_modes.json"
CONF="$NOX_ROOT/config/reasoning_modes.json"
t_pre() { nox_need_receipt P2-04 P2-06; nox_need_var NOX_AUTO_ETA_S NOX_DEEP_ETA_S NOX_MAX_ETA_S; nox_need_file "$NOX_REPORT_DIR/P2-06_eta.json"
  nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "llama-server не отвечает" "P2-04"; }
t_check() {
  mkdir -p "$NOX_ROOT/config"
  python3 -B - "$NOX_LLAMA_URL" "$NOX_REPORT_DIR/P2-06_eta.json" "$CONF" "$NOX_REPORT_DIR/P2-15_probes.json" "$NOX_AUTO_ETA_S" "$NOX_DEEP_ETA_S" "$NOX_MAX_ETA_S" <<'PY' || { nox_log NO "пробы режимов не прошли (см. лог)"; NOX_NFAIL=$((NOX_NFAIL+1)); NOX_FAILS+="пробы; "; return 1; }
import json, os, sys
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_llm as L
url, etap, conf, probes, ea, ed, em = sys.argv[1:8]
tps = json.load(open(etap))["decode_tps_p50"]
eta = {"auto": float(ea), "deep": float(ed), "max": float(em)}; eff = {"auto": "low", "deep": "high", "max": "max"}
assert all(v in ("low", "high", "max") for v in eff.values())          # G03: строка effort валидируется в коде
budget = {k: int(eta[k] * tps) for k in eta}
def ask(effort, prompt, mt):
    ex = {"temperature": 1.0, "chat_template_kwargs": {"reasoning_effort": effort, "clear_thinking": True}}
    r = L.chat(url, [{"role": "user", "content": prompt}], mt, ex)
    return {"effort": effort, "total_s": r["total"], "reasoning_chars": len(r["reasoning"]), "content_chars": len(r["content"]),
            "completion_tokens": (r["usage"] or {}).get("completion_tokens"), "finish": r["finish"]}
task = "У Маши 3 яблока, у Пети вдвое больше, а у Оли на 2 меньше, чем у Пети. Сколько яблок у всех троих вместе? Ответь числом."
low = ask("low", task, budget["auto"]); high = ask("high", task, budget["deep"])
auto = [ask("low", p, budget["auto"]) for p in ("Что такое хеш-таблица? Два предложения.", "Столица Франции?", "Переведи на английский: доброе утро.", "Назови три цвета радуги.", task)]
p95 = L.pct([a["total_s"] for a in auto], .95)
res = {"tps": tps, "budget": budget, "low": low, "high": high, "auto": auto, "auto_p95_s": p95,
       "empty_auto": sum(1 for a in auto if a["content_chars"] == 0), "effect_ok": low["reasoning_chars"] < high["reasoning_chars"]}
json.dump(res, open(probes, "w"), ensure_ascii=False, indent=1)
json.dump({"modes": {k: {"reasoning_effort": eff[k], "clear_thinking": True, "max_tokens": budget[k], "eta_s": eta[k]} for k in eta},
           "agent_profile": {"clear_thinking": False, "note": "G06: preserved thinking для инструментальных циклов"}}, open(conf, "w"), ensure_ascii=False, indent=1)
PY
  local r="$NOX_REPORT_DIR/P2-15_probes.json" k
  for k in auto_p95_s empty_auto effect_ok; do nox_metric "$k" "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))[sys.argv[2]])' "$r" "$k")"; done
  nox_chk "эффект effort виден (low < high по размышлению)" test "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["effect_ok"])' "$r")" = True
  nox_chk "в Авто нет пустых ответов" test "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["empty_auto"])' "$r")" -eq 0
  nox_chk "p95 Авто <= целевого ETA" nox_le "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["auto_p95_s"])' "$r")" "$NOX_AUTO_ETA_S"
  nox_chk "reasoning_modes.json записан" test -s "$CONF"
  nox_verdict
}
nox_run_task
