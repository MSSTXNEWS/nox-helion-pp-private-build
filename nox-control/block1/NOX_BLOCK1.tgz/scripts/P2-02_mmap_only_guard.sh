#!/usr/bin/env bash
# ID: P2-02
# ЦЕЛЬ: запуск главной модели только через mmap: guard-launcher отвергает --no-mmap/--mlock/KV-квант/-rtr/ngram; файлы модели читаются через mmap; RSS+cache <= 560 ГБ; держатель memfd жив.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-01
# ГОТОВО: 11 GGUF отдают магию "GGUF" через mmap; cgroup memory.current <= 560 ГБ; свободно >= 150 ГБ; тест отказов launcher-а пройден; при работающем llama-server в его argv нет --no-mmap/--mlock.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: lib/nox_llama_launch.sh (уже в наборе), ничего не скачивается
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-02 S1 "$@"
NOX_PLAN="тест отказов launcher-а; mmap-чтение магии GGUF у 11 файлов; memory.current <= 560 ГБ; проверка argv работающего сервера и держателя"
t_pre() { nox_need_cmd python3; nox_need_receipt P2-01; nox_need_file "$NOX_RUN_DIR/glm53_manifest.json"; }
t_check() {
  local bad a pid cur
  for a in "--no-mmap" "--mlock" "-ctk q8_0" "-ctv q4_0" "-rtr" "--spec-type ngram-map-k" "-md draft.gguf"; do
    # shellcheck disable=SC2046,SC2086
    nox_chk "launcher отвергает: $a" bash -c "NOX_LLAMA_BIN=/bin/false '$NOX_LIB_DIR/nox_llama_launch.sh' -m x $a >/dev/null 2>&1; [ \$? -eq 3 ]"
  done
  nox_chk "launcher пропускает допустимые флаги (доходит до запуска)" bash -c "NOX_TASKSET=0 NOX_LLAMA_BIN=/bin/true '$NOX_LIB_DIR/nox_llama_launch.sh' -m x -ctk f16 -ctv f16 --cpu-moe >/dev/null 2>&1"
  bad="$(python3 -B - "$NOX_RUN_DIR/glm53_manifest.json" "$NOX_ROOT/glm53" <<'PY'
import json, mmap, os, sys
m = json.load(open(sys.argv[1])); bad = []
for f in m["files"]:
    p = os.path.join(sys.argv[2], os.path.basename(f["path"]))
    try:
        with open(p, "rb") as fh, mmap.mmap(fh.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            if len(mm) != f["size"] or (os.path.basename(p).endswith("00001-of-00011.gguf") and mm[:4] != b"GGUF"):
                bad.append(p)
    except Exception as e:
        bad.append("%s (%s)" % (p, e))
print(len(bad), *bad)
PY
)"
  nox_chk "11 файлов читаются через mmap, размеры верны, магия GGUF" test "${bad%% *}" = 0
  cur="$(nox_cg_mem_cur)"; nox_metric cgroup_mem_cur_gb "$((cur/1000000000))"; nox_metric ram_free_gb "$(( $(nox_ram_free)/1000000000 ))"
  nox_chk "RSS+cache <= 560 ГБ" test "$cur" -le 560000000000
  nox_chk "свободно >= 150 ГБ" test "$(nox_ram_free)" -ge 150000000000
  pid="$(nox_llama_pid)"
  if [ -n "$pid" ]; then nox_chk "argv llama-server без --no-mmap/--mlock" bash -c "! tr '\\0' ' ' </proc/$pid/cmdline | grep -Eq -- '--no-mmap|--mlock'"; fi
  if [ "$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/glm53_holder.json"))["mode"])')" = memfd ]; then
    nox_chk "держатель memfd жив" bash -c "kill -0 \$(python3 -c 'import json;print(json.load(open(\"$NOX_RUN_DIR/glm53_holder.json\"))[\"pid\"])')"; fi
  nox_verdict
}
nox_run_task
