#!/usr/bin/env bash
# ID: P1-T10
# ЦЕЛЬ: метрики двух карт S2 по UUID (VRAM/загрузка/температура) рядом с прогрессом обучения; гейт PV-08: обучение не поднимает TTFT чата >10%.
# СЕРВЕР: S2
# ЗАВИСИМОСТИ: нет
# ГОТОВО: run/gpu_metrics.json: 2 карты, у каждой UUID, memory.used/total, utilization, temperature; обновляется таймером.
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: bin/nox_gpu_metrics.sh, run/gpu_metrics.json, run/gpu_metrics.jsonl (история)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-T10 S2 "$@"
NOX_PLAN="установить nox_gpu_metrics.sh (nvidia-smi по UUID -> JSON, + progress из run/train_progress.json если есть); cron 1 мин; проверка 2 карты"
t_pre() { nox_need_cmd nvidia-smi python3; }
t_do() {
  mkdir -p "$NOX_ROOT/bin"
  cat >"$NOX_ROOT/bin/nox_gpu_metrics.sh" <<'X'
#!/usr/bin/env bash
R="${NOX_ROOT:-/root/nox}/run"; mkdir -p "$R"
nvidia-smi --query-gpu=uuid,index,name,memory.used,memory.total,utilization.gpu,temperature.gpu --format=csv,noheader,nounits | python3 -I -c '
import sys,json,time,os
g=[]
for l in sys.stdin:
    p=[x.strip() for x in l.split(",")]
    if len(p)<7: continue
    g.append({"uuid":p[0],"index":int(p[1]),"name":p[2],"vram_used_mib":int(p[3]),"vram_total_mib":int(p[4]),"util_pct":int(p[5]),"temp_c":int(p[6])})
pf=os.path.join(os.environ.get("NOX_ROOT","/root/nox"),"run","train_progress.json")
prog=json.load(open(pf)) if os.path.exists(pf) else None
o={"t":time.strftime("%FT%TZ",time.gmtime()),"gpus":g,"train_progress":prog}
r=os.path.join(os.environ.get("NOX_ROOT","/root/nox"),"run")
json.dump(o,open(r+"/gpu_metrics.json.tmp","w")); os.replace(r+"/gpu_metrics.json.tmp",r+"/gpu_metrics.json")
open(r+"/gpu_metrics.jsonl","a").write(json.dumps(o)+"\n")'
X
  chmod +x "$NOX_ROOT/bin/nox_gpu_metrics.sh"
  [ -w /etc/cron.d ] && echo "* * * * * root NOX_ROOT=$NOX_ROOT $NOX_ROOT/bin/nox_gpu_metrics.sh" >/etc/cron.d/nox-gpu-metrics || nox_log WARN "нет /etc/cron.d: таймер за супервизором P1-12"
  "$NOX_ROOT/bin/nox_gpu_metrics.sh"
}
t_check() {
  nox_chk "gpu_metrics.json есть" test -s "$NOX_RUN_DIR/gpu_metrics.json"
  [ -s "$NOX_RUN_DIR/gpu_metrics.json" ] || return 1
  local n u; n="$(python3 -I -c 'import json,sys;print(len(json.load(open(sys.argv[1]))["gpus"]))' "$NOX_RUN_DIR/gpu_metrics.json")"
  u="$(python3 -I -c 'import json,sys;print(len({g["uuid"] for g in json.load(open(sys.argv[1]))["gpus"] if g["uuid"].startswith("GPU-")}))' "$NOX_RUN_DIR/gpu_metrics.json")"
  nox_metric gpus "$n"; nox_chk "две карты S2 с UUID" test "$n" -ge 2 -a "$u" -ge 2
  nox_verdict
}
nox_run_task
