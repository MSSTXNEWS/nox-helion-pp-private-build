#!/usr/bin/env bash
# ID: PV-05
# ЦЕЛЬ: общий рабочий контекст 8 ядер: ответ на «на чём остановились?» из S03 без вызовов главной модели.
# СЕРВЕР: S2 (живой контур NOX на S2; исполнитель - REASON)
# ЗАВИСИМОСТИ: PV-01
# ГОТОВО: ответ = последнее подтверждённое решение + источник; счётчик вызовов главной модели не вырос.
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА (не выдумываются): NOX_RESONANCE_URL; сценарий $NOX_ROOT/scenarios/PV-05.json с шагами-тегами: summary_answer,last_decision_with_source,zero_main_calls (формат - в шапке lib/nox_scenario.py).
#   Без сценария скрипт сохраняет openapi.json контура (если отдаётся) в $NOX_ROOT/discovery/ и честно отвечает BLOCKED. Это скрипт приёмки: он ПРОВЕРЯЕТ, а не меняет контур.
# ИСТОЧНИКИ:
#   Drive: канон Резонанса 1DtuxYMF... (ID неполный; уточнить)
#   Интернет: нет
#   Генерируется: reports/PV-05.scenario.json (результат каждого шага)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_scen.sh"
nox_begin PV-05 S2 "$@"
NOX_PLAN="выполнить сценарий приёмки PV-05 (теги: summary_answer,last_decision_with_source,zero_main_calls) против $NOX_RESONANCE_URL"
nox_scenario_task PV-05 "summary_answer,last_decision_with_source,zero_main_calls"
