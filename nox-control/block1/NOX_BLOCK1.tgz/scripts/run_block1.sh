#!/usr/bin/env bash
# run_block1.sh - БЛОК 1 «Оптимизация машины» (D01-01…D01-20) одной командой.
#   На S1:  NOX_SERVER=S1 ./run_block1.sh        На S2: NOX_SERVER=S2 ./run_block1.sh
#   Флаги: --dry-run | --check | --status
# Порядок = зависимостям плана v6. BLOCKED не останавливает остальное (повторная попытка в конце, правило «вернуться к заблокированным»);
# FAIL останавливает и печатает лог. Код выхода: 0 всё PASS, 1 FAIL, 3 есть BLOCKED.
# Владельческие шаги (D01-01, D01-02): скрипт только проверяет результат; без действия владельца будут BLOCKED.
set -uo pipefail
cd "$(dirname "$0")"
MODE="${1:-}"; SRV="${NOX_SERVER:-}"
[ -n "$SRV" ] || SRV="$(. lib/nox_common.sh; nox_detect_server)"
# id | сервера | D-номер
LIST="P1-01:S1,S2:D01-01 P10-06:S1,S2:D01-02 P1-02:S1,S2:D01-03 P1-03:S1:D01-04 P1-T07:S1,S2:D01-16 P1-15:S1:D01-15 P1-05:S1:D01-05 P1-06:S1:D01-06
P1-13:S1:D01-07 P1-04:S1:D01-08 P1-07:S1:D01-09 P1-T01:S1:D01-10 P1-14:S1:D01-11 P1-08:S1,S2:D01-12 P1-12:S1,S2:D01-13 P1-T12:S1:D01-14
P10-13:S1,S2:D01-17 P1-19:S2:D01-18 P1-T10:S2:D01-19 P1-T05:S2:D01-20"
if [ "$MODE" = --status ]; then python3 -B lib/nox_runner.py --status 2>/dev/null || ls "${NOX_ROOT:-/root/nox}/receipts"; exit 0; fi
FLAG=""; [ "$MODE" = --dry-run ] && FLAG=--dry-run; [ "$MODE" = --check ] && FLAG=--check
declare -A RES; blocked=(); failed=0
run_one() { local id="$1" f; f="$(ls ${id}_*.sh 2>/dev/null | head -1)"; [ -n "$f" ] || { echo "нет скрипта $id"; return 2; }; bash "$f" $FLAG; }
for item in $LIST; do IFS=: read -r id srvs dn <<<"$item"
  case ",$srvs," in *",$SRV,"*) ;; *) continue;; esac
  echo "=== $dn  $id  (сервер $SRV)"; run_one "$id"; rc=$?
  RES[$id]=$rc
  case $rc in 0) ;; 3|4) blocked+=("$id:$dn");; *) echo "FAIL $dn $id: лог ${NOX_ROOT:-/root/nox}/logs/$id.log"; failed=1; break;; esac
done
if [ $failed = 0 ] && [ ${#blocked[@]} -gt 0 ] && [ -z "$FLAG" ]; then
  echo "=== повтор заблокированных (${#blocked[@]})"; still=()
  for b in "${blocked[@]}"; do id="${b%%:*}"; run_one "$id"; rc=$?; [ $rc = 0 ] || still+=("$b"); [ $rc = 1 ] && failed=1; done
  blocked=("${still[@]}")
fi
echo "=== ИТОГ блока 1 на $SRV: FAIL=$failed BLOCKED=${#blocked[@]} ${blocked[*]:-}"
[ $failed = 1 ] && exit 1; [ ${#blocked[@]} -gt 0 ] && exit 3; exit 0
