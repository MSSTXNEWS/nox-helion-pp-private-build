#!/usr/bin/env bash
# ID: P1-17
# ЦЕЛЬ: S2: точка отката и эталон "не хуже" до любых изменений: снимок S03/адаптеров/конфигов на склад с SHA-манифестом + замер TTFT и мини-экзамен текущего чата S2.
# СЕРВЕР: S2
# ЗАВИСИМОСТИ: P1-09 (S1: экзаменатор lib/nox_exam.py и exam20.jsonl берутся из этого же набора скриптов; квитанция S1 проверяется раннером)
# ГОТОВО: tar.gz на складе, sha256-манифест (по содержимому архива) сошёлся при повторной распаковке; reports/P1-17_baseline.json: TTFT p50/p95 по 5 коротким промптам и экзамен 20 вопросов (баллы).
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА (не выдумываются): NOX_S2_BACKUP_PATHS (пути S03, адаптеров, конфигов на S2), NOX_STORE_DIR (склад, доступный с S2: смонтирован/sshfs), NOX_S2_CHAT_URL (OpenAI-совместимый /v1/chat/completions текущего чата S2).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: $NOX_STORE_DIR/s2_baseline_<время>.tar.gz + .sha256.manifest, reports/P1-17_baseline.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-17 S2 "$@"
NOX_PLAN="tar снимка на склад; sha256 манифест + проверка; TTFT (5 промптов) и экзамен 20 вопросов на чате S2"
BASE="$NOX_REPORT_DIR/P1-17_baseline.json"
t_pre() { nox_need_var NOX_S2_BACKUP_PATHS NOX_STORE_DIR NOX_S2_CHAT_URL; nox_need_file "$NOX_STORE_DIR"; local p; for p in $NOX_S2_BACKUP_PATHS; do nox_need_file "$p"; done
  curl -fsS --max-time 10 "$NOX_S2_CHAT_URL/v1/models" >/dev/null 2>&1 || nox_blocked "чат S2 не отвечает на /v1/models" "адрес OpenAI-совместимого API чата S2"; nox_need_file "$NOX_SCRIPTS_DIR/exam/exam20.jsonl"; }
t_do() {
  local ts f; ts="$(date -u +%Y%m%dT%H%M%SZ)"; f="$NOX_STORE_DIR/s2_baseline_$ts.tar.gz"
  # shellcheck disable=SC2046,SC2086
  tar -czf "$f" $NOX_S2_BACKUP_PATHS
  mkdir -p "$NOX_TMP/mk" && tar -xzf "$f" -C "$NOX_TMP/mk" && ( cd "$NOX_TMP/mk" && find . -type f -exec sha256sum {} + ) >"${f%.tar.gz}.sha256.manifest"
  echo "$f" >"$NOX_RUN_DIR/P1-17.last"
  python3 -B - "$NOX_S2_CHAT_URL" "$NOX_SCRIPTS_DIR/exam/exam20.jsonl" "$BASE" <<'PY'
import json, os, sys
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_llm as L, nox_exam as E
url, exam, out = sys.argv[1:4]
tt = [L.chat(url, [{"role": "user", "content": p}], 48, {"temperature": 0})["ttft"] for p in ("Привет.", "Что такое RAM?", "Назови столицу Японии.", "Скажи слово: готов.", "Сколько будет 2+2?")]
ex = E.run(url, E.load(exam), {}, int(os.environ.get("NOX_EXAM_MAX_TOKENS", "2048")))
json.dump({"ttft_p50": L.pct(tt, .5), "ttft_p95": L.pct(tt, .95), "exam_score": ex["score"], "exam_of": ex["of"], "exam": ex["details"]}, open(out, "w"), ensure_ascii=False, indent=1)
PY
}
t_check() {
  local f; f="$(cat "$NOX_RUN_DIR/P1-17.last" 2>/dev/null || true)"
  nox_chk "архив снимка существует и читается" bash -c "[ -n '$f' ] && tar -tzf '$f' >/dev/null"
  [ -n "$f" ] || return 1
  nox_chk "манифест существует" test -s "${f%.tar.gz}.sha256.manifest"
  local d="$NOX_TMP/verify"; mkdir -p "$d"; tar -xzf "$f" -C "$d"
  nox_chk "SHA256 файлов архива = манифест" bash -c "cd '$d' && sha256sum -c --quiet '${f%.tar.gz}.sha256.manifest'"
  nox_chk "эталон скорости и экзамена записан" test -s "$BASE"
  nox_metric ttft_p50 "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["ttft_p50"])' "$BASE")"; nox_metric exam_score "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["exam_score"])' "$BASE")"
  nox_input "${f%.tar.gz}.sha256.manifest"
  nox_verdict
}
nox_run_task
