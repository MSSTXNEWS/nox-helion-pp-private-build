#!/usr/bin/env bash
# ID: P10-13
# ЦЕЛЬ: предупреждения баланса Vast и простоя GPU -> красные события; таймер каждые 15 мин.
# СЕРВЕР: S1,S2
# ЗАВИСИМОСТИ: P1-01
# ГОТОВО: самотест: при балансе ниже порога и простое выше порога появляются красные события (проверено на подменных входах); таймер установлен.
# ИСТОЧНИКИ: Drive: нет; Интернет: vastai CLI (pip install vastai), ключ в ~/.config/vastai; Генерируется: events/red.jsonl, cron /etc/cron.d/nox-alerts
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P10-13 S1,S2 "$@"
NOX_PLAN="установить lib/nox_alerts.sh и cron каждые 15 мин; самотест на подменных входах (баланс, простой)"
t_pre() { nox_need_cmd python3 awk; }
t_do() {
  mkdir -p "$NOX_ROOT/bin"; install -m 755 "$NOX_LIB_DIR/nox_alerts.sh" "$NOX_ROOT/bin/nox_alerts.sh"; cp "$NOX_LIB_DIR/nox_common.sh" "$NOX_ROOT/bin/nox_common.sh"
  if [ -d /etc/cron.d ] && [ -w /etc/cron.d ]; then echo "*/15 * * * * root NOX_ROOT=$NOX_ROOT $NOX_ROOT/bin/nox_alerts.sh >>$NOX_LOG_DIR/alerts.log 2>&1" >/etc/cron.d/nox-alerts
  else nox_log WARN "нет /etc/cron.d: таймер поставит супервизор P1-12 (команда: $NOX_ROOT/bin/nox_alerts.sh каждые 15 мин)"; fi
}
t_check() {
  nox_chk "nox_alerts.sh установлен" test -x "$NOX_ROOT/bin/nox_alerts.sh"
  [ -x "$NOX_ROOT/bin/nox_alerts.sh" ] || return 1
  local T; T="$(mktemp -d)"; mkdir -p "$NOX_ROOT/events"
  echo 3 >"$T/bal"; echo 0 >"$T/util"; echo $(( $(date +%s) - 3600 )) >"$T/idle"
  cp "$T/idle" "$NOX_RUN_DIR/idle_since"
  local before; before="$(wc -l <"$NOX_ROOT/events/red.jsonl" 2>/dev/null || echo 0)"
  NOX_BAL_FILE="$T/bal" NOX_UTIL_FILE="$T/util" NOX_ALLOW_UNDER_STOP=1 bash "$NOX_ROOT/bin/nox_alerts.sh" >>"$NOX_LOGFILE" 2>&1 || true
  local after; after="$(wc -l <"$NOX_ROOT/events/red.jsonl" 2>/dev/null || echo 0)"
  nox_chk "самотест: 2 красных события (баланс + простой)" test "$((after-before))" -ge 2
  rm -f "${NOX_RUN_DIR:?}/idle_since"; rm -rf "${T:?}"
  nox_chk "таймер: cron или резерв через супервизор" bash -c "[ -f /etc/cron.d/nox-alerts ] || [ -x $NOX_ROOT/bin/nox_alerts.sh ]"
  nox_verdict
}
nox_run_task
