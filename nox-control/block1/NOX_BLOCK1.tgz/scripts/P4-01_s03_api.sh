#!/usr/bin/env bash
# ID: P4-01
# ЦЕЛЬ: единая доверенная память S03 на S1: перенос SQLite-базы с S2 (консистентный .backup), API (lib/nox_s03_api.py, схема nox_mem с level M0-M7), запись с S2 по Tailscale, восстановление из снапшота.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-10
# ГОТОВО: запись с S2 по tailnet видна на S1; из снапшота (sqlite .backup) тестовая запись восстанавливается; PRAGMA integrity_check = ok; API отвечает /health.
# ФАКТЫ, КОТОРЫЕ НУЖНЫ (не выдумываются): NOX_S03_DB (путь к файлу S03 на S1), NOX_S2_S03_PATH (путь к SQLite-файлу S03 на S2; если S03 на S2 не SQLite - BLOCKED), NOX_S2_SSH (доступ S1->S2), NOX_S03_BIND, NOX_S03_PORT, NOX_S03_ADDR_FOR_S2 (адрес S1 в tailnet для S2).
#   Миграция СТАРЫХ таблиц S2 в схему nox_mem требует знания старой схемы: скрипт переносит файл целиком, таблицу nox_mem добавляет рядом; маппинг старых данных - отдельная карточка/факт.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: apt: rsync (python3 с модулем sqlite3 нужен и на S2)
#   Генерируется: run/s03.token (0600, Bearer-токен API), services.d/s03.conf, lib/nox_s03_api.py
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P4-01 S1 "$@"
NOX_PLAN="снять .backup на S2 -> rsync -> integrity+sha; migrate схемы; токен; запуск API (watchdog); запись с S2; снапшот-восстановление"
TOK="$NOX_RUN_DIR/s03.token"; API="$NOX_LIB_DIR/nox_s03_api.py"
t_pre() { nox_need_receipt P1-10; nox_need_var NOX_S03_DB NOX_S2_S03_PATH NOX_S2_SSH NOX_S03_BIND NOX_S03_PORT NOX_S03_ADDR_FOR_S2; nox_need_cmd python3 rsync ssh curl
  # shellcheck disable=SC2046,SC2086
  ssh $(nox_ssh_opts) $NOX_S2_SSH true 2>>"$NOX_LOGFILE" || nox_blocked "S1 не может зайти на S2 по ssh" "добавить публичный ключ S1 на S2 (ключ: $(cat ~/.ssh/id_ed25519.pub 2>/dev/null || echo нет))"; }
t_backup() { nox_backup "$NOX_S03_DB" "$NOX_ROOT/services.d/s03.conf"; }
t_rollback() { nox_restore || true; rm -f "$NOX_ROOT/services.d/s03.conf"; [ -s "$LLAMA_WDST/s03.pid" ] && kill "$(cat "$LLAMA_WDST/s03.pid")" 2>/dev/null || true; }
LLAMA_WDST="$NOX_RUN_DIR/wd"
t_do() {
  mkdir -p "$(dirname "$NOX_S03_DB")" "$NOX_ROOT/services.d" "$LLAMA_WDST"
  if [ ! -s "$NOX_S03_DB" ]; then
    # shellcheck disable=SC2046,SC2086
    ssh $(nox_ssh_opts) $NOX_S2_SSH "python3 -c \"import sqlite3,sys;s=sqlite3.connect(sys.argv[1]);d=sqlite3.connect(sys.argv[2]);s.backup(d)\" '$NOX_S2_S03_PATH' /tmp/nox_s03_export.db && sha256sum /tmp/nox_s03_export.db" >"$NOX_TMP/s2.sha" 2>>"$NOX_LOGFILE" || nox_blocked "на S2 не удалось сделать .backup файла $NOX_S2_S03_PATH (не SQLite или нет файла)" "формат и путь S03 на S2"
    # shellcheck disable=SC2046,SC2086
    rsync -a -e "ssh $(nox_ssh_opts) $(echo $NOX_S2_SSH | sed 's/ [^ ]*@.*//')" "$(echo $NOX_S2_SSH | grep -o '[^ ]*@[^ ]*'):/tmp/nox_s03_export.db" "$NOX_S03_DB"
    [ "$(sha256sum "$NOX_S03_DB" | cut -d' ' -f1)" = "$(cut -d' ' -f1 "$NOX_TMP/s2.sha")" ] || { rm -f "$NOX_S03_DB"; return 1; }
  fi
  python3 -B "$NOX_LIB_DIR/nox_s03.py" migrate "$NOX_S03_DB"
  [ -s "$TOK" ] || { umask 177; python3 -c 'import secrets;print(secrets.token_urlsafe(32))' >"$TOK"; }
  printf 'NAME=s03\nORDER=5\nCMD=%q\nHEALTH_URL=http://%s:%s/health\nMAX_RESTARTS=3\nWINDOW_S=600\nGRACE_S=30\n' \
    "python3 -B $API --db $NOX_S03_DB --bind $NOX_S03_BIND --port $NOX_S03_PORT --token-file $TOK" "$NOX_S03_BIND" "$NOX_S03_PORT" >"$NOX_ROOT/services.d/s03.conf"
  if ! { [ -s "$LLAMA_WDST/watchdog.pid" ] && kill -0 "$(cat "$LLAMA_WDST/watchdog.pid")" 2>/dev/null; }; then
    setsid nohup python3 -B "$API" --db "$NOX_S03_DB" --bind "$NOX_S03_BIND" --port "$NOX_S03_PORT" --token-file "$TOK" >>"$NOX_LOG_DIR/s03.service.log" 2>&1 & echo $! >"$LLAMA_WDST/s03.pid"; date +%s >"$LLAMA_WDST/s03.started"; fi
  nox_wait_health "http://$NOX_S03_BIND:$NOX_S03_PORT" 60
}
t_check() {
  local base="http://$NOX_S03_BIND:$NOX_S03_PORT" tid="__nox_test_p401_$$" r
  nox_chk "integrity_check S03 = ok" python3 -B "$NOX_LIB_DIR/nox_s03.py" integrity "$NOX_S03_DB"
  nox_chk "API /health" nox_health "$base"
  [ "$NOX_NFAIL" -eq 0 ] || return 1
  # запись с S2 по tailnet
  # shellcheck disable=SC2046,SC2086
  printf 'Authorization: Bearer %s\n' "$(cat "$TOK")" | ssh $(nox_ssh_opts) $NOX_S2_SSH "curl -fsS -X POST http://$NOX_S03_ADDR_FOR_S2:$NOX_S03_PORT/mem -H @- -H 'Content-Type: application/json' -d '{\"id\":\"$tid\",\"level\":\"M1\",\"scope\":\"owner\",\"text\":\"запись с S2\",\"source\":\"P4-01\"}'" >>"$NOX_LOGFILE" 2>&1 \
    || nox_blocked "запись с S2 на API S1 не удалась" "достижимость $NOX_S03_ADDR_FOR_S2:$NOX_S03_PORT с S2 (tailnet, bind-адрес API)"
  nox_chk "запись с S2 видна на S1" curl -fsS -H "Authorization: Bearer $(cat "$TOK")" "$base/mem/$tid"
  # восстановление из снапшота
  python3 -B "$NOX_LIB_DIR/nox_s03.py" backup "$NOX_S03_DB" "$NOX_TMP/snap.db"; python3 -B "$NOX_LIB_DIR/nox_s03.py" sql "$NOX_S03_DB" "DELETE FROM nox_mem WHERE id='$tid'"
  nox_chk "после удаления записи нет" bash -c "[ \"\$(python3 -B '$NOX_LIB_DIR/nox_s03.py' sql '$NOX_S03_DB' \"SELECT count(*) FROM nox_mem WHERE id='$tid'\")\" = 0 ]"
  nox_chk "в снапшоте запись есть (восстановимо)" bash -c "[ \"\$(python3 -B '$NOX_LIB_DIR/nox_s03.py' sql '$NOX_TMP/snap.db' \"SELECT count(*) FROM nox_mem WHERE id='$tid'\")\" = 1 ]"
  nox_chk "integrity снапшота = ok" python3 -B "$NOX_LIB_DIR/nox_s03.py" integrity "$NOX_TMP/snap.db"
  nox_metric s03_records "$(python3 -B "$NOX_LIB_DIR/nox_s03.py" sql "$NOX_S03_DB" 'SELECT count(*) FROM nox_mem')"
  nox_verdict
}
nox_run_task
