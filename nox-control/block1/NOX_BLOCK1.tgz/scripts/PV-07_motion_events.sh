#!/usr/bin/env bash
# ID: PV-07
# ЦЕЛЬ: MOTION100 -> реальные события: 4 события шины дают 4 разные анимации, ложных срабатываний 0.
# СЕРВЕР: S2 (живой контур NOX на S2; исполнитель - TOOLS)
# ЗАВИСИМОСТИ: PV-02
# ГОТОВО: 4 события -> 4 различных анимации; ложных срабатываний 0 за прогон.
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА (не выдумываются): NOX_RESONANCE_URL; сценарий $NOX_ROOT/scenarios/PV-07.json с шагами-тегами: ev_memory_found,ev_answer_started,ev_tool_done,ev_stop_confirmed,distinct_animations,no_false_positives (формат - в шапке lib/nox_scenario.py).
#   Без сценария скрипт сохраняет openapi.json контура (если отдаётся) в $NOX_ROOT/discovery/ и честно отвечает BLOCKED. Это скрипт приёмки: он ПРОВЕРЯЕТ, а не меняет контур.
# ИСТОЧНИКИ:
#   Drive: MAX WOW ANIMATION + VIDEO V1 1UdBW99SXGpgMadaVCsRSTynwuN8unVBypgmh4R8lvCA: lib/nox_fetch_drive.sh 1UdBW99SXGpgMadaVCsRSTynwuN8unVBypgmh4R8lvCA $NOX_SRC_DIR/motion.txt txt
#   Интернет: нет
#   Генерируется: reports/PV-07.scenario.json (результат каждого шага)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_scen.sh"
nox_begin PV-07 S2 "$@"
NOX_PLAN="выполнить сценарий приёмки PV-07 (теги: ev_memory_found,ev_answer_started,ev_tool_done,ev_stop_confirmed,distinct_animations,no_false_positives) против $NOX_RESONANCE_URL"
nox_scenario_task PV-07 "ev_memory_found,ev_answer_started,ev_tool_done,ev_stop_confirmed,distinct_animations,no_false_positives"
