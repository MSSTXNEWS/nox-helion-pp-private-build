#!/usr/bin/env bash
# ID: P1-T07
# ЦЕЛЬ: fio read-only тест диска (S1/S2): seq-read 1М и randread 4К; ничего не пишет (--readonly).
# СЕРВЕР: S1,S2
# ЗАВИСИМОСТИ: нет
# ГОТОВО: logs/fio/<хост>.json: MB/s и IOPS; seq-read >= NOX_FIO_MIN_MBS (по умолчанию 100).
# ИСТОЧНИКИ: Drive: нет; Интернет: apt install fio; Генерируется: logs/fio/<host>.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-T07 S1,S2 "$@"
NOX_PLAN="fio --readonly по существующему большому файлу; seq 1M и rand 4K; результат в JSON"
t_pre() { command -v fio >/dev/null 2>&1 || { [ "$DRY" = 1 ] || apt-get install -y fio >>"$NOX_LOGFILE" 2>&1 || true; }; command -v fio >/dev/null 2>&1 || nox_blocked "нет fio" "apt install fio"; }
target() { local d f; for d in "${NOX_FIO_TARGET:-}" "${NOX_STORE_DIR:-}" "${NOX_MODEL_DIR:-}" /root/nox /root; do [ -n "$d" ] || continue
  [ -f "$d" ] && { echo "$d"; return; }
  [ -d "$d" ] || continue
  f="$(find "$d" -maxdepth 3 -type f -size +512M 2>/dev/null | head -1)"; [ -n "$f" ] && { echo "$f"; return; }; done; return 0; }
t_do() {
  local T; T="$(target)"; [ -n "$T" ] || T="$(find / -xdev -type f -size +100M 2>/dev/null | head -1)"
  [ -n "$T" ] || { nox_log ERR "нет файла >100 МБ для чтения"; return 1; }
  mkdir -p "$NOX_ROOT/logs/fio"; nox_log INFO "цель fio: $T"
  fio --name=seq --filename="$T" --readonly --rw=read --bs=1M --iodepth=16 --direct=1 --ioengine=libaio --runtime=20 --time_based --output-format=json --output="$NOX_ROOT/logs/fio/$(hostname)_seq.json" >>"$NOX_LOGFILE" 2>&1 || return 1
  fio --name=rnd --filename="$T" --readonly --rw=randread --bs=4k --iodepth=32 --direct=1 --ioengine=libaio --runtime=15 --time_based --output-format=json --output="$NOX_ROOT/logs/fio/$(hostname)_rnd.json" >>"$NOX_LOGFILE" 2>&1 || return 1
  python3 -I - "$NOX_ROOT/logs/fio" "$(hostname)" <<'P'
import json,sys
d,h=sys.argv[1:3]
s=json.load(open(f"{d}/{h}_seq.json"))["jobs"][0]["read"]; r=json.load(open(f"{d}/{h}_rnd.json"))["jobs"][0]["read"]
json.dump({"host":h,"seq_mbs":round(s["bw"]/1024,1),"rand_iops":int(r["iops"])},open(f"{d}/{h}.json","w"))
P
}
t_check() {
  local f="$NOX_ROOT/logs/fio/$(hostname).json"
  nox_chk "результат fio есть" test -s "$f"
  [ -s "$f" ] || return 1
  local m i; m="$(python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1]))["seq_mbs"])' "$f")"; i="$(python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1]))["rand_iops"])' "$f")"
  nox_metric seq_read_mbs "$m"; nox_metric rand4k_iops "$i"
  nox_chk "seq-read >= ${NOX_FIO_MIN_MBS:-100} МБ/с" nox_ge "$m" "${NOX_FIO_MIN_MBS:-100}"
  nox_verdict
}
nox_run_task
