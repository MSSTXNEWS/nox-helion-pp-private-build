#!/usr/bin/env bash
# ID: P4-05
# ЦЕЛЬ: FAST: scoped FTS5 + WarmS03Cache (LRU+TTL, инвалидация по principal и по отзыву). Собственная реализация в lib/nox_s03.py (референс из пакета Exec03 nox_mind_v41/warm_cache.py: если каталог NOX_MIND_DIR задан - только сверка наличия файла).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P4-01
# ГОТОВО: поиск по 100 000 записей: p95 < 50 мс (синтетическая БД во временном каталоге; реальный S03 не трогается); кэш хитует; после смены прав и после отзыва записи кэш инвалидируется. Подключение к HTTP-API S03 - через POST /search (lib/nox_s03_api.py), измеряется отдельно в P4-09.
# ИСТОЧНИКИ:
#   Drive: нет (референс-код Exec03 лежит на S2 в staging-пакете; путь не известен - NOX_MIND_DIR)
#   Интернет: нет (SQLite FTS5 входит в python3-sqlite3)
#   Генерируется: reports/P4-05_fts.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P4-05 S1 "$@"
NOX_PLAN="bench-fts 100000: p50/p95; проверка кэша и инвалидации"
t_pre() { nox_need_receipt P4-01; nox_need_cmd python3; python3 -c 'import sqlite3;sqlite3.connect(":memory:").execute("create virtual table t using fts5(x)")' 2>/dev/null || nox_blocked "SQLite без FTS5" "python3 с FTS5"; }
t_check() {
  local r; r="$(python3 -B "$NOX_LIB_DIR/nox_s03.py" bench-fts 100000)"; echo "$r" >"$NOX_REPORT_DIR/P4-05_fts.json"; nox_log INFO "$r"
  local k; for k in records search_p50_ms search_p95_ms; do nox_metric "$k" "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])[sys.argv[2]])' "$r" "$k")"; done
  nox_chk "100000 записей" test "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["records"])' "$r")" -eq 100000
  nox_chk "поиск p95 < 50 мс" nox_le "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["search_p95_ms"])' "$r")" 49.9
  nox_chk "кэш отдаёт записанное" test "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["cache_hit"])' "$r")" = True
  nox_chk "смена прав инвалидирует кэш" test "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["after_principal_invalidate"])' "$r")" = False
  nox_chk "отзыв записи инвалидирует кэш" test "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["after_revoke_invalidate"])' "$r")" = False
  [ -z "${NOX_MIND_DIR:-}" ] || nox_metric exec03_reference_present "$([ -f "$NOX_MIND_DIR/warm_cache.py" ] && echo yes || echo no)"
  nox_verdict
}
nox_run_task
