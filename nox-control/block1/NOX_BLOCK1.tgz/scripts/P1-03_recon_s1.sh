#!/usr/bin/env bash
# ID: P1-03
# ЦЕЛЬ: разведка S1: cgroup-лимит RAM, ядра/NUMA, /dev/shm, PCIe-линк, полоса RAM (STREAM triad); пересчёт потолка ток/с (A02).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-02
# ГОТОВО: отчёт $NOX_ROOT/reports/P1-03_recon.txt; cgroup-лимит >= 520 ГБ (влезает 467 ГБ + бюджет); потолок ток/с пересчитан по измеренной полосе.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: apt: gcc (для STREAM; если нет - BLOCKED). Паспорт GPU: RTX 5060 Ti 448 ГБ/с (NOX_GPU_BW_GBS, спецификация NVIDIA)
#   Генерируется: reports/P1-03_recon.txt, reports/P1-03_ceiling.json; активные ГБ/токен берутся из канона 1.1 (CPU 21, GPU 4)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-03 S1 "$@"
NOX_PLAN="cat memory.max; nproc; lscpu; df /dev/shm; nvidia-smi -q (PCIe); STREAM triad; пересчёт A02"
REP="$NOX_REPORT_DIR/P1-03_recon.txt"
t_pre() { nox_need_cmd gcc lscpu nvidia-smi python3; }
t_check() {
  local mx cur nodes sock cps tps phys shm gen wid bw ceil
  mx="$(nox_cg_mem_max)"; cur="$(nox_cg_mem_cur)"
  nproc_n="$(nproc)"; sock="$(lscpu | awk -F: '/^Socket\(s\)/{gsub(/ /,"",$2);print $2}')"
  cps="$(lscpu | awk -F: '/^Core\(s\) per socket/{gsub(/ /,"",$2);print $2}')"; tps="$(lscpu | awk -F: '/^Thread\(s\) per core/{gsub(/ /,"",$2);print $2}')"
  nodes="$(lscpu | awk -F: '/^NUMA node\(s\)/{gsub(/ /,"",$2);print $2}')"; phys=$((sock*cps))
  shm="$(df -B1 --output=size /dev/shm | tail -1 | tr -d ' ')"
  gen="$(nvidia-smi --query-gpu=pcie.link.gen.current --format=csv,noheader)"; wid="$(nvidia-smi --query-gpu=pcie.link.width.current --format=csv,noheader)"
  cat >"$NOX_TMP/stream.c" <<'C'
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
int main(){ size_t n=128UL*1024*1024; double *a=malloc(n*8),*b=malloc(n*8),*c=malloc(n*8); double best=0;
#pragma omp parallel for
 for(size_t i=0;i<n;i++){a[i]=0;b[i]=1.0;c[i]=2.0;}
 for(int k=0;k<8;k++){ double t=omp_get_wtime();
#pragma omp parallel for
  for(size_t i=0;i<n;i++) a[i]=b[i]+3.0*c[i];
  t=omp_get_wtime()-t; double g=3.0*n*8/t/1e9; if(g>best)best=g;}
 printf("%.1f\n",best+a[7]*0); return 0; }
C
  gcc -O3 -fopenmp -march=native -o "$NOX_TMP/stream" "$NOX_TMP/stream.c" || { nox_log NO "STREAM не собрался"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
  bw="$("$NOX_TMP/stream")"
  ceil="$(nox_llm ceiling --active-cpu-gb 21 --cpu-gbs "$bw" --active-gpu-gb 4 --gpu-gbs "${NOX_GPU_BW_GBS:-448}" | python3 -c 'import json,sys;print(round(json.load(sys.stdin)["ceiling_tps"],2))')"
  { echo "cgroup_mem_max_bytes=$mx"; echo "cgroup_mem_cur_bytes=$cur"; echo "vcpu=$nproc_n sockets=$sock cores_per_socket=$cps threads_per_core=$tps phys_cores=$phys numa_nodes=$nodes"
    echo "dev_shm_size_bytes=$shm"; echo "pcie_gen=$gen width=$wid"; echo "stream_triad_gbs=$bw"; echo "ceiling_tps_A02=$ceil (CPU 21 ГБ, GPU 4 ГБ на токен; формула A02)"
    lscpu | grep -E 'Model name|Flags' | cut -c1-200; } >"$REP"
  nox_metric cgroup_mem_max_gb "$((mx/1000000000))"; nox_metric phys_cores "$phys"; nox_metric vcpu "$nproc_n"; nox_metric numa_nodes "$nodes"
  nox_metric dev_shm_gb "$((shm/1000000000))"; nox_metric pcie "gen$gen x$wid"; nox_metric stream_gbs "$bw"; nox_metric ceiling_tps "$ceil"
  nox_chk "cgroup-лимит RAM >= 520 ГБ" test "$mx" -ge 520000000000
  nox_chk "отчёт записан" test -s "$REP"
  nox_verdict
}
nox_run_task
