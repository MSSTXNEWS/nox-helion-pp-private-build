#!/usr/bin/env bash
# ID: P3-05
# ЦЕЛЬ: режимы Быстро/Авто/Глубоко/Максимум с ETA: ETA = токены / измеренный ток/с (+ префилл); привязка к reasoning_effort и бюджету токенов.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-15, P2-06
# ГОТОВО: (а) формула ETA на 4 реальных ответах Авто отличается от факта <= 30%; (б) UI отдаёт ETA в пределах +-30% от факта. Для (б) нужен контракт: GET $NOX_UI_ETA_URL?mode=<auto|deep|max>&tokens=<N> -> JSON {"eta_s": число}. Нет URL - BLOCKED (UI-часть не проверяется "на глаз").
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: config/eta_formula.json, reports/P3-05_eta_check.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P3-05 S1 "$@"
NOX_PLAN="eta_formula.json из P2-06; 4 ответа Авто: предсказанное vs фактическое время; запрос ETA у UI и сравнение"
t_pre() { nox_need_receipt P2-15 P2-06; nox_need_file "$NOX_ROOT/config/reasoning_modes.json"; nox_need_file "$NOX_REPORT_DIR/P2-06_eta.json"; nox_need_var NOX_UI_ETA_URL; nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "GLM не отвечает" "P2-04"; }
t_check() {
  python3 -B - "$NOX_LLAMA_URL" "$NOX_ROOT/config" "$NOX_REPORT_DIR" "$NOX_UI_ETA_URL" <<'PY' || { nox_log NO "проверка ETA завершилась ошибкой"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
import json, os, sys, urllib.request, urllib.parse
sys.path.insert(0, os.environ["NOX_LIB_DIR"]); import nox_llm as L
url, cfg, rep, ui = sys.argv[1:5]
e = json.load(open(rep + "/P2-06_eta.json")); modes = json.load(open(cfg + "/reasoning_modes.json"))["modes"]
tps, pf = e["decode_tps_p50"], e["prefill_tps_p50"] or 0
json.dump({"decode_tps": tps, "prefill_tps": pf, "formula": "eta_s = prompt_tokens/prefill_tps + completion_tokens/decode_tps", "modes": modes}, open(cfg + "/eta_formula.json", "w"), indent=1)
errs, ui_errs = [], []
for q in ("Назови три плюса префикс-кэша.", "Объясни, что такое mmap.", "Зачем нужен watchdog?", "Что такое квантование?"):
    r = L.chat(url, [{"role": "user", "content": q}], modes["auto"]["max_tokens"], {"temperature": 1.0, "chat_template_kwargs": {"reasoning_effort": modes["auto"]["reasoning_effort"], "clear_thinking": True}})
    u = r["usage"]; pn, cn = u.get("prompt_tokens", 0), u.get("completion_tokens", 0)
    pred = (pn / pf if pf else 0) + cn / tps; errs.append(abs(pred - r["total"]) / r["total"])
    try:
        uie = json.load(urllib.request.urlopen(ui + ("&" if "?" in ui else "?") + urllib.parse.urlencode({"mode": "auto", "tokens": cn}), timeout=20))["eta_s"]
        ui_errs.append(abs(uie - r["total"]) / r["total"])
    except Exception as ex:
        ui_errs.append(None); print("UI ETA недоступен:", ex, file=sys.stderr)
json.dump({"formula_err": errs, "ui_err": ui_errs}, open(rep + "/P3-05_eta_check.json", "w"), indent=1)
PY
  local f u; f="$(python3 -c 'import json,sys;print(round(max(json.load(open(sys.argv[1]))["formula_err"]),3))' "$NOX_REPORT_DIR/P3-05_eta_check.json")"
  u="$(python3 -c 'import json,sys;e=json.load(open(sys.argv[1]))["ui_err"];print("NA" if None in e else round(max(e),3))' "$NOX_REPORT_DIR/P3-05_eta_check.json")"
  nox_metric formula_max_err "$f"; nox_metric ui_max_err "$u"
  nox_chk "формула ETA: ошибка <= 30%" nox_le "$f" 0.3
  [ "$u" != NA ] || nox_blocked "UI не ответил на $NOX_UI_ETA_URL по контракту {eta_s}" "реализация эндпоинта ETA в UI (контракт в шапке скрипта)"
  nox_chk "UI ETA: ошибка <= 30%" nox_le "$u" 0.3
  nox_verdict
}
nox_run_task
