#!/usr/bin/env bash
# ID: P1-13
# ЦЕЛЬ: бюджет RAM S1 с учётом cgroup-лимита: веса + KV + служебное; свободно >=150 ГБ при полной загрузке.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-03
# ГОТОВО: run/ram_budget.json; free_after_load >= NOX_RAM_FREE_MIN_GB (150).
# ИСТОЧНИКИ: Drive: нет; Интернет: нет; Генерируется: run/ram_budget.json (cgroup max, веса, KV, резерв, свободно)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-13 S1 "$@"
NOX_PLAN="прочитать cgroup memory.max и RAM; веса=размер каталога модели (или NOX_MODEL_BYTES); KV и резерв; записать бюджет; проверить свободно>=150 ГБ"
t_pre() { nox_need_cmd python3 awk; }
t_do() {
  local tot cg mb kv rs
  tot="$(nox_mem_total)"; cg="$(nox_cg_mem_max)"; [ -n "$cg" ] && [ "$cg" -gt 0 ] 2>/dev/null || cg="$tot"
  [ "$cg" -gt "$tot" ] && cg="$tot"
  mb="${NOX_MODEL_BYTES:-}"
  if [ -z "$mb" ]; then for d in "${NOX_MODEL_DIR:-}" /root/nox/models /workspace/models /models; do [ -d "$d" ] && mb="$(du -sb "$d" | cut -f1)" && break; done; fi
  [ -n "$mb" ] && [ "$mb" -gt 0 ] || mb=$((467*1000000000))
  kv="${NOX_KV_BYTES:-$((30*1000000000))}"; rs="${NOX_RESERVE_BYTES:-$((20*1000000000))}"
  python3 -I - "$NOX_RUN_DIR/ram_budget.json" "$tot" "$cg" "$mb" "$kv" "$rs" <<'P'
import json,sys,time
f,tot,cg,mb,kv,rs=sys.argv[1],*map(int,sys.argv[2:])
free=cg-mb-kv-rs
json.dump({"t":time.strftime("%FT%TZ",time.gmtime()),"mem_total":tot,"cgroup_max":cg,"weights":mb,"kv":kv,"reserve":rs,"free_after_load":free,"free_gb":round(free/1e9,1)},open(f,"w"),indent=1)
P
}
t_check() {
  nox_chk "ram_budget.json есть" test -s "$NOX_RUN_DIR/ram_budget.json"
  [ -s "$NOX_RUN_DIR/ram_budget.json" ] || return 1
  local g; g="$(python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1]))["free_gb"])' "$NOX_RUN_DIR/ram_budget.json")"
  nox_metric free_after_load_gb "$g"
  nox_chk "свободно при полной загрузке >= ${NOX_RAM_FREE_MIN_GB:-150} ГБ" nox_ge "$g" "${NOX_RAM_FREE_MIN_GB:-150}"
  nox_verdict
}
nox_run_task
