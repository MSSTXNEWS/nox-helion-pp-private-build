#!/usr/bin/env bash
# ID: P4-02
# ЦЕЛЬ: схема M0-M7 (поле level) в S03 и проверщик ссылок [m:id]: ответ без существующего id блокируется.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P4-01
# ГОТОВО: таблица nox_mem (level CHECK M0-M7) создана; selftest: существующий id проходит, выдуманный id блокируется, ответ без ссылки блокируется (--require), без требования - допускается. CLI проверщика: python3 lib/nox_s03.py check-ref DB --require < ответ.txt (код 1 = блок).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: таблицы nox_mem + nox_mem_fts в NOX_S03_DB (бэкап файла БД перед миграцией)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P4-02 S1 "$@"
NOX_PLAN="бэкап БД; migrate; selftest-ref (временные записи удаляются)"
t_pre() { nox_need_receipt P4-01; nox_need_var NOX_S03_DB; nox_need_file "$NOX_S03_DB"; nox_need_cmd python3; }
t_backup() { python3 -B "$NOX_LIB_DIR/nox_s03.py" backup "$NOX_S03_DB" "$NOX_BACKUP_DIR/P4-02.pre.db"; }
t_rollback() { cp -a "$NOX_BACKUP_DIR/P4-02.pre.db" "$NOX_S03_DB"; }
t_do() { python3 -B "$NOX_LIB_DIR/nox_s03.py" migrate "$NOX_S03_DB"; }
t_check() {
  nox_chk "схема nox_mem есть, колонки верны" python3 -B -c 'import sys;sys.path.insert(0,"'"$NOX_LIB_DIR"'");import nox_s03 as S;c=S.connect("'"$NOX_S03_DB"'");assert [r[1] for r in c.execute("PRAGMA table_info(nox_mem)")]==S.COLS'
  nox_chk "level принимает только M0-M7" bash -c "! python3 -B '$NOX_LIB_DIR/nox_s03.py' sql '$NOX_S03_DB' \"INSERT INTO nox_mem VALUES('__bad','M9','owner','','x','','h',0,'t')\" 2>/dev/null"
  nox_chk "проверщик ссылок: selftest" python3 -B "$NOX_LIB_DIR/nox_s03.py" selftest-ref "$NOX_S03_DB"
  nox_verdict
}
nox_run_task
