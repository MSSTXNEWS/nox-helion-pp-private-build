#!/usr/bin/env bash
# ID: PV-02
# ЦЕЛЬ: один живой чат на всех страницах: большой и мини-чат делят session_id; продолжение ответа после обрыва по request_id; STOP отменяет только свой request.
# СЕРВЕР: S2 (живой контур NOX на S2; исполнитель - TOOLS)
# ЗАВИСИМОСТИ: PV-01
# ГОТОВО: обрыв (abort_after_bytes) -> ответ дописывается по request_id; STOP отменяет только свой запрос; session_id общий.
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА (не выдумываются): NOX_RESONANCE_URL; сценарий $NOX_ROOT/scenarios/PV-02.json с шагами-тегами: one_session,resume_after_drop,stop_only_own (формат - в шапке lib/nox_scenario.py).
#   Без сценария скрипт сохраняет openapi.json контура (если отдаётся) в $NOX_ROOT/discovery/ и честно отвечает BLOCKED. Это скрипт приёмки: он ПРОВЕРЯЕТ, а не меняет контур.
# ИСТОЧНИКИ:
#   Drive: README WEB WOW 1FTEuz9G... и план потока 1SwQwESb... (ID неполные в каноне; полные найти: rclone lsf gdrive: --include '*WEB WOW*')
#   Интернет: нет
#   Генерируется: reports/PV-02.scenario.json (результат каждого шага)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_scen.sh"
nox_begin PV-02 S2 "$@"
NOX_PLAN="выполнить сценарий приёмки PV-02 (теги: one_session,resume_after_drop,stop_only_own) против $NOX_RESONANCE_URL"
nox_scenario_task PV-02 "one_session,resume_after_drop,stop_only_own"
