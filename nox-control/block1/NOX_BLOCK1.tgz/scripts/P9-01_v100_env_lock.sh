#!/usr/bin/env bash
# ID: P9-01
# ЦЕЛЬ: окружение обучения V100: закреплённые версии PEFT 0.21.3, TRL 1.18.0, bitsandbytes 0.50.2, safetensors 0.8.0 (программа 16.11) + smoke LoRA на GPU (fp16).
# СЕРВЕР: S2
# ЗАВИСИМОСТИ: P1-16
# ГОТОВО: версии пакетов равны закреплённым; smoke LoRA (3 шага на крошечной случайной GPT-2) проходит на V100 с конечным loss. Если закреплённой версии нет на PyPI - pip сообщит, и скрипт честно вернёт FAIL с откатом окружения из pip freeze.
# ИСТОЧНИКИ:
#   Drive: V4П часть 5 (версии): 1BlD1_gtzd7YKDdkM07i0Iubz-ZagYuIxchiSojy2Ce0
#   Интернет: PyPI: peft==0.21.3, trl==1.18.0, bitsandbytes==0.50.2, safetensors==0.8.0 (pip install --no-deps не используется: зависимости нужны)
#   Генерируется: locks/P9-01.pre.freeze (для отката), locks/s2_train.freeze (обновляется после успеха)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P9-01 S2 "$@"
NOX_PLAN="pip freeze (бэкап); pip install закреплённых версий; smoke LoRA; обновить lock"
PIN=("peft==0.21.3" "trl==1.18.0" "bitsandbytes==0.50.2" "safetensors==0.8.0"); PRE="$NOX_ROOT/locks/P9-01.pre.freeze"
t_pre() { nox_need_receipt P1-16; nox_need_cmd python3 pip3; }
t_backup() { mkdir -p "$NOX_ROOT/locks"; pip3 freeze >"$PRE"; }
t_rollback() { [ -s "$PRE" ] && pip3 install -q -r "$PRE" >>"$NOX_LOGFILE" 2>&1 || true; }
t_do() { pip3 install -q "${PIN[@]}" >>"$NOX_LOGFILE" 2>&1 && pip3 freeze >"$NOX_ROOT/locks/s2_train.freeze" && sha256sum "$NOX_ROOT/locks/s2_train.freeze" >"$NOX_ROOT/locks/s2_train.freeze.sha256"; }
t_check() {
  local p v want
  for p in "${PIN[@]}"; do v="$(pip3 show "${p%%==*}" 2>/dev/null | sed -n 's/^Version: //p')"; want="${p##*==}"; nox_metric "${p%%==*}" "${v:-нет}"; nox_chk "${p%%==*} == $want" test "$v" = "$want"; done
  [ "$NOX_NFAIL" -eq 0 ] || return 1
  nox_chk "smoke LoRA на V100" python3 -B - <<'PY'
import torch
from transformers import GPT2Config, GPT2LMHeadModel
from peft import LoraConfig, get_peft_model
torch.manual_seed(0)
m = GPT2LMHeadModel(GPT2Config(n_layer=2, n_head=2, n_embd=64, vocab_size=512, n_positions=64)).cuda()
m = get_peft_model(m, LoraConfig(r=4, lora_alpha=8, target_modules=["c_attn"], fan_in_fan_out=True, task_type="CAUSAL_LM"))
opt = torch.optim.AdamW([p for p in m.parameters() if p.requires_grad], lr=1e-3); sc = torch.cuda.amp.GradScaler()
x = torch.randint(0, 512, (4, 32), device="cuda")
for _ in range(3):
    with torch.autocast("cuda", dtype=torch.float16):
        loss = m(input_ids=x, labels=x).loss
    sc.scale(loss).backward(); sc.step(opt); sc.update(); opt.zero_grad()
assert torch.isfinite(loss).item(), "loss не конечен"
PY
  nox_verdict
}
nox_run_task
