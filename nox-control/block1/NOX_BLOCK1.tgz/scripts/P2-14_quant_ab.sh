#!/usr/bin/env bash
# ID: P2-14
# ЦЕЛЬ: A/B кванта Q4_K_XL против IQ4_XS: решение по правилу "скорость при <= -1 балла экзамена" и записью решения владельцу (Q).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-09, P2-06
# ГОТОВО: в reports/ab_journal.jsonl есть замеры с метками q4kxl и iq4xs; reports/P2-14_decision.json с прирост скорости, дельтой экзамена и вердиктом; решение остаётся за владельцем.
# ВАЖНО (запрет раздела 12 "две главные модели в RAM"): 467 ГБ + 365 ГБ > 762 ГБ, поэтому одновременно держать нельзя. Скрипт сам снимает замер q4kxl на работающем сервере. Для iq4xs нужна ОТДЕЛЬНАЯ сессия: остановить сервер, загрузить IQ4_XS вместо Q4 (P2-01 с NOX_GLM_FOLDER=UD-IQ4_XS и новой копией манифеста), запустить P2-04, затем `lib/ab.sh run quant iq4xs`, потом вернуть Q4 (467 ГБ, 25-40 мин). Старое не удаляется без проверенной замены: Q4 остаётся на складе. Без метки iq4xs скрипт честно отвечает BLOCKED.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: HF unsloth/GLM-5.3-GGUF, папка UD-IQ4_XS/ (365 ГБ) по ревизии из HF API (как в P2-01)
#   Генерируется: reports/ab_journal.jsonl (lib/ab.sh), reports/P2-14_decision.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-14 S1 "$@"
NOX_PLAN="ab.sh run quant q4kxl (если нет метки); compare q4kxl iq4xs; записать решение"
J="$NOX_REPORT_DIR/ab_journal.jsonl"; DEC="$NOX_REPORT_DIR/P2-14_decision.json"
has() { [ -s "$J" ] && python3 -c 'import json,sys;sys.exit(0 if any(json.loads(l)["label"]==sys.argv[1] for l in open(sys.argv[2])) else 1)' "$1" "$J"; }
t_pre() { nox_need_receipt P1-09 P2-06; }
t_do() { has q4kxl || { nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "сервер не отвечает - нельзя снять замер q4kxl" "запустить P2-04"; "$NOX_LIB_DIR/ab.sh" run quant q4kxl; }; }
t_check() {
  has q4kxl || { nox_log NO "нет замера q4kxl"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
  has iq4xs || nox_blocked "нет замера iq4xs (две главные модели в RAM нельзя)" "отдельная сессия с IQ4_XS и затем: lib/ab.sh run quant iq4xs (см. шапку скрипта)"
  local r; r="$("$NOX_LIB_DIR/ab.sh" compare q4kxl iq4xs || true)"; nox_log INFO "$r"
  python3 -c 'import json,sys;d=json.loads(sys.argv[1]);d["decision"]="owner_Q";d["rule"]="IQ4_XS, если скорость выше и экзамен не хуже чем на 1 балл";json.dump(d,open(sys.argv[2],"w"),ensure_ascii=False,indent=1)' "$r" "$DEC"
  nox_metric decode_gain "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["decode_gain"])' "$r")"; nox_metric exam_delta "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["exam_delta"])' "$r")"
  nox_chk "решение записано владельцу" test -s "$DEC"
  nox_verdict
}
nox_run_task
