#!/usr/bin/env bash
# ID: PV-01
# ЦЕЛЬ: сквозная приёмка живого Резонанса: разговор -> мини-чат -> факт со ссылкой S03 -> исправление владельцем -> перезагрузка -> следующий ответ использует исправление -> STOP с серверной квитанцией.
# СЕРВЕР: S2 (живой контур NOX на S2; исполнитель - QA)
# ЗАВИСИМОСТИ: нет (внешние: P7-03, P4-01 - слой Резонанса)
# ГОТОВО: 7 шагов s1..s7 PASS на одном SHA контура (sha_paths в сценарии).
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА (не выдумываются): NOX_RESONANCE_URL; сценарий $NOX_ROOT/scenarios/PV-01.json с шагами-тегами: s1,s2,s3,s4,s5,s6,s7 (формат - в шапке lib/nox_scenario.py).
#   Без сценария скрипт сохраняет openapi.json контура (если отдаётся) в $NOX_ROOT/discovery/ и честно отвечает BLOCKED. Это скрипт приёмки: он ПРОВЕРЯЕТ, а не меняет контур.
# ИСТОЧНИКИ:
#   Drive: Канон Резонанса 1DtuxYMF... (ID неполный в каноне - полный найти на Диске); Evidence Gate 1JiSWC-mhg7y_RLehUgQZxNZNEHZzbwQ9ykYc4SHY5dE
#   Интернет: нет
#   Генерируется: reports/PV-01.scenario.json (результат каждого шага)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"; . "$(dirname "$0")/lib/nox_scen.sh"
nox_begin PV-01 S2 "$@"
NOX_PLAN="выполнить сценарий приёмки PV-01 (теги: s1,s2,s3,s4,s5,s6,s7) против $NOX_RESONANCE_URL"
nox_scenario_task PV-01 "s1,s2,s3,s4,s5,s6,s7"
