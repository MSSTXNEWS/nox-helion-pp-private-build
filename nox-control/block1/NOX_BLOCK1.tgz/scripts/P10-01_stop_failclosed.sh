#!/usr/bin/env bash
# ID: P10-01
# ЦЕЛЬ: универсальный STOP fail-closed (9.1): файл-флаг /run/nox/STOP, агент lib/nox_stop_agent.sh с политиками stop|freeze|keep на сервис; остановка <= 10 с, резюме при снятии; сломанный флаг = остановка.
# СЕРВЕР: S1,S2
# ЗАВИСИМОСТИ: P1-12
# ГОТОВО: тест на реальных процессах (отдельный экземпляр агента, временные каталоги, production не затрагивается): флаг -> процесс policy=stop завершён <=10 с; policy=freeze в состоянии T с замком паузы <=10 с; policy=keep работает; флаг снят -> freeze продолжен <=10 с, замок снят; "сломанный" флаг (путь под обычным файлом) -> nox_stop_gate блокирует (fail-closed). Рабочий агент запущен.
# ЧЕГО ЗДЕСЬ НЕТ: API-кнопки STOP в UI, остановки токенов текущей генерации (нужен клиент стрима, проверяющий флаг/закрывающий соединение) и "свой STOP - только создатель" (права на запись флага: файл создаёт root/владелец) - это слой Резонанса/прокси; в квитанцию пишется stop_scope=files_and_services.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: run/wd/stop_agent.pid, STOP_POLICY= в services.d/*.conf (их пишут владельцы сервисов)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P10-01 S1,S2 "$@"
NOX_PLAN="запустить рабочий stop_agent; selftest на временных каталогах: stop/freeze/keep, резюме, сломанный флаг"
AG="$NOX_LIB_DIR/nox_stop_agent.sh"; export NOX_ALLOW_UNDER_STOP=1
t_pre() { nox_need_receipt P1-12; nox_need_cmd setsid; }
t_do() { setsid nohup "$AG" >>"$NOX_LOG_DIR/stop_agent.log" 2>&1 & sleep 2; }
t_rollback() { [ -s "$NOX_RUN_DIR/wd/stop_agent.pid" ] && kill "$(cat "$NOX_RUN_DIR/wd/stop_agent.pid")" 2>/dev/null || true; }
selftest() {
  local T n el t0 agpid pids=()
  T="$(mktemp -d)"; mkdir -p "$T/conf" "$T/st" "$T/pause"
  for n in stopper freezer keeper; do
    printf 'NAME=%s\nSTOP_POLICY=%s\n' "$n" "$([ $n = stopper ] && echo stop || { [ $n = freezer ] && echo freeze || echo keep; })" >"$T/conf/$n.conf"
    setsid sleep 600 & echo $! >"$T/st/$n.pid"; pids+=($!)
  done
  NOX_WD_CONF_DIR="$T/conf" NOX_WD_STATE="$T/st" NOX_STOP_FLAG="$T/STOP" NOX_PAUSE_DIR="$T/pause" NOX_ROOT="$T/root" NOX_RUN_DIR="$T/root/run" NOX_LOG_DIR="$T/root/logs" setsid "$AG" >"$T/agent.log" 2>&1 &
  agpid=$!; sleep 3
  t0=$(date +%s); : >"$T/STOP"
  until ! kill -0 "$(cat "$T/st/stopper.pid")" 2>/dev/null || [ $(( $(date +%s) - t0 )) -gt 15 ]; do sleep 1; done; el=$(( $(date +%s) - t0 )); nox_metric stop_latency_s "$el"
  nox_chk "policy=stop завершён <= 10 с" test "$el" -le 10
  sleep 2
  nox_chk "policy=freeze в состоянии T" test "$(nox_pid_state "$(cat "$T/st/freezer.pid")")" = T
  nox_chk "у замороженного есть замок паузы" test -s "$T/pause/$(cat "$T/st/freezer.pid").lock"
  nox_chk "policy=keep продолжает работать" bash -c "[ \"\$(sed 's/.*) //' /proc/$(cat "$T/st/keeper.pid")/stat | cut -c1)\" != T ]"
  t0=$(date +%s); rm -f "$T/STOP"
  until [ "$(nox_pid_state "$(cat "$T/st/freezer.pid")")" != T ] || [ $(( $(date +%s) - t0 )) -gt 15 ]; do sleep 1; done; el=$(( $(date +%s) - t0 )); nox_metric resume_latency_s "$el"
  nox_chk "после снятия флага freeze продолжен <= 10 с" test "$el" -le 10
  nox_chk "замок паузы снят" test ! -e "$T/pause/$(cat "$T/st/freezer.pid").lock"
  # сломанный флаг: каталог флага невозможно создать (родитель - обычный файл) -> gate блокирует
  : >"$T/plainfile"
  nox_chk "сломанный флаг = остановка (fail-closed)" bash -c "NOX_ALLOW_UNDER_STOP=0 NOX_STOP_FLAG='$T/plainfile/STOP' NOX_ROOT='$T/root2' bash -c '. \"$NOX_LIB_DIR/nox_common.sh\"; NOX_ID=t NOX_RECEIPT_DIR=$T/r NOX_LOG_DIR=$T/l NOX_TMP=$T NOX_RUN_DIR=$T; nox_stop_gate' >/dev/null 2>&1; [ \$? -eq 3 ]"
  kill "$agpid" "${pids[@]}" 2>/dev/null || true; rm -rf "$T"
}
t_check() {
  nox_chk "рабочий stop_agent запущен" bash -c "[ -s '$NOX_RUN_DIR/wd/stop_agent.pid' ] && kill -0 \$(cat '$NOX_RUN_DIR/wd/stop_agent.pid')"
  selftest; nox_metric stop_scope files_and_services
  nox_verdict
}
nox_run_task
