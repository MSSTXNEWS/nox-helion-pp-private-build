#!/usr/bin/env bash
# ID: P2-06
# ЦЕЛЬ: baseline decode/prefill/TTFT на 5 промптах (коротк EN, RU, код, ~1000 ток контекста, ~5000 ток) x3 повтора; p50/p95; пересчёт ETA.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-04, P1-08
# ГОТОВО: reports/P2-06_baseline.csv (15 строк, decode_tps>0), метрики p50/p95, reports/P2-06_eta.json. Измерение идёт через API сервера (timings); llama-sweep-bench грузил бы модель второй раз (VRAM/RAM) и здесь не используется.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: reports/P2-06_baseline.csv, reports/P2-06_eta.json (ETA = токены / измеренный ток/с)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P2-06 S1 "$@"
NOX_PLAN="nox_llm bench (3 повтора x 5 промптов, cache_prompt=false, temperature 0); расчёт ETA"
t_pre() { nox_need_receipt P2-04 P1-08; nox_health "$NOX_LLAMA_URL" >/dev/null || nox_blocked "llama-server не отвечает" "запустить P2-04"; }
t_check() {
  local b; b="$(nox_llm bench --url "$NOX_LLAMA_URL" --repeats 3 --n 128 --ctx 1000 --long 5000 --out "$NOX_REPORT_DIR/P2-06_baseline.csv")" || nox_blocked "bench не выполнился" "доступность /completion и /tokenize"
  nox_log INFO "$b"
  local k v; for k in decode_tps_p50 decode_tps_p05 prefill_tps_p50 ttft_s_p50 ttft_s_p95 rows; do v="$(python3 -c 'import json,sys;print(json.loads(sys.argv[1]).get(sys.argv[2]))' "$b" "$k")"; nox_metric "$k" "$v"; done
  nox_chk "15 строк в CSV" test "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["rows"])' "$b")" -eq 15
  nox_chk "decode ток/с > 0" nox_ge "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["decode_tps_p50"] or 0)' "$b")" 0.01
  python3 - "$b" "$NOX_REPORT_DIR/P2-06_eta.json" <<'PY'
import json, sys
b = json.loads(sys.argv[1]); t = b["decode_tps_p50"]; p = b["prefill_tps_p50"] or 0
json.dump({"decode_tps_p50": t, "prefill_tps_p50": p, "eta_s_per_100_tokens": round(100 / t, 1),
           "eta_s_300_tokens": round(300 / t, 1), "prefill_s_per_5000_tokens": round(5000 / p, 1) if p else None,
           "estimate_in_canon": "2-3 ток/с (гипотеза)", "within_estimate": 2 <= t <= 3}, open(sys.argv[2], "w"), indent=1)
PY
  nox_chk "ETA записан" test -s "$NOX_REPORT_DIR/P2-06_eta.json"
  nox_verdict
}
nox_run_task
