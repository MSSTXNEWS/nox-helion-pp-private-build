#!/usr/bin/env bash
# ID: P2-04
# ЦЕЛЬ: базовый запуск A07: llama-server с GLM-5.3 (внимание/dense/shared на GPU, эксперты в RAM через --cpu-moe), mmap, KV f16, под watchdog.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-02, P1-06
# ГОТОВО: /health отвечает, тестовый запрос возвращает ответ, в логе "offloaded N/N layers to GPU" и нет признаков CPU-fallback; команда сохранена в run/llama.cmd, сервис зарегистрирован в services.d/llama.conf.
# ЗАПРЕТЫ: запуск только через lib/nox_llama_launch.sh (guard раздела 12); без --no-mmap/--mlock; KV f16; без draft/ngram.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет (бинарник из P1-06, модель из P2-01)
#   Генерируется: run/llama.cmd, services.d/llama.conf, slots/ (--slot-save-path), логи logs/llama.service.log
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
. "$(dirname "$0")/lib/nox_llama_ctl.sh"
nox_begin P2-04 S1 "$@"
NOX_PLAN="собрать команду A07 (+-t/-tb из cpu_plan, --metrics, --host/--port); записать services.d/llama.conf; дождаться /health; тестовый запрос; проверить лог"
SLOTS="$NOX_ROOT/slots"; SVCLOG="$NOX_LOG_DIR/llama.service.log"; WDST="$NOX_RUN_DIR/wd"
llama_args() {
  local m a; m="$NOX_ROOT/glm53/$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/glm53_manifest.json"))["files"][0]["path"].split("/")[-1])')"
  a="-m $m -ngl 99 --cpu-moe -fa on --jinja -c 32768 -b 4096 -ub 1024 -np 1 --cache-reuse 256 --slot-save-path $SLOTS --temp 1.0 --top-p 0.95 --min-p 0.01 -ctk f16 -ctv f16 --metrics --host $NOX_LLAMA_HOST --port $NOX_LLAMA_PORT"
  if [ -s "$NOX_RUN_DIR/cpu_plan.json" ]; then a="$a -t $(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/cpu_plan.json"))["t"])') -tb $(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/cpu_plan.json"))["tb"])')"; fi
  echo "$a"
}
t_pre() { nox_need_receipt P2-02 P1-06; nox_need_file "$NOX_RUN_DIR/llama_build.json"; nox_need_cmd curl python3; nox_forbid_args "$(llama_args)"; }
t_backup() { nox_backup "$NOX_RUN_DIR/llama.cmd" "$NOX_RUN_DIR/llama.args" "$NOX_ROOT/services.d/llama.conf"; }
t_do() {
  mkdir -p "$SLOTS" "$NOX_ROOT/services.d" "$WDST"
  local args; args="$(llama_args)"
  echo "$NOX_LIB_DIR/nox_llama_launch.sh $args" >"$NOX_RUN_DIR/llama.cmd"
  read -r -a LLAMA_ARGS <<<"$args"; llama_args_save; llama_conf_write
  if [ -s "$WDST/watchdog.pid" ] && kill -0 "$(cat "$WDST/watchdog.pid")" 2>/dev/null; then nox_log INFO "watchdog запущен: он поднимет llama сам"
  else
    # shellcheck disable=SC2046,SC2086
    setsid nohup "$NOX_LIB_DIR/nox_llama_launch.sh" $args >>"$SVCLOG" 2>&1 & echo $! >"$WDST/llama.pid"; date +%s >"$WDST/llama.started"
  fi
  nox_wait_health "$NOX_LLAMA_URL" "${NOX_LLAMA_START_TIMEOUT:-1800}"
}
t_rollback() { local p; p="$(cat "$WDST/llama.pid" 2>/dev/null || true)"; rm -f "$NOX_ROOT/services.d/llama.conf"; [ -n "$p" ] && kill "$p" 2>/dev/null || true; nox_restore || true; }
t_check() {
  nox_chk "/health отвечает" nox_health "$NOX_LLAMA_URL"
  [ "$NOX_NFAIL" -eq 0 ] || return 1
  local pid out ln
  pid="$(nox_llama_pid)"; nox_chk "процесс жив и не в состоянии T" nox_healthy "$pid" "$NOX_LLAMA_URL"
  out="$(nox_llm chat --url "$NOX_LLAMA_URL" --prompt "Ответь одним словом: готов?" --max-tokens 256 --extra '{"temperature":1.0,"chat_template_kwargs":{"reasoning_effort":"low"}}')" || out='{}'
  nox_chk "тестовый запрос дал ответ" python3 -c 'import json,sys;d=json.loads(sys.argv[1]);sys.exit(0 if (d.get("content") or d.get("reasoning")) else 1)' "$out"
  nox_metric test_ttft_s "$(python3 -c 'import json,sys;print(round(json.loads(sys.argv[1]).get("ttft") or -1,2))' "$out")"
  ln="$(grep -h 'offloaded' "$SVCLOG" 2>/dev/null | tail -1)"; nox_metric offload_line "${ln:-нет строки offloaded}"
  nox_chk "все слои на GPU (offloaded N/N)" bash -c "echo '$ln' | awk '{for(i=1;i<=NF;i++) if(\$i ~ /^[0-9]+\\/[0-9]+\$/){split(\$i,a,\"/\"); exit !(a[1]==a[2])}; exit 1}'"
  nox_chk "нет признаков CPU-fallback в логе" bash -c "! grep -Eiq 'fall(ing)? ?back to cpu|no CUDA devices|failed to initialize CUDA|CUDA error' '$SVCLOG'"
  nox_chk "CUDA-устройство найдено в логе" grep -q 'found 1 CUDA devices' "$SVCLOG"
  nox_chk "argv без --no-mmap/--mlock" bash -c "! tr '\\0' ' ' </proc/$pid/cmdline | grep -Eq -- '--no-mmap|--mlock'"
  nox_verdict
}
nox_run_task
