#!/usr/bin/env python3
"""nox_prio.py - приоритетный менеджер ресурсов S1: чат > судья > фон; вытеснение и IDLE-гейт.
  apply : классы: chat (llama-server) nice -5 / судья nice 0 / фон nice 15 + ionice idle.
  gate  : код 0 если фон можно запускать (чат не активен последние NOX_IDLE_S сек), иначе 1.
  touch : отметить активность чата (зовёт API/прокси чата).
  evict : при активном чате SIGSTOP фоновым PID только через замок паузы 9.7 (/run/nox/pause/<pid>.lock); при IDLE - SIGCONT и снятие замка.
"""
import os, sys, time, subprocess, json
ROOT = os.environ.get("NOX_ROOT", "/root/nox")
ACT = os.path.join(ROOT, "run", "chat_active")
PAUSE = os.environ.get("NOX_PAUSE_DIR", "/run/nox/pause")
IDLE_S = int(os.environ.get("NOX_IDLE_S", "30"))
CLASSES = [("chat", "llama-server", -5), ("judge", "nox_judge", 0)]
BG = os.environ.get("NOX_BG_PATTERNS", "nox_train,nox_worm,nox_distill").split(",")

def pids(pat):
    out = subprocess.run(["pgrep", "-f", pat], capture_output=True, text=True).stdout.split()
    return [int(p) for p in out if int(p) != os.getpid()]

def renice(pid, n, idle=False):
    try:
        os.setpriority(os.PRIO_PROCESS, pid, n)
        if idle: subprocess.run(["ionice", "-c3", "-p", str(pid)], capture_output=True)
        return True
    except Exception:
        return False

def apply():
    res = {}
    for cls, pat, nice in CLASSES:
        res[cls] = {p: renice(p, nice) for p in pids(pat)}
    res["bg"] = {p: renice(p, 15, True) for pat in BG for p in pids(pat)}
    out = {k: {str(p): v for p, v in d.items()} for k, d in res.items()}
    json.dump({"t": time.time(), "applied": out}, open(os.path.join(ROOT, "run", "prio_applied.json"), "w"), indent=1)
    print(json.dumps(out))

def active():
    try: return time.time() - os.path.getmtime(ACT) < IDLE_S
    except OSError: return False

def evict():
    os.makedirs(PAUSE, exist_ok=True)
    for pat in BG:
        for p in pids(pat):
            lock = os.path.join(PAUSE, f"{p}.lock")
            if active() and not os.path.exists(lock):
                open(lock, "w").write(json.dumps({"by": "nox_prio", "until": int(time.time()) + 600}))
                os.kill(p, 19)
            elif not active() and os.path.exists(lock):
                os.kill(p, 18); os.remove(lock)

if __name__ == "__main__":
    c = sys.argv[1] if len(sys.argv) > 1 else "gate"
    os.makedirs(os.path.join(ROOT, "run"), exist_ok=True)
    if c == "apply": apply()
    elif c == "touch": open(ACT, "a").close(); os.utime(ACT, None)
    elif c == "gate": sys.exit(1 if active() else 0)
    elif c == "evict": evict()
    else: sys.exit(2)
