#!/usr/bin/env python3
"""S03: схема памяти nox_mem (уровни M0-M7, области доступа, SHA факта, отзыв), FTS5, проверка ссылок [m:id], Evidence Gate, WarmCache (LRU+TTL).
Единая доверенная память - один SQLite-файл. Таблица nox_mem создаётся ЭТИМ модулем; чужая таблица с тем же именем и другими колонками -> ошибка (миграция старых данных - отдельный факт о старой схеме).
CLI: migrate DB | check-ref DB [--require] (текст из stdin) | selftest-ref DB | bench-fts [N] | evidence-test DB | integrity DB"""
import hashlib, json, os, re, sqlite3, sys, tempfile, time
from collections import OrderedDict

LEVELS = ["M%d" % i for i in range(8)]
SCOPES = ("owner", "project", "persona", "dialog")
COLS = ["id", "level", "scope", "scope_ref", "text", "source", "fact_sha", "revoked", "created_at"]
DDL = """
CREATE TABLE IF NOT EXISTS nox_mem(
  id TEXT PRIMARY KEY,
  level TEXT NOT NULL CHECK(level IN ('M0','M1','M2','M3','M4','M5','M6','M7')),
  scope TEXT NOT NULL CHECK(scope IN ('owner','project','persona','dialog')),
  scope_ref TEXT NOT NULL DEFAULT '',
  text TEXT NOT NULL, source TEXT NOT NULL DEFAULT '', fact_sha TEXT NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE VIRTUAL TABLE IF NOT EXISTS nox_mem_fts USING fts5(text, content='nox_mem', content_rowid='rowid');
CREATE TRIGGER IF NOT EXISTS nox_mem_ai AFTER INSERT ON nox_mem BEGIN INSERT INTO nox_mem_fts(rowid,text) VALUES (new.rowid,new.text); END;
CREATE TRIGGER IF NOT EXISTS nox_mem_ad AFTER DELETE ON nox_mem BEGIN INSERT INTO nox_mem_fts(nox_mem_fts,rowid,text) VALUES('delete',old.rowid,old.text); END;
"""

def connect(path):
    c = sqlite3.connect(path, timeout=30); c.execute("PRAGMA journal_mode=WAL"); return c

def migrate(c):
    have = [r[1] for r in c.execute("PRAGMA table_info(nox_mem)")]
    if have and have != COLS:
        raise RuntimeError("таблица nox_mem уже есть с другими колонками: %s" % have)
    c.executescript(DDL); c.commit()

def add(c, id_, level, scope, ref, text, source=""):
    sha = hashlib.sha256(text.encode()).hexdigest()
    c.execute("INSERT INTO nox_mem(id,level,scope,scope_ref,text,source,fact_sha,created_at) VALUES(?,?,?,?,?,?,?,?)",
              (id_, level, scope, ref, text, source, sha, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())))
    return sha

def allowed_sql(p):
    """p: {'owner':bool,'projects':[..],'persona':str|None,'dialog':str|None} -> (условие, параметры)."""
    parts, args = [], []
    if p.get("owner"): parts.append("scope='owner'")
    if p.get("projects"): parts.append("(scope='project' AND scope_ref IN (%s))" % ",".join("?" * len(p["projects"]))); args += list(p["projects"])
    if p.get("persona"): parts.append("(scope='persona' AND scope_ref=?)"); args.append(p["persona"])
    if p.get("dialog"): parts.append("(scope='dialog' AND scope_ref=?)"); args.append(p["dialog"])
    return ("(%s)" % " OR ".join(parts) if parts else "0"), args

def search(c, q, p, limit=10):
    cond, args = allowed_sql(p)
    fq = " ".join('"%s"' % w.replace('"', "") for w in q.split())
    rows = c.execute("SELECT m.id,m.level,m.text,m.fact_sha FROM nox_mem_fts f JOIN nox_mem m ON m.rowid=f.rowid "
                     "WHERE nox_mem_fts MATCH ? AND m.revoked=0 AND " + cond + " ORDER BY rank LIMIT ?", [fq] + args + [limit]).fetchall()
    # Evidence Gate: пустой результат - НЕ отрицательный факт
    return {"status": "FOUND" if rows else "NO_EVIDENCE", "rows": rows}

def revoke(c, id_):
    c.execute("UPDATE nox_mem SET revoked=1 WHERE id=?", (id_,)); c.commit()

REF = re.compile(r"\[m:([A-Za-z0-9_.:\-]+)\]")
def check_refs(c, text, require=True):
    ids = REF.findall(text)
    if not ids: return (not require), ["<нет ссылок [m:id]>"] if require else []
    missing = [i for i in ids if not c.execute("SELECT 1 FROM nox_mem WHERE id=? AND revoked=0", (i,)).fetchone()]
    return (not missing), missing

class WarmCache:
    """LRU+TTL; ключ (principal, запрос); инвалидация по id записи (отзыв) и по principal (смена прав)."""
    def __init__(self, cap=1024, ttl=300): self.cap, self.ttl, self.d = cap, ttl, OrderedDict()
    @staticmethod
    def pkey(p): return json.dumps(p, sort_keys=True)
    def get(self, p, q):
        k = (self.pkey(p), q); v = self.d.get(k)
        if not v: return None
        if time.time() - v[0] > self.ttl: del self.d[k]; return None
        self.d.move_to_end(k); return v[1]
    def put(self, p, q, res):
        self.d[(self.pkey(p), q)] = (time.time(), res)
        while len(self.d) > self.cap: self.d.popitem(last=False)
    def invalidate_id(self, id_):
        for k in [k for k, v in self.d.items() if any(r[0] == id_ for r in v[1]["rows"])]: del self.d[k]
    def invalidate_principal(self, p):
        pk = self.pkey(p)
        for k in [k for k in self.d if k[0] == pk]: del self.d[k]

def cmd_bench(n):
    d = tempfile.mkdtemp(); c = connect(d + "/b.db"); migrate(c)
    words = ["сервер", "память", "модель", "кэш", "ядро", "поток", "файл", "сеть", "диск", "токен", "запрос", "ответ", "журнал", "задача", "узел"]
    rows = [("b%d" % i, LEVELS[i % 8], "project", "p%d" % (i % 5), " ".join(words[(i * j + j) % 15] for j in range(1, 9)) + " зап%d" % i,
             "", hashlib.sha256(str(i).encode()).hexdigest(), 0, "2026-01-01T00:00:00Z") for i in range(n)]
    c.executemany("INSERT INTO nox_mem VALUES(?,?,?,?,?,?,?,?,?)", rows); c.commit()
    p = {"projects": ["p1", "p2"]}; ts = []
    for i in range(200):
        q = "сервер память" if i % 2 else "сервер память зап%d" % (i * 7 % n)
        t = time.perf_counter(); search(c, q, p); ts.append((time.perf_counter() - t) * 1000)
    ts.sort(); wc = WarmCache(); search(c, "сервер", p)
    r = search(c, "сервер", p); wc.put(p, "сервер", r); hit1 = wc.get(p, "сервер") is not None
    wc.invalidate_principal(p); hit2 = wc.get(p, "сервер") is not None
    wc.put(p, "сервер", r); wc.invalidate_id(r["rows"][0][0]) if r["rows"] else None; hit3 = wc.get(p, "сервер") is not None
    print(json.dumps({"records": n, "search_p50_ms": round(ts[len(ts) // 2], 2), "search_p95_ms": round(ts[int(len(ts) * .95) - 1], 2),
                      "cache_hit": hit1, "after_principal_invalidate": hit2, "after_revoke_invalidate": hit3}))

def cmd_evidence(db):
    c = connect(db); migrate(c); ids = []
    try:
        for i, (scope, ref) in enumerate([("persona", "pA"), ("persona", "pB"), ("project", "prX"), ("owner", "")]):
            id_ = "__nox_test_%d" % i; ids.append(id_); add(c, id_, "M2", scope, ref, "уникальноеслово%d секрет" % i, "test")
        c.commit()
        pa = {"persona": "pA"}
        a = search(c, "уникальноеслово0", pa); b = search(c, "уникальноеслово1", pa); o = search(c, "уникальноеслово3", pa); none = search(c, "несуществующеесловоxyz", pa)
        wc = WarmCache(); wc.put(pa, "q", a); revoke(c, "__nox_test_0"); wc.invalidate_id("__nox_test_0"); after = search(c, "уникальноеслово0", pa)
        res = {"own_persona_read": a["status"] == "FOUND", "foreign_persona_blocked": b["status"] == "NO_EVIDENCE",
               "owner_scope_blocked_for_persona": o["status"] == "NO_EVIDENCE", "empty_is_not_negative_fact": none["status"] == "NO_EVIDENCE" and none["rows"] == [],
               "revoked_hidden": after["status"] == "NO_EVIDENCE", "cache_invalidated_on_revoke": wc.get(pa, "q") is None,
               "fact_sha_present": bool(a["rows"] and a["rows"][0][3])}
    finally:
        for i in ids: c.execute("DELETE FROM nox_mem WHERE id=?", (i,))
        c.commit()
    print(json.dumps(res)); sys.exit(0 if all(res.values()) else 1)

def cmd_selftest_ref(db):
    c = connect(db); migrate(c); tid = "__nox_test_ref"
    try:
        add(c, tid, "M1", "owner", "", "проверочная запись", "test"); c.commit()
        res = {"existing_id_passes": check_refs(c, "Факт [m:%s]." % tid)[0], "fake_id_blocked": not check_refs(c, "Факт [m:не-существует-123].")[0],
               "no_ref_blocked": not check_refs(c, "Факт без ссылки.", True)[0], "no_ref_allowed_when_not_required": check_refs(c, "Болтовня.", False)[0]}
    finally:
        c.execute("DELETE FROM nox_mem WHERE id=?", (tid,)); c.commit()
    print(json.dumps(res)); sys.exit(0 if all(res.values()) else 1)

if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "migrate": c = connect(sys.argv[2]); migrate(c); print("ok")
    elif cmd == "integrity":
        c = connect(sys.argv[2]); r = c.execute("PRAGMA integrity_check").fetchone()[0]; print(r); sys.exit(0 if r == "ok" else 1)
    elif cmd == "check-ref":
        c = connect(sys.argv[2]); ok, miss = check_refs(c, sys.stdin.read(), "--require" in sys.argv)
        print(json.dumps({"ok": ok, "missing": miss}, ensure_ascii=False)); sys.exit(0 if ok else 1)
    elif cmd == "sql":      # sql DB "запрос": печатает первый столбец строк результата, коммитит
        c = connect(sys.argv[2])
        for r in c.execute(sys.argv[3]).fetchall(): print(r[0])
        c.commit()
    elif cmd == "backup":   # backup DB DEST: консистентная копия через sqlite3 backup API
        s = sqlite3.connect(sys.argv[2]); d = sqlite3.connect(sys.argv[3]); s.backup(d); d.close(); s.close()
    elif cmd == "selftest-ref": cmd_selftest_ref(sys.argv[2])
    elif cmd == "bench-fts": cmd_bench(int(sys.argv[2]) if len(sys.argv) > 2 else 100000)
    elif cmd == "evidence-test": cmd_evidence(sys.argv[2])
