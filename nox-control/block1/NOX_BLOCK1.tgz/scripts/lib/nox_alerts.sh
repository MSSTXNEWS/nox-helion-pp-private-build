#!/usr/bin/env bash
# nox_alerts.sh - предупреждения баланса Vast и простоя GPU. Запускать по таймеру каждые 15 мин.
# Красное событие -> $NOX_ROOT/events/red.jsonl (подхватывается лентой и пушем).
#   NOX_BAL_FILE: если задан, баланс читается из файла (число $), иначе `vastai show user --raw`.
. "$(dirname "$0")/nox_common.sh"
bal=""
if [ -n "${NOX_BAL_FILE:-}" ] && [ -r "$NOX_BAL_FILE" ]; then bal="$(cat "$NOX_BAL_FILE")"
elif command -v vastai >/dev/null 2>&1; then bal="$(vastai show user --raw 2>/dev/null | python3 -I -c 'import json,sys;print(json.load(sys.stdin).get("credit",""))' 2>/dev/null || true)"; fi
if [ -n "$bal" ]; then
  min="${NOX_BAL_MIN_USD:-15}"
  awk -v b="$bal" -v m="$min" 'BEGIN{exit !(b+0<m+0)}' && nox_red_event "баланс Vast \$$bal < порога \$$min: пополнить, иначе остановятся серверы"
else nox_log WARN "баланс недоступен (нет vastai/ключа или NOX_BAL_FILE)"; fi
# простой: загрузка GPU < NOX_IDLE_UTIL% подряд NOX_IDLE_MIN минут при отсутствии STOP
if command -v nvidia-smi >/dev/null 2>&1 || [ -n "${NOX_UTIL_FILE:-}" ]; then
  u="$( [ -n "${NOX_UTIL_FILE:-}" ] && cat "$NOX_UTIL_FILE" || nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits | sort -n | tail -1 | tr -d ' ')"
  st="$NOX_RUN_DIR/idle_since"; mkdir -p "$NOX_RUN_DIR"
  if awk -v u="$u" -v t="${NOX_IDLE_UTIL:-5}" 'BEGIN{exit !(u+0<t+0)}' && [ ! -e "$NOX_STOP_FLAG" ]; then
    [ -e "$st" ] || date +%s >"$st"
    mins=$(( ( $(date +%s) - $(cat "$st") ) / 60 ))
    [ "$mins" -ge "${NOX_IDLE_MIN:-30}" ] && nox_red_event "простой GPU: загрузка ${u}% уже ${mins} мин (деньги тратятся впустую)"
  else rm -f "${st:?}"; fi
fi
