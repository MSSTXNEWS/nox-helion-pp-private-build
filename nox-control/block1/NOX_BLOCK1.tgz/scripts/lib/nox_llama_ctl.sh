#!/usr/bin/env bash
# Управление llama-server главной модели (подключается после nox_common.sh). Аргументы хранятся по одному на строку в run/llama.args.
# Функции: llama_args_load, llama_flag_set FLAG [VALUE], llama_flag_del FLAG [1=есть значение], llama_args_save, llama_conf_write [ENV...],
#          llama_stop, llama_start [ENV...], llama_restart [ENV...].
LLAMA_ARGS_FILE="$NOX_RUN_DIR/llama.args"; LLAMA_SVCLOG="$NOX_LOG_DIR/llama.service.log"; LLAMA_WDST="$NOX_RUN_DIR/wd"
llama_args_load() { mapfile -t LLAMA_ARGS <"$LLAMA_ARGS_FILE"; }
llama_args_save() { printf '%s\n' "${LLAMA_ARGS[@]}" >"$LLAMA_ARGS_FILE"; }
llama_flag_del() { local i out=() skip=0 a; for a in "${LLAMA_ARGS[@]}"; do
  if [ "$skip" = 1 ]; then skip=0; continue; fi; if [ "$a" = "$1" ]; then [ "${2:-0}" = 1 ] && skip=1; continue; fi; out+=("$a"); done; LLAMA_ARGS=("${out[@]}"); }
llama_flag_set() { local i; for i in "${!LLAMA_ARGS[@]}"; do if [ "${LLAMA_ARGS[$i]}" = "$1" ]; then LLAMA_ARGS[$((i+1))]="${2:-}"; return 0; fi; done
  LLAMA_ARGS+=("$1"); [ $# -ge 2 ] && LLAMA_ARGS+=("$2"); return 0; }
llama_conf_write() { # ENV-пары (VAR=val) в начало команды
  local cmd; cmd="$(printf '%q ' env "$@" "$NOX_LIB_DIR/nox_llama_launch.sh" "${LLAMA_ARGS[@]}")"
  mkdir -p "$NOX_ROOT/services.d"
  { printf 'NAME=llama\nORDER=10\n'; printf 'CMD=%q\n' "$cmd"; printf 'HEALTH_URL=%s\nMAX_RESTARTS=3\nWINDOW_S=1800\nGRACE_S=%s\n' "$NOX_LLAMA_URL" "${NOX_LLAMA_START_TIMEOUT:-1800}"; } >"$NOX_ROOT/services.d/llama.conf"; }
llama_stop() { local p; p="$(nox_llama_pid)"; [ -z "$p" ] && return 0
  kill -TERM "$p" 2>/dev/null || true; local t=0; while kill -0 "$p" 2>/dev/null && [ $t -lt 120 ]; do sleep 2; t=$((t+2)); done; kill -KILL "$p" 2>/dev/null || true; rm -f "$LLAMA_WDST/llama.pid"; }
llama_start() { mkdir -p "$LLAMA_WDST"
  setsid nohup env "$@" "$NOX_LIB_DIR/nox_llama_launch.sh" "${LLAMA_ARGS[@]}" >>"$LLAMA_SVCLOG" 2>&1 & echo $! >"$LLAMA_WDST/llama.pid"; date +%s >"$LLAMA_WDST/llama.started"
  nox_wait_health "$NOX_LLAMA_URL" "${NOX_LLAMA_START_TIMEOUT:-1800}"; }
llama_restart() { llama_stop; llama_start "$@"; }
llama_n_layer() { grep -h -o 'n_layer *= *[0-9]*' "$LLAMA_SVCLOG" 2>/dev/null | tail -1 | grep -o '[0-9]*$'; }
