#!/usr/bin/env bash
# Агент универсального STOP (9.1). Следит за файлом-флагом $NOX_STOP_FLAG раз в секунду.
# Политика сервиса задаётся в его conf ($NOX_WD_CONF_DIR/*.conf) переменной STOP_POLICY:
#   stop  - SIGTERM (затем SIGKILL через 5 с): черви, обучение, диспетчер, FORGE (watchdog не рестартует при STOP);
#   freeze - SIGSTOP с замком паузы $NOX_PAUSE_DIR/<pid>.lock (9.7 п.3), при снятии флага SIGCONT и снятие замка;
#   keep (по умолчанию) - не трогать (чат/главная модель не замораживается никогда; остановка текущей генерации - дело клиента стрима через nox_stop_gate/проверку флага).
# Недоступный/сломанный флаг трактуется как STOP (fail-closed): если каталог флага недоступен.
set -uo pipefail
. "$(dirname "$0")/nox_common.sh"
CONF="${NOX_WD_CONF_DIR:-$NOX_ROOT/services.d}"; ST="${NOX_WD_STATE:-$NOX_RUN_DIR/wd}"; mkdir -p "$ST" "$NOX_PAUSE_DIR" 2>/dev/null
echo $$ >"$ST/stop_agent.pid"; prev=0
flag_active() { [ -e "$NOX_STOP_FLAG" ] && return 0; [ -d "$(dirname "$NOX_STOP_FLAG")" ] && [ -r "$(dirname "$NOX_STOP_FLAG")" ] || return 0; return 1; }
each() { local c; for c in "$CONF"/*.conf; do [ -e "$c" ] || continue; ( NAME=""; STOP_POLICY=keep; . "$c"; pid="$(cat "$ST/$NAME.pid" 2>/dev/null || true)"; "$1" "$NAME" "$STOP_POLICY" "$pid" ); done; }
on_stop() { [ -n "$3" ] && kill -0 "$3" 2>/dev/null || return 0
  case "$2" in
    stop) kill -TERM "$3"; ( sleep 5; kill -KILL "$3" 2>/dev/null ) & ;;
    freeze) NOX_ID=stop_agent nox_pause_lock "$3" "STOP" "$(( $(date +%s) + 86400 ))"; kill -STOP "$3";;
  esac; }
on_resume() { [ -n "$3" ] && kill -0 "$3" 2>/dev/null || return 0
  [ "$2" = freeze ] && { kill -CONT "$3"; nox_pause_unlock "$3"; }; return 0; }
while :; do
  if flag_active; then cur=1; else cur=0; fi
  if [ "$cur" != "$prev" ]; then
    if [ "$cur" = 1 ]; then nox_log INFO "STOP: применяю политики"; each on_stop; else nox_log INFO "STOP снят: резюме"; each on_resume; fi
    prev=$cur
  fi
  sleep 1
done
