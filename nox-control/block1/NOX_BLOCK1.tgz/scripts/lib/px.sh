#!/bin/bash
# px: диспетчер дополнительных режимов из архива; подрежим в /root/nox/scripts/PX_MODE
M="$(tr -d '[:space:]' < /root/nox/scripts/PX_MODE)"; echo "PX=$M"
case "$M" in
  viol) ps -eo pid,etimes,args | grep -E 'llama-server|llama-cli' | grep -v grep | sed -E 's#(/[A-Za-z0-9_.-]+)+/##g' | grep -oE '^ *[0-9]+ +[0-9]+|--no-mmap|--mlock|(-ctk|-ctv|--cache-type-[kv]) +[a-z0-9_]+|--port +[0-9]+|llama-server' | tr '\n' ' ' | cut -c1-900; echo;;
  detail) python3 -I - <<'PY'
import json
s=json.load(open('/root/nox/state/PARETO_STATUS.json'))
for k,v in sorted(s.items()):
    if k[:3] in('D02','D03','D04','D05') and v['status'] in('BLOCKED','FAIL','WAIT_FLASH'): print(k,v['status'],v['script'],v['reason'][:100])
PY
  ;;
  *) echo "unknown px $M";;
esac
