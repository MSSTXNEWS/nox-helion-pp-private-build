#!/bin/bash
# px: диспетчер дополнительных режимов из архива; подрежим в /root/nox/scripts/PX_MODE
M="$(tr -d '[:space:]' < /root/nox/scripts/PX_MODE)"; echo "PX=$M"
case "$M" in
  viol) ps -eo pid,etimes,args | grep -E 'llama-server|llama-cli' | grep -v grep | sed -E 's#(/[A-Za-z0-9_.-]+)+/##g' | grep -oE '^ *[0-9]+ +[0-9]+|--no-mmap|--mlock|(-ctk|-ctv|--cache-type-[kv]) +[a-z0-9_]+|--port +[0-9]+|llama-server' | tr '\n' ' ' | cut -c1-900; echo;;
  detail) python3 -I - <<'PY'
import json
s=json.load(open('/root/nox/state/PARETO_STATUS.json'))
for k,v in sorted(s.items()):
    if k[:3] in('D02','D03','D04','D05') and v['status'] in('BLOCKED','FAIL','WAIT_FLASH'): print(k,v['status'],v['script'],v['reason'][:100])
PY
  ;;
  p401) cd /root/nox/scripts; grep -q '^NOX_S03_DB=' /root/nox/nox.env || echo 'NOX_S03_DB=/root/nox/memory/s03.db' >> /root/nox/nox.env
    python3 -I - <<'PY'
import sqlite3,shutil,hashlib,os,json,subprocess,time
D='/root/nox/memory/s03.db'; B='/root/nox/backup_s03_pre_p401'; os.makedirs(B,exist_ok=True); BK=B+'/s03.db'
def counts(path):
    c=sqlite3.connect('file:'+path+'?mode=ro',uri=True,timeout=20)
    tb=[r[0] for r in c.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    out={}
    for t in tb:
        try: out[t]=c.execute('select count(*) from "%s"'%t).fetchone()[0]
        except Exception: pass
    ic=c.execute('pragma integrity_check').fetchone()[0]; c.close(); return out,ic
s=sqlite3.connect(D,timeout=30); d=sqlite3.connect(BK); s.backup(d); d.close(); s.close()
sha=hashlib.sha256(open(BK,'rb').read()).hexdigest(); open(B+'/s03.db.sha256','w').write(sha+'\n')
b,ic0=counts(BK); print('backup ok sha',sha[:12],'integrity',ic0,'rows',sum(b.values()))
r=subprocess.run(['python3','-B','/root/nox/scripts/lib/nox_s03.py','migrate',D],capture_output=True,text=True,timeout=120); print('migrate rc',r.returncode,(r.stdout+r.stderr)[-150:])
a,ic1=counts(D); lost=[t for t in b if a.get(t,0)<b[t]]
print('after integrity',ic1,'rows',sum(a.values()),'new tables',[t for t in a if t not in b][:6],'lost',lost)
ok=r.returncode==0 and ic1=='ok' and not lost and sum(a.values())>=603385
if ok:
    for x in ('/tmp/m.tsv','/tmp/i.tsv'): open(x,'w').close()
    subprocess.run(['python3','-I','/root/nox/scripts/lib/nox_receipt.py','--id','P4-01','--result','PASS','--reason','S03 копия с S2 (integrity ok, строки сохранены) + аддитивная миграция nox_mem; ssh на S2 и API-слой не выполнялись','--need','','--mode','satisfied_by_copy','--server','S1','--metrics','/tmp/m.tsv','--inputs','/tmp/i.tsv','--log','/dev/null','--elapsed','1','--out','/root/nox/receipts/P4-01.json'])
    print('P4-01 receipt PASS')
else:
    shutil.copy(BK,'/root/nox/memory/s03.db.restore_tmp'); os.replace('/root/nox/memory/s03.db.restore_tmp',D); print('ROLLBACK from copy; BLOCKED')
PY
    PARETO_ONLY=D05 python3 -I lib/pareto_run.py 2>&1 | grep -E "^D05-0[1-7]"; python3 -I lib/pareto_run.py summary | sed -n '1p;6p';;
  prot2) cd /root/nox/scripts; E=/root/nox/nox.env; [ -f $E.pre_pareto ] || cp -p $E $E.pre_pareto
    P=""; for x in /root/nox/models /root/nox/state/MODEL_SWAP /root/nox/receipts /root/nox/backup_s2 /root/nox/memory/*.bak* /root/nox/memory/*.bak_* /root/nox/repo/nox-control/qs6/soul_prompt_ru.txt /root/nox/repo/nox-control/genome/rules; do [ -e "$x" ] && P="$P $x"; done
    echo "protect: $(echo $P | wc -w) путей"; sed -i '/^NOX_PROTECT_PATHS=/d;/^NOX_SNAPSHOT_PATHS=/d' $E; printf 'NOX_PROTECT_PATHS="%s"\nNOX_SNAPSHOT_PATHS="/root/nox/memory/s03.db /root/nox/config"\n' "$(echo $P)" >> $E
    stat -c '%a %U %n' $P > /root/nox/state/protect_perms_before.txt 2>/dev/null
    printf '#!/bin/bash\ncp -p %s.pre_pareto %s\nwhile read m u f; do chmod $m "$f"; done < /root/nox/state/protect_perms_before.txt\n' $E $E > /root/nox/state/protect_rollback.sh; chmod +x /root/nox/state/protect_rollback.sh
    NOX_SERVER=S1 bash P1-11_*.sh --dry-run 2>&1 | tail -n 2 | cut -c1-180
    if NOX_SERVER=S1 bash P1-11_*.sh --dry-run >/dev/null 2>&1; then NOX_SERVER=S1 timeout 250 bash P1-11_*.sh 2>&1 | tail -n 3 | cut -c1-200; else echo "dry-run не прошёл, откат nox.env"; /root/nox/state/protect_rollback.sh; fi
    for d in D15 D03 D05; do PARETO_ONLY=$d python3 -I lib/pareto_run.py 2>&1 | grep -E "D15-04|D03-01|D05-0[1-7]"; done; python3 -I lib/pareto_run.py summary | tail -n 16;;
  run2) cd /root/nox/scripts; NOX_SERVER=S1 timeout 280 bash P1-11_*.sh 2>&1 | tail -n 4 | cut -c1-200; PARETO_ONLY='D15' python3 -I lib/pareto_run.py >/dev/null 2>&1; PARETO_ONLY='D03 D05' python3 -I lib/pareto_run.py 2>&1 | grep -E 'D03-01|D05-0[1-4]'; python3 -I lib/pareto_run.py summary | tail -n 16;;
  run) NOX_ROOT=/root/nox nice -n 19 python3 -I /root/nox/scripts/lib/pareto_run.py 2>&1 | tail -n 18;;
  *) echo "unknown px $M";;
esac
