#!/usr/bin/env python3
"""Исполнитель сценариев приёмки (JSON). Использование: nox_scenario.py FILE --base URL --require tag1,tag2,...
Сценарий: {"id": "...", "sha_paths": ["путь",...], "steps": [шаг,...]}. Шаг HTTP: {"tag","name","method","path","headers":{},"json":{},"expect_status":200,
 "expect_contains":"текст","expect_regex":"...","expect_json":{"a.b":значение | {"gte":n}|{"lte":n}|{"regex":"..."}|{"contains":"..."}},
 "save":{"var":"a.b"},"save_regex":{"var":"regex с группой"},"stream":true,"abort_after_bytes":N,"timeout":60}.
 Шаг shell: {"tag","name","shell":"команда","expect_rc":0,"expect_contains":"..."}; шаг {"sleep":секунды}.
 Подстановки: {{var}} (сохранённое), {{env:NAME}}. PASS = все требуемые теги присутствуют, все шаги прошли, SHA файлов sha_paths в начале и конце совпал.
Печатает JSON-итог; код 0 только при PASS."""
import argparse, hashlib, json, os, re, subprocess, sys, time, urllib.request, urllib.error

def sha_tree(paths):
    h = hashlib.sha256()
    for p in paths:
        if os.path.isdir(p):
            for r, _, fs in sorted(os.walk(p)):
                for f in sorted(fs):
                    try: h.update(open(os.path.join(r, f), "rb").read())
                    except OSError: continue
        elif os.path.exists(p):
            h.update(open(p, "rb").read())
    return h.hexdigest()

def sub(s, vars_):
    if isinstance(s, str):
        s = re.sub(r"\{\{env:([A-Za-z0-9_]+)\}\}", lambda m: os.environ.get(m.group(1), ""), s)
        return re.sub(r"\{\{([A-Za-z0-9_]+)\}\}", lambda m: str(vars_.get(m.group(1), m.group(0))), s)
    if isinstance(s, dict): return {k: sub(v, vars_) for k, v in s.items()}
    if isinstance(s, list): return [sub(v, vars_) for v in s]
    return s

def dig(obj, path):
    for k in path.split("."):
        obj = obj[int(k)] if isinstance(obj, list) else obj[k]
    return obj

def match(val, exp):
    if isinstance(exp, dict):
        if "gte" in exp: return val >= exp["gte"]
        if "lte" in exp: return val <= exp["lte"]
        if "regex" in exp: return re.search(exp["regex"], str(val)) is not None
        if "contains" in exp: return exp["contains"] in str(val)
        return False
    return val == exp

def run_step(st, base, vars_):
    st = sub(st, vars_)
    if "sleep" in st: time.sleep(st["sleep"]); return True, "sleep"
    if "shell" in st:
        r = subprocess.run(st["shell"], shell=True, capture_output=True, text=True, timeout=st.get("timeout", 300))
        ok = r.returncode == st.get("expect_rc", 0) and st.get("expect_contains", "") in (r.stdout + r.stderr)
        return ok, "rc=%d %s" % (r.returncode, (r.stdout + r.stderr)[-200:])
    data = json.dumps(st["json"]).encode() if "json" in st else None
    req = urllib.request.Request(base + st["path"], data=data, method=st.get("method", "GET"), headers=dict({"Content-Type": "application/json"} if data else {}, **st.get("headers", {})))
    try:
        resp = urllib.request.urlopen(req, timeout=st.get("timeout", 60)); code = resp.status
    except urllib.error.HTTPError as e:
        resp, code = e, e.code
    if st.get("abort_after_bytes"):
        body = resp.read(st["abort_after_bytes"]).decode("utf-8", "replace"); resp.close()
    else:
        body = resp.read().decode("utf-8", "replace")
    ok = code == st.get("expect_status", 200)
    if "expect_contains" in st: ok &= st["expect_contains"] in body
    if "expect_regex" in st: ok &= re.search(st["expect_regex"], body) is not None
    js = None
    if st.get("expect_json") or st.get("save"):
        try: js = json.loads(body)
        except json.JSONDecodeError: ok = False
    for p, exp in (st.get("expect_json") or {}).items():
        try: ok &= match(dig(js, p), exp)
        except (KeyError, IndexError, TypeError): ok = False
    for var, p in (st.get("save") or {}).items():
        try: vars_[var] = dig(js, p)
        except (KeyError, IndexError, TypeError, ValueError): ok = False
    for var, rx in (st.get("save_regex") or {}).items():
        m = re.search(rx, body)
        if m: vars_[var] = m.group(1)
        else: ok = False
    return ok, "http %d %s" % (code, body[:150].replace("\n", " "))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--base", required=True); ap.add_argument("--require", required=True)
    a = ap.parse_args(); sc = json.load(open(a.file, encoding="utf-8")); vars_ = {}; res = []
    s0 = sha_tree(sc.get("sha_paths", []))
    for st in sc["steps"]:
        try: ok, info = run_step(st, a.base, vars_)
        except Exception as e: ok, info = False, "исключение: %s" % e
        res.append({"tag": st.get("tag"), "name": st.get("name"), "ok": bool(ok), "info": info})
    s1 = sha_tree(sc.get("sha_paths", []))
    need = [t for t in a.require.split(",") if t]; have = {r["tag"] for r in res if r["tag"]}
    missing = [t for t in need if t not in have]; failed = [r["tag"] or r["name"] for r in res if not r["ok"]]
    out = {"missing_tags": missing, "failed": failed, "sha_stable": s0 == s1, "sha": s0, "steps": res}
    print(json.dumps(out, ensure_ascii=False)); sys.exit(0 if (not missing and not failed and s0 == s1) else 1)
