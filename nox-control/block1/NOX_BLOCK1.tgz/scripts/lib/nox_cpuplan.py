#!/usr/bin/env python3
"""Строит cpu_plan.json из lscpu -p: -t = физ.ядра-2, -tb = vCPU; чату - по одному потоку на (физ-2) ядер, быстрому тиру - оба потока двух последних ядер."""
import json, subprocess, sys
rows = [l.split(",") for l in subprocess.check_output(["lscpu", "-p=CPU,CORE,SOCKET"], text=True).splitlines() if not l.startswith("#")]
cores = {}
for cpu, core, sock in rows:
    cores.setdefault((sock, core), []).append(int(cpu))
keys = sorted(cores, key=lambda k: (int(k[0]), int(k[1])))
phys, vcpu = len(keys), len(rows)
t = max(1, phys - 2)
chat = [cores[k][0] for k in keys[:t]]
fast = [c for k in keys[t:] for c in cores[k]]
plan = {"phys_cores": phys, "vcpu": vcpu, "t": t, "tb": vcpu, "chat_cpus": ",".join(map(str, chat)),
        "chat_cpus_with_ht": ",".join(str(c) for k in keys[:t] for c in cores[k]), "fast_cpus": ",".join(map(str, fast))}
json.dump(plan, open(sys.argv[1], "w"), indent=1)
print(json.dumps(plan))
