#!/usr/bin/env python3
"""PV-06: одинаковые задания на GLM (S1, effort high) и DeepSeek (S2): время до первого содержательного текста, ток/с, качество (регулярка/вызов инструмента)."""
import argparse, csv, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nox_llm as L

def run_task(url, t, max_tokens, extra):
    if t.get("tools"):
        r = L.chat_sync(url, t["messages"], max_tokens, dict({"tools": t["tools"], "tool_choice": "auto"}, **extra))
        msg = r["choices"][0]["message"]; calls = [c["function"]["name"] for c in (msg.get("tool_calls") or [])]
        tm = r.get("timings") or {}
        return {"ok": t["tool_name"] in calls, "t_content": None, "tps": tm.get("predicted_per_second"), "total": None, "answer": ",".join(calls)}
    r = L.chat(url, t["messages"], max_tokens, extra)
    u = r["usage"] or {}; gen = u.get("completion_tokens"); span = (r["total"] - (r["ttft"] or 0)) or None
    return {"ok": bool(re.search(t["rx"], r["content"])), "t_content": r["t_content"], "tps": (gen / span) if gen and span else None,
            "total": r["total"], "answer": r["content"][:60].replace("\n", " ")}

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--glm", required=True); ap.add_argument("--ds", required=True); ap.add_argument("--tasks", required=True)
    ap.add_argument("--max-tokens", type=int, required=True); ap.add_argument("--out-csv", required=True); ap.add_argument("--out-json", required=True)
    a = ap.parse_args(); tasks = [json.loads(l) for l in open(a.tasks, encoding="utf-8") if l.strip()]; rows = []
    for t in tasks:
        for name, url, ex in (("GLM-5.3", a.glm, {"temperature": 1.0, "chat_template_kwargs": {"reasoning_effort": "high", "clear_thinking": True}}),
                              ("DeepSeek", a.ds, {"temperature": 0.6})):
            try: r = run_task(url, t, a.max_tokens, ex); r["error"] = ""
            except Exception as e: r = {"ok": False, "t_content": None, "tps": None, "total": None, "answer": "", "error": str(e)[:100]}
            rows.append(dict(task=t["id"], category=t["category"], model=name, **r)); print(json.dumps(rows[-1], ensure_ascii=False), flush=True)
    with open(a.out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    summ = {}
    for m in ("GLM-5.3", "DeepSeek"):
        rr = [r for r in rows if r["model"] == m]
        summ[m] = {"quality": sum(r["ok"] for r in rr), "of": len(rr), "errors": sum(1 for r in rr if r["error"]),
                   "t_content_p50": L.pct([r["t_content"] for r in rr], .5), "t_content_p95": L.pct([r["t_content"] for r in rr], .95),
                   "tps_p50": L.pct([r["tps"] for r in rr], .5)}
    json.dump(summ, open(a.out_json, "w"), ensure_ascii=False, indent=1); print(json.dumps(summ, ensure_ascii=False))
