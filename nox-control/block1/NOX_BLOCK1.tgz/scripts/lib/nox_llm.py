#!/usr/bin/env python3
"""HTTP-клиент llama-server (OpenAI-совместимый) для замеров NOX. Только stdlib.
Подкоманды: chat, completion, bench, tokenize, fill, slot, ceiling.
Все цифры берутся из ответа сервера (timings) или из часов клиента; ничего не выдумывается."""
import argparse, csv, json, math, sys, time, urllib.request, urllib.error

def _req(url, payload=None, timeout=3600, method=None):
    data = None if payload is None else json.dumps(payload).encode()
    r = urllib.request.Request(url, data=data, method=method or ("POST" if data is not None else "GET"),
                               headers={"Content-Type": "application/json"})
    return urllib.request.urlopen(r, timeout=timeout)

def post_json(url, payload, timeout=3600):
    with _req(url, payload, timeout) as r:
        return json.loads(r.read().decode())

def get_json(url, timeout=30):
    with _req(url, None, timeout) as r:
        return json.loads(r.read().decode())

def sse(url, payload, timeout=3600):
    payload = dict(payload, stream=True)
    with _req(url, payload, timeout) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith("data:"):
                body = line[5:].strip()
                if body == "[DONE]":
                    return
                try:
                    yield json.loads(body)
                except json.JSONDecodeError:
                    continue

def chat(base, messages, max_tokens=256, extra=None, timeout=3600):
    """Стрим /v1/chat/completions. Возвращает метрики: ttft (первый любой токен), t_content (первый токен ответа после размышлений)."""
    payload = {"messages": messages, "max_tokens": max_tokens, "stream_options": {"include_usage": True}}
    payload.update(extra or {})
    t0 = time.time(); ttft = t_content = None
    content, reasoning, last, finish = [], [], {}, None
    for ch in sse(base + "/v1/chat/completions", payload, timeout):
        last = ch
        for c in ch.get("choices", []):
            d = c.get("delta", {}) or {}
            rc = d.get("reasoning_content") or d.get("reasoning")
            if rc:
                reasoning.append(rc); ttft = ttft or time.time() - t0
            if d.get("content"):
                content.append(d["content"]); ttft = ttft or time.time() - t0; t_content = t_content or time.time() - t0
            if d.get("tool_calls"):
                ttft = ttft or time.time() - t0; t_content = t_content or time.time() - t0
                content.append(json.dumps(d["tool_calls"], ensure_ascii=False))
            finish = c.get("finish_reason") or finish
    total = time.time() - t0
    return {"ttft": ttft, "t_content": t_content, "total": total, "content": "".join(content),
            "reasoning": "".join(reasoning), "usage": last.get("usage") or {}, "timings": last.get("timings") or {}, "finish": finish}

def completion(base, prompt, n_predict=64, extra=None, timeout=3600):
    payload = {"prompt": prompt, "n_predict": n_predict}
    payload.update(extra or {})
    t0 = time.time(); ttft = None; text = []; last = {}
    for ch in sse(base + "/completion", payload, timeout):
        if ch.get("content") and ttft is None:
            ttft = time.time() - t0
        text.append(ch.get("content", "")); last = ch
    tm = last.get("timings") or {}
    return {"ttft": ttft, "total": time.time() - t0, "timings": tm, "text": "".join(text),
            "tokens_cached": last.get("tokens_cached"), "tokens_evaluated": last.get("tokens_evaluated")}

def chat_sync(base, messages, max_tokens=1, extra=None, timeout=3600):
    """Нестриминговый /v1/chat/completions: возвращает JSON целиком (timings: prompt_n, cache_n, predicted_per_second)."""
    payload = {"messages": messages, "max_tokens": max_tokens, "stream": False}
    payload.update(extra or {})
    return post_json(base + "/v1/chat/completions", payload, timeout)

def hit_ratio(resp):
    tm = resp.get("timings") or {}
    if "cache_n" not in tm or "prompt_n" not in tm:
        return None
    tot = tm["cache_n"] + tm["prompt_n"]
    return tm["cache_n"] / tot if tot else None

def tokenize(base, text):
    return len(post_json(base + "/tokenize", {"content": text})["tokens"])

def fill(base, n_tokens, seed_text=None):
    unit = seed_text or "Рассмотрим журнал событий сервера: узел принял запрос, записал факт в память и вернул подтверждение. "
    text = unit
    while tokenize(base, text) < n_tokens:
        text += unit * max(1, n_tokens // 40)
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi) // 2
        if tokenize(base, text[:mid]) < n_tokens: lo = mid + 1
        else: hi = mid
    return text[:lo]

def pct(vals, p):
    v = sorted(x for x in vals if x is not None)
    if not v: return None
    return v[max(0, math.ceil(p * len(v)) - 1)]

BENCH_PROMPTS = [
    ("short_en", "Explain in three sentences how a hash table handles collisions."),
    ("ru", "Объясни простыми словами, чем отличается процесс от потока в операционной системе, и приведи пример."),
    ("code", "Write a Python function that merges overlapping intervals and add three unit tests."),
]

def bench(base, repeats, out_csv, n_predict, ctx_tokens, long_tokens, only=None):
    only = set(only.split(",")) if only else None
    items = [x for x in BENCH_PROMPTS if not only or x[0] in only]
    if not only or ("ctx%d" % ctx_tokens) in only:
        items.append(("ctx%d" % ctx_tokens, fill(base, ctx_tokens) + "\nКратко: о чём этот журнал?"))
    if not only or ("long%d" % long_tokens) in only:
        items.append(("long%d" % long_tokens, fill(base, long_tokens) + "\nКратко: о чём этот журнал?"))
    rows = []
    for pid, text in items:
        for rep in range(repeats):
            r = completion(base, text, n_predict, {"cache_prompt": False, "temperature": 0, "seed": 1})
            tm = r["timings"]
            rows.append({"prompt": pid, "rep": rep, "prompt_n": tm.get("prompt_n"), "prompt_ms": tm.get("prompt_ms"),
                         "prefill_tps": tm.get("prompt_per_second"), "decode_n": tm.get("predicted_n"),
                         "decode_tps": tm.get("predicted_per_second"), "ttft_s": r["ttft"], "total_s": r["total"]})
    with open(out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    dec = [r["decode_tps"] for r in rows]; pre = [r["prefill_tps"] for r in rows if (r["prompt_n"] or 0) > 200]
    ttf = [r["ttft_s"] for r in rows]
    return {"decode_tps_p50": pct(dec, .5), "decode_tps_p05": pct(dec, .05), "prefill_tps_p50": pct(pre, .5),
            "ttft_s_p50": pct(ttf, .5), "ttft_s_p95": pct(ttf, .95), "rows": len(rows), "csv": out_csv}

def main():
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="cmd", required=True)
    c = sp.add_parser("chat"); c.add_argument("--url", required=True); c.add_argument("--prompt", required=True)
    c.add_argument("--max-tokens", type=int, default=256); c.add_argument("--extra", default="{}")
    k = sp.add_parser("completion"); k.add_argument("--url", required=True); k.add_argument("--prompt", required=True)
    k.add_argument("--n", type=int, default=64); k.add_argument("--extra", default="{}")
    b = sp.add_parser("bench"); b.add_argument("--url", required=True); b.add_argument("--out", required=True)
    b.add_argument("--repeats", type=int, default=3); b.add_argument("--n", type=int, default=128)
    b.add_argument("--only", default=""); b.add_argument("--ctx", type=int, default=1000); b.add_argument("--long", type=int, default=5000)
    t = sp.add_parser("tokenize"); t.add_argument("--url", required=True); t.add_argument("--file", required=True)
    s = sp.add_parser("slot"); s.add_argument("--url", required=True); s.add_argument("--action", required=True, choices=["save", "restore", "erase"])
    s.add_argument("--filename", default=""); s.add_argument("--slot", type=int, default=0)
    q = sp.add_parser("ceiling"); q.add_argument("--active-cpu-gb", type=float, required=True); q.add_argument("--cpu-gbs", type=float, required=True)
    q.add_argument("--active-gpu-gb", type=float, required=True); q.add_argument("--gpu-gbs", type=float, required=True)
    a = ap.parse_args()
    if a.cmd == "chat":
        r = chat(a.url, [{"role": "user", "content": a.prompt}], a.max_tokens, json.loads(a.extra))
    elif a.cmd == "completion":
        r = completion(a.url, a.prompt, a.n, json.loads(a.extra))
    elif a.cmd == "bench":
        r = bench(a.url, a.repeats, a.out, a.n, a.ctx, a.long, a.only)
    elif a.cmd == "tokenize":
        r = {"tokens": tokenize(a.url, open(a.file, encoding="utf-8").read())}
    elif a.cmd == "slot":
        body = {"filename": a.filename} if a.filename else {}
        r = post_json("%s/slots/%d?action=%s" % (a.url, a.slot, a.action), body)
    else:  # A02: ток/с ~ 1 / (ГБ_CPU/полоса_CPU + ГБ_GPU/полоса_GPU)
        r = {"ceiling_tps": 1.0 / (a.active_cpu_gb / a.cpu_gbs + a.active_gpu_gb / a.gpu_gbs)}
    print(json.dumps(r, ensure_ascii=False))

if __name__ == "__main__":
    try:
        main()
    except urllib.error.URLError as e:
        print(json.dumps({"error": "http", "detail": str(e)}, ensure_ascii=False)); sys.exit(5)
