#!/usr/bin/env python3
"""Раннер первой волны NOX (читает wave1.tsv). Режимы: --plan, --dry-run, --check, --only ID, --from ID, --status, --next, --keep-going, --parallel N, --no-deps.
Инстансы: задача "S1,S2" -> ID@S1 и ID@S2. Зависимость выполнена, если PASS инстанс той же машины (или единственный инстанс).
FAIL останавливает запуск новых задач (дожидается работающих) и печатает отчёт; BLOCKED не останавливает независимые ветки, после очереди блокированные пробуются ещё раз.
Транспорт: локально, если раннер на этой машине; иначе ssh по NOX_S1_SSH / NOX_S2_SSH (скрипты копируются rsync в NOX_REMOTE_SCRIPTS).
Статус для диспетчера NOX: $NOX_ROOT/receipts/wave1_status.json (+ --status печатает его же). Коды выхода: 0 всё PASS, 1 есть FAIL, 3 есть BLOCKED/пропуски, 2 ошибка вызова."""
import argparse, concurrent.futures as cf, json, os, shlex, subprocess, sys, threading, time

HERE = os.path.dirname(os.path.abspath(__file__)); SCRIPTS = os.path.dirname(HERE)
NOX_ROOT = os.environ.get("NOX_ROOT", "/root/nox"); REMOTE_ROOT = os.environ.get("NOX_REMOTE_ROOT", "/root/nox")
REMOTE_SCRIPTS = os.environ.get("NOX_REMOTE_SCRIPTS", REMOTE_ROOT + "/scripts")
SSHO = ["-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "-o", "StrictHostKeyChecking=accept-new"]

def detect_local():
    s = os.environ.get("NOX_SERVER")
    if s: return s
    try:
        g = subprocess.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"], capture_output=True, text=True, timeout=20).stdout
    except (OSError, subprocess.SubprocessError):
        return "UNKNOWN"
    return "S1" if "5060" in g else "S2" if "V100" in g else "UNKNOWN"

class Host:
    def __init__(self, name, local, ssh):
        self.name, self.local, self.ssh = name, local, ssh
    def run(self, cmd, timeout):
        full = cmd if self.local else ["ssh"] + SSHO + shlex.split(self.ssh) + [cmd if isinstance(cmd, str) else shlex.join(cmd)]
        if self.local and isinstance(cmd, str): full = ["bash", "-c", cmd]
        return subprocess.run(full, capture_output=True, text=True, timeout=timeout)
    def receipt(self, rid):
        root = NOX_ROOT if self.local else REMOTE_ROOT
        try:
            r = self.run("cat %s/receipts/%s.json" % (root, rid), 30)
            return json.loads(r.stdout) if r.returncode == 0 else None
        except (subprocess.SubprocessError, json.JSONDecodeError):
            return None
    def script_dir(self): return SCRIPTS if self.local else REMOTE_SCRIPTS
    def sync(self):
        if self.local: return True
        host = [a for a in shlex.split(self.ssh) if "@" in a][0]; port = shlex.split(self.ssh)
        e = "ssh " + " ".join(SSHO) + (" -p " + port[port.index("-p") + 1] if "-p" in port else "")
        r = subprocess.run(["rsync", "-a", "--delete", "-e", e, SCRIPTS + "/", host + ":" + REMOTE_SCRIPTS + "/"], capture_output=True, text=True)
        return r.returncode == 0

def load(path):
    rows = []
    for l in open(path, encoding="utf-8"):
        if l.startswith("#") or not l.strip(): continue
        c = l.rstrip("\n").split("\t"); k = ["id", "track", "server", "executor", "order", "deps", "ext_hard", "ext_info", "script", "kind", "group", "timeout_s", "title"]
        d = dict(zip(k, c + [""] * (len(k) - len(c)))); d["order"] = int(d["order"]); d["timeout_s"] = int(d["timeout_s"] or 3600)
        d["deps"] = [x for x in d["deps"].split(",") if x]; rows.append(d)
    return sorted(rows, key=lambda r: r["order"])

def instances(rows):
    out = {}
    for r in rows:
        for s in (r["server"].split(",") if "," in r["server"] else [r["server"]]):
            key = r["id"] + ("@" + s if "," in r["server"] else "")
            out[key] = dict(r, key=key, host=s, state="pending", reason="", need="", rc=None, start=None, end=None, log="")
    return out

def dep_keys(inst, task, ids):
    res = []
    for d in task["deps"]:
        k = d + "@" + task["host"]
        res.append(k if k in inst else d)
    return [k for k in res if k in inst]

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tsv", default=os.path.join(SCRIPTS, "wave1.tsv")); ap.add_argument("--plan", action="store_true"); ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--check", action="store_true"); ap.add_argument("--only"); ap.add_argument("--from", dest="from_id"); ap.add_argument("--status", action="store_true")
    ap.add_argument("--next", action="store_true"); ap.add_argument("--keep-going", action="store_true"); ap.add_argument("--no-deps", action="store_true")
    ap.add_argument("--parallel", type=int, default=int(os.environ.get("NOX_PARALLEL", "4"))); ap.add_argument("--track", choices=["A", "B"])
    a = ap.parse_args()
    rows = load(a.tsv); inst = instances(rows); local = detect_local()
    hosts = {}
    for n in ("S1", "S2"):
        ssh = os.environ.get("NOX_%s_SSH" % n, "-p 62281 root@174.88.252.223" if n == "S1" else "")
        hosts[n] = Host(n, local == n, ssh)
    hosts["OWNER"] = Host("OWNER", True, ""); hosts["ANY"] = Host("ANY", True, "")
    status_path = os.path.join(NOX_ROOT, "receipts", "wave1_status.json")

    if a.plan:
        print("%-10s %-3s %-6s %-12s %-8s %s" % ("ID", "лн", "сервер", "исполнитель", "группа", "зависимости -> (внешние)"))
        for r in rows:
            print("%-10s %-3s %-6s %-12s %-8s %s%s%s" % (r["id"], r["track"], r["server"], r["executor"], r["group"] or "-", ",".join(r["deps"]) or "-",
                  (" | жёстк.внешн: " + r["ext_hard"]) if r["ext_hard"] else "", (" | справ.: " + r["ext_info"]) if r["ext_info"] else ""))
        print("\nпараллельно: разные серверы и разные группы; одна группа на одном сервере - строго по очереди. Инстансов: %d" % len(inst)); return 0

    sel = list(inst.values())
    if a.track: sel = [t for t in sel if a.track in t["track"].split(",")]
    if a.only: sel = [t for t in sel if t["id"] == a.only]
    if a.from_id:
        o = next((r["order"] for r in rows if r["id"] == a.from_id), None)
        if o is None: print("нет ID", a.from_id); return 2
        sel = [t for t in sel if t["order"] >= o]
    if not sel: print("нечего выполнять"); return 2
    selkeys = {t["key"] for t in sel}
    ext_done = a.dry_run or a.check or a.no_deps

    def done(k):   # зависимость вне выборки проверяется по квитанции на её хосте
        if k in selkeys: return inst[k]["state"] == "PASS"
        t = inst[k]; r = hosts[t["host"] if t["host"] in hosts else "ANY"].receipt(t["id"]); return bool(r and r.get("result") == "PASS")
    def dead(k): return k in selkeys and inst[k]["state"] in ("FAIL",)

    if a.status:
        out = {}
        for k, t in inst.items():
            r = hosts[t["host"] if t["host"] in hosts else "ANY"].receipt(t["id"])
            out[k] = {"result": r.get("result") if r else "NO_RECEIPT", "reason": r.get("reason") if r else "", "need_fact": r.get("need_fact") if r else "", "time_utc": r.get("time_utc") if r else None}
        print(json.dumps(out, ensure_ascii=False, indent=1)); return 0
    if a.next:
        for t in sel:
            if all(done(k) for k in dep_keys(inst, t, inst)) and not done(t["key"]): print(t["key"])
        return 0

    for h in hosts.values():
        if not h.local and any(t["host"] == h.name for t in sel):
            if not h.ssh: print("нет NOX_%s_SSH для обращения к %s" % (h.name, h.name)); return 2
            if not h.sync(): print("не удалось синхронизировать скрипты на %s (rsync/ssh)" % h.name); return 2

    lock = threading.Lock(); running_groups = set(); stop = threading.Event(); retried = set()
    flags = (["--dry-run"] if a.dry_run else []) + (["--check"] if a.check else [])

    def execute(t):
        h = hosts[t["host"] if t["host"] in hosts else "ANY"]; t["start"] = time.time(); t["state"] = "running"
        cmd = "bash %s/%s %s" % (h.script_dir(), t["script"], " ".join(flags))
        try:
            r = h.run(cmd, t["timeout_s"]); t["rc"] = r.returncode; tail = (r.stdout + r.stderr).strip().splitlines()[-6:]
        except subprocess.TimeoutExpired:
            t["rc"] = 124; tail = ["таймаут %d с" % t["timeout_s"]]
        t["end"] = time.time(); rec = None if (a.dry_run) else h.receipt(t["id"])
        t["state"] = {0: "PASS", 1: "FAIL", 3: "BLOCKED", 4: "BUSY"}.get(t["rc"], "FAIL")
        if a.dry_run: t["state"] = "DRY_OK" if t["rc"] == 0 else ("WOULD_BLOCK" if t["rc"] == 3 else "FAIL")
        t["reason"] = (rec or {}).get("reason") or " / ".join(tail)[-200:]; t["need"] = (rec or {}).get("need_fact", "")
        t["log"] = "%s/logs/%s.log" % (NOX_ROOT if h.local else REMOTE_ROOT, t["id"])
        print("[%s] %-10s %-11s %s%s" % (time.strftime("%H:%M:%S"), t["key"], t["state"], t["reason"][:110], (" | нужен факт: " + t["need"]) if t["need"] else ""), flush=True)
        if t["state"] == "FAIL" and not a.keep_going: stop.set()
        return t

    def ready(t):
        if t["state"] != "pending": return False
        ks = dep_keys(inst, t, inst)
        if ext_done: return True
        return all(done(k) for k in ks)

    with cf.ThreadPoolExecutor(max_workers=max(1, a.parallel)) as ex:
        futs = {}
        while True:
            with lock:
                for t in sel:
                    if t["state"] == "pending" and any(dead(k) for k in dep_keys(inst, t, inst)) and not ext_done:
                        t["state"] = "SKIPPED_DEP"; t["reason"] = "зависимость в FAIL"
                if not stop.is_set():
                    for t in sel:
                        gk = (t["host"], t["group"])
                        if len(futs) >= a.parallel: break
                        if ready(t) and not (t["group"] and gk in running_groups):
                            if t["group"]: running_groups.add(gk)
                            t["state"] = "starting"; futs[ex.submit(execute, t)] = t
            if not futs:
                blocked = [t for t in sel if t["state"] in ("BLOCKED", "BUSY") and t["key"] not in retried]
                if blocked and not stop.is_set():
                    progressed = any(t["state"] in ("PASS", "DRY_OK") for t in sel)
                    if progressed or not retried:
                        for t in blocked: retried.add(t["key"]); t["state"] = "pending"
                        continue
                break
            donef, _ = cf.wait(list(futs), timeout=2, return_when=cf.FIRST_COMPLETED)
            with lock:
                for f in donef:
                    t = futs.pop(f)
                    if t["group"]: running_groups.discard((t["host"], t["group"]))
                    try: f.result()
                    except Exception as e: t["state"] = "FAIL"; t["reason"] = "ошибка раннера: %s" % e; stop.set()

    for t in sel:
        if t["state"] == "pending": t["state"] = "SKIPPED_DEP" if not stop.is_set() else "NOT_RUN"; t["reason"] = t["reason"] or ("зависимость не PASS (блок/пропуск)" if not stop.is_set() else "остановлено из-за FAIL")
    rep = {t["key"]: {k: t[k] for k in ("state", "reason", "need", "rc", "log", "server", "executor")} for t in sel}
    if not (a.dry_run or a.check):
        os.makedirs(os.path.dirname(status_path), exist_ok=True); json.dump(rep, open(status_path, "w"), ensure_ascii=False, indent=1)
    print("\n=== ОТЧЁТ ===")
    cnt = {}
    for t in sel: cnt[t["state"]] = cnt.get(t["state"], 0) + 1
    print(" ".join("%s=%d" % kv for kv in sorted(cnt.items())))
    for t in sel:
        if t["state"] in ("FAIL",): print("ПРОВАЛ  %s (%s): %s\n         лог: %s  квитанция: .../receipts/%s.json" % (t["key"], t["executor"], t["reason"], t["log"], t["id"]))
    for t in sel:
        if t["state"] in ("BLOCKED", "WOULD_BLOCK"): print("ЖДЁТ ФАКТА  %s: %s -> нужно: %s" % (t["key"], t["reason"], t["need"] or "см. лог"))
    for t in sel:
        if t["state"] in ("SKIPPED_DEP", "NOT_RUN"): print("ПРОПУЩЕНО  %s: %s" % (t["key"], t["reason"]))
    if any(t["state"] == "FAIL" for t in sel): return 1
    if any(t["state"] in ("BLOCKED", "BUSY", "WOULD_BLOCK", "SKIPPED_DEP", "NOT_RUN") for t in sel): return 3
    return 0

if __name__ == "__main__":
    sys.exit(main())
