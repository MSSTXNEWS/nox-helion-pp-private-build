#!/usr/bin/env bash
# ab.sh - протокол A/B (A39): один рычаг, один сценарий, p50/p95, журнал.
# Порядок: бэкап -> действие (делает оператор/скрипт рычага) -> ab.sh run -> журнал -> при провале откат.
#   ab.sh run <lever> <label> [--url U] [--repeats N] [--no-exam]   замер скорости (nox_llm bench) + экзамен -> reports/ab_journal.jsonl
#   ab.sh compare <labelA> <labelB>                                   правило: оставить B, если скорость выросла и экзамен упал не более чем на 1 балл
#   ab.sh --selftest                                                  проверка эталона экзамена без сервера
set -euo pipefail
D="$(cd "$(dirname "$0")" && pwd)"; . "$D/nox_common.sh"
J="$NOX_REPORT_DIR/ab_journal.jsonl"; mkdir -p "$NOX_REPORT_DIR"
cmd="${1:---selftest}"; shift || true
case "$cmd" in
  --selftest) python3 -B "$D/nox_exam.py" selftest;;
  run)
    lever="${1:?lever}"; label="${2:?label}"; shift 2; url="$NOX_LLAMA_URL"; rep=3; exam=1
    while [ $# -gt 0 ]; do case "$1" in --url) url="$2"; shift;; --repeats) rep="$2"; shift;; --no-exam) exam=0;; esac; shift; done
    b="$(python3 -B "$D/nox_llm.py" bench --url "$url" --repeats "$rep" --out "$NOX_REPORT_DIR/ab_${label}.csv")"
    e='{"score":null}'; [ "$exam" = 1 ] && e="$(python3 -B "$D/nox_exam.py" run --url "$url")"
    commit="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/llama_build.json"))["commit"])' 2>/dev/null || echo unknown)"
    python3 -c 'import json,sys,datetime
b=json.loads(sys.argv[2]); e=json.loads(sys.argv[3])
print(json.dumps({"t":datetime.datetime.utcnow().isoformat()+"Z","lever":sys.argv[4],"label":sys.argv[1],"bench":b,"exam_score":e.get("score"),"commit":sys.argv[5]},ensure_ascii=False))' "$label" "$b" "$e" "$lever" "$commit" | tee -a "$J";;
  compare)
    python3 - "$J" "${1:?A}" "${2:?B}" <<'PY'
import json, sys
rows = [json.loads(l) for l in open(sys.argv[1])]
get = lambda lab: [r for r in rows if r["label"] == lab][-1]
a, b = get(sys.argv[2]), get(sys.argv[3])
da = b["bench"]["decode_tps_p50"] / a["bench"]["decode_tps_p50"] - 1
de = (b["exam_score"] or 0) - (a["exam_score"] or 0)
keep = da > 0 and de >= -1
print(json.dumps({"decode_gain": round(da, 3), "exam_delta": de, "keep_B": keep}))
sys.exit(0 if keep else 1)
PY
  ;;
  *) echo "usage: ab.sh run|compare|--selftest" >&2; exit 2;;
esac
