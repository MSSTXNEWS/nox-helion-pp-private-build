#!/usr/bin/env bash
# Ежедневный снимок конфигов и S03 (запускается cron-ом от root): tar.gz в $NOX_BACKUP_DIR/daily, хранить 14 дней.
set -euo pipefail
. "$(dirname "$0")/nox_common.sh"
: "${NOX_SNAPSHOT_PATHS:?задайте NOX_SNAPSHOT_PATHS в nox.env}"
d="$NOX_BACKUP_DIR/daily"; mkdir -p "$d"; f="$d/snap_$(date -u +%Y%m%dT%H%M%SZ).tar.gz"
# shellcheck disable=SC2086
tar -czf "$f" $NOX_SNAPSHOT_PATHS "$NOX_ROOT/config" 2>/dev/null || tar -czf "$f" $NOX_SNAPSHOT_PATHS
tar -tzf "$f" >/dev/null && sha256sum "$f" >"$f.sha256"
find "$d" -name 'snap_*' -mtime +14 -delete
echo "$f"
