#!/usr/bin/env bash
# Скачивает файл с Google Диска по ID. Использование: nox_fetch_drive.sh <FILE_ID> <DEST_FILE> [txt|md|docx|pdf]
# Метод 1 (предпочтительно): rclone с remote "gdrive" (rclone config; scope drive.readonly):
#   rclone --drive-export-formats <fmt> backend copyid gdrive: <ID> <DEST_FILE>
# Метод 2 (файл общий по ссылке): gdown --id <ID> -O <DEST_FILE>   (pip install gdown)
# Нет ни того ни другого -> код 3 и точное сообщение, что сделать.
set -euo pipefail
id="${1:?ID}"; dest="${2:?DEST}"; fmt="${3:-txt}"
mkdir -p "$(dirname "$dest")"
[ -s "$dest" ] && { echo "уже есть: $dest"; exit 0; }
remote="${NOX_RCLONE_REMOTE:-gdrive}"
if command -v rclone >/dev/null 2>&1 && rclone listremotes 2>/dev/null | grep -qx "$remote:"; then
  rclone --drive-export-formats "$fmt" backend copyid "$remote:" "$id" "$dest" && [ -s "$dest" ] && exit 0
fi
if command -v gdown >/dev/null 2>&1; then gdown --id "$id" -O "$dest" && [ -s "$dest" ] && exit 0; fi
echo "BLOCKED: не удалось скачать Drive-файл $id. Нужно: rclone remote '$remote' (rclone config) или публичная ссылка + gdown, либо положить файл вручную в $dest" >&2
exit 3
