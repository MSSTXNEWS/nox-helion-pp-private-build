#!/usr/bin/env python3
"""Минимальный HTTP-API единой памяти S03 (SQLite, схема lib/nox_s03.py). Запуск: nox_s03_api.py --db FILE --bind HOST --port N --token-file FILE.
GET /health (без токена); POST /mem {id,level,scope,scope_ref,text,source}; GET /mem/<id>; POST /search {q,principal,limit}. Токен: Authorization: Bearer <token>."""
import argparse, json, os, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nox_s03 as S

ap = argparse.ArgumentParser(); ap.add_argument("--db", required=True); ap.add_argument("--bind", required=True)
ap.add_argument("--port", type=int, required=True); ap.add_argument("--token-file", required=True); A = ap.parse_args()
TOKEN = open(A.token_file).read().strip()
_c = S.connect(A.db); S.migrate(_c); _c.close()

class H(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def _auth(self):
        if self.headers.get("Authorization", "") != "Bearer " + TOKEN: self._send(401, {"error": "unauthorized"}); return False
        return True
    def do_GET(self):
        if self.path == "/health": return self._send(200, {"ok": True})
        if not self._auth(): return
        if self.path.startswith("/mem/"):
            c = S.connect(A.db); r = c.execute("SELECT id,level,scope,scope_ref,text,source,fact_sha,revoked FROM nox_mem WHERE id=?", (self.path[5:],)).fetchone(); c.close()
            return self._send(200 if r else 404, {"row": r})
        self._send(404, {"error": "not found"})
    def do_POST(self):
        if not self._auth(): return
        d = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}"); c = S.connect(A.db)
        try:
            if self.path == "/mem":
                sha = S.add(c, d["id"], d["level"], d["scope"], d.get("scope_ref", ""), d["text"], d.get("source", "")); c.commit(); return self._send(200, {"ok": True, "fact_sha": sha})
            if self.path == "/search":
                return self._send(200, S.search(c, d["q"], d.get("principal", {}), d.get("limit", 10)))
            self._send(404, {"error": "not found"})
        except Exception as e:
            self._send(400, {"error": str(e)})
        finally:
            c.close()
    def log_message(self, *a): return None

ThreadingHTTPServer((A.bind, A.port), H).serve_forever()
