#!/usr/bin/env python3
"""Пишет квитанцию /root/nox/receipts/<ID>.json (атомарно). Поля: id, time_utc, host, server, mode, result, reason, need_fact, inputs_sha, metrics, elapsed_s, log."""
import argparse, json, os, socket, datetime, tempfile

def tsv(path):
    d = {}
    if not os.path.exists(path):
        return d
    for line in open(path, encoding="utf-8"):
        if "\t" in line:
            k, v = line.rstrip("\n").split("\t", 1)
            d[k] = v
    return d

def num(v):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v

p = argparse.ArgumentParser()
for a in ("id", "result", "reason", "need", "mode", "server", "metrics", "inputs", "log", "elapsed", "out"):
    p.add_argument("--" + a, default="")
a = p.parse_args()
rec = {
    "id": a.id,
    "time_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "host": socket.gethostname(),
    "server": a.server,
    "mode": a.mode,
    "result": a.result,
    "reason": a.reason,
    "need_fact": a.need,
    "inputs_sha": tsv(a.inputs),
    "metrics": {k: num(v) for k, v in tsv(a.metrics).items()},
    "elapsed_s": num(a.elapsed or "0"),
    "log": a.log,
}
os.makedirs(os.path.dirname(a.out), exist_ok=True)
fd, tmp = tempfile.mkstemp(dir=os.path.dirname(a.out))
with os.fdopen(fd, "w", encoding="utf-8") as f:
    json.dump(rec, f, ensure_ascii=False, indent=1)
os.replace(tmp, a.out)
