#!/usr/bin/env bash
# Единственная точка запуска llama-server главной модели: проверка запретов раздела 12 по argv, затем exec (с taskset под чат, если есть cpu_plan).
# Использование: nox_llama_launch.sh <аргументы llama-server>. Отказ = код 3 и сообщение "ЗАПРЕТ: ...".
set -euo pipefail
. "$(dirname "$0")/nox_common.sh"
nox_blocked() { echo "ЗАПРЕТ: $1" >&2; exit 3; }
nox_forbid_args "$*"
BIN="${NOX_LLAMA_BIN:-${NOX_LLAMA_DIR:-$NOX_ROOT/llama.cpp}/build-sm120/bin/llama-server}"
[ -x "$BIN" ] || { echo "нет бинарника $BIN (выполните P1-06)" >&2; exit 3; }
pre=()
if [ "${NOX_TASKSET:-1}" = 1 ] && [ -s "$NOX_RUN_DIR/cpu_plan.json" ] && command -v taskset >/dev/null; then
  pre=(taskset -c "$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/cpu_plan.json"))["chat_cpus_with_ht"])')")
fi
exec "${pre[@]}" "$BIN" "$@"
