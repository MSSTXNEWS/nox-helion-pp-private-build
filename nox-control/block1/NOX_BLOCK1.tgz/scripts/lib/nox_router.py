#!/usr/bin/env python3
"""Роутер сложности (P3-03): младший судья классифицирует запрос в Ур.1-4 (канон 5.1); слова «быстро»/«подумай» сдвигают уровень.
run --judge URL --labels file: точность против ручной разметки."""
import argparse, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nox_llm as L

SYSTEM = ("Ты классификатор сложности запросов. Уровни: 1 - мгновенно (болтовня, простые команды, короткие факты); "
          "2 - обдуманно (нужно объяснение или рассуждение в один подход); 3 - глубоко (код, многошаговый анализ, проектирование: нужен черновик и критика); "
          "4 - совет (нужен поиск в интернете, внешние источники, сверка мнений). Ответь ОДНОЙ цифрой 1-4, без пояснений.")

def shift(text, level):
    t = text.lower()
    if re.search(r"\bбыстро\b", t): level -= 1
    if re.search(r"\bподумай", t): level += 1
    return max(1, min(4, level))

def classify(judge_url, text):
    r = L.chat(judge_url, [{"role": "system", "content": SYSTEM}, {"role": "user", "content": text}], 16,
               {"temperature": 0, "chat_template_kwargs": {"enable_thinking": False}})
    m = re.search(r"[1-4]", r["content"])
    base = int(m.group()) if m else 2
    return shift(text, base), base, r["total"]

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--judge", required=True); ap.add_argument("--labels", required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args(); rows = [json.loads(l) for l in open(a.labels, encoding="utf-8") if l.strip()]
    res, ok = [], 0
    for r in rows:
        lvl, base, sec = classify(a.judge, r["q"]); good = lvl == r["level"]; ok += good
        res.append({"q": r["q"], "label": r["level"], "pred": lvl, "ok": good, "sec": round(sec, 2)})
    out = {"n": len(rows), "agree": ok / len(rows), "p95_s": L.pct([x["sec"] for x in res], .95), "rows": res}
    json.dump(out, open(a.out, "w"), ensure_ascii=False, indent=1); print(json.dumps({k: out[k] for k in ("n", "agree", "p95_s")}))
