#!/usr/bin/env python3
"""P1-04: тест 20 ГБ в RAM без второй копии. mode=shm: файл в /dev/shm + симлинк + чтение через mmap; mode=memfd: memfd_create + mmap через /proc/self/fd.
Печатает JSON-метрики. Проверка: каждый 1-МиБ блок читается через mmap с правильным байтом; рост Shmem при mmap-чтении < 1 ГиБ (нет копии)."""
import json, mmap, os, sys, time

MODE, GIB, PATH, LINK = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
BLK = 1 << 20

def meminfo(key):
    for l in open("/proc/meminfo"):
        if l.startswith(key + ":"):
            return int(l.split()[1]) * 1024

def cg_cur():
    for p in ("/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory/memory.usage_in_bytes"):
        if os.path.exists(p):
            return int(open(p).read())
    return None

n = GIB * 1024
t0 = time.time()
if MODE == "shm":
    f = open(PATH, "wb", buffering=0)
    path = PATH
else:
    fd = os.memfd_create("nox_t20", 0)
    f = os.fdopen(fd, "r+b", buffering=0)
    path = "/proc/self/fd/%d" % fd
for i in range(n):
    f.write(bytes([i % 251]) * BLK)
f.flush()
wsec = time.time() - t0
if MODE == "shm":
    f.close()
    if os.path.islink(LINK) or os.path.exists(LINK):
        os.remove(LINK)
    os.symlink(PATH, LINK)
    path = LINK
sh0, cg0 = meminfo("Shmem"), cg_cur()
fh = open(path, "rb")
mm = mmap.mmap(fh.fileno(), 0, access=mmap.ACCESS_READ)
t1 = time.time(); bad = 0
for i in range(n):
    if mm[i * BLK] != i % 251 or mm[i * BLK + BLK - 1] != i % 251:
        bad += 1
rsec = time.time() - t1
sh1, cg1 = meminfo("Shmem"), cg_cur()
size = len(mm)
mm.close(); fh.close(); f.close() if MODE != "shm" else None
if MODE == "shm":
    os.remove(LINK); os.remove(PATH)
print(json.dumps({"mode": MODE, "gib": GIB, "bytes_mapped": size, "bad_blocks": bad, "write_s": round(wsec, 1),
                  "mmap_read_s": round(rsec, 1), "shmem_delta_gib": round((sh1 - sh0) / 2**30, 3),
                  "cgroup_delta_gib": None if cg0 is None else round((cg1 - cg0) / 2**30, 3)}))
