#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
/* STREAM triad: a = b + 3*c; печатает лучшую полосу ГБ/с */
int main(void){ size_t n=128UL*1024*1024; double *a=malloc(n*8),*b=malloc(n*8),*c=malloc(n*8); double best=0;
#pragma omp parallel for
 for(size_t i=0;i<n;i++){a[i]=0;b[i]=1.0;c[i]=2.0;}
 for(int k=0;k<8;k++){ double t=omp_get_wtime();
#pragma omp parallel for
  for(size_t i=0;i<n;i++) a[i]=b[i]+3.0*c[i];
  t=omp_get_wtime()-t; double g=3.0*n*8/t/1e9; if(g>best)best=g;}
 printf("%.1f\n",best+a[7]*0); return 0; }
