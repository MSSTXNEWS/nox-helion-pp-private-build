#!/usr/bin/env python3
"""Прогон направлений D02..D16 плана Парето v6 на S1: только безопасное (--dry-run/--check, whitelist реальных лёгких задач, read-only обработчики).
Пишет /root/nox/state/PARETO_STATUS.json, квитанции /root/nox/receipts/Dxx-nn.json, таблицу PARETO_SUMMARY.txt. Содержимое чатов/памяти не читает."""
import json, os, re, subprocess, sys, time, shutil
R = os.environ.get('NOX_ROOT', '/root/nox')
SC = os.path.join(R, 'scripts')
ST = os.path.join(R, 'state'); os.makedirs(ST, exist_ok=True)
RC = os.path.join(R, 'receipts')
tasks = json.load(open(os.path.join(SC, 'config', 'pareto_tasks.json')))
W = {}
for l in open(os.path.join(SC, 'wave1.tsv')).read().split('\n')[1:]:
    c = l.split('\t')
    if len(c) > 12: W[c[0]] = dict(server=c[2], kind=c[9], group=c[10], to=int(c[11] or 300))
REAL = {'P1-09', 'P1-11', 'P3-01', 'P4-02', 'P10-01'}   # лёгкие действия, идемпотентные, без нагрузки
ONLY = os.environ.get('PARETO_ONLY', '').split()
SPath = os.path.join(ST, 'PARETO_STATUS.json')
status = json.load(open(SPath)) if os.path.exists(SPath) else {}

def sh(cmd, to=60):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=to)
        return p.returncode, (p.stdout + p.stderr)
    except subprocess.TimeoutExpired:
        return 124, 'timeout'

def prohibitions():
    os.makedirs(R + '/config', exist_ok=True)
    reg = {"forbidden_flags_main": ["--no-mmap", "--mlock", "-ctk q8_0", "-ctv q8_0", "--cache-type-k q*", "--cache-type-v q*"],
           "rules": ["одна главная модель", "KV главной только f16", "STOP-флаг /run/nox/STOP уважать", "S2 не создавать", "ничего чужого не удалять"]}
    json.dump(reg, open(R + '/config/prohibitions.json', 'w'), ensure_ascii=False, indent=1)
    rc, out = sh("ps -eo pid,args | grep -E 'llama-server|llama-cli' | grep -v grep")
    bad = [l for l in out.split('\n') if not re.search(r'--port (8083|8084|8090)\b', l) and re.search(r'--no-mmap|--mlock|(-ctk|-ctv|--cache-type-[kv])[ =]q', l)]
    return ('PASS', f'реестр запретов записан; у главной модели запрещённых флагов нет (судья :8083 с q8 KV не главная, §12 не нарушает)') if not bad else ('FAIL', f'нарушителей: {len(bad)}')

def services():
    rc, out = sh("ss -ltn 2>/dev/null | awk 'NR>1{print $4}' | sed 's/.*://' | sort -un | tr '\\n' ' '")
    open(ST + '/services_ports.txt', 'w').write(out)
    return 'PASS', 'слушающие порты записаны в state/services_ports.txt (без обращения к 8081/8082/8091): ' + out.strip()[:200]

def disk():
    rc, out = sh("df -P / | awk 'NR==2{print $5}' | tr -d %")
    u = int(out.strip() or 0)
    json.dump({'root_used_pct': u, 't': time.strftime('%FT%TZ', time.gmtime())}, open(ST + '/disk_watch.json', 'w'))
    return ('PASS' if u < 85 else 'FAIL'), f'диск / занят {u}% (порог 85%)'

def stopcheck():
    return ('PASS', 'STOP-флаг отсутствует') if not os.path.exists('/run/nox/STOP') else ('BLOCKED', 'STOP-флаг стоит')

def s03copy():
    import sqlite3
    db = R + '/memory/s03.db'
    if not os.path.exists(db): return 'BLOCKED', 'нет /root/nox/memory/s03.db'
    c = sqlite3.connect('file:' + db + '?mode=ro', uri=True, timeout=10)
    ic = c.execute('PRAGMA integrity_check').fetchone()[0]
    tb = [r[0] for r in c.execute("select name from sqlite_master where type='table'")]
    n = {t: c.execute('select count(*) from "%s"' % t.replace('"', '')).fetchone()[0] for t in tb[:40]}
    json.dump({'integrity': ic, 'rows': n, 'size': os.path.getsize(db)}, open(ST + '/s03_copy_check.json', 'w'))
    if ic != 'ok': return 'FAIL', 'integrity_check=' + ic[:60]
    return 'SATISFIED_BY_COPY', f'S2->S1 копия s03.db: integrity ok, таблиц {len(tb)}, строк {sum(n.values())}'

HANDLERS = {'D05-01': s03copy, 'D03-13': prohibitions, 'D03-05': services, 'D14-13': disk}

def put(t, st, reason, extra=None):
    d = dict(id=t['id'], title=t['title'], status=st, reason=reason[:300], t=time.strftime('%FT%TZ', time.gmtime()), script=t.get('pid', ''))
    if extra: d.update(extra)
    status[t['id']] = d
    json.dump(d, open(f"{RC}/{t['id']}.json", 'w'), ensure_ascii=False)
    json.dump(status, open(SPath, 'w'), ensure_ascii=False, indent=0)
    print(f"{t['id']} {st} {reason[:110]}", flush=True)

def classify(t):
    pid = t['pid']; w = W.get(pid, {})
    srv = t['server']
    if re.search(r'владел', t['exec']) and not pid and t['exec'].startswith('владелец'):
        return 'BLOCKED', 'действие владельца (деньги/доступы/решение)'
    if srv.startswith('S2') or srv in ('ПК', 'склад') or (w.get('server') == 'S2') or w.get('group', '').startswith('s2'):
        return 'BLOCKED', 'требует S2/ПК/склада; S2 удалён'
    return None

def main():
    for t in tasks:
        if ONLY and t['id'] not in ONLY and t['id'][:3] not in ONLY: continue
        if os.path.exists('/run/nox/STOP'): print('STOP-флаг: прерываюсь'); break
        i = t['id']; pid = t['pid']; w = W.get(pid, {})
        c = classify(t)
        if c: put(t, *c); continue
        if i in HANDLERS:
            st, why = HANDLERS[i](); put(t, st, why); continue
        if not pid:
            put(t, 'SKIPPED', 'нет готового скрипта: требует разработки кода/UI/данных (вне безопасных замеров S1)'); continue
        script = next((f for f in os.listdir(SC) if f.startswith(pid + '_') and f.endswith('.sh')), None)
        if not script: put(t, 'SKIPPED', f'скрипт {pid} не найден на S1'); continue
        glm = t.get('glm') or w.get('group') == 'llama'
        mode = '--dry-run' if (glm and pid not in REAL) else ('' if pid in REAL else '--check')
        if pid in ('P2-01',):
            put(t, 'SKIPPED', 'GLM-5.3 удалена; загрузка 467 ГБ запрещена по диску/балансу'); continue
        env = f"NOX_SERVER=S1 NOX_ROOT={R}"
        rc, out = sh(f"cd {SC} && {env} nice -n 19 ionice -c3 bash {script} {mode} 2>&1 | tail -n 4", to=min(w.get('to', 300), 240))
        rcs = sh(f"python3 -I -c \"import json;d=json.load(open('{RC}/{pid}.json'));print(d.get('result'),d.get('reason','')[:150])\"")[1].strip() if mode != '--dry-run' else ''
        tail = ' | '.join(x.strip() for x in out.strip().split('\n')[-2:])[:200]
        if mode == '--dry-run':
            ok = 'DRY' in out or rc == 0
            put(t, 'WAIT_FLASH', f'ждёт Flash-проверки (llama/GLM-задача); dry-run rc={rc}: {tail}')
        elif rcs.startswith('PASS'):
            put(t, 'PASS', ('выполнено' if mode == '' else 'check') + ': ' + rcs)
        elif rcs.startswith('BLOCKED'):
            put(t, 'BLOCKED', rcs)
        elif rcs.startswith('FAIL'):
            put(t, 'FAIL', rcs)
        else:
            put(t, 'BLOCKED' if rc in (3, 4) else 'FAIL', f'rc={rc}: {tail}')
    summary()

def summary():
    rows = {}
    for t in tasks:
        d = rows.setdefault(t['id'][:3], dict(total=0, PASS=0, SATISFIED_BY_COPY=0, WAIT_FLASH=0, BLOCKED=0, SKIPPED=0, FAIL=0, none=0, why={}))
        d['total'] += 1; s = status.get(t['id'])
        if not s: d['none'] += 1; continue
        d[s['status']] = d.get(s['status'], 0) + 1
        k = s['reason'][:60]; d['why'][k] = d['why'].get(k, 0) + 1
    L = ['напр | всего | PASS+COPY | FAIL | ждёт Flash | BLOCKED | SKIPPED | не запущено']
    for k in sorted(rows):
        d = rows[k]; L.append(f"{k} | {d['total']} | {d['PASS']+d['SATISFIED_BY_COPY']} | {d['FAIL']} | {d['WAIT_FLASH']} | {d['BLOCKED']} | {d['SKIPPED']} | {d['none']}")
    open(ST + '/PARETO_SUMMARY.txt', 'w').write('\n'.join(L) + '\n')
    print('\n'.join(L))

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'summary': summary()
    else: main()
