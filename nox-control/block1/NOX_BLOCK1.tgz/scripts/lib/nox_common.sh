#!/usr/bin/env bash
# nox_common.sh - общая библиотека NOX v5 (подключается через `. lib/nox_common.sh`).
# Даёт: логирование, квитанции, проверки cgroup/RAM/VRAM, замки паузы и обслуживания,
# STOP-флаг, бэкап/откат, запреты раздела 12, health-check (/proc/PID/stat + /health),
# стандартный жизненный цикл задачи (nox_begin / nox_run_task).
# Коды выхода: 0 PASS, 1 FAIL, 2 ошибка вызова, 3 BLOCKED (нужен факт/действие), 4 занято.
NOX_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; export NOX_LIB_DIR
NOX_SCRIPTS_DIR="$(dirname "$NOX_LIB_DIR")"
NOX_ROOT="${NOX_ROOT:-/root/nox}"
# shellcheck disable=SC1091
[ -f "$NOX_ROOT/nox.env" ] && . "$NOX_ROOT/nox.env"
NOX_LOG_DIR="${NOX_LOG_DIR:-$NOX_ROOT/logs}"
NOX_RECEIPT_DIR="${NOX_RECEIPT_DIR:-$NOX_ROOT/receipts}"
NOX_BACKUP_DIR="${NOX_BACKUP_DIR:-$NOX_ROOT/backups}"
NOX_RUN_DIR="${NOX_RUN_DIR:-$NOX_ROOT/run}"
NOX_REPORT_DIR="${NOX_REPORT_DIR:-$NOX_ROOT/reports}"
NOX_SRC_DIR="${NOX_SRC_DIR:-$NOX_ROOT/src}"
NOX_PAUSE_DIR="${NOX_PAUSE_DIR:-/run/nox/pause}"
NOX_MAINT_DIR="${NOX_MAINT_DIR:-/run/nox/maint}"
NOX_STOP_FLAG="${NOX_STOP_FLAG:-/run/nox/STOP}"
NOX_LLAMA_HOST="${NOX_LLAMA_HOST:-127.0.0.1}"
NOX_LLAMA_PORT="${NOX_LLAMA_PORT:-8080}"   # штатный порт llama-server; переопределяется в nox.env
NOX_LLAMA_URL="${NOX_LLAMA_URL:-http://$NOX_LLAMA_HOST:$NOX_LLAMA_PORT}"
NOX_NFAIL=0; NOX_FAILS=""; DRY=0; CHECK=0; NOX_ARGS=()

nox_log() { local lvl="$1"; shift; printf '%s [%s] %s\n' "$(date -u +%FT%TZ)" "$lvl" "$*" | tee -a "${NOX_LOGFILE:-/dev/null}" >&2; }

# ---------- вызов задачи ----------
nox_usage() { sed -n '/^# ID:/,/^# ----/p' "$0" | sed 's/^# \{0,1\}//'; }
nox_begin() { # ID SERVER(S1|S2|S1,S2|OWNER|ANY) "$@"
  NOX_ID="$1"; NOX_SERVER_REQ="$2"; shift 2
  while [ $# -gt 0 ]; do case "$1" in
    --dry-run) DRY=1;; --check) CHECK=1;; -h|--help) nox_usage; exit 0;; *) NOX_ARGS+=("$1");; esac; shift; done
  mkdir -p "$NOX_LOG_DIR" "$NOX_RECEIPT_DIR" "$NOX_BACKUP_DIR" "$NOX_RUN_DIR" "$NOX_REPORT_DIR" "$NOX_SRC_DIR" 2>/dev/null \
    || { echo "BLOCKED: нет прав создать $NOX_ROOT (задайте NOX_ROOT)" >&2; exit 3; }
  NOX_LOGFILE="$NOX_LOG_DIR/$NOX_ID.log"; NOX_TMP="$(mktemp -d)"; : >"$NOX_TMP/metrics.tsv"; : >"$NOX_TMP/inputs.tsv"
  trap 'rm -rf "$NOX_TMP"' EXIT
  exec 9>"$NOX_RUN_DIR/$NOX_ID.lock"; flock -n 9 || { nox_log ERR "задача уже выполняется"; exit 4; }
  NOX_T0=$(date +%s); nox_input "$0"
  nox_log INFO "== $NOX_ID старт (dry=$DRY check=$CHECK) host=$(hostname)"
}
nox_metric() { printf '%s\t%s\n' "$1" "$2" >>"$NOX_TMP/metrics.tsv"; nox_log METRIC "$1=$2"; }
nox_input() { [ -f "$1" ] && printf '%s\t%s\n' "$1" "$(sha256sum "$1" | cut -d' ' -f1)" >>"$NOX_TMP/inputs.tsv" || true; }
nox_finish() { # RESULT REASON [NEED_FACT]
  local res="$1" reason="${2:-}" need="${3:-}" mode=run
  [ "$CHECK" = 1 ] && mode=check
  nox_log "$res" "$NOX_ID: $reason ${need:+| нужен факт: $need}"
  if [ "$DRY" != 1 ]; then
    python3 -I "$NOX_LIB_DIR/nox_receipt.py" --id "$NOX_ID" --result "$res" --reason "$reason" --need "$need" \
      --mode "$mode" --server "${NOX_DETECTED:-?}" --metrics "$NOX_TMP/metrics.tsv" --inputs "$NOX_TMP/inputs.tsv" \
      --log "$NOX_LOGFILE" --elapsed "$(( $(date +%s) - NOX_T0 ))" --out "$NOX_RECEIPT_DIR/$NOX_ID.json" \
      || { echo "не удалось записать квитанцию" >&2; exit 1; }
  fi
  case "$res" in PASS) exit 0;; FAIL) exit 1;; BLOCKED) exit 3;; esac; exit 2
}
nox_blocked() { nox_finish BLOCKED "$1" "${2:-}"; }
nox_fail() { nox_finish FAIL "$1" "${2:-}"; }
nox_chk() { local d="$1"; shift; if "$@" >>"${NOX_LOGFILE:-/dev/null}" 2>&1; then nox_log OK "$d"; else nox_log NO "$d"; NOX_NFAIL=$((NOX_NFAIL+1)); NOX_FAILS+="$d; "; fi; }
nox_verdict() { [ "$NOX_NFAIL" -eq 0 ]; }
nox_ge() { awk -v a="$1" -v b="$2" 'BEGIN{exit !(a+0>=b+0)}'; }
nox_le() { awk -v a="$1" -v b="$2" 'BEGIN{exit !(a+0<=b+0)}'; }
nox_run() { if [ "$DRY" = 1 ]; then nox_log DRY "$*"; else nox_log RUN "$*"; "$@" >>"$NOX_LOGFILE" 2>&1; fi; }

# ---------- требования ----------
nox_need_cmd() { local c; for c in "$@"; do command -v "$c" >/dev/null 2>&1 || nox_blocked "нет команды $c" "установить $c (apt/pip) на этом хосте"; done; }
nox_need_var() { local v; for v in "$@"; do [ -n "${!v:-}" ] || nox_blocked "не задана переменная $v" "значение $v (в $NOX_ROOT/nox.env)"; done; }
nox_need_file() { [ -e "$1" ] || nox_blocked "нет файла/каталога $1" "${2:-получить $1 (см. SRC в шапке скрипта)}"; nox_input "$1"; }
nox_receipt_result() { python3 -I -c 'import json,sys;print(json.load(open(sys.argv[1])).get("result",""))' "$NOX_RECEIPT_DIR/$1.json" 2>/dev/null || true; }
nox_need_receipt() { local d; for d in "$@"; do [ "$(nox_receipt_result "$d")" = PASS ] || nox_blocked "зависимость $d не PASS" "выполнить $d (квитанция $NOX_RECEIPT_DIR/$d.json со статусом PASS)"; done; }
nox_detect_server() {
  if [ -n "${NOX_SERVER:-}" ]; then echo "$NOX_SERVER"; return; fi
  local g; g="$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | tr '\n' ';' || true)"
  case "$g" in *5060*) echo S1;; *V100*) echo S2;; *) echo UNKNOWN;; esac
}
nox_require_server() {
  NOX_DETECTED="$(nox_detect_server)"
  case "$NOX_SERVER_REQ" in OWNER|ANY) return 0;; esac
  case ",$NOX_SERVER_REQ," in *",$NOX_DETECTED,"*) return 0;; esac
  nox_blocked "скрипт для $NOX_SERVER_REQ, определён сервер: $NOX_DETECTED" "запустить на $NOX_SERVER_REQ (при ошибке определения задать NOX_SERVER=S1|S2 в nox.env)"
}
nox_stop_gate() {
  [ "${NOX_ALLOW_UNDER_STOP:-0}" = 1 ] && return 0
  mkdir -p "$(dirname "$NOX_STOP_FLAG")" 2>/dev/null || nox_blocked "нельзя проверить STOP-флаг (fail-closed)" "права на $(dirname "$NOX_STOP_FLAG")"
  [ ! -e "$NOX_STOP_FLAG" ] || nox_blocked "активен STOP-флаг $NOX_STOP_FLAG" "владелец снимает STOP"
}

# ---------- cgroup / RAM / VRAM ----------
nox_mem_total() { awk '/^MemTotal/{print $2*1024}' /proc/meminfo; }
nox_cg_mem_max() { local v=""
  [ -r /sys/fs/cgroup/memory.max ] && v="$(cat /sys/fs/cgroup/memory.max)"
  [ -z "$v" ] && [ -r /sys/fs/cgroup/memory/memory.limit_in_bytes ] && v="$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes)"
  case "$v" in ""|max) nox_mem_total;; *) local t; t="$(nox_mem_total)"; [ "$v" -gt "$t" ] && echo "$t" || echo "$v";; esac; }
nox_cg_mem_cur() { if [ -r /sys/fs/cgroup/memory.current ]; then cat /sys/fs/cgroup/memory.current
  elif [ -r /sys/fs/cgroup/memory/memory.usage_in_bytes ]; then cat /sys/fs/cgroup/memory/memory.usage_in_bytes
  else awk '/^MemTotal/{t=$2}/^MemAvailable/{a=$2}END{print (t-a)*1024}' /proc/meminfo; fi; }
nox_ram_free() { local m c a; m="$(nox_cg_mem_max)"; c="$(nox_cg_mem_cur)"; a="$(awk '/^MemAvailable/{print $2*1024}' /proc/meminfo)"
  local f=$((m-c)); [ "$a" -lt "$f" ] && f="$a"; echo "$f"; }
nox_need_ram_free() { local f; f="$(nox_ram_free)"; [ "$f" -ge "$1" ] || nox_blocked "свободной RAM $((f/1000000000)) ГБ < нужно $(($1/1000000000)) ГБ (cgroup-лимит учтён)" "освободить RAM или другой инстанс"; }
nox_vram_total_mib() { nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -1 | tr -d ' '; }
nox_vram_used_mib() { nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | head -1 | tr -d ' '; }
nox_vram_free_mib() { echo $(( $(nox_vram_total_mib) - $(nox_vram_used_mib) )); }
nox_gpu_temp() { nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits | head -1 | tr -d ' '; }

# ---------- замки паузы (9.7) и обслуживания ----------
nox_pause_lock() { # PID причина до_epoch  (SIGSTOP/cgroup.freeze без замка запрещены)
  mkdir -p "$NOX_PAUSE_DIR"; printf '{"pid":%s,"by":"%s","why":"%s","until":%s}\n' "$1" "$NOX_ID" "$2" "$3" >"$NOX_PAUSE_DIR/$1.lock"; }
nox_pause_unlock() { rm -f "$NOX_PAUSE_DIR/$1.lock"; }
nox_stopped_without_lock() { local p st; for p in /proc/[0-9]*; do p="${p#/proc/}"
  st="$(sed 's/.*) //' "/proc/$p/stat" 2>/dev/null | cut -c1)" || continue
  if [ "$st" = T ] && [ ! -e "$NOX_PAUSE_DIR/$p.lock" ]; then printf '%s %s\n' "$p" "$(tr '\0' ' ' </proc/$p/cmdline 2>/dev/null | cut -c1-80)"; fi; done; }
nox_maint_begin() { mkdir -p "$NOX_MAINT_DIR"; printf '{"by":"%s","until":%s}\n' "$NOX_ID" "$(( $(date +%s) + ${1:-3600} ))" >"$NOX_MAINT_DIR/$NOX_ID.lock"; }
nox_maint_end() { rm -f "$NOX_MAINT_DIR/$NOX_ID.lock"; }

# ---------- health ----------
nox_pid_state() { sed 's/.*) //' "/proc/$1/stat" 2>/dev/null | cut -c1; }
nox_health() { curl -fsS --max-time "${2:-5}" "${1:-$NOX_LLAMA_URL}/health" 2>/dev/null; }
nox_llama_pid() { pgrep -f "llama-server.*--port $NOX_LLAMA_PORT" | head -1 || pgrep -x llama-server | head -1 || true; }
nox_healthy() { # PID URL: состояние не T/Z/нет И /health отвечает
  local s; s="$(nox_pid_state "$1")"; [ -n "$s" ] && [ "$s" != T ] && [ "$s" != Z ] && nox_health "$2" >/dev/null; }
nox_wait_health() { local url="$1" to="${2:-600}" t=0; while [ "$t" -lt "$to" ]; do nox_health "$url" 3 >/dev/null && return 0; sleep 5; t=$((t+5)); done; return 1; }

# ---------- бэкап / откат ----------
nox_backup() { local ts d p; ts="$(date -u +%Y%m%dT%H%M%SZ)"; d="$NOX_BACKUP_DIR/$NOX_ID/$ts"; mkdir -p "$d"
  : >"$d/absent.list"; for p in "$@"; do if [ -e "$p" ]; then cp -a --parents "$p" "$d/"; else echo "$p" >>"$d/absent.list"; fi; done
  echo "$d" >"$NOX_BACKUP_DIR/$NOX_ID/LAST"; NOX_BK="$d"; nox_log INFO "бэкап: $d"; }
nox_restore() { local d="${NOX_BK:-$(cat "$NOX_BACKUP_DIR/$NOX_ID/LAST" 2>/dev/null)}" p
  [ -d "$d" ] || { nox_log WARN "нет бэкапа для отката"; return 1; }
  (cd "$d" && find . -mindepth 1 ! -name absent.list -type f -o -type l | sed 's|^\./||' | while read -r f; do mkdir -p "/$(dirname "$f")"; cp -a "$f" "/$f"; done)
  while read -r p; do [ -n "$p" ] && rm -rf "$p"; done <"$d/absent.list"; nox_log INFO "откат из $d"; }

# ---------- запреты раздела 12 ----------
nox_forbid_args() { # строка аргументов запуска главной модели
  local a=" $* "
  case "$a" in *" --no-mmap "*|*" --mlock "*) nox_blocked "запрет 12: --no-mmap/--mlock для главной модели";; esac
  echo "$a" | grep -Eq -- ' (-ctk|-ctv|--cache-type-k|--cache-type-v) (q[0-9]_[0-9a-z]+|iq4_nl) ' && nox_blocked "запрет 12: KV-квант (только f16 до экзамена A25)"
  echo "$a" | grep -Eq -- ' (-rtr|--run-time-repack) ' && nox_blocked "запрет 12: -rtr в гибриде CPU/GPU"
  echo "$a" | grep -Eq -- ' (-md|--model-draft|--spec-type|--draft) ' && nox_blocked "запрет 12: внешний draft/ngram для главной модели"
  echo "$a" | grep -Eq -- ' --split-mode tensor | -sm tensor ' && echo "$a" | grep -Eq -- ' (-ctk|-ctv) ' && nox_blocked "запрет 12: split-mode tensor + квант KV"
  case "$a" in *drop_caches*) nox_blocked "запрет 12: drop_caches";; esac; return 0; }

# ---------- вспомогательное ----------
nox_ssh_opts() { echo "-o BatchMode=yes -o ConnectTimeout=10 -o StrictHostKeyChecking=accept-new"; }
nox_llm() { python3 -B "$NOX_LIB_DIR/nox_llm.py" "$@"; }  # chat/bench/ttft, см. nox_llm.py
nox_fetch_drive() { "$NOX_LIB_DIR/nox_fetch_drive.sh" "$@"; }
nox_patch_dir() { # REPO_DIR PATCH_DIR: git apply --check, затем apply; патч помечен "# applies-to:" в первых строках
  local repo="$1" pd="$2" p n=0; [ -d "$pd" ] || return 0
  for p in "$pd"/*.patch; do [ -e "$p" ] || continue; nox_input "$p"
    if git -C "$repo" apply --check "$p" 2>>"$NOX_LOGFILE"; then git -C "$repo" apply "$p" && n=$((n+1)) && nox_log INFO "патч применён: $p"
    elif git -C "$repo" apply --check -R "$p" 2>/dev/null; then nox_log INFO "патч уже применён: $p"
    else nox_blocked "патч $p не применим к $(git -C "$repo" rev-parse --short HEAD)" "ревизия исходника, к которой патч сделан (строка applies-to в патче)"; fi; done
  nox_metric patches_applied "$n"; }

# ---------- жизненный цикл ----------
nox_run_task() { # хуки: t_pre t_check [t_do t_backup t_rollback]; переменная NOX_PLAN
  nox_log INFO "ПЛАН: ${NOX_PLAN:-(не задан)}"
  nox_require_server; nox_stop_gate
  declare -F t_pre >/dev/null && t_pre
  if [ "$DRY" = 1 ]; then nox_log DRY "dry-run: требования выполнены, изменений не сделано"; exit 0; fi
  NOX_NFAIL=0; NOX_FAILS=""
  if [ "$CHECK" = 1 ] || ! declare -F t_do >/dev/null; then
    if t_check; then nox_finish PASS "критерий выполнен"; else nox_fail "критерий не выполнен: $NOX_FAILS"; fi
  fi
  if t_check; then nox_finish PASS "уже выполнено (идемпотентно)"; fi
  NOX_NFAIL=0; NOX_FAILS=""
  declare -F t_backup >/dev/null && t_backup
  if ! t_do; then declare -F t_rollback >/dev/null && t_rollback || true; nox_fail "действие завершилось ошибкой (откат выполнен)"; fi
  NOX_NFAIL=0; NOX_FAILS=""
  if t_check; then nox_finish PASS "действие выполнено, критерий подтверждён"; fi
  declare -F t_rollback >/dev/null && t_rollback || true
  nox_fail "после действия критерий не выполнен: $NOX_FAILS (откат выполнен)"
}

nox_stream_gbs() { gcc -O3 -fopenmp -march=native -o "$NOX_TMP/stream" "$NOX_LIB_DIR/stream.c" && "$NOX_TMP/stream"; }
nox_red_event() { mkdir -p "$NOX_ROOT/events"; printf '{"t":"%s","level":"red","src":"%s","msg":"%s"}\n' "$(date -u +%FT%TZ)" "${NOX_ID:-wd}" "$1" >>"$NOX_ROOT/events/red.jsonl"; nox_log RED "$1"; }
