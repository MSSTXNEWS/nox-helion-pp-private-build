#!/usr/bin/env bash
# Общий цикл для карточек приёмки живого контура: nox_scenario_task ID "<теги через запятую>"
# Требует: NOX_RESONANCE_URL (адрес живого «Резонанса»; не выдумывается) и файл сценария $NOX_ROOT/scenarios/<ID>.json (или NOX_SCENARIO_DIR).
# Нет сценария -> сохраняется openapi.json контура в $NOX_ROOT/discovery/<ID>_openapi.json (если он отдаётся) и BLOCKED с указанием, что написать.
nox_scenario_task() {
  local id="$1" tags="$2"
  nox_scen_pre() { nox_need_cmd python3 curl; nox_need_var NOX_RESONANCE_URL
    curl -fsS --max-time 10 "$NOX_RESONANCE_URL/health" >/dev/null 2>&1 || curl -fsS --max-time 10 -o /dev/null "$NOX_RESONANCE_URL/" || nox_blocked "живой контур $NOX_RESONANCE_URL не отвечает" "адрес/доступность Резонанса на S2"
    local f="${NOX_SCENARIO_DIR:-$NOX_ROOT/scenarios}/$id.json"
    if [ ! -s "$f" ]; then mkdir -p "$NOX_ROOT/discovery"
      curl -fsS --max-time 15 "$NOX_RESONANCE_URL/openapi.json" -o "$NOX_ROOT/discovery/${id}_openapi.json" 2>/dev/null && nox_log INFO "openapi контура сохранён: $NOX_ROOT/discovery/${id}_openapi.json"
      nox_blocked "нет сценария $f" "реальные эндпоинты Резонанса/S03 для шагов с тегами: $tags (формат - в шапке lib/nox_scenario.py)"; fi
    nox_input "$f"; NOX_SCEN_FILE="$f"; }
  t_pre() { nox_scen_pre; }
  t_check() {
    local out; out="$(python3 -B "$NOX_LIB_DIR/nox_scenario.py" "$NOX_SCEN_FILE" --base "$NOX_RESONANCE_URL" --require "$tags" 2>>"$NOX_LOGFILE")" && rc=0 || rc=$?
    nox_log INFO "$out"; echo "$out" >"$NOX_REPORT_DIR/$id.scenario.json"
    nox_metric scenario_sha "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["sha"][:16])' "$out" 2>/dev/null || echo NA)"
    nox_chk "все требуемые шаги ($tags) присутствуют" python3 -c 'import json,sys;sys.exit(1 if json.loads(sys.argv[1])["missing_tags"] else 0)' "$out"
    nox_chk "все шаги прошли" python3 -c 'import json,sys;sys.exit(1 if json.loads(sys.argv[1])["failed"] else 0)' "$out"
    nox_chk "SHA контура неизменен за прогон" python3 -c 'import json,sys;sys.exit(0 if json.loads(sys.argv[1])["sha_stable"] else 1)' "$out"
    nox_verdict
  }
  nox_run_task
}
