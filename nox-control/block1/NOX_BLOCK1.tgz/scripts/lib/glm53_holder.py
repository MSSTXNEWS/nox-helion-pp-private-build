#!/usr/bin/env python3
"""Держатель GLM-5.3 в RAM (развитие nox_glm53_ram_load.sh из канона 24.1).
Аргументы: manifest.json  OUT_DIR  mode(shm|memfd)  [threads=4]. Манифест (имена, размеры, sha256, ревизия) строит P2-01 из HF API.
shm: файлы в /dev/shm (докачка по Range) + симлинки в OUT_DIR. memfd: memfd_create в этом процессе + симлинки на /proc/PID/fd/N; процесс НЕ убивать.
Статус пишется в OUT_DIR/../run/glm53_holder.json. Код выхода 0 только если все файлы докачаны до точного размера."""
import json, os, sys, threading, time, urllib.parse, urllib.request, urllib.error
KEEP = []  # живые memfd-объекты (нельзя закрывать)

man = json.load(open(sys.argv[1])); OUT = sys.argv[2]; MODE = sys.argv[3]; TH = int(sys.argv[4]) if len(sys.argv) > 4 else 4
RUN = os.path.join(os.path.dirname(OUT.rstrip("/")), "run"); os.makedirs(RUN, exist_ok=True); os.makedirs(OUT, exist_ok=True)
TOK = os.environ.get("HF_TOKEN")
BASE = "https://huggingface.co/%s/resolve/%s/" % (man["repo"], man["sha"])

class NoAuthRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        n = super().redirect_request(req, fp, code, msg, headers, newurl)
        if n is not None and urllib.parse.urlparse(newurl).netloc != urllib.parse.urlparse(req.full_url).netloc:
            n.headers.pop("Authorization", None); n.unredirected_hdrs.pop("Authorization", None)
        return n
opener = urllib.request.build_opener(NoAuthRedirect)

status = {"mode": MODE, "pid": os.getpid(), "t_start": time.time(), "t_end": None, "files": {}, "errors": []}
lock = threading.Lock()
def save():
    with lock:
        json.dump(status, open(os.path.join(RUN, "glm53_holder.json"), "w"), indent=1)

def fetch(item):
    name = os.path.basename(item["path"]); size = item["size"]; link = os.path.join(OUT, name)
    if MODE == "shm":
        path = "/dev/shm/" + name
        if os.path.exists(path) and os.path.getsize(path) > size:
            os.remove(path)
        f = open(path, "ab"); done = f.tell()
    else:
        fd = os.memfd_create(name, 0); f = os.fdopen(fd, "r+b", buffering=0); path = "/proc/%d/fd/%d" % (os.getpid(), fd); done = 0
        KEEP.append(f)
    attempt = 0
    while done < size and attempt < 60:
        try:
            r = urllib.request.Request(BASE + item["path"])
            if TOK: r.add_header("Authorization", "Bearer " + TOK)
            if done: r.add_header("Range", "bytes=%d-" % done)
            with opener.open(r, timeout=120) as resp:
                while True:
                    b = resp.read(16 << 20)
                    if not b: break
                    f.write(b); done += len(b)
        except Exception as e:
            attempt += 1; print("%s: retry %d at %.1f GB: %s" % (name, attempt, done / 1e9, e), flush=True); time.sleep(10)
    f.flush()
    if MODE == "shm": f.close()
    ok = done == size
    if ok:
        if os.path.islink(link) or os.path.exists(link): os.remove(link)
        os.symlink(path, link)
    else:
        status["errors"].append("%s: %d из %d байт" % (name, done, size))
    status["files"][name] = {"path": path, "link": link, "size": size, "ok": ok}; save()
    print(("OK " if ok else "FAIL ") + name, "%.2f GB" % (done / 1e9), flush=True)

sem = threading.Semaphore(TH)
def worker(it):
    with sem: fetch(it)
ths = [threading.Thread(target=worker, args=(it,)) for it in man["files"]]
[t.start() for t in ths]; [t.join() for t in ths]
status["t_end"] = time.time(); save()
good = not status["errors"] and len(status["files"]) == len(man["files"])
print("ALL_DONE" if good else "INCOMPLETE", flush=True)
if not good: sys.exit(1)
if MODE == "memfd":
    print("Держатель memfd живёт, пока жив процесс. Не убивать.", flush=True)
    while True: time.sleep(3600)
