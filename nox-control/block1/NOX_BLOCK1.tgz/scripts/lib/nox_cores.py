#!/usr/bin/env python3
"""Ядра C01-C08, реестр endpoint-ов и guard единого active_model_id (P3-01) + сборка промпта с профилями ядер (P3-02).
cores.yaml пишется в формате JSON (валидный YAML 1.2), читается стандартным json."""
import hashlib, json, os, sys, time

CORES = [
    ("C01", "CONSCIOUSNESS", "стратегия, цели, планирование, модель себя, прямой чат"),
    ("C02", "PERSONA", "характер, черты, поведение, эмоциональная оценка, тон RU/ES"),
    ("C03", "ATLAS", "знания, FACT ATLAS, RAG, документы, цитаты, проверка фактов"),
    ("C04", "VOICE", "ASR/TTS, микрофон, звонки, устройства"),
    ("C05", "REFLECTION", "ошибки, self-check, экзамены, калибровка уверенности, дрейф"),
    ("C06", "CORE", "runtime, ресурсы, CPU/GPU/RAM/VRAM, resource governor"),
    ("C07", "NEXUS", "провайдеры, области доступа, маршруты, реестр провайдеров"),
    ("C08", "FORGE", "создание, код, инструменты, веса, LoRA/QLoRA, GPU-задачи"),
]
CLASS_TO_CORE = {"chat": "C01", "persona": "C02", "knowledge": "C03", "voice": "C04", "reflection": "C05",
                 "system": "C06", "routing": "C07", "build": "C08"}

def build_registry(main_url, main_model_id, judge_url=None):
    eps = [{"id": main_model_id, "role": "main", "url": main_url, "active": True}]
    if judge_url:
        eps.append({"id": "junior_judge", "role": "fast_tier", "url": judge_url, "active": True})
    return {"active_model_id": main_model_id, "endpoints": eps,
            "cores": [{"id": i, "name": n, "purpose": p, "model": main_model_id if i in ("C01", "C08") else "per_core_registry"} for i, n, p in CORES]}

def check_registry(reg, live_main_ports=None):
    """Возвращает список нарушений: должен быть ровно один активный main endpoint, совпадающий с active_model_id."""
    v = []
    mains = [e for e in reg["endpoints"] if e.get("role") == "main" and e.get("active")]
    if len(mains) != 1:
        v.append("активных main endpoint-ов: %d (нужен ровно 1)" % len(mains))
    elif mains[0]["id"] != reg.get("active_model_id"):
        v.append("active_model_id не совпадает с единственным main endpoint")
    if live_main_ports is not None and len(set(live_main_ports)) > 1:
        v.append("работает несколько процессов главной модели на портах %s" % sorted(set(live_main_ports)))
    return v

def live_main_ports(match="glm"):
    ports = []
    for p in os.listdir("/proc"):
        if not p.isdigit():
            continue
        try:
            argv = open("/proc/%s/cmdline" % p, "rb").read().decode(errors="replace").split("\0")
        except OSError:
            continue
        if argv and (os.path.basename(argv[0]).startswith("llama-server") or any(a.endswith("llama-server") for a in argv[:3])):
            joined = " ".join(argv).lower()
            if match in joined and "--port" in argv:
                ports.append(argv[argv.index("--port") + 1])
    return ports

def prefix_block():
    return "Ядра NOX (профили, неизменный блок):\n" + "\n".join("%s %s: %s" % c for c in CORES)

def assemble(soul, mode, core, cls, user_text, status_tail, log_path):
    """system = душа -> режим -> core-память -> профили ядер (всё стабильно); указатель активного ядра и время/статус - только в конец user."""
    core_id = CLASS_TO_CORE[cls]
    system = "\n\n".join([soul.strip(), mode.strip(), core.strip(), prefix_block()])
    user = "%s\n[активное ядро: %s]\n%s" % (user_text, core_id, status_tail)
    msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps({"t": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "class": cls, "active_core": core_id,
                            "prefix_sha": hashlib.sha256(system.encode()).hexdigest()[:16],
                            "cores_in_prefix": [c[0] for c in CORES]}, ensure_ascii=False) + "\n")
    return msgs

if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "write":      # write <out> <main_url> <main_model_id> [judge_url]
        json.dump(build_registry(sys.argv[3], sys.argv[4], sys.argv[5] if len(sys.argv) > 5 else None), open(sys.argv[2], "w"), ensure_ascii=False, indent=1)
    elif cmd == "check":    # check <registry>  (с учётом реально работающих процессов)
        v = check_registry(json.load(open(sys.argv[2])), live_main_ports())
        for x in v: print("НАРУШЕНИЕ:", x)
        sys.exit(1 if v else 0)
    elif cmd == "selftest": # синтетический реестр с двумя активными main -> обязан дать нарушение; корректный -> нет
        good = build_registry("http://x:1", "m")
        bad = json.loads(json.dumps(good)); bad["endpoints"].append({"id": "m2", "role": "main", "url": "http://x:2", "active": True})
        ok = not check_registry(good) and bool(check_registry(bad)) and bool(check_registry(good, ["1", "2"]))
        print(json.dumps({"two_endpoints_detected": ok})); sys.exit(0 if ok else 1)
