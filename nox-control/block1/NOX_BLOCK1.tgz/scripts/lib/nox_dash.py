#!/usr/bin/env python3
"""Статический дашборд из monitor.csv: последние 120 строк + максимумы. Без внешних библиотек."""
import csv, html, sys
rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8")))[-120:]
if not rows:
    sys.exit(0)
def mx(k):
    v = []
    for r in rows:
        try: v.append(float(r[k]))
        except (ValueError, TypeError): continue
    return max(v) if v else None
head = "<h3>NOX monitor</h3><p>строк: %d; max t GPU: %s; max VRAM MiB: %s; max majflt: %s</p>" % (len(rows), mx("gpu_temp_c"), mx("vram_used_mib"), mx("llama_majflt"))
cols = list(rows[0].keys())
body = "<table border=1 cellpadding=3><tr>%s</tr>%s</table>" % ("".join("<th>%s</th>" % c for c in cols),
        "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % html.escape(r[c] or "") for c in cols) for r in rows[::-1]))
open(sys.argv[2], "w", encoding="utf-8").write("<!doctype html><meta charset=utf-8><meta http-equiv=refresh content=10>" + head + body)
