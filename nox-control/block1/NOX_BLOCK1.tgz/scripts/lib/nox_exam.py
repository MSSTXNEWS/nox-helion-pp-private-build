#!/usr/bin/env python3
"""Мини-экзамен 20 вопросов (exam/exam20.jsonl): temperature 0, seed 1, оценка регулярками по content (без судьи-LLM, поэтому судья != обучавшийся выполняется по построению).
selftest: gold проходит свой rx, wrong - нет (проверка эталона без сервера). run: гонит вопросы через сервер, баллы = число верных из 20."""
import argparse, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nox_llm

def load(path):
    return [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]

def selftest(items):
    bad = [i["id"] for i in items if not re.search(i["rx"], i["gold"]) or re.search(i["rx"], i["wrong"])]
    return {"questions": len(items), "bad_ids": bad, "ok": len(items) == 20 and not bad}

def run(url, items, extra, max_tokens):
    res = []
    for i in items:
        r = nox_llm.chat(url, [{"role": "user", "content": i["q"]}], max_tokens,
                         dict({"temperature": 0, "seed": 1}, **extra))
        ok = bool(re.search(i["rx"], r["content"].strip()))
        res.append({"id": i["id"], "ok": ok, "answer": r["content"].strip()[:80], "total_s": round(r["total"], 1)})
    return {"score": sum(1 for x in res if x["ok"]), "of": len(items), "details": res}

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("mode", choices=["selftest", "run"])
    ap.add_argument("--file", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "exam", "exam20.jsonl"))
    ap.add_argument("--url"); ap.add_argument("--extra", default=os.environ.get("NOX_EXAM_EXTRA", '{"chat_template_kwargs":{"reasoning_effort":"low"}}'))
    ap.add_argument("--max-tokens", type=int, default=int(os.environ.get("NOX_EXAM_MAX_TOKENS", "2048")))
    a = ap.parse_args(); items = load(a.file)
    out = selftest(items) if a.mode == "selftest" else run(a.url, items, json.loads(a.extra), a.max_tokens)
    print(json.dumps(out, ensure_ascii=False))
    sys.exit(0 if (a.mode == "run" or out["ok"]) else 1)
