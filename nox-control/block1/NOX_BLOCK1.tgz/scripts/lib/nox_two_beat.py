#!/usr/bin/env python3
"""Двухтактный ответ (Talker-Reasoner), проверка T10.7: быстрый тир даёт реплику-такт без фактов, GLM даёт итог, NLI-проверка (судья) ищет противоречия между репликой и итогом.
Здесь проверяется содержательная часть (реплика + итог + NLI). Отрисовка потока (перефразирование чанков, «тишина-токен» раз в 1 с) - слой UI/прокси и этим тестом не покрывается."""
import argparse, json, os, re, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nox_llm as L

TOPICS = ["фотосинтезе", "хеш-таблицах", "столице Франции", "протоколе TCP", "теореме Пифагора", "кэше процессора", "вулканах", "электронной почте",
          "гравитации", "двоичной системе", "бэкапах данных", "квантовании моделей", "иммунной системе", "системе доменных имён", "циклах сна",
          "языке Python", "плотности воды", "эволюции", "шифровании", "морских приливах", "магнитном поле Земли", "базах данных", "радуге", "блокчейне", "солнечной энергии"]
TEMPL = ["Расскажи кратко о {t}.", "Что важно знать о {t}?"]
TALKER = "Ты быстрый тир ассистента NOX. Ответь ОДНОЙ короткой вступительной репликой (до 15 слов), что сейчас займёшься вопросом. Не сообщай никаких фактов и цифр."
NLI = ("Реплика А: «{a}»\nИтоговый ответ Б: «{b}»\nПротиворечит ли реплика А итоговому ответу Б по смыслу или фактам? Ответь одним словом: ДА или НЕТ.")

def dialogs(n):
    out = [TEMPL[i % 2].format(t=TOPICS[(i // 2) % len(TOPICS)]) for i in range(n)]
    return out

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--glm", required=True); ap.add_argument("--judge", required=True)
    ap.add_argument("--n", type=int, default=50); ap.add_argument("--max-tokens", type=int, required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args(); rows = []
    for q in dialogs(a.n):
        t = L.chat(a.judge, [{"role": "system", "content": TALKER}, {"role": "user", "content": q}], 40, {"temperature": 0, "chat_template_kwargs": {"enable_thinking": False}})
        g = L.chat(a.glm, [{"role": "user", "content": q}], a.max_tokens, {"temperature": 1.0, "chat_template_kwargs": {"reasoning_effort": "low", "clear_thinking": True}})
        v = L.chat(a.judge, [{"role": "user", "content": NLI.format(a=t["content"].strip(), b=g["content"].strip()[:1500])}], 8, {"temperature": 0, "chat_template_kwargs": {"enable_thinking": False}})
        contra = bool(re.search(r"\bДА\b", v["content"].upper()))
        rows.append({"q": q, "talker": t["content"].strip(), "talker_s": round(t["total"], 2), "final_empty": not g["content"].strip(), "contradiction": contra})
        print(json.dumps(rows[-1], ensure_ascii=False), flush=True)
    res = {"n": len(rows), "contradictions": sum(r["contradiction"] for r in rows), "empty_final": sum(r["final_empty"] for r in rows),
           "talker_p95_s": L.pct([r["talker_s"] for r in rows], .95), "rows": rows}
    json.dump(res, open(a.out, "w"), ensure_ascii=False, indent=1)
