#!/usr/bin/env bash
# Независимый watchdog NOX. Читает $NOX_WD_CONF_DIR/*.conf (shell-фрагменты):
#   NAME=llama  CMD='...команда запуска (exec)...'  [HEALTH_URL=http://127.0.0.1:8080]  [MAX_RESTARTS=3]  [WINDOW_S=600]  [GRACE_S=60]  [ORDER=10]
# Правила: здоровье = /proc/PID/stat (не T/Z) + HEALTH_URL (если задан) после GRACE_S; STOP-флаг и замки обслуживания => не рестартовать;
# T без замка паузы > 60 с => kill -CONT по ORDER при свободной памяти >= 5% лимита (9.7 п.2); лимит рестартов => красное событие и halt до удаления $STATE/NAME.halted.
set -uo pipefail
. "$(dirname "$0")/nox_common.sh"
CONF="${NOX_WD_CONF_DIR:-$NOX_ROOT/services.d}"; ST="${NOX_WD_STATE:-$NOX_RUN_DIR/wd}"; IV="${NOX_WD_INTERVAL:-5}"
mkdir -p "$CONF" "$ST" "$NOX_LOG_DIR"; echo $$ >"$ST/watchdog.pid"
maint_active() { local f now; now=$(date +%s); for f in "$NOX_MAINT_DIR"/*.lock; do [ -e "$f" ] || continue
  local u; u="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["until"])' "$f" 2>/dev/null || echo 0)"; [ "$u" -gt "$now" ] && return 0; done; return 1; }
start_svc() { # NAME CMD
  setsid nohup bash -c "exec $2" >>"$NOX_LOG_DIR/$1.service.log" 2>&1 & echo $! >"$ST/$1.pid"; date +%s >"$ST/$1.started"; : >"$ST/$1.tsince"; }
check_one() {
  local NAME CMD HEALTH_URL MAX_RESTARTS=3 WINDOW_S=600 GRACE_S=60 ORDER=10
  # shellcheck disable=SC1090
  . "$1"; : "${NAME:?}" "${CMD:?}"
  [ -e "$ST/$NAME.halted" ] && return 0
  [ -e "$NOX_STOP_FLAG" ] && return 0
  maint_active && return 0
  local pid st now started ok=1; now=$(date +%s); pid="$(cat "$ST/$NAME.pid" 2>/dev/null || true)"
  st=""; [ -n "$pid" ] && st="$(nox_pid_state "$pid")"
  if [ "$st" = T ]; then
    [ -s "$ST/$NAME.tsince" ] || echo "$now" >"$ST/$NAME.tsince"
    if [ ! -e "$NOX_PAUSE_DIR/$pid.lock" ] && [ $((now - $(cat "$ST/$NAME.tsince"))) -gt 60 ]; then
      if [ "$(nox_ram_free)" -ge $(( $(nox_cg_mem_max) / 20 )) ]; then kill -CONT "$pid"; nox_red_event "$NAME: состояние T без замка >60 с, послан CONT"; : >"$ST/$NAME.tsince"
      else nox_red_event "$NAME: T без замка, но свободной памяти < 5% лимита - CONT не послан"; fi
    fi
    return 0
  fi
  : >"$ST/$NAME.tsince"
  started="$(cat "$ST/$NAME.started" 2>/dev/null || echo 0)"
  if [ -z "$st" ] || [ "$st" = Z ]; then ok=0
  elif [ -n "${HEALTH_URL:-}" ] && [ $((now - started)) -gt "$GRACE_S" ] && ! curl -fsS --max-time 5 "$HEALTH_URL" >/dev/null 2>&1; then
    local f="$ST/$NAME.hfail"; echo "$now" >>"$f"; [ "$(awk -v n="$now" '$1>n-30' "$f" | wc -l)" -ge 3 ] && { ok=0; kill -TERM "$pid" 2>/dev/null; sleep 5; kill -KILL "$pid" 2>/dev/null; : >"$f"; }
  fi
  [ "$ok" = 1 ] && return 0
  echo "$now" >>"$ST/$NAME.restarts"
  local n; n="$(awk -v n="$now" -v w="$WINDOW_S" '$1>n-w' "$ST/$NAME.restarts" | wc -l)"
  if [ "$n" -gt "$MAX_RESTARTS" ]; then : >"$ST/$NAME.halted"; nox_red_event "$NAME: лимит рестартов ($MAX_RESTARTS за ${WINDOW_S}с) - остановлен, нужен ручной разбор"; return 0; fi
  nox_log INFO "watchdog: рестарт $NAME ($n/$MAX_RESTARTS)"; start_svc "$NAME" "$CMD"
}
while :; do
  for c in $(grep -l '^ORDER=' "$CONF"/*.conf 2>/dev/null | xargs -r grep -H '^ORDER=' | sort -t= -k2 -n | cut -d: -f1) $(grep -L '^ORDER=' "$CONF"/*.conf 2>/dev/null); do
    [ -e "$c" ] && ( check_one "$c" ); done
  sleep "$IV"
done
