#!/usr/bin/env bash
# Сэмплер метрик каждые N с -> $NOX_REPORT_DIR/monitor.csv. Поля: ts,gpu_temp_c,vram_used_mib,cg_mem_cur,cg_mem_max,llama_pid,llama_state,llama_majflt,llama_decode_tps,gpu_util
# decode_tps берётся из /metrics llama-server (нужен флаг --metrics), иначе пусто. Hit-rate moe-cache в /metrics неизвестен -> не выдумывается.
set -uo pipefail
. "$(dirname "$0")/nox_common.sh"
IV="${NOX_MON_INTERVAL:-5}"; CSV="$NOX_REPORT_DIR/monitor.csv"; mkdir -p "$NOX_REPORT_DIR"
[ -s "$CSV" ] || echo "ts,gpu_temp_c,vram_used_mib,cg_mem_cur,cg_mem_max,llama_pid,llama_state,llama_majflt,llama_decode_tps,gpu_util" >"$CSV"
while :; do
  pid="$(nox_llama_pid)"; st=""; mf=""; tps=""
  [ -n "$pid" ] && { st="$(nox_pid_state "$pid")"; mf="$(sed 's/.*) //' /proc/$pid/stat | awk '{print $10}')"; }
  tps="$(curl -fsS --max-time 2 "$NOX_LLAMA_URL/metrics" 2>/dev/null | awk '/^llamacpp:predicted_tokens_seconds /{print $2}')"
  printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' "$(date -u +%FT%TZ)" "$(nox_gpu_temp 2>/dev/null)" "$(nox_vram_used_mib 2>/dev/null)" "$(nox_cg_mem_cur)" "$(nox_cg_mem_max)" "$pid" "$st" "$mf" "$tps" "$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')" >>"$CSV"
  python3 -B "$NOX_LIB_DIR/nox_dash.py" "$CSV" "$NOX_REPORT_DIR/dashboard.html" 2>/dev/null || true
  sleep "$IV"
done
