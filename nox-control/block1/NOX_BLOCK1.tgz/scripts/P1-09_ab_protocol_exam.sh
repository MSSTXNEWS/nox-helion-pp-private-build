#!/usr/bin/env bash
# ID: P1-09
# ЦЕЛЬ: протокол A/B (lib/ab.sh) и эталонный мини-экзамен 20 вопросов (exam/exam20.jsonl, temperature 0, seed 1, оценка регулярками без LLM-судьи).
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P1-08
# ГОТОВО: ab.sh и nox_exam.py на месте и исполняемы; эталон: 20 вопросов, у каждого gold проходит свой rx, wrong - не проходит (selftest); эталон скопирован в $NOX_ROOT/exam.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: exam/exam20.jsonl (написан для NOX; расширение/замена набора - решение владельца, поле rx проверяется selftest)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-09 S1 "$@"
NOX_PLAN="selftest эталона exam20.jsonl; копия в $NOX_ROOT/exam; проверка ab.sh --selftest"
t_pre() { nox_need_cmd python3; nox_need_file "$NOX_SCRIPTS_DIR/exam/exam20.jsonl"; }
t_do() { mkdir -p "$NOX_ROOT/exam" && cp -a "$NOX_SCRIPTS_DIR/exam/exam20.jsonl" "$NOX_ROOT/exam/"; }
t_check() {
  nox_chk "ab.sh исполняем" test -x "$NOX_LIB_DIR/ab.sh"
  nox_chk "эталон скопирован" cmp -s "$NOX_SCRIPTS_DIR/exam/exam20.jsonl" "$NOX_ROOT/exam/exam20.jsonl"
  nox_chk "ab.sh --selftest" "$NOX_LIB_DIR/ab.sh" --selftest
  nox_metric exam_questions "$(wc -l <"$NOX_SCRIPTS_DIR/exam/exam20.jsonl")"
  nox_verdict
}
nox_run_task
