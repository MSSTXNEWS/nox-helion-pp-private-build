#!/usr/bin/env bash
# ID: P1-11
# ЦЕЛЬ: системный пользователь nox; ядро, сторож и бэкапы только для чтения для nox; ежедневный снимок конфигов и S03.
# СЕРВЕР: S1,S2
# ЗАВИСИМОСТИ: P1-02
# ГОТОВО: запись из nox в каждый защищённый путь запрещена (проверка su nox -c touch); возможность чтения только фиксируется (под /root у nox по умолчанию нет доступа); снимок создан и читается; cron-задача установлена.
# ФАКТЫ, КОТОРЫЕ НУЖНЫ С СЕРВЕРА: NOX_PROTECT_PATHS (каталог(и) "ядра" NOX), NOX_SNAPSHOT_PATHS (каталог S03 и конфиги) - скрипт их не выдумывает.
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: apt: cron (если нет)
#   Генерируется: пользователь nox, /etc/cron.d/nox_snapshot, $NOX_BACKUP_DIR/daily/snap_*.tar.gz
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P1-11 S1,S2 "$@"
NOX_PLAN="useradd nox; chown root + chmod go-w на NOX_PROTECT_PATHS, бэкапы и lib; тест записи от nox; cron-снимок"
PROT="${NOX_PROTECT_PATHS:-} $NOX_BACKUP_DIR $NOX_LIB_DIR"
t_pre() { nox_need_var NOX_PROTECT_PATHS NOX_SNAPSHOT_PATHS; [ "$(id -u)" = 0 ] || nox_blocked "нужен root" "запуск от root"; nox_need_cmd useradd su; local p; for p in $NOX_PROTECT_PATHS; do nox_need_file "$p"; done; }
t_backup() { nox_backup /etc/passwd /etc/cron.d/nox_snapshot; stat -c '%n %U:%G %a' $PROT >"$NOX_RUN_DIR/P1-11.perms.prev"; }
t_rollback() { nox_restore || true; }
t_do() {
  id nox >/dev/null 2>&1 || { local g=(); getent group nox >/dev/null && g=(-g nox); useradd --system --create-home --shell /bin/bash "${g[@]}" nox; }
  local p; for p in $PROT; do chown -R root:root "$p"; chmod -R go-w "$p"; done
  chmod 750 "$NOX_BACKUP_DIR"; setfacl -m u:nox:rx "$NOX_BACKUP_DIR" 2>/dev/null || chmod 755 "$NOX_BACKUP_DIR"
  printf '17 3 * * * root %s >>%s/snapshot.log 2>&1\n' "$NOX_LIB_DIR/nox_snapshot.sh" "$NOX_LOG_DIR" >/etc/cron.d/nox_snapshot
  command -v cron >/dev/null 2>&1 || apt-get install -y cron >>"$NOX_LOGFILE" 2>&1 || nox_log WARN "apt-get install cron не удался"
  command -v cron >/dev/null 2>&1 || nox_blocked "cron недоступен на хосте" "установить cron либо настроить systemd-timer для lib/nox_snapshot.sh"
  pgrep -x cron >/dev/null || cron
}
t_check() {
  local p f
  nox_chk "пользователь nox есть" id nox
  for p in $PROT; do
    nox_metric "nox_reads_$(basename "$p")" "$(su -s /bin/bash nox -c "ls '$p' >/dev/null 2>&1" && echo yes || echo "no(нужен o+x на родителях, напр. chmod 711 /root, если сервисам nox это требуется)")"
    nox_chk "nox НЕ пишет в $p" bash -c "! su -s /bin/bash nox -c \"touch '$p/.nox_wtest'\" 2>/dev/null"
    rm -f "$p/.nox_wtest"
  done
  nox_chk "cron-задача установлена" test -s /etc/cron.d/nox_snapshot
  nox_metric cron_running "$(pgrep -x cron >/dev/null && echo yes || echo no)"
  f="$("$NOX_LIB_DIR/nox_snapshot.sh" 2>>"$NOX_LOGFILE")" || f=""
  nox_chk "снимок создан и читается" bash -c "[ -n '$f' ] && tar -tzf '$f' >/dev/null && sha256sum -c '$f.sha256'"
  nox_verdict
}
nox_run_task
