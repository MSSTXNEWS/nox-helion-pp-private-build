#!/usr/bin/env bash
# ID: P4-03
# ЦЕЛЬ: часовой инкрементальный бэкап S03 (restic: дедуп + шифрование) на склад и тест восстановления.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P4-01 (+P1-11, P1-12 по решению ревизии)
# ГОТОВО: restic-снимок создан, `restic check` ok, восстановление S03 в чистый каталог <= 600 с, восстановленная БД проходит integrity_check, хэши блоков проверены restic check; cron раз в час установлен.
# ФАКТЫ (не выдумываются): NOX_RESTIC_REPO (внешний диск/Hetzner SFTP: restic -r sftp:user@host:path), NOX_SNAPSHOT_PATHS (S03, личность, ядро, диспетчер, конфиги, слоты), NOX_S03_DB. Пароль репозитория: NOX_RESTIC_PASSWORD_FILE (если файла нет - создаётся случайный 0600; ВЛАДЕЛЬЦУ сохранить копию: без него бэкап не открыть).
# ИСТОЧНИКИ:
#   Drive: нет (ежедневный снимок <=100 МБ на Google Диск - rclone, отдельный шаг владельца, раздел 9.4)
#   Интернет: apt: restic (https://github.com/restic/restic, версия из репозитория ОС)
#   Генерируется: /etc/cron.d/nox_restic, restic-репозиторий, reports/P4-03_restore.json
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P4-03 S1 "$@"
NOX_PLAN="restic init (если нет); backup; check; restore во временный каталог; sha256; cron 0 * * * *"
PW="${NOX_RESTIC_PASSWORD_FILE:-$NOX_ROOT/owner/restic.pass}"
t_pre() { nox_need_receipt P4-01; nox_need_var NOX_RESTIC_REPO NOX_SNAPSHOT_PATHS NOX_S03_DB; nox_need_file "$NOX_S03_DB"
  command -v restic >/dev/null 2>&1 || { [ "$DRY" = 1 ] || apt-get install -y restic >>"$NOX_LOGFILE" 2>&1; command -v restic >/dev/null 2>&1 || [ "$DRY" = 1 ] || nox_blocked "restic не установлен" "apt install restic / релиз с GitHub"; }; }
t_backup() { nox_backup /etc/cron.d/nox_restic; }
t_rollback() { nox_restore || true; }
t_do() {
  mkdir -p "$(dirname "$PW")"; [ -s "$PW" ] || { umask 177; python3 -c 'import secrets;print(secrets.token_urlsafe(32))' >"$PW"; nox_log WARN "создан пароль restic $PW: владельцу СОХРАНИТЬ КОПИЮ"; }
  export RESTIC_REPOSITORY="$NOX_RESTIC_REPO" RESTIC_PASSWORD_FILE="$PW"
  restic cat config >/dev/null 2>&1 || restic init >>"$NOX_LOGFILE" 2>&1
  # shellcheck disable=SC2046,SC2086
  restic backup $NOX_SNAPSHOT_PATHS >>"$NOX_LOGFILE" 2>&1
  command -v cron >/dev/null 2>&1 || apt-get install -y cron >>"$NOX_LOGFILE" 2>&1
  # shellcheck disable=SC2046,SC2086
  printf '0 * * * * root RESTIC_REPOSITORY=%q RESTIC_PASSWORD_FILE=%q restic backup %s && RESTIC_REPOSITORY=%q RESTIC_PASSWORD_FILE=%q restic forget --keep-hourly 48 --keep-daily 14 >>%s/restic.log 2>&1\n' "$NOX_RESTIC_REPO" "$PW" "$NOX_SNAPSHOT_PATHS" "$NOX_RESTIC_REPO" "$PW" "$NOX_LOG_DIR" >/etc/cron.d/nox_restic
  pgrep -x cron >/dev/null || cron
}
t_check() {
  export RESTIC_REPOSITORY="$NOX_RESTIC_REPO" RESTIC_PASSWORD_FILE="$PW"
  nox_metric restic_version "$(restic version 2>/dev/null | head -1)"
  nox_chk "репозиторий открывается" restic cat config
  [ "$NOX_NFAIL" -eq 0 ] || return 1
  nox_chk "restic check" restic check
  local t0 t1 el d="$NOX_TMP/restore"; t0=$(date +%s); mkdir -p "$d"
  restic restore latest --target "$d" --include "$(dirname "$NOX_S03_DB")" >>"$NOX_LOGFILE" 2>&1 || { nox_log NO "restore не удался"; NOX_NFAIL=$((NOX_NFAIL+1)); return 1; }
  t1=$(date +%s); el=$((t1-t0)); nox_metric restore_s "$el"; nox_chk "восстановление <= 600 с" test "$el" -le 600
  nox_chk "восстановленная БД проходит integrity_check (хэши блоков проверены restic check)" python3 -B "$NOX_LIB_DIR/nox_s03.py" integrity "$d$NOX_S03_DB"
  nox_chk "cron-задача установлена" test -s /etc/cron.d/nox_restic
  nox_metric snapshots "$(restic snapshots --json 2>/dev/null | python3 -c 'import json,sys;print(len(json.load(sys.stdin)))')"
  nox_verdict
}
nox_run_task
