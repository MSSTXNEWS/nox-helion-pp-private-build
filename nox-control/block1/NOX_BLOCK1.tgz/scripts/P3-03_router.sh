#!/usr/bin/env bash
# ID: P3-03
# ЦЕЛЬ: роутер сложности на быстром тире: младший судья классифицирует Ур.1-4; слова «быстро»/«подумай» сдвигают уровень.
# СЕРВЕР: S1
# ЗАВИСИМОСТИ: P2-19
# ГОТОВО: совпадение с ручной разметкой >= 85% на 50 запросах (config/router_labels.jsonl; разметку составил Claude как стартовую - владелец/MEM может заменить файл на свою).
# ИСТОЧНИКИ:
#   Drive: нет
#   Интернет: нет
#   Генерируется: reports/P3-03_router.json (по каждому запросу: метка, предсказание, время), lib/nox_router.py (код роутера)
# ----
set -euo pipefail
. "$(dirname "$0")/lib/nox_common.sh"
nox_begin P3-03 S1 "$@"
LAB="${NOX_ROUTER_LABELS:-$NOX_SCRIPTS_DIR/config/router_labels.jsonl}"
NOX_PLAN="50 запросов -> судья (temperature 0, без thinking) -> сдвиг по ключевым словам -> доля совпадений"
t_pre() { nox_need_receipt P2-19; nox_need_file "$LAB"; nox_need_file "$NOX_RUN_DIR/fast_tier.json"; }
t_check() {
  local port; port="$(python3 -c 'import json;print(json.load(open("'"$NOX_RUN_DIR"'/fast_tier.json"))["ports"]["judge"])')"
  nox_health "http://$NOX_LLAMA_HOST:$port" >/dev/null || nox_blocked "судья не отвечает" "P2-19"
  local r; r="$(python3 -B "$NOX_LIB_DIR/nox_router.py" --judge "http://$NOX_LLAMA_HOST:$port" --labels "$LAB" --out "$NOX_REPORT_DIR/P3-03_router.json")" || nox_blocked "классификация не выполнена" "ответы судьи по /v1/chat/completions"
  nox_log INFO "$r"; nox_input "$LAB"
  nox_metric agree "$(python3 -c 'import json,sys;print(round(json.loads(sys.argv[1])["agree"],3))' "$r")"; nox_metric n "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["n"])' "$r")"; nox_metric judge_p95_s "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["p95_s"])' "$r")"
  nox_chk "50 запросов размечено" test "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["n"])' "$r")" -ge 50
  nox_chk "совпадение >= 85%" nox_ge "$(python3 -c 'import json,sys;print(json.loads(sys.argv[1])["agree"])' "$r")" 0.85
  nox_verdict
}
nox_run_task
