#!/usr/bin/env python3
"""Collect bounded, read-only Linux resource and serving-process preflight facts."""

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import http.client
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess


PROC = Path('/proc')
COMMAND_ENV = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LC_ALL': 'C'}
LLAMA_FLAGS = (
    '--flash-attn', '--load-mode', '--lazy-mode', '--cpu-moe', '--n-cpu-moe',
    '--moe-cache-mib', '--cache-ram', '--cache-reuse', '--slot-save-path',
    '--cache-type-k', '--cache-type-v', '--reasoning-effort', '--jinja',
    '--spec-type', '--n-gpu-layers', '--ctx-size', '--threads-batch',
)


def read_text(path):
    try:
        return path.read_text(encoding='utf-8', errors='replace').strip()
    except OSError:
        return None


def integer(value):
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def counters(raw):
    values = {}
    for line in (raw or '').splitlines():
        key, _, value = line.partition(' ')
        number = integer(value)
        if number is not None:
            values[key] = number
    return values


def decode_mount_field(value):
    return re.sub(r'\\([0-7]{3})', lambda match: chr(int(match[1], 8)), value)


def mounts(proc=PROC):
    rows = []
    for line in (read_text(proc / 'self/mountinfo') or '').splitlines():
        before, sep, after = line.partition(' - ')
        left, right = before.split(), after.split()
        if sep and len(left) >= 6 and right:
            rows.append({
                'device': left[2], 'root': decode_mount_field(left[3]),
                'mountpoint': decode_mount_field(left[4]), 'filesystem': right[0],
            })
    return rows


def cgroup_location(proc, mount_rows):
    relative = next((line[3:] for line in (read_text(proc / 'self/cgroup') or '').splitlines()
                     if line.startswith('0::/')), None)
    if relative is None:
        return None
    group = PurePosixPath(relative)
    if '..' in group.parts:
        return None
    candidates = []
    for row in mount_rows:
        if row['filesystem'] != 'cgroup2':
            continue
        root, mountpoint = PurePosixPath(row['root']), Path(row['mountpoint'])
        if group.is_relative_to(root):
            candidates.append((len(root.parts), mountpoint / group.relative_to(root), mountpoint, root))
        else:
            # A cgroup namespace can report a path relative to a delegated mount root.
            candidates.append((0, mountpoint.joinpath(*group.parts[1:]), mountpoint, root))
    for _, path, mountpoint, root in sorted(candidates, key=lambda item: item[0], reverse=True):
        if (path / 'memory.current').is_file() or (path / 'cgroup.controllers').is_file():
            return path, mountpoint, root
    return None


def cgroup_probe(proc=PROC, mount_rows=None):
    location = cgroup_location(proc, mounts(proc) if mount_rows is None else mount_rows)
    if location is None:
        return {'status': 'CGROUP_V2_UNAVAILABLE', 'ancestors': []}
    leaf, mountpoint, root = location
    rows, path = [], leaf
    cpuset = None
    while True:
        current = integer(read_text(path / 'memory.current'))
        maximum_raw = read_text(path / 'memory.max')
        maximum = integer(maximum_raw)
        high_raw = read_text(path / 'memory.high')
        high = integer(high_raw)
        quota, _, period_raw = (read_text(path / 'cpu.max') or '').partition(' ')
        quota_number, period = integer(quota), integer(period_raw)
        cpuset = cpuset or read_text(path / 'cpuset.cpus.effective')
        rows.append({
            'path': '/' + str(path.relative_to(mountpoint)) if path != mountpoint else '/',
            'current_bytes': current, 'limit_bytes': maximum,
            'limit_kind': 'unlimited' if maximum_raw == 'max' else 'finite' if maximum is not None else 'unknown',
            'headroom_bytes': max(0, maximum - current) if None not in (current, maximum) else None,
            'high_bytes': high,
            'high_kind': 'unlimited' if high_raw == 'max' else 'finite' if high is not None else 'unknown',
            'high_headroom_bytes': max(0, high - current) if None not in (current, high) else None,
            'cpu_quota_cores': quota_number / period if quota_number is not None and period else None,
            'memory_stat_bytes': {k: v for k, v in counters(read_text(path / 'memory.stat')).items()
                                  if k in {'anon', 'file', 'kernel', 'shmem', 'file_mapped', 'active_file', 'inactive_file'}},
            'memory_events': counters(read_text(path / 'memory.events')),
        })
        if path == mountpoint:
            break
        path = path.parent
    limits = [row['limit_bytes'] for row in rows if row['limit_bytes'] is not None]
    headrooms = [row['headroom_bytes'] for row in rows if row['headroom_bytes'] is not None]
    high_headrooms = [row['high_headroom_bytes'] for row in rows if row['high_headroom_bytes'] is not None]
    quotas = [row['cpu_quota_cores'] for row in rows if row['cpu_quota_cores'] is not None]
    complete = all(row['limit_kind'] != 'unknown' and
                   (row['limit_kind'] == 'unlimited' or row['current_bytes'] is not None) for row in rows)
    high_complete = all(row['high_kind'] != 'unknown' and
                        (row['high_kind'] == 'unlimited' or row['current_bytes'] is not None) for row in rows)
    return {
        'status': 'OK' if complete else 'PARTIAL', 'ancestors': rows,
        'ancestors_visibility': 'VISIBLE_MOUNT_SUBTREE' if root != PurePosixPath('/') else 'VISIBLE_NAMESPACE',
        'visible_memory_limit_bytes': min(limits, default=None),
        'visible_memory_headroom_bytes': min(headrooms, default=None),
        'effective_memory_limit_bytes': min(limits, default=None) if complete else None,
        'effective_memory_headroom_bytes': min(headrooms, default=None) if complete else None,
        'memory_high_status': 'OK' if high_complete else 'PARTIAL',
        'visible_memory_high_headroom_bytes': min(high_headrooms, default=None),
        'effective_memory_high_headroom_bytes': min(high_headrooms, default=None) if high_complete else None,
        'cpu_quota_cores': min(quotas, default=None), 'cpuset': cpuset,
    }


def host_memory(proc=PROC):
    keys = {'MemTotal': 'total_bytes', 'MemAvailable': 'available_bytes',
            'SwapTotal': 'swap_total_bytes', 'SwapFree': 'swap_free_bytes'}
    values = {}
    for line in (read_text(proc / 'meminfo') or '').splitlines():
        key, _, rest = line.partition(':')
        if key in keys:
            fields = rest.split()
            amount = integer(fields[0]) if fields else None
            if amount is not None and fields[1:] == ['kB']:
                values[keys[key]] = amount * 1024
    return values


def cpu_probe(proc=PROC):
    try:
        affinity = sorted(os.sched_getaffinity(0))
    except (AttributeError, OSError):
        affinity = None
    processors = []
    for block in (read_text(proc / 'cpuinfo') or '').split('\n\n'):
        fields = dict((key.strip(), value.strip()) for key, sep, value in
                      (line.partition(':') for line in block.splitlines()) if sep)
        cpu_id = integer(fields.get('processor'))
        if cpu_id is not None and (affinity is None or cpu_id in affinity):
            processors.append(fields)
    topology = {(item['physical id'], item['core id']) for item in processors
                if 'physical id' in item and 'core id' in item}
    topology_known = bool(processors) and all('physical id' in row and 'core id' in row for row in processors)
    flags = [set(item.get('flags', item.get('Features', '')).split()) for item in processors]
    return {
        'logical_affinity_count': len(affinity) if affinity is not None else None,
        'physical_affinity_cores': len(topology) if topology_known else None,
        'affinity': affinity, 'flags': sorted(set.intersection(*flags)) if flags else [],
        'model': sorted({item['model name'] for item in processors if 'model name' in item}),
    }


def filesystem_probe(path, mount_rows):
    try:
        path = path.resolve()
    except (OSError, RuntimeError) as error:
        return {'path': str(path), 'status': type(error).__name__}
    records = [row for row in mount_rows if path.is_relative_to(row['mountpoint'])]
    mount = max(records, key=lambda row: len(row['mountpoint']), default={})
    result = {'path': str(path), **{k: mount.get(k) for k in ('filesystem', 'mountpoint', 'device')}}
    try:
        sample = os.statvfs(path)
    except OSError as error:
        return {**result, 'status': type(error).__name__}
    return {**result, 'status': 'OK', 'total_bytes': sample.f_blocks * sample.f_frsize,
            'available_bytes': sample.f_bavail * sample.f_frsize,
            'read_only_mount': bool(sample.f_flag & os.ST_RDONLY)}


def capture(command, timeout, **options):
    return subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          text=True, errors='replace', check=False, timeout=timeout,
                          env=COMMAND_ENV, **options)


def gpu_probe():
    binary = shutil.which('nvidia-smi', path=COMMAND_ENV['PATH'])
    if binary is None:
        return {'status': 'NVIDIA_SMI_UNAVAILABLE', 'devices': []}
    query = 'index,name,driver_version,memory.total,memory.used,memory.free,pci.bus_id'
    arguments = ['--format=csv,noheader,nounits']
    try:
        result = capture([binary, f'--query-gpu={query},compute_cap', *arguments], 5)
        fields = 8
        if result.returncode:
            result = capture([binary, f'--query-gpu={query}', *arguments], 5)
            fields = 7
    except (OSError, subprocess.TimeoutExpired) as error:
        return {'status': type(error).__name__, 'devices': []}
    if result.returncode or len(result.stdout) > 32768:
        return {'status': 'GPU_QUERY_FAILED', 'exit_code': result.returncode, 'devices': []}
    devices = []
    for row in csv.reader(result.stdout.splitlines(), skipinitialspace=True):
        if len(row) != fields:
            return {'status': 'GPU_QUERY_FORMAT', 'devices': []}
        index, name, driver, total, used, free, bus, *extra = row
        compute = extra[0].strip() if extra else ''
        devices.append({'index': integer(index), 'name': name.strip(), 'driver_version': driver.strip(),
                        'total_mib': integer(total), 'used_mib': integer(used),
                        'free_mib': integer(free), 'pci_bus_id': bus.strip(),
                        'compute_capability': compute if re.fullmatch(r'\d+\.\d+', compute) else None})
    complete = bool(devices) and all(None not in (row['index'], row['total_mib'], row['used_mib'], row['free_mib'])
                                     for row in devices)
    return {'status': 'OK' if complete else 'PARTIAL', 'devices': devices}


def stat_identity(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


def llama_probe(path, expected_sha):
    if path is None:
        return {'status': 'NOT_REQUESTED', 'capabilities': {}}
    report = {'path': str(path), 'pin_matches': None, 'capabilities': {}}
    try:
        resolved = path.resolve(strict=True)
        fd = os.open(resolved, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        with os.fdopen(fd, 'rb') as binary:
            original = os.fstat(fd)
            if not stat.S_ISREG(original.st_mode):
                return {**report, 'status': 'NOT_REGULAR'}
            hasher = hashlib.sha256()
            for chunk in iter(lambda: binary.read(1024 * 1024), b''):
                hasher.update(chunk)
            digest = hasher.hexdigest()
            report.update(path=str(resolved), sha256=digest, size_bytes=original.st_size)
            if stat_identity(os.fstat(fd)) != stat_identity(original):
                return {**report, 'status': 'FILE_CHANGED'}
            if expected_sha is None:
                return {**report, 'status': 'HASH_ONLY'}
            report['pin_matches'] = digest == expected_sha
            if not report['pin_matches']:
                return {**report, 'status': 'SHA256_MISMATCH'}
            result = capture([f'/proc/self/fd/{fd}', '--help'], 10, pass_fds=(fd,))
            if result.returncode or len(result.stdout) > 1048576:
                return {**report, 'status': 'HELP_FAILED', 'exit_code': result.returncode}
            if stat_identity(os.fstat(fd)) != stat_identity(original):
                return {**report, 'status': 'FILE_CHANGED'}
            detected = set(re.findall(r'(?<![\w-])--[a-z][a-z0-9-]*', result.stdout))
            capabilities = {flag: flag in detected for flag in LLAMA_FLAGS}
            return {**report, 'status': 'OK' if any(capabilities.values()) else 'HELP_UNRECOGNIZED',
                    'capabilities': capabilities}
    except (OSError, RuntimeError, subprocess.TimeoutExpired) as error:
        return {**report, 'status': type(error).__name__}


def health_probe(port):
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=2)
    try:
        connection.request('GET', '/health')
        with connection.getresponse() as response:
            return {'port': port, 'http_status': response.status, 'ok': response.status == 200}
    except (OSError, http.client.HTTPException) as error:
        return {'port': port, 'ok': False, 'status': type(error).__name__}
    finally:
        connection.close()


def instance_identity():
    labels = [os.environ[key] for key in ('VAST_CONTAINERLABEL', 'CONTAINER_ID') if os.environ.get(key)]
    if not labels:
        return {'status': 'UNAVAILABLE', 'instance_id': None}
    pinned = {label.removeprefix('C.') for label in labels}
    if len(pinned) != 1 or not re.fullmatch(r'[1-9][0-9]{0,19}', next(iter(pinned))):
        return {'status': 'UNRECOGNIZED_OR_CONFLICTING', 'instance_id': None}
    return {'status': 'ENVIRONMENT_LABEL_ONLY', 'instance_id': int(next(iter(pinned)))}


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--disk-path', action='append', type=Path, metavar='PATH',
                        help='also inspect this filesystem path; repeatable')
    parser.add_argument('--llama-server', type=Path, metavar='PATH', help='hash an explicit llama-server binary')
    parser.add_argument('--llama-sha256', metavar='HEX', help='only execute --help when the binary matches this pin')
    parser.add_argument('--health-port', action='append', type=int, metavar='PORT',
                        help='also GET http://127.0.0.1:PORT/health without credentials; repeatable')
    parser.add_argument('--expected-instance', type=int, metavar='ID',
                        help='require agreement with the local instance label before further checks')
    args = parser.parse_args(argv)
    if args.llama_sha256 is not None:
        args.llama_sha256 = args.llama_sha256.lower()
        if args.llama_server is None or not re.fullmatch(r'[0-9a-f]{64}', args.llama_sha256):
            parser.error('--llama-sha256 requires --llama-server and exactly 64 hex characters')
    if any(not 1 <= port <= 65535 for port in args.health_port or ()):
        parser.error('--health-port must be between 1 and 65535')
    if args.expected_instance is not None and args.expected_instance <= 0:
        parser.error('--expected-instance must be positive')
    return args


def main(argv=None):
    args = parse_args(argv)
    identity = instance_identity()
    report = {'schema': 'nox_server_probe_v1', 'read_only': True,
              'observed_at': datetime.now(timezone.utc).isoformat(), 'identity': identity}
    if args.expected_instance is not None and args.expected_instance != identity['instance_id']:
        report.update(status='HOLD_INSTANCE', expected_instance=args.expected_instance)
    else:
        mount_rows = mounts()
        paths = dict.fromkeys((Path('/dev/shm'), Path.cwd(), *(args.disk_path or ())))
        llama = llama_probe(args.llama_server, args.llama_sha256)
        report.update(status='HOLD_LLAMA_PIN' if args.llama_sha256 and llama['status'] != 'OK' else 'OBSERVED',
                      cgroup=cgroup_probe(mount_rows=mount_rows), host_memory=host_memory(), cpu=cpu_probe(),
                      filesystems=[filesystem_probe(path, mount_rows) for path in paths], gpu=gpu_probe(),
                      llama_server=llama, health=[health_probe(port) for port in dict.fromkeys(args.health_port or ())])
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return 0 if report['status'] == 'OBSERVED' else 2


if __name__ == '__main__':
    raise SystemExit(main())
