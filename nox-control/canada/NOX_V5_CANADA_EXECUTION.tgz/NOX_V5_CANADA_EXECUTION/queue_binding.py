#!/usr/bin/env python3
"""Count Original295 links in a supplied snapshot without attesting its producer."""

import argparse
import hashlib
import json
from pathlib import Path
import re


SCHEMA = "NOX_NATIVE_QUEUE_BINDING_V1"
EXPECTED_ORIGINALS = 295
DIGEST = re.compile(r"[0-9a-f]{64}")


class Hold(ValueError):
    """An input failure with a fixed diagnostic that discloses no record data."""


def member_id(value, error):
    if not isinstance(value, str) or not value or value.strip() != value:
        raise Hold(error)
    return value


def original_ids(catalog):
    if not isinstance(catalog, dict):
        raise Hold("INVALID_CATALOG")
    if "original_295_rows" in catalog:
        rows = catalog["original_295_rows"]
    else:
        cards = catalog.get("cards")
        if not isinstance(cards, list) or not all(isinstance(card, dict) for card in cards):
            raise Hold("INVALID_CATALOG")
        card_ids = [member_id(card.get("id"), "INVALID_CATALOG_ID") for card in cards]
        if len(set(card_ids)) != len(card_ids):
            raise Hold("DUPLICATE_CATALOG_ID")
        rows = [card for card in cards if card.get("origin") == "ORIGINAL_295"]
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise Hold("INVALID_ORIGINAL295_ROWS")
    ids = [member_id(row.get("id"), "INVALID_ORIGINAL295_ID") for row in rows]
    if len(ids) != EXPECTED_ORIGINALS or len(set(ids)) != EXPECTED_ORIGINALS:
        raise Hold("ORIGINAL295_CARDINALITY_OR_DUPLICATE")
    return set(ids)


def snapshot_rows(snapshot):
    if not isinstance(snapshot, dict):
        raise Hold("INVALID_NATIVE_SNAPSHOT")
    arrays = [snapshot[key] for key in ("items", "tasks", "jobs") if key in snapshot]
    if len(arrays) != 1 or not isinstance(arrays[0], list):
        raise Hold("EXPECTED_ONE_NATIVE_RECORD_ARRAY")
    return arrays[0]


def row_identity(row):
    if not isinstance(row, dict):
        raise Hold("INVALID_NATIVE_RECORD")
    aliases = [member_id(row[key], "INVALID_NATIVE_ID") for key in ("task_id", "TaskID") if key in row]
    if len(set(aliases)) > 1:
        raise Hold("CONFLICTING_NATIVE_ID_ALIASES")
    return aliases[0] if aliases else member_id(row.get("id"), "INVALID_NATIVE_ID")


def declared_parent(row):
    parents = [member_id(row[key], "INVALID_DECLARED_ORIGINAL_ID")
               for key in ("original_task_id", "parent_task_id") if row.get(key) is not None]
    if len(set(parents)) > 1:
        raise Hold("CONFLICTING_DECLARED_PARENT_IDS")
    return parents[0] if parents else None


def count_bindings(snapshot, catalog):
    originals = original_ids(catalog)
    rows = snapshot_rows(snapshot)
    seen = {}
    matched = set()
    direct = linked = outside = repeated = 0

    for row in rows:
        native_id = row_identity(row)
        if native_id in seen:
            # Mapping equality conflates JSON true, 1 and 1.0 in Python.
            if json.dumps(row, sort_keys=True) != json.dumps(seen[native_id], sort_keys=True):
                raise Hold("CONFLICTING_DUPLICATE_NATIVE_ID")
            repeated += 1
            continue
        seen[native_id] = row
        parent = declared_parent(row)
        if native_id in originals:
            if parent is not None and parent != native_id:
                raise Hold("CONFLICTING_DIRECT_ORIGINAL_BINDING")
            matched.add(native_id)
            direct += 1
        elif parent in originals:
            matched.add(parent)
            linked += 1
        else:
            outside += 1

    return {
        "snapshot_records": len(rows),
        "unique_native_ids": len(seen),
        "identical_duplicate_rows": repeated,
        "original295_catalog_count": len(originals),
        "original295_ids_matched": len(matched),
        "original295_direct_rows": direct,
        "original295_linked_rows": linked,
        "outside_original295_rows": outside,
    }


def unique_object(pairs):
    obj = dict(pairs)
    if len(obj) != len(pairs):
        raise Hold("DUPLICATE_JSON_KEY")
    return obj


def reject_nonstandard_number(_value):
    raise Hold("INVALID_JSON_NUMBER")


def read_json(path, expected_digest):
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if expected_digest is not None and digest != expected_digest:
        raise Hold("INPUT_SHA256_MISMATCH")
    content = json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_nonstandard_number)
    return content, digest


def sha_arg(value):
    value = value.lower()
    if not DIGEST.fullmatch(value):
        raise argparse.ArgumentTypeError("expected a 64-digit SHA-256")
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("native_snapshot", type=Path)
    parser.add_argument("--catalog", type=Path, required=True)
    parser.add_argument("--snapshot-sha256", type=sha_arg)
    parser.add_argument("--catalog-sha256", type=sha_arg)
    args = parser.parse_args(argv)

    report = {"schema": SCHEMA, "native_execution_enabled": False, "acceptance_verified": False}
    code = 0
    try:
        snapshot, snapshot_hash = read_json(args.native_snapshot, args.snapshot_sha256)
        catalog, catalog_hash = read_json(args.catalog, args.catalog_sha256)
        counts = count_bindings(snapshot, catalog)
        report.update(state="BINDINGS_COUNTED", snapshot_sha256=snapshot_hash, catalog_sha256=catalog_hash, **counts)
    except Hold as error:
        report.update(state="HOLD", reason=str(error))
        code = 2
    except (OSError, ValueError, RecursionError):
        report.update(state="HOLD", reason="INVALID_OR_UNREADABLE_JSON")
        code = 2

    print(json.dumps(report, sort_keys=True))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
