from copy import deepcopy
import json
import unittest

import model_handoff as trace


ACTIVE = "nox-bench-" + "ab" * 16
FOREIGN = "nox-bench-" + "cd" * 16
REVOKED = "nox-bench-" + "ef" * 16
SCOPE = {"owner": "qa-owner", "data_scope": "qa-project", "project": "consilium",
         "core": "C03", "persona": "qa-persona", "dialog": "dialog-1"}


def marker_digest(marker):
    return trace.digest(marker.encode("ascii"))


def observed_message(text):
    return trace.observe_messages(json.dumps({"messages": [{"role": "user", "content": text}]}).encode())


def build_trace():
    ingress = observed_message("What was the decided order?")
    handoff = observed_message("Scoped fact: " + ACTIVE)
    attempt = {"request_id": "request-1", "exchange_id": "exchange-1", "scope": SCOPE,
               "request_sha256": ingress["body_sha256"], "route_id": "resonance-model",
               "runtime_sha256": "a" * 64, "model_sha256": "b" * 64, "route_sha256": "d" * 64}
    kv = {"attempt": attempt, "exporter": "backend", "body_sha256": handoff["body_sha256"],
          "context_sha256": handoff["context_sha256"], "model_call_id": "model-call-1",
          "job_id": "job-1", "slot_scope": SCOPE, "revocation_epoch": 11,
          "slot_generation": "slot-2.gen15", "prefix_sha256": "c" * 64, "cached_tokens": 26,
          "cached_canary_sha256s": [marker_digest(ACTIVE)]}
    records = [
        {"event_id": "decision", "revision": 2, "scope": SCOPE, "state": "active",
         "canary_sha256": marker_digest(ACTIVE)},
        {"event_id": "decision", "revision": 1, "scope": SCOPE, "state": "revoked",
         "canary_sha256": marker_digest(REVOKED)},
        {"event_id": "decoy", "revision": 1, "scope": {**SCOPE, "core": "C04"}, "state": "active",
         "canary_sha256": marker_digest(FOREIGN)},
    ]
    return {"attempt": attempt, "ingress": {**ingress, "attempt": attempt},
            "ledger": {"attempt": attempt, "exporter": "s03-reader", "revocation_epoch": 11, "records": records},
            "required_canary_sha256s": [marker_digest(ACTIVE)],
            "model_handoffs": [{**handoff, "attempt": attempt, "exporter": "gateway-handoff", "model_call_id": "model-call-1"}],
            "backend_kv": kv,
            "backend_terminal": {key: kv[key] for key in ("attempt", "exporter", "body_sha256", "context_sha256",
                                                           "model_call_id", "job_id", "slot_generation")}
            | {"state": "done"}, "expected_terminal": "done"}


class ModelHandoffTest(unittest.TestCase):
    def assert_hold(self, fixture, code):
        with self.assertRaises(trace.TraceError) as failure:
            trace.verify(fixture)
        self.assertEqual(str(failure.exception), code)

    def test_same_attempt_seals_handoff_active_memory_and_cache(self):
        report = trace.verify(build_trace())
        self.assertEqual(report["backend_terminal"], "done")
        self.assertEqual(report["negative_control_canaries"], 2)
        self.assertEqual(report["observed_cached_tokens"], 26)
        self.assertFalse(report["independent_exporter_auth_verified"])
        self.assertFalse(report["live_acceptance"])

    def test_actual_outgoing_bytes_detect_foreign_and_revoked_evidence(self):
        for other in (FOREIGN, REVOKED):
            with self.subTest(other=other[:12]):
                fixture = build_trace()
                actual = observed_message("Authorized " + ACTIVE + " and leaked:" + other)
                fixture["model_handoffs"][0].update(actual)
                fixture["backend_kv"]["body_sha256"] = actual["body_sha256"]
                fixture["backend_terminal"]["body_sha256"] = actual["body_sha256"]
                self.assert_hold(fixture, "REVOKED_FOREIGN_OR_UNKNOWN_CANARY_IN_MODEL_INPUT")

    def test_early_clean_render_cannot_attest_different_backend_input(self):
        fixture = build_trace()
        fixture["backend_kv"]["body_sha256"] = observed_message("Late rebuild " + FOREIGN)["body_sha256"]
        self.assert_hold(fixture, "BACKEND_HANDOFF_DIGEST_MISMATCH")

    def test_previous_revision_cannot_reenter_even_if_labeled_active(self):
        fixture = build_trace()
        fixture["ledger"]["records"][1]["state"] = "active"
        fixture["model_handoffs"][0].update(observed_message("Old and new " + REVOKED + " " + ACTIVE))
        self.assert_hold(fixture, "REVOKED_FOREIGN_OR_UNKNOWN_CANARY_IN_MODEL_INPUT")

    def test_wrong_core_old_epoch_and_inherited_prefix_each_hold(self):
        for key, value, code in [
            ("slot_scope", {**SCOPE, "core": "C04"}, "KV_SCOPE_OR_EPOCH_MISMATCH"),
            ("revocation_epoch", 10, "KV_SCOPE_OR_EPOCH_MISMATCH"),
            ("cached_canary_sha256s", [marker_digest(REVOKED)], "UNAUTHORIZED_OR_STALE_KV_CANARY"),
        ]:
            with self.subTest(key=key):
                fixture = build_trace()
                fixture["backend_kv"][key] = value
                self.assert_hold(fixture, code)

    def test_ingress_canary_or_second_handoff_cannot_claim_recall(self):
        fixture = build_trace()
        fixture["ingress"]["canary_sha256s"] = [marker_digest(ACTIVE)]
        self.assert_hold(fixture, "CANARY_ALREADY_IN_USER_INPUT")
        fixture = build_trace()
        fixture["model_handoffs"].append(deepcopy(fixture["model_handoffs"][0]))
        self.assert_hold(fixture, "EXPECTED_EXACTLY_ONE_MODEL_HANDOFF")

    def test_cold_negative_only_trace_can_attest_one_cancelled_backend_job(self):
        fixture = build_trace()
        fixture["required_canary_sha256s"] = []
        handoff = observed_message("No authorized answer")
        fixture["model_handoffs"][0].update(handoff)
        fixture["backend_kv"].update(body_sha256=handoff["body_sha256"], context_sha256=handoff["context_sha256"],
                                    cached_tokens=0, cached_canary_sha256s=[])
        fixture["backend_terminal"].update(body_sha256=handoff["body_sha256"],
                                          context_sha256=handoff["context_sha256"], state="cancelled")
        fixture["expected_terminal"] = "cancelled"
        self.assertEqual(trace.verify(fixture)["backend_terminal"], "cancelled")
        fixture["backend_terminal"]["job_id"] = "unrelated-job"
        self.assert_hold(fixture, "BACKEND_JOB_MISMATCH")


if __name__ == "__main__":
    unittest.main()
