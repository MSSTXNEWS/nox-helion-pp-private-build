import copy
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import acceptance
import fetch_model
import model_plan
import shadow_glm


def synthetic_receipt():
    scope = dict(owner="a", data_scope="private", project="lab", persona="base", dialog="demo")
    turns = [
        dict(exchange=f"turn-{i}", scope=scope, terminal="done", visible_content=True,
             input_sha256="1" * 64, answer_sha256="2" * 64)
        for i in (1, 2)
    ]
    rows = [
        dict(id=f"m{i}-{role}", exchange=turn["exchange"], role=role, sha256=turn[field], scope=scope)
        for i, turn in enumerate(turns)
        for role, field in (("user", "input_sha256"), ("assistant", "answer_sha256"))
    ]
    return dict(scope=scope, browser_turns=turns, canonical_readback=rows,
                observer_ids={"runner": "r", "browser": "b", "s03_readback": "s"},
                continuation=dict(dialog="demo", canonical_rows_after_reload=[r["id"] for r in rows],
                                  same_exchange_replays_without_new_job=True),
                scope_probe=dict(foreign_scope_seen_by_model=False, positive_scoped_evidence_seen_by_model=True,
                                 foreign_before_sha256="3" * 64, foreign_after_sha256="3" * 64),
                stop=dict(request="stop-3", backend_request="stop-3", backend_terminal="cancelled",
                          events_after_terminal=0, unrelated_request_unchanged=True))


class FirstWaveTests(unittest.TestCase):
    def test_receipt_checks_paired_messages_without_promoting(self):
        data = synthetic_receipt()
        result = acceptance.verify(data)
        self.assertEqual(result["state"], "EVIDENCE_CONSISTENT")
        self.assertFalse(result["live_acceptance"])
        for key, mutation in [
            ("stop", {"backend_request": "wrong"}),
            ("continuation", {"same_exchange_replays_without_new_job": False}),
            ("scope_probe", {"foreign_scope_seen_by_model": True}),
        ]:
            changed = copy.deepcopy(data)
            changed[key].update(mutation)
            with self.assertRaises(ValueError):
                acceptance.verify(changed)

    def test_verified_release_inventory_is_exact(self):
        root = Path(__file__).parent
        cards = json.loads((root / "canon-v5-cards.json").read_text())
        optim = json.loads((root / "optimization-register.json").read_text())
        self.assertEqual(len({c["id"] for c in cards["cards"]}), 208)
        self.assertEqual(len({c["id"] for c in cards["original_295_rows"]}), 295)
        self.assertEqual(len({c["id"] for c in optim["optimizations"]}), 125)
        extras = {c["id"] for c in optim["canon_v5_supplement"]}
        self.assertEqual(extras, {f"A{i:02d}" for i in range(46, 57)} | {f"B{i:02d}" for i in range(81, 95)})
        self.assertTrue(extras.isdisjoint(c["id"] for c in optim["optimizations"]))
        self.assertEqual(len(model_plan.SHARDS), 11)
        self.assertEqual(sum(s.size_bytes for s in model_plan.SHARDS), 467_289_116_837)

    def test_stage_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            data = root / "data"
            data.write_bytes(b"fixture")
            alias = root / "alias"
            alias.symlink_to(data)
            self.assertEqual(fetch_model.file_size(data), 7)
            with self.assertRaises(ValueError):
                fetch_model.file_size(alias)

    def test_shadow_budget_rejects_wrong_instance_before_model_work(self):
        with patch.object(shadow_glm, "instance_identity", return_value={"instance_id": 60509551}):
            with self.assertRaisesRegex(ValueError, "does not match S1"):
                shadow_glm.observed_budget(4096, 100)

    def test_shadow_selects_explicit_mmap_without_inherited_overrides(self):
        self.assertEqual(shadow_glm.explicit_mmap_flag("--load-mode MODE\n  mmap: file map\n"), ["--load-mode", "mmap"])
        self.assertEqual(shadow_glm.explicit_mmap_flag("--mmap, --no-mmap"), ["--mmap"])
        with self.assertRaisesRegex(ValueError, "explicit mmap"):
            shadow_glm.explicit_mmap_flag("--no-mmap")
        env = shadow_glm.engine_environment({"CUDA_VISIBLE_DEVICES": "0", "LLAMA_ARG_LOAD_MODE": "none",
                                             "LD_PRELOAD": "unexpected", "NOX_API_TOKEN": "unused"})
        self.assertEqual(env, {"CUDA_VISIBLE_DEVICES": "0", "LC_ALL": "C"})

    def test_small_pilot_maps_and_hashes_regular_file(self):
        payload = b"test-mmap"
        digest = hashlib.sha256(payload).hexdigest()
        with tempfile.TemporaryDirectory() as raw:
            directory = Path(raw)
            (directory / "fixture.gguf").write_bytes(payload)
            shard = model_plan.Shard("fixture.gguf", len(payload), digest)
            directory_fd = model_plan.open_root(directory)
            try:
                result = model_plan.verify_shard(directory_fd, shard, model_plan.mount_types(), mapped=True)
            finally:
                os.close(directory_fd)
        self.assertEqual((result["state"], result["read_mode"], result["sha256"]), ("verified", "mmap", digest))
        with self.assertRaisesRegex(ValueError, "small first shard"):
            model_plan.verify("/unopened-directory", only=2, mmap_pilot=True)


if __name__ == "__main__":
    unittest.main()
