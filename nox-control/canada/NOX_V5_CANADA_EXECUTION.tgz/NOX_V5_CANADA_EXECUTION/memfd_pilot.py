"""Run a bounded, ephemeral S1 RAM-backing pilot with no model download."""

import argparse
import hashlib
import json
import mmap
import os
import sys

from host_admission import cgroup_budget
from server_probe import cgroup_probe, host_memory, instance_identity

GIB = 1024**3
CHUNK = 1024**2
S1_INSTANCE = 61825960


def ram_admission(group, host, reserve, payload, provider_headroom):
    required = reserve + payload
    rows = group.get("ancestors", [])
    hard_kind, hard = cgroup_budget(rows, "limit_bytes", "limit_kind")
    high_kind, high = cgroup_budget(rows, "high_bytes", "high_kind")
    reasons = []
    if group.get("status") != "OK" or hard_kind == "UNKNOWN" or high_kind == "UNKNOWN":
        reasons.append("CGROUP_LIMIT_UNKNOWN")
    if hard is not None and hard < required:
        reasons.append("CGROUP_MAX")
    if high is not None and high < required:
        reasons.append("CGROUP_HIGH")
    if type(host) is not int or host < required:
        reasons.append("HOST_AVAILABLE")
    if group.get("ancestors_visibility") != "VISIBLE_NAMESPACE" and provider_headroom is None:
        reasons.append("CGROUP_ANCESTOR_UNVERIFIED")
    elif provider_headroom is not None and provider_headroom < required:
        reasons.append("PROVIDER_HEADROOM")
    return reasons


def exercise(size, check_capacity):
    with os.fdopen(os.memfd_create("nox-s1-backing-pilot", os.MFD_CLOEXEC), "wb") as owner:
        fd = owner.fileno()
        os.ftruncate(fd, size)
        source, borrowed = hashlib.sha256(), hashlib.sha256()
        with mmap.mmap(fd, size, access=mmap.ACCESS_WRITE) as view:
            for offset in range(0, size, CHUNK):
                if offset % (256 * CHUNK) == 0:
                    check_capacity(size - offset)
                pattern = hashlib.sha256(offset.to_bytes(8, "big")).digest()
                block = (pattern * (CHUNK // len(pattern)))[:min(size - offset, CHUNK)]
                view[offset:offset + len(block)] = block
                source.update(block)
        with open(f"/proc/self/fd/{fd}", "rb") as reader:
            if (os.fstat(fd).st_dev, os.fstat(fd).st_ino) != (os.fstat(reader.fileno()).st_dev,
                                                            os.fstat(reader.fileno()).st_ino):
                raise ValueError("REOPENED_INODE_CHANGED")
            with mmap.mmap(reader.fileno(), size, access=mmap.ACCESS_READ) as view:
                for offset in range(0, size, CHUNK):
                    borrowed.update(view[offset:offset + CHUNK])
        if source.digest() != borrowed.digest():
            raise ValueError("MAPPED_SHA_MISMATCH")
        return source.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gib", type=int, choices=range(1, 21), default=20)
    parser.add_argument("--reserve-gib", type=int, required=True,
                        help="RAM headroom to retain during the pilot, based on the measured workload")
    parser.add_argument("--provider-headroom-bytes", type=int,
                        help="independent observed headroom before pilot where ancestors are outside the namespace")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args(argv)
    if args.reserve_gib <= 0 or args.provider_headroom_bytes is not None and args.provider_headroom_bytes <= 0:
        parser.error("headroom and reserve must be positive")
    size = args.gib * GIB
    result = {"schema": "nox_s1_memfd_pilot_v1", "instance": S1_INSTANCE,
              "payload_bytes": size, "reserve_bytes": args.reserve_gib * GIB,
              "model_downloaded": False, "production_modified": False}
    if not args.apply:
        print(json.dumps(result | {"state": "PLAN"}))
        return 0
    if instance_identity()["instance_id"] != S1_INSTANCE:
        print(json.dumps(result | {"state": "HOLD", "reasons": ["S1_INSTANCE_UNVERIFIED"]}))
        return 2

    def check(remaining):
        provider = args.provider_headroom_bytes
        if provider is not None:
            provider = max(0, provider - (size - remaining))
        reasons = ram_admission(cgroup_probe(), host_memory().get("available_bytes"),
                                result["reserve_bytes"], remaining, provider)
        if reasons:
            raise ValueError(",".join(reasons))

    try:
        check(size)
        payload_sha = exercise(size, check)
        result.update(state="PILOT_PASSED", payload_sha256=payload_sha)
    except (AttributeError, OSError, ValueError, MemoryError) as exc:
        result.update(state="HOLD", reasons=str(exc).split(",") if type(exc) is ValueError else [type(exc).__name__])
    print(json.dumps(result, sort_keys=True))
    return 0 if result["state"] == "PILOT_PASSED" else 2


if __name__ == "__main__":
    sys.exit(main())
