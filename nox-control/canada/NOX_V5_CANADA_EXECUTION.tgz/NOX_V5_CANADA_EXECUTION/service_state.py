"""Read only the verified process identity and optional loopback health of a NOX service."""

import argparse
import json
from pathlib import Path
import sys

from server_probe import health_probe, instance_identity

TARGETS = {"S1": 61825960, "S2": 60509551}
STOPPED = {"T", "t", "Z", "X", "x"}


def identity(proc, pid):
    with (proc / str(pid) / "stat").open("rb") as stream:
        raw = stream.read(8193)
    prefix, delimiter, fields = raw.rpartition(b") ")
    if len(raw) > 8192 or not delimiter or not prefix.startswith(f"{pid} (".encode()):
        raise ValueError("PROCESS_STAT_FORMAT")
    fields = fields.split()
    if len(fields) <= 19 or len(fields[0]) != 1:
        raise ValueError("PROCESS_STAT_FORMAT")
    return fields[0].decode("ascii"), int(fields[19])


def inspect(pid, ticks, port, proc=Path("/proc"), ping=health_probe):
    before, start = identity(proc, pid)
    if start != ticks:
        raise ValueError("PROCESS_GENERATION_CHANGED")
    receipt = {"pid": pid, "start_ticks": ticks, "kernel_state": before,
               "health_checked": False, "live_chat_verified": False}
    if before in STOPPED:
        return receipt | {"state": "HOLD_KERNEL", "health": None}
    if port is None:
        return receipt | {"state": "PROCESS_OBSERVED", "health": None}
    check = ping(port)
    after, start = identity(proc, pid)
    if start != ticks:
        raise ValueError("PROCESS_GENERATION_CHANGED")
    receipt.update(kernel_state=after, health_checked=True, health=check)
    if after in STOPPED:
        return receipt | {"state": "HOLD_KERNEL"}
    return receipt | {"state": "HEALTH_OBSERVED" if check.get("ok") is True else "HOLD_HEALTH"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", choices=TARGETS, required=True)
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--start-ticks", type=int, required=True)
    parser.add_argument("--health-port", type=int)
    args = parser.parse_args(argv)
    if min(args.pid, args.start_ticks) < 1 or args.health_port is not None and not 1 <= args.health_port <= 65535:
        parser.error("positive PID/start ticks and a valid local port are required")
    expected = TARGETS[args.target]
    try:
        if instance_identity()["instance_id"] != expected:
            raise ValueError("INSTANCE_LABEL_MISMATCH")
        result = inspect(args.pid, args.start_ticks, args.health_port)
    except (OSError, ValueError) as exc:
        result = {"state": "HOLD", "reason": str(exc) if type(exc) is ValueError else type(exc).__name__}
    print(json.dumps(result | {"schema": "nox_service_state_v1", "instance": expected,
                               "production_modified": False}))
    return 2 if result["state"].startswith("HOLD") else 0


if __name__ == "__main__":
    sys.exit(main())
