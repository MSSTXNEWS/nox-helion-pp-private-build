from contextlib import redirect_stdout
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO, StringIO
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import chat_bench as bench


FIXTURE = {
    "runtime": {"model_sha256": "a" * 64, "runtime_sha256": "b" * 64},
    "request": {"model": "local-fixture", "temperature": 0, "top_p": 1, "seed": 7, "max_tokens": 16},
    "cases": [{"id": "case-private", "messages": [
        {"role": "system", "content": "PRIVATE_SYSTEM"},
        {"role": "user", "content": "PRIVATE_FIRST_USER"},
        {"role": "assistant", "content": "PRIVATE_FIRST_ASSISTANT"},
        {"role": "user", "content": "PRIVATE_QUESTION"},
    ], "expected_exact": "PRIVATE_EXPECTED"}],
}


def canned_packet(delta, reason=None, model="local-fixture"):
    return (b"data: " + bench.json_bytes({"model": model, "choices": [
        {"index": 0, "delta": delta, "finish_reason": reason},
    ]}) + b"\r\n\r\n")


VALID_STREAM = (b": keepalive\r\n\r\n"
                + canned_packet({"role": "assistant"})
                + canned_packet({"reasoning_content": "PRIVATE_REASONING"})
                + canned_packet({"content": "  "})
                + canned_packet({"content": "PRIVATE_"})
                + canned_packet({"content": "EXPECTED"}, "stop")
                + b"data: [DONE]\r\n\r\n")


class BenchTest(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.path = Path(temp.name) / "fixture.json"
        self.path.write_bytes(bench.json_bytes(FIXTURE))
        self.digest = bench.sha256(self.path.read_bytes())
        self.case = FIXTURE["cases"][0]

    def run_cli(self, *args):
        output = StringIO()
        with redirect_stdout(output):
            code = bench.main(["--fixture", str(self.path), *args])
        return code, json.loads(output.getvalue()), output.getvalue()

    def parse(self, raw):
        values = iter([0.010, 0.020, 0.030, 0.040, 0.050, 0.060])
        sample = bench.make_sample(self.case)
        bench.parse_stream(BytesIO(raw), self.case, "local-fixture", 0, sample, lambda: next(values))
        return sample

    def test_offline_plan_never_connects_and_pins_ordered_cases(self):
        with patch.object(bench, "stage_request", side_effect=AssertionError("unexpected network")):
            code, result, raw = self.run_cli("--endpoint", "http://localhost:8001/v1/chat/completions")
        self.assertEqual(code, 0)
        self.assertEqual(result["fixture_sha256"], self.digest)
        self.assertEqual(result["cases_sha256"], bench.sha256(bench.json_bytes(FIXTURE["cases"])))
        self.assertEqual(result["summary"]["n_attempted"], 0)
        self.assertFalse(result["runtime_pins_independently_verified"])
        self.assertNotIn("PRIVATE_", raw)

    def test_apply_rejects_remote_hosts_unpinned_fixtures_and_unsafe_urls(self):
        with patch.object(bench, "stage_request", side_effect=AssertionError("unexpected network")):
            endpoint = "http://127.0.0.1:8001/v1/chat/completions"
            for args, expected in [
                (["--endpoint", endpoint], "APPLY_REQUIRES_ENDPOINT_AND_FIXTURE_SHA256"),
                (["--endpoint", endpoint, "--fixture-sha256", "0" * 64], "FIXTURE_SHA256_MISMATCH"),
                *[(["--endpoint", url, "--fixture-sha256", self.digest], "ENDPOINT_NOT_DIRECT_HTTP_LOOPBACK")
                  for url in ("http://127.0.0.2:80/v1/chat/completions", "http://example.test:80/v1/chat/completions",
                              "http://unused:SECRET@localhost:80/v1/chat/completions", endpoint + "?SECRET",
                              "http://localhost:80/../v1/chat/completions", "http://localhost:80/api/install/backup",
                              "http://[::ffff:127.0.0.1]:80/v1/chat/completions")],
            ]:
                with self.subTest(expected=expected):
                    code, result, raw = self.run_cli("--apply", *args)
                    self.assertEqual((code, result["error"], result["network_requests"]), (2, expected, 0))
                    self.assertNotIn("SECRET", raw)

    def test_visible_ttft_excludes_role_reasoning_whitespace_and_keepalive(self):
        result = self.parse(VALID_STREAM)
        self.assertEqual((result["first_sse_data_ms"], result["first_reasoning_ms"],
                          result["ttft_visible_ms"], result["full_response_ms"]), (10, 20, 40, 60))
        self.assertTrue(result["quality_pass"])
        self.assertIsNone(result["error"])

    def test_error_and_incomplete_or_truncated_streams_cannot_pass(self):
        text = {"content": "PRIVATE_EXPECTED"}
        cases = [
            (canned_packet(text, "stop"), "SSE_MISSING_DONE"),
            (canned_packet(text, "length") + b"data: [DONE]\n\n", None),
            (b"event: error\ndata: PRIVATE_SERVER_ERROR\n\n", "SERVER_SSE_ERROR"),
            (b"data: {bad}\n\n", "INVALID_SSE"),
            (canned_packet(text, "stop", model="PRIVATE_WRONG_MODEL"), "MODEL_ID_MISMATCH"),
            (b"data: [DONE]\n\n", "NO_VISIBLE_CONTENT"),
        ]
        for raw, error in cases:
            with self.subTest(error=error):
                got = self.parse(raw)
                self.assertEqual(got["error"], error)
                self.assertFalse(got["quality_pass"])
                self.assertNotIn("PRIVATE_", json.dumps(got))

    def test_sample_counts_include_failed_attempts_without_polluting_full_latency(self):
        good, partial = self.parse(VALID_STREAM), self.parse(canned_packet({"content": "partial"}))
        good["elapsed_ms"], partial["elapsed_ms"] = 65, 95
        summary = bench.summarize([good, partial])
        self.assertEqual((summary["n_attempted"], summary["n_complete"], summary["n_quality_pass"]), (2, 1, 1))
        self.assertEqual(summary["visible_ttft_all_observed"]["n"], 2)
        self.assertEqual(summary["full_completed"], {"n": 1, "p50_ms": 60, "p95_ms": 60})
        self.assertEqual(summary["elapsed_all_attempts"]["p95_ms"], 95)

    def test_loopback_apply_preserves_full_messages_and_does_not_follow_redirects(self):
        requests = []

        class StagingStub(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                message = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                requests.append((self.path, message, self.headers.get("Authorization")))
                if self.path.startswith("/redirect/"):
                    self.send_response(307)
                    self.send_header("Location", "http://127.0.0.1:1/v1/chat/completions")
                    self.end_headers()
                    return
                if self.path.startswith("/timeout/"):
                    time.sleep(0.2)
                    return
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.end_headers()
                self.wfile.write(VALID_STREAM)

        with ThreadingHTTPServer(("127.0.0.1", 0), StagingStub) as server:
            thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
            thread.start()
            try:
                port = server.server_port
                with patch.dict("os.environ", {"NOX_CHAT_BENCH_API_KEY": "PRIVATE_SECRET"}):
                    code, result, raw = self.run_cli("--apply", "--fixture-sha256", self.digest,
                                                     "--endpoint", f"http://localhost:{port}/v1/chat/completions")
                self.assertEqual((code, result["summary"]["n_quality_pass"]), (0, 1))
                self.assertEqual(requests[0][1], {**FIXTURE["request"], "stream": True, "n": 1,
                                                 "messages": self.case["messages"]})
                self.assertEqual(requests[0][2], "Bearer PRIVATE_SECRET")
                self.assertNotIn("PRIVATE_", raw)
                for prefix, expected in [("redirect", "HTTP_REDIRECT"), ("timeout", "TIMEOUT")]:
                    code, result, _ = self.run_cli("--apply", "--fixture-sha256", self.digest, "--timeout-s", "0.1",
                                                   "--endpoint", f"http://localhost:{port}/{prefix}/v1/chat/completions")
                    self.assertEqual((code, result["samples"][0]["error"]), (1, expected))
                self.assertEqual(len(requests), 3)
            finally:
                server.shutdown()
                thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
