#!/usr/bin/env python3
"""Probe a local staging llama.cpp server's actual GLM-5.3 template and API."""

import argparse
import http.client
import json
import math
import os
import re

from chat_bench import BenchError, json_bytes, loopback_endpoint, stage_request


CHAT_PATH = "/v1/chat/completions"
EFFORTS = ("low", "high", "max")
VISIBLE_MARKER = "NOX-GLM-53-READY"
HISTORY_THOUGHT = "NOX_OLD_SYNTHETIC_REASONING"
TOOL_THOUGHT = "NOX_CURRENT_SYNTHETIC_TOOL_REASONING"
MODEL_NAME = re.compile(r"glm[-_ ]?5[._-]?3", re.IGNORECASE)
MAX_JSON_BYTES = 1024 * 1024
TOOL = {
    "type": "function",
    "function": {
        "name": "nox_probe_echo",
        "description": "Return the given synthetic probe label unchanged.",
        "parameters": {
            "type": "object",
            "properties": {"label": {"type": "string"}},
            "required": ["label"],
            "additionalProperties": False,
        },
    },
}


def glm_request_settings(model, effort, max_tokens=512):
    """Publisher sampling baseline and GLM-specific template arguments."""
    if effort not in EFFORTS:
        raise ValueError("INVALID_GLM_REASONING_EFFORT")
    if not isinstance(model, str) or not model.strip():
        raise ValueError("INVALID_MODEL")
    if type(max_tokens) is not int or max_tokens < 1:
        raise ValueError("INVALID_MAX_TOKENS")
    return {
        "model": model,
        "reasoning_effort": effort,
        "chat_template_kwargs": {"reasoning_effort": effort, "clear_thinking": True},
        "temperature": 1.0,
        "top_p": 0.95,
        "min_p": 0.01,
        "max_tokens": max_tokens,
        "cache_prompt": True,
    }


def request_json(endpoint, path, data, timeout, api_key):
    host, port, _ = endpoint
    headers = {"Accept": "application/json", "Connection": "close"}
    if api_key:
        headers["Authorization"] = "Bearer " + api_key
    if data is not None:
        headers["Content-Type"] = "application/json"
    connection = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        connection.request("POST" if data is not None else "GET", path,
                           body=json_bytes(data) if data is not None else None, headers=headers)
        with connection.getresponse() as response:
            if response.status != 200:
                raise BenchError(f"HTTP_{response.status}")
            raw = response.read(MAX_JSON_BYTES + 1)
        if len(raw) > MAX_JSON_BYTES:
            raise BenchError("JSON_RESPONSE_LIMIT")
        value = json.loads(raw)
        if not isinstance(value, dict) or value.get("error") is not None:
            raise BenchError("INVALID_JSON_RESPONSE")
        return value
    except TimeoutError:
        raise BenchError("TIMEOUT") from None
    except (ValueError, OSError, http.client.HTTPException, RecursionError):
        raise BenchError("TRANSPORT_OR_JSON_ERROR") from None
    finally:
        connection.close()


def rendered_prompt(send, model, effort, messages, clear=True, tools=None):
    settings = glm_request_settings(model, effort)
    payload = {
        "model": model,
        "messages": messages,
        "reasoning_effort": effort,
        "chat_template_kwargs": {**settings["chat_template_kwargs"], "clear_thinking": clear},
    }
    if tools:
        payload["tools"] = tools
    prompt = send("/apply-template", payload).get("prompt")
    if not isinstance(prompt, str):
        raise BenchError("TEMPLATE_RENDER_UNAVAILABLE")
    return prompt


def template_checks(send, model):
    messages = [
        {"role": "user", "content": "NOX_SYNTHETIC_FIRST_TURN"},
        {"role": "assistant", "content": "NOX_SYNTHETIC_VISIBLE_HISTORY",
         "reasoning_content": HISTORY_THOUGHT},
        {"role": "user", "content": "NOX_SYNTHETIC_SECOND_TURN"},
    ]
    rendered = {effort: rendered_prompt(send, model, effort, messages) for effort in EFFORTS}
    low_prompt = rendered["low"]
    retained = rendered_prompt(send, model, "low", messages, clear=False)
    tool_turn = [
        messages[-1],
        {"role": "assistant", "content": "", "reasoning_content": TOOL_THOUGHT,
         "tool_calls": [
             {"id": "fixture-a", "type": "function",
              "function": {"name": "nox_probe_echo", "arguments": '{"label":"alpha"}'}},
             {"id": "fixture-b", "type": "function",
              "function": {"name": "nox_probe_echo", "arguments": '{"label":"beta"}'}},
         ]},
        {"role": "tool", "tool_call_id": "fixture-b", "content": "NOX_TOOL_RESULT_BETA"},
        {"role": "tool", "tool_call_id": "fixture-a", "content": "NOX_TOOL_RESULT_ALPHA"},
    ]
    tool_prompt = rendered_prompt(send, model, "high", tool_turn, tools=[TOOL])
    return {
        "embedded_glm_template": low_prompt.startswith("[gMASK]<sop>"),
        "reasoning_effort": {
            effort: f"Reasoning Effort: {effort.capitalize()}" in rendered[effort] for effort in EFFORTS
        },
        "clear_previous_thinking": HISTORY_THOUGHT in retained and HISTORY_THOUGHT not in low_prompt,
        "preserve_visible_history": "NOX_SYNTHETIC_VISIBLE_HISTORY" in low_prompt,
        "preserve_current_tool_reasoning": TOOL_THOUGHT in tool_prompt,
        "tool_arguments_rendered": all(
            f"<arg_value>{value}</arg_value>" in tool_prompt for value in ("alpha", "beta")
        ),
        "tool_observations_bound_in_call_order": (
            0 <= tool_prompt.find("NOX_TOOL_RESULT_ALPHA") < tool_prompt.find("NOX_TOOL_RESULT_BETA")
        ),
    }


def generation_checks(send, endpoint, model, timeout, api_key):
    messages = [
        {"role": "user", "content": f"Запомни код {VISIBLE_MARKER} и ответь «Да»."},
        {"role": "assistant", "content": "Да"},
        {"role": "user", "content": "Ответь только кодом из первого сообщения, без кавычек и знаков."},
    ]
    case = {"id": "glm53_visible_sse_context_recall_ru", "messages": messages,
            "expected_exact": VISIBLE_MARKER}
    sse = stage_request(endpoint, glm_request_settings(model, "low"), case, timeout, api_key)
    schema = {
        "type": "object",
        "properties": {"status": {"type": "string", "enum": ["ready"]}},
        "required": ["status"],
        "additionalProperties": False,
    }
    payload = {
        **glm_request_settings(model, "low"),
        "stream": False,
        "response_format": {"type": "json_schema", "schema": schema},
        "messages": [{"role": "user", "content": "Devuelve un objeto JSON con status igual a ready."}],
    }
    structured = send(CHAT_PATH, payload)
    try:
        choice, = structured["choices"]
        structured_ok = (
            structured["model"] == model and choice["finish_reason"] == "stop"
            and json.loads(choice["message"]["content"]) == {"status": "ready"}
        )
    except (KeyError, ValueError, TypeError):
        structured_ok = False
    return {
        "two_turn_visible_sse": sse,
        "strict_structured_output": structured_ok,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint", help="Direct staging URL ending in /v1/chat/completions")
    parser.add_argument("--model", default="nox-glm53", help="Exact advertised GLM-5.3 staging model ID")
    parser.add_argument("--apply", action="store_true", help="Run loopback checks")
    parser.add_argument("--with-generation", action="store_true", help="Also run two synthetic chat calls")
    parser.add_argument("--timeout-s", type=float, default=120)
    args = parser.parse_args(argv)
    result = {"mode": "staging" if args.apply else "offline_plan", "checks": {}}
    try:
        if not MODEL_NAME.search(args.model):
            raise BenchError("MODEL_ID_NOT_GLM53")
        if not math.isfinite(args.timeout_s) or args.timeout_s <= 0:
            raise BenchError("INVALID_TIMEOUT")
        endpoint = loopback_endpoint(args.endpoint) if args.endpoint or args.apply else None
        if endpoint is not None and endpoint[2] != CHAT_PATH:
            raise BenchError("EXPECTED_STANDALONE_LLAMA_CHAT_PATH")
        if not args.apply:
            result["checks"] = {"reasoning_efforts": list(EFFORTS), "generation_requested": args.with_generation}
            print(json.dumps(result, sort_keys=True))
            return 0
        api_key = os.environ.get("NOX_CHAT_BENCH_API_KEY")

        def send(path, body=None):
            return request_json(endpoint, path, body, args.timeout_s, api_key)

        checks = result["checks"]
        checks["health"] = send("/health").get("status") == "ok"
        listed = send("/v1/models").get("data")
        checks["model_id_exact"] = isinstance(listed, list) and any(
            isinstance(item, dict) and item.get("id") == args.model for item in listed
        )
        if not checks["health"] or not checks["model_id_exact"]:
            raise BenchError("GLM53_STAGING_NOT_READY")
        template = template_checks(send, args.model)
        checks["template"] = template
        template_ok = all(
            all(value.values()) if isinstance(value, dict) else value for value in template.values()
        )
        result["template_verified"] = template_ok
        if not template_ok:
            raise BenchError("GLM53_TEMPLATE_MISMATCH")
        if args.with_generation:
            generation = generation_checks(send, endpoint, args.model, args.timeout_s, api_key)
            checks["generation"] = generation
            stream = generation["two_turn_visible_sse"]
            result["generation_verified"] = bool(
                stream["quality_pass"] and stream["terminal_done"] and stream["error"] is None
                and stream["response_model_id"] == "MATCH" and generation["strict_structured_output"]
            )
            if not result["generation_verified"]:
                raise BenchError("GLM53_GENERATION_PROBE_MISMATCH")
    except BenchError as error:
        result["error"] = str(error)
        print(json.dumps(result, sort_keys=True))
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
