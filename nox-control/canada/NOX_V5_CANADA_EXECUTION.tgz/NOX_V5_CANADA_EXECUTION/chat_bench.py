#!/usr/bin/env python3
"""Measure an authorized staging chat with a SHA-pinned synthetic fixture.

Without --apply the command validates the fixture and prints a plan. Network
mode accepts a direct HTTP loopback listener only. A port forwarded to a
production service is outside the intended scope. No prompt, reply, API key,
server error text or requested URL appears in the report.

Fixture keys: runtime, request, cases. See test_chat_bench.py for an example.
"""

import argparse
from collections import Counter
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import re
import socket
import threading
import time
from urllib.parse import urlsplit


MAX_FIXTURE_BYTES = 8 * 1024 * 1024
MAX_STREAM_BYTES = 4 * 1024 * 1024
MAX_LINE_BYTES = 256 * 1024
SHA256 = re.compile(r"[0-9a-f]{64}\Z")
CHAT_PATH = re.compile(r"/(?:[A-Za-z0-9_-]+/)*v1/chat/completions\Z")
FINISH_REASONS = {"stop", "length", "content_filter", "tool_calls", "function_call"}
ROLE_NAMES = {"developer", "system", "user", "assistant", "tool", "function"}
REQUIRED_SETTINGS = {"model", "temperature", "top_p", "seed", "max_tokens"}
OPTIONAL_SETTINGS = {
    "reasoning_effort", "min_p", "repeat_penalty", "presence_penalty", "frequency_penalty",
    "cache_prompt", "id_slot",
}


class BenchError(Exception):
    """A fixed, safe diagnostic code."""


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False,
                      separators=(",", ":")).encode("utf-8")


def loopback_endpoint(url):
    try:
        parts = urlsplit(url)
        host, port = parts.hostname, parts.port
    except (ValueError, TypeError):
        raise BenchError("ENDPOINT_NOT_DIRECT_HTTP_LOOPBACK") from None
    if (parts.scheme != "http" or host not in {"localhost", "127.0.0.1", "::1"}
            or port is None or not 1 <= port <= 65535
            or parts.username is not None or parts.password is not None
            or "?" in url or "#" in url or not CHAT_PATH.fullmatch(parts.path)):
        raise BenchError("ENDPOINT_NOT_DIRECT_HTTP_LOOPBACK")
    return ("127.0.0.1" if host == "localhost" else host), port, parts.path


def load_fixture(path, expected_digest):
    try:
        with path.open("rb") as source:
            raw = source.read(MAX_FIXTURE_BYTES + 1)
        if len(raw) > MAX_FIXTURE_BYTES:
            raise BenchError("FIXTURE_LIMIT")
        digest = sha256(raw)
        if expected_digest is not None and (not SHA256.fullmatch(expected_digest) or digest != expected_digest):
            raise BenchError("FIXTURE_SHA256_MISMATCH")
        obj = json.loads(raw)
    except (OSError, UnicodeError, ValueError, RecursionError):
        raise BenchError("INVALID_FIXTURE") from None
    if not isinstance(obj, dict) or set(obj) != {"runtime", "request", "cases"}:
        raise BenchError("INVALID_FIXTURE")
    pins, settings, cases = obj["runtime"], obj["request"], obj["cases"]
    if (not isinstance(pins, dict) or set(pins) != {"model_sha256", "runtime_sha256"}
            or any(not isinstance(value, str) or not SHA256.fullmatch(value) for value in pins.values())):
        raise BenchError("INVALID_RUNTIME_PINS")
    if (not isinstance(settings, dict) or not REQUIRED_SETTINGS <= settings.keys()
            or settings.keys() - REQUIRED_SETTINGS - OPTIONAL_SETTINGS):
        raise BenchError("INVALID_REQUEST_SETTINGS")
    if (not isinstance(settings["model"], str) or not settings["model"].strip()
            or type(settings["seed"]) is not int or type(settings["max_tokens"]) is not int
            or settings["max_tokens"] < 1
            or type(settings["temperature"]) not in (int, float) or not 0 <= settings["temperature"] <= 2
            or type(settings["top_p"]) not in (int, float) or not 0 <= settings["top_p"] <= 1):
        raise BenchError("INVALID_REQUEST_SETTINGS")
    if not isinstance(cases, list) or not cases:
        raise BenchError("INVALID_CASES")
    ids = set()
    for case in cases:
        if not isinstance(case, dict) or set(case) != {"id", "messages", "expected_exact"}:
            raise BenchError("INVALID_CASES")
        case_id, messages, expected = case["id"], case["messages"], case["expected_exact"]
        if (not isinstance(case_id, str) or not case_id.strip() or case_id in ids
                or not isinstance(expected, str) or not expected.strip()
                or not isinstance(messages, list) or not messages):
            raise BenchError("INVALID_CASES")
        for message in messages:
            if not isinstance(message, dict) or not isinstance(message.get("role"), str) or message["role"] not in ROLE_NAMES:
                raise BenchError("INVALID_CASES")
        if not any(message["role"] == "user" for message in messages):
            raise BenchError("INVALID_CASES")
        ids.add(case_id)
    try:
        json_bytes(obj)
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise BenchError("INVALID_FIXTURE") from None
    return obj, digest


def sse_frames(source):
    total = 0
    event = None
    data = []
    while raw := source.readline(MAX_LINE_BYTES + 1):
        total += len(raw)
        if len(raw) > MAX_LINE_BYTES or total > MAX_STREAM_BYTES:
            raise BenchError("SSE_LIMIT")
        try:
            line = raw.decode("utf-8").rstrip("\r\n")
        except UnicodeDecodeError:
            raise BenchError("INVALID_SSE") from None
        if not line:
            if data or event == "error":
                yield event, "\n".join(data)
            event, data = None, []
            continue
        field, sep, value = line.partition(":")
        if field == "data" and sep:
            data.append(value.removeprefix(" "))
        elif field == "event" and sep:
            event = value.removeprefix(" ")


def make_sample(case, status=None):
    return {
        "case_sha256": sha256(case["id"].encode("utf-8")), "http_status": status,
        "first_sse_data_ms": None, "first_reasoning_ms": None, "ttft_visible_ms": None,
        "full_response_ms": None, "elapsed_ms": None, "terminal_done": False, "finish_reason": None,
        "quality_pass": False, "response_model_id": "UNREPORTED", "error": None,
    }


def parse_stream(source, case, model, started, sample, clock=time.monotonic):
    answer = []
    try:
        for event, data in sse_frames(source):
            elapsed = round((clock() - started) * 1000, 3)
            if event == "error":
                raise BenchError("SERVER_SSE_ERROR")
            if sample["first_sse_data_ms"] is None:
                sample["first_sse_data_ms"] = elapsed
            if data.strip() == "[DONE]":
                sample["terminal_done"] = True
                sample["full_response_ms"] = elapsed
                break
            try:
                packet = json.loads(data)
            except (ValueError, RecursionError):
                raise BenchError("INVALID_SSE") from None
            if not isinstance(packet, dict):
                raise BenchError("INVALID_SSE")
            if packet.get("error") is not None:
                raise BenchError("SERVER_SSE_ERROR")
            if "model" in packet:
                sample["response_model_id"] = "MATCH" if packet["model"] == model else "MISMATCH"
                if sample["response_model_id"] == "MISMATCH":
                    raise BenchError("MODEL_ID_MISMATCH")
            choices = packet.get("choices", [])
            if not isinstance(choices, list) or len(choices) > 1:
                raise BenchError("INVALID_SSE")
            if not choices:
                continue
            choice = choices[0]
            if not isinstance(choice, dict) or choice.get("index", 0) != 0:
                raise BenchError("INVALID_SSE")
            reason = choice.get("finish_reason")
            if reason is not None:
                sample["finish_reason"] = reason if isinstance(reason, str) and reason in FINISH_REASONS else "OTHER"
            delta = choice.get("delta", {})
            if not isinstance(delta, dict):
                raise BenchError("INVALID_SSE")
            reasoning = delta.get("reasoning_content") or delta.get("reasoning")
            if isinstance(reasoning, str) and reasoning.strip() and sample["first_reasoning_ms"] is None:
                sample["first_reasoning_ms"] = elapsed
            content = delta.get("content")
            if isinstance(content, str):
                answer.append(content)
                if content.strip() and sample["ttft_visible_ms"] is None:
                    sample["ttft_visible_ms"] = elapsed
        if not sample["terminal_done"]:
            raise BenchError("SSE_MISSING_DONE")
        if sample["ttft_visible_ms"] is None:
            raise BenchError("NO_VISIBLE_CONTENT")
        sample["quality_pass"] = (sample["finish_reason"] == "stop"
                                  and "".join(answer).strip() == case["expected_exact"].strip())
    except BenchError as failure:
        sample["error"] = str(failure)


def stage_request(endpoint, settings, case, timeout, api_key):
    host, port, path = endpoint
    started = time.monotonic()
    sample = make_sample(case)
    if host not in {"127.0.0.1", "::1"} or not 1 <= port <= 65535 or not CHAT_PATH.fullmatch(path):
        sample.update(error="ENDPOINT_NOT_DIRECT_HTTP_LOOPBACK", elapsed_ms=0)
        return sample
    connection = http.client.HTTPConnection(host, port, timeout=timeout)
    timer = None
    expired = threading.Event()
    payload = json_bytes({**settings, "messages": case["messages"], "stream": True, "n": 1})
    headers = {"Accept": "text/event-stream", "Content-Type": "application/json", "Connection": "close"}
    if api_key:
        headers["Authorization"] = "Bearer " + api_key
    try:
        connection.connect()
        connected_socket = connection.sock

        def close_timed_out_socket():
            expired.set()
            try:
                connected_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

        timer = threading.Timer(max(0, started + timeout - time.monotonic()), close_timed_out_socket)
        timer.daemon = True
        timer.start()
        connection.request("POST", path, body=payload, headers=headers)
        with connection.getresponse() as response:
            sample["http_status"] = response.status
            if response.status != 200:
                sample["error"] = "HTTP_REDIRECT" if 300 <= response.status < 400 else "HTTP_ERROR"
            elif response.getheader("Content-Type", "").split(";", 1)[0].strip().lower() != "text/event-stream":
                sample["error"] = "EXPECTED_SSE_CONTENT_TYPE"
            else:
                parse_stream(response, case, settings["model"], started, sample)
    except TimeoutError:
        sample["error"] = "TIMEOUT"
    except (OSError, http.client.HTTPException, ValueError):
        sample["error"] = "TRANSPORT_ERROR"
    finally:
        if timer is not None:
            timer.cancel()
        connection.close()
    finished = time.monotonic()
    if expired.is_set() or finished - started > timeout:
        sample["error"] = "TIMEOUT"
        sample["quality_pass"] = False
    sample["elapsed_ms"] = round((finished - started) * 1000, 3)
    return sample


def distribution(values):
    series = sorted(value for value in values if value is not None)
    if not series:
        return {"n": 0, "p50_ms": None, "p95_ms": None}
    return {"n": len(series), "p50_ms": series[math.ceil(0.50 * len(series)) - 1],
            "p95_ms": series[math.ceil(0.95 * len(series)) - 1]}


def summarize(samples):
    complete = [sample for sample in samples if sample["terminal_done"] and sample["error"] is None]
    errors = Counter(sample["error"] for sample in samples if sample["error"] is not None)
    return {
        "n_attempted": len(samples), "n_complete": len(complete),
        "n_quality_pass": sum(sample["quality_pass"] for sample in complete),
        "error_counts": dict(errors), "quantile_method": "nearest_rank",
        "visible_ttft_completed": distribution(sample["ttft_visible_ms"] for sample in complete),
        "visible_ttft_all_observed": distribution(sample["ttft_visible_ms"] for sample in samples),
        "full_completed": distribution(sample["full_response_ms"] for sample in complete),
        "elapsed_all_attempts": distribution(sample["elapsed_ms"] for sample in samples),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture", type=Path, required=True)
    parser.add_argument("--fixture-sha256")
    parser.add_argument("--apply", action="store_true", help="send requests to the authorized staging listener")
    parser.add_argument("--endpoint")
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--timeout-s", type=float, default=90)
    args = parser.parse_args(argv)
    try:
        if args.repeats < 1 or not math.isfinite(args.timeout_s) or args.timeout_s <= 0:
            raise BenchError("INVALID_RUN_SETTINGS")
        if args.apply and (not args.endpoint or not args.fixture_sha256):
            raise BenchError("APPLY_REQUIRES_ENDPOINT_AND_FIXTURE_SHA256")
        endpoint = loopback_endpoint(args.endpoint) if args.endpoint else None
        fixture, digest = load_fixture(args.fixture, args.fixture_sha256)
    except BenchError as failure:
        print(json.dumps({"mode": "rejected", "error": str(failure), "network_requests": 0}))
        return 2
    settings, cases = fixture["request"], fixture["cases"]
    samples = []
    if args.apply:
        api_key = os.environ.get("NOX_CHAT_BENCH_API_KEY")
        for repeat in range(1, args.repeats + 1):
            for case in cases:
                sample = stage_request(endpoint, settings, case, args.timeout_s, api_key)
                sample["repeat_index"] = repeat
                samples.append(sample)
    report = {
        "mode": "local_staging" if args.apply else "offline_plan", "fixture_sha256": digest,
        "cases_sha256": sha256(json_bytes(cases)), "request_settings_sha256": sha256(json_bytes(settings)),
        "runtime_pins": fixture["runtime"], "runtime_pins_independently_verified": False,
        "evidence_scope": "staging_stream_and_exact_fixture_output",
        "canonical_s03_verified": False,
        "n_planned": len(cases) * args.repeats, "timeout_s": args.timeout_s,
        "summary": summarize(samples), "samples": samples,
    }
    print(json.dumps(report, sort_keys=True))
    return int(args.apply and report["summary"]["n_quality_pass"] != len(samples))


if __name__ == "__main__":
    raise SystemExit(main())
