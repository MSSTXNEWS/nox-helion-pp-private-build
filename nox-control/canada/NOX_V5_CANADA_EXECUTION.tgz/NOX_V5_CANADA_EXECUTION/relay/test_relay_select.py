from pathlib import Path
import json
import unittest

from relay_select import MODELS, select


ROOT = Path(__file__).parent


class RelayTest(unittest.TestCase):
    def setUp(self):
        self.plan = json.loads((ROOT / "pareto-200.json").read_text())
        self.tasks = {x["id"]: x for b in self.plan["blocks"] for x in b["cards"]}
        self.snapshot = {
            "schema": "nox_relay_owner_export_v1", **MODELS, "observation_sha256": "a" * 64,
            "accepted_receipts": {"P1-02": "b" * 64}, "active_locks": [],
            "hosts": {"S1": {"instance_id": 61825960, "allows_work": True, "stop_clear": True,
                             "owner_observation_sha256": "b" * 64,
                             "free_for_relay": {"cpu_slots": 7, "ram_bytes": 90, "disk_bytes": 90, "gpu_mib": 16}}},
            "reviewed_bindings": {
                "P1-03": {"target": "S1", "owner_reviewed": True, "binding_sha256": "c" * 64,
                          "native_task_id": "reviewed-model-host-inventory", "expected_effect_sha256": "d" * 64,
                          "requested": {"cpu_slots": 1, "ram_bytes": 10, "disk_bytes": 0, "gpu_mib": 0}},
            },
        }

    def test_plan_count_and_candidates(self):
        self.assertEqual(len(self.tasks), 200)
        self.assertEqual(len(self.plan["pv_gates"]), 8)
        first = select(self.plan, self.snapshot)
        self.assertEqual(first["selected"][0]["canonical_id"], "P1-03")
        self.assertEqual(first["native_submissions"], 0)
        self.assertEqual(first, select(self.plan, self.snapshot))

    def test_stop_and_dependencies_hold(self):
        self.snapshot["hosts"]["S1"]["stop_clear"] = False
        self.assertEqual(select(self.plan, self.snapshot)["state"], "HOLD")
        self.snapshot["hosts"]["S1"]["stop_clear"] = True
        self.snapshot["accepted_receipts"] = {}
        self.assertEqual(select(self.plan, self.snapshot)["state"], "HOLD")

    def test_source_research_is_available_through_same_relay_after_approval(self):
        plan = json.loads((ROOT / "pareto-220-glm.json").read_text())
        self.assertEqual(len(plan["experiment_cards"]), 20)
        selected = next(c for c in plan["experiment_cards"] if c["id"] == "GLM20-16")
        self.snapshot["accepted_receipts"].update({k: "b" * 64 for k in selected["source_dependencies"]})
        binding = self.snapshot["reviewed_bindings"].pop("P1-03")
        self.snapshot["reviewed_bindings"][selected["id"]] = binding
        result = select(plan, self.snapshot)
        self.assertEqual(result["selected"][0]["canonical_id"], selected["id"])
        self.assertEqual(result["native_submissions"], 0)


    def test_glm50_routes_with_current_dependencies_and_does_not_submit(self):
        plan = json.loads((ROOT / "pareto-270-glm.json").read_text())
        self.assertEqual(len(plan["experiment_cards"]), 70)
        new = next(c for c in plan["experiment_cards"] if c["id"] == "GLM50-08")
        self.snapshot["accepted_receipts"].update({k: "b" * 64 for k in new["source_dependencies"]})
        binding = self.snapshot["reviewed_bindings"].pop("P1-03")
        self.snapshot["reviewed_bindings"][new["id"]] = binding
        self.snapshot.pop("auxiliary")
        result = select(plan, self.snapshot)
        self.assertEqual(result["selected"][0]["canonical_id"], new["id"])
        self.assertEqual(result["native_submissions"], 0)
