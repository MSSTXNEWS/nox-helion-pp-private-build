from contextlib import redirect_stdout
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
import tempfile
import unittest

import relay_receipt as relay


def trace(operation="update"):
    key = {"task_id": "FIXTURE-01", "request_id": "fixture-request", "job_id": "fixture-job", "claim_nonce": "fixture-claim",
           "claim_epoch": 12, "scope_sha256": "1" * 64, "source_sha256": "2" * 64}
    obj, receipt_digest = "3" * 64, "4" * 64
    before, after = (None if operation == "create" else "5" * 64), (None if operation == "delete" else "6" * 64)
    effect = {"operation": operation, "object_id_sha256": obj, "before_sha256": before, "after_sha256": after}
    intent = {"binding": deepcopy(key), "native_operation": "fixture_apply", "effect": deepcopy(effect)}
    row = {"id": key["task_id"], "status": "done", "handler": "owner_native_typed_leaf", "leaf_sha_matches": True,
           "receipt_sha_matches": True, "receipt_claim_matches": True, "claim": {"nonce": key["claim_nonce"]},
           "leaf": {"operation": "fixture_apply"}, "worker_result": {"state": "NATIVE_LEAF_COMPLETED"},
           "result": {"verified": True, "receipt_sha256": receipt_digest},
           "receipt": {"schema": "NOX_NATIVE_SUBAGENT_RECEIPT_V1", "phase": "NATIVE_LEAF_COMPLETED_ORIGINAL_NOT_ACCEPTED",
                       "task_id": key["task_id"], "job_id": key["job_id"], "source_sha256": key["source_sha256"]}}
    execution = {"binding": deepcopy(key), "native_operation": "fixture_apply", "native_receipt_sha256": receipt_digest,
                 "mode": "native_effect", "outcome": "APPLIED", "test_only": False, "dry_run": False, "no_op": False,
                 "exporter": "fixture-dispatcher", "start_seq": 20, "terminal_seq": 21, "effect": deepcopy(effect)}
    readback = {"binding": deepcopy(key), "exporter": "fixture-reader", "native_receipt_sha256": receipt_digest,
                "mode": "native_object_readback",
                "before": {"object_id_sha256": obj, "state_sha256": before, "seq": 19, "present": before is not None},
                "after": {"object_id_sha256": obj, "state_sha256": after, "seq": 22, "present": after is not None}}
    return {"schema": relay.SCHEMA, "intent": intent, "dispatcher": {"row": row, "execution": execution}, "readback": readback}


class RelayReceiptTest(unittest.TestCase):
    def verify(self, data):
        return relay.verify(data["intent"], data["dispatcher"], data["readback"])

    def assert_hold(self, data, code):
        with self.assertRaises(relay.Hold) as raised:
            self.verify(data)
        self.assertEqual(str(raised.exception), code)

    def test_three_approved_object_transitions(self):
        for operation in ("create", "update", "delete"):
            with self.subTest(operation=operation):
                result = self.verify(trace(operation))
                self.assertEqual(result["state"], "EFFECT_EVIDENCE_CONSISTENT")
                self.assertEqual(result["effect_operation"], operation)
                self.assertFalse(result["native_provenance_verified"])
                self.assertFalse(result["original_task_accepted"])

    def test_dry_run_test_no_op_and_review_hold_even_with_changed_object(self):
        for flag in ("test_only", "dry_run", "no_op"):
            with self.subTest(flag=flag):
                data = trace()
                data["dispatcher"]["execution"][flag] = True
                self.assert_hold(data, "NO_APPLIED_NATIVE_EFFECT")
        data = trace()
        data["dispatcher"]["row"]["receipt"]["phase"] = "NATIVE_REVIEW_COMPLETED_CANDIDATE_NOT_APPLIED"
        self.assert_hold(data, "DISPATCH_CHECK_OR_REVIEW_ONLY")
        for operation in relay.OBSERVED_CHECK_OPERATIONS:
            data = trace()
            data["dispatcher"]["row"]["leaf"]["operation"] = operation
            data["dispatcher"]["execution"]["native_operation"] = operation
            data["intent"]["native_operation"] = operation
            self.assert_hold(data, "DISPATCH_CHECK_OR_REVIEW_ONLY")

    def test_native_status_and_retry_claim_cannot_be_substituted(self):
        for field in ("receipt_sha_matches", "receipt_claim_matches"):
            data = trace()
            data["dispatcher"]["row"][field] = 1
            self.assert_hold(data, "DISPATCH_NOT_VERIFIED_TERMINAL")
        data = trace()
        data["dispatcher"]["row"]["claim"]["nonce"] = "older-claim"
        self.assert_hold(data, "DISPATCH_NATIVE_IDENTITY_MISMATCH")
        data = trace()
        data["dispatcher"]["execution"]["binding"]["claim_epoch"] = 11
        self.assert_hold(data, "DISPATCH_REQUEST_MISMATCH")

    def test_request_scope_terminal_digest_and_independent_reader_are_required(self):
        variants = [
            ("binding", {**trace()["readback"]["binding"], "request_id": "other-request"}, "READBACK_REQUEST_MISMATCH"),
            ("binding", {**trace()["readback"]["binding"], "scope_sha256": "9" * 64}, "READBACK_REQUEST_MISMATCH"),
            ("native_receipt_sha256", "9" * 64, "READBACK_REQUEST_MISMATCH"),
            ("exporter", "fixture-dispatcher", "INDEPENDENT_READBACK_REQUIRED"),
        ]
        for field, value, expected in variants:
            with self.subTest(field=field, value=value):
                data = trace()
                data["readback"][field] = value
                self.assert_hold(data, expected)

    def test_wrong_object_same_bytes_no_change_and_reordered_observations_fail(self):
        data = trace()
        data["readback"]["after"]["object_id_sha256"] = "f" * 64
        self.assert_hold(data, "OBJECT_OBSERVATION_MISMATCH")
        data = trace()
        data["readback"]["after"]["state_sha256"] = data["readback"]["before"]["state_sha256"]
        self.assert_hold(data, "PHYSICAL_EFFECT_MISMATCH_OR_NO_OP")
        data = trace()
        data["readback"]["after"]["seq"] = 21
        self.assert_hold(data, "READBACK_NOT_CAUSALLY_ORDERED")

    def test_journal_stable_event_is_distinct_from_mutable_evidence_digest(self):
        data = trace()
        first = self.verify(data)
        self.assertEqual(first, self.verify(deepcopy(data)))
        data["readback"]["after"]["seq"] = 23
        later = self.verify(data)
        self.assertEqual(first["journal_event_id"], later["journal_event_id"])
        self.assertNotEqual(first["evidence_sha256"], later["evidence_sha256"])

    def test_cli_does_not_leak_untrusted_json_or_duplicate_keys(self):
        with tempfile.TemporaryDirectory() as directory:
            entry = Path(directory) / "trace.json"
            entry.write_text('{"schema":"PRIVATE_SECRET","schema":"other"}', encoding="utf-8")
            stdout = StringIO()
            with redirect_stdout(stdout):
                self.assertEqual(relay.main([str(entry)]), 2)
            self.assertNotIn("PRIVATE_SECRET", stdout.getvalue())
            self.assertEqual(json.loads(stdout.getvalue())["error"], "DUPLICATE_JSON_KEY")


if __name__ == "__main__":
    unittest.main()
