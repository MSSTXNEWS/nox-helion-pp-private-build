#!/usr/bin/env bash
# Authorized S1 shell. This launcher targets the loopback shadow, not production ingress.
set -euo pipefail
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
kit="${NOX_EXECUTION_KIT:-$here/..}"
stage="${NOX_GLM_STAGE:-/root/nox/glm53}"
python="${NOX_RELAY_PYTHON:-python3}"
phase="${1:-observe}"
if (( $# )); then shift; fi
case "$phase" in
  observe) exec "$python" -B "$kit/server_probe.py" --disk-path "$stage" "$@" --expected-instance 61825960 ;;
  memfd-plan) exec "$python" -B "$kit/memfd_pilot.py" "$@" ;;
  first-shard-plan) exec "$python" -B "$kit/fetch_model.py" "$stage" "$@" --expected-instance 61825960 --only 1 ;;
  verify-first)
    "$python" -B "$kit/server_probe.py" --expected-instance 61825960 --disk-path "$stage"
    exec "$python" -B "$kit/model_plan.py" verify "$stage" --only 1 --mmap-pilot
    ;;
  stage) exec "$python" -B "$kit/fetch_model.py" "$stage" "$@" --expected-instance 61825960 ;;
  shadow) exec "$python" -B "$kit/shadow_glm.py" "$stage" "$@" ;;
  *) printf 'Usage: %s {observe|memfd-plan|first-shard-plan|verify-first|stage|shadow} [arguments]\n' "$0" >&2; exit 2 ;;
esac
