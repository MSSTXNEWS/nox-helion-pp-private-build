"""Append and look up metadata-only observations in a private POSIX NOX relay journal.

Pass a separate local SQLite path. Derive event IDs from stable operation identity,
not the result or its evidence. The optional evidence SHA is a reference to a
receipt authenticated elsewhere. This tool does not approve work or access NOX.
"""

import argparse
from contextlib import closing
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import tempfile


APP_ID = 0x4E4F5852
VERSION = 1
SHA = re.compile(r"[0-9a-f]{64}")
TASK_ID = re.compile(r"[A-Z0-9][A-Z0-9_.-]{0,39}")
CODE = re.compile(r"[A-Z][A-Z0-9_]{1,47}")
EVENT_FIELDS = ("event_id", "task_id", "kind", "code", "source_sha256", "lesson_code", "evidence_sha256")
VISIBLE_COLUMNS = ", ".join(("seq", *EVENT_FIELDS, "recorded_at"))


class Hold(ValueError):
    """A bounded status safe to print without raw exception text."""


def matches(pattern, value):
    return type(value) is str and pattern.fullmatch(value) is not None


def valid_event(event):
    if not matches(SHA, event["event_id"]) or not matches(TASK_ID, event["task_id"]):
        raise Hold("INVALID_EVENT_OR_TASK_ID")
    if event["kind"] not in ("error", "lesson") or not matches(CODE, event["code"]):
        raise Hold("INVALID_OBSERVATION_CODE")
    lesson_code = event["lesson_code"]
    if (lesson_code is None and event["kind"] == "lesson") or (
        lesson_code is not None and not matches(CODE, lesson_code)
    ):
        raise Hold("INVALID_LESSON_CODE")
    evidence = event["evidence_sha256"]
    if not matches(SHA, event["source_sha256"]) or (evidence is not None and not matches(SHA, evidence)):
        raise Hold("INVALID_SOURCE_OR_EVIDENCE_SHA256")


def private_regular(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
        raise Hold("JOURNAL_PATH_NOT_PRIVATE_REGULAR_FILE")
    return info


def initialize(path):
    # Publish a complete empty journal atomically. Concurrent first writers can
    # create candidates, but only one can publish at the supplied path.
    with tempfile.TemporaryDirectory(prefix=".relay-journal-", dir=path.parent) as directory:
        candidate = Path(directory) / "journal.sqlite"
        fd = os.open(candidate, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(fd)
        with closing(sqlite3.connect(candidate)) as db:
            db.executescript(f"""
                BEGIN IMMEDIATE;
                PRAGMA application_id = {APP_ID};
                PRAGMA user_version = {VERSION};
                CREATE TABLE observations (
                    seq INTEGER PRIMARY KEY,
                    event_id TEXT NOT NULL UNIQUE,
                    task_id TEXT NOT NULL,
                    kind TEXT NOT NULL CHECK (kind IN ('error', 'lesson')),
                    code TEXT NOT NULL,
                    source_sha256 TEXT NOT NULL,
                    lesson_code TEXT,
                    evidence_sha256 TEXT,
                    recorded_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                    CHECK (kind != 'lesson' OR lesson_code IS NOT NULL)
                );
                CREATE INDEX task_order ON observations(task_id, seq);
                COMMIT;
            """)
            if db.execute("PRAGMA journal_mode=WAL").fetchone() != ("wal",):
                raise Hold("JOURNAL_WAL_UNAVAILABLE")
        with candidate.open("rb") as handle:
            os.fsync(handle.fileno())
        try:
            os.link(candidate, path, follow_symlinks=False)
        except FileExistsError:
            return
        directory_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)


def connect(path, *, write=False):
    private_regular(path)
    for suffix in ("-wal", "-shm", "-journal"):
        try:
            private_regular(path.with_name(path.name + suffix))
        except FileNotFoundError:
            continue
    mode = "rw" if write else "ro"
    db = sqlite3.connect(path.as_uri() + f"?mode={mode}", uri=True, timeout=5, isolation_level=None)
    try:
        db.execute("PRAGMA trusted_schema=OFF")
        if not write:
            db.execute("PRAGMA query_only=ON")
        if (db.execute("PRAGMA application_id").fetchone() != (APP_ID,)
                or db.execute("PRAGMA user_version").fetchone() != (VERSION,)
                or db.execute("PRAGMA journal_mode").fetchone() != ("wal",)):
            raise Hold("JOURNAL_IDENTITY_MISMATCH")
        if write:
            db.execute("PRAGMA synchronous=FULL")
        db.row_factory = sqlite3.Row
        return db
    except (Hold, sqlite3.Error):
        db.close()
        raise


def observe(db_path, *, event_id, task_id, kind, code, source_sha256, lesson_code=None, evidence_sha256=None):
    values = (event_id, task_id, kind, code, source_sha256, lesson_code, evidence_sha256)
    event = dict(zip(EVENT_FIELDS, values, strict=True))
    valid_event(event)
    path = Path(db_path).absolute()
    try:
        private_regular(path)
    except FileNotFoundError:
        initialize(path)
    with closing(connect(path, write=True)) as db:
        db.execute("BEGIN IMMEDIATE")
        result = db.execute("""
            INSERT INTO observations (event_id, task_id, kind, code, source_sha256, lesson_code, evidence_sha256)
            VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(event_id) DO NOTHING
        """, values)
        row = db.execute(f"SELECT {VISIBLE_COLUMNS} FROM observations WHERE event_id = ?", (event_id,)).fetchone()
        if tuple(row[key] for key in EVENT_FIELDS) != values:
            raise Hold("EVENT_ID_CONFLICT")
        state = "RECORDED" if result.rowcount == 1 else "ALREADY_RECORDED"
        db.execute("COMMIT")
    return {"state": state, "advisory_only": True, "observation": dict(row)}


def status(db_path, *, task_id=None, limit=20):
    if task_id is not None and not matches(TASK_ID, task_id):
        raise Hold("INVALID_TASK_ID")
    if type(limit) is not int or not 1 <= limit <= 100:
        raise Hold("INVALID_STATUS_LIMIT")
    result = {"state": "EMPTY", "advisory_only": True, "counts": {"error": 0, "lesson": 0},
              "observations": [], "lessons": []}
    path = Path(db_path).absolute()
    try:
        private_regular(path)
    except FileNotFoundError:
        return result
    filters = "WHERE task_id = ?" if task_id is not None else ""
    parameters = (task_id,) if task_id is not None else ()
    lesson_filter = "AND task_id = ?" if task_id is not None else ""
    with closing(connect(path)) as db:
        db.execute("BEGIN")
        for row in db.execute(f"SELECT kind, count(*) AS n FROM observations {filters} GROUP BY kind", parameters):
            result["counts"][row["kind"]] = row["n"]
        result["observations"] = [dict(row) for row in db.execute(f"""
            SELECT {VISIBLE_COLUMNS} FROM observations {filters} ORDER BY seq DESC LIMIT ?
        """, (*parameters, limit))]
        result["lessons"] = [dict(row) for row in db.execute(f"""
            SELECT task_id, lesson_code, count(*) AS observations,
                   count(DISTINCT source_sha256) AS source_versions, max(seq) AS last_seq
            FROM observations WHERE kind = 'lesson' {lesson_filter}
            GROUP BY task_id, lesson_code ORDER BY last_seq DESC LIMIT ?
        """, (*parameters, limit))]
        db.execute("COMMIT")
    if result["observations"]:
        result["state"] = "OBSERVED"
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    append = commands.add_parser("observe")
    for key in EVENT_FIELDS:
        append.add_argument("--" + key.replace("_", "-"), required=key not in {"lesson_code", "evidence_sha256"})
    read = commands.add_parser("status")
    read.add_argument("--task-id")
    read.add_argument("--limit", type=int, default=20)
    args = parser.parse_args(argv)
    try:
        if args.command == "observe":
            result = observe(args.db, **{key: getattr(args, key) for key in EVENT_FIELDS})
        else:
            result = status(args.db, task_id=args.task_id, limit=args.limit)
    except (Hold, OSError, sqlite3.Error) as failure:
        reason = str(failure) if isinstance(failure, Hold) else "JOURNAL_IO_OR_SQLITE_HOLD"
        print(json.dumps({"state": "HOLD", "reason": reason, "advisory_only": True}, sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
