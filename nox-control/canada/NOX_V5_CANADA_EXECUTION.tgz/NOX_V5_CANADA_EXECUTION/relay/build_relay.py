"""Create a 10 × 20 ranked NOX relay handoff from the exact v5 source cards."""

import argparse
import hashlib
import json
from pathlib import Path
import re

CANON = "https://docs.google.com/document/d/1RMDs29IIEwjgCKvFEB4eBcPiRhUTXRegisQRTsiGJ0M/edit"
ARCHIVE = "https://drive.google.com/drive/folders/1vrEGWiVWPWQ28xnRX69X8eRjo_lpdTDS"
KIT = "https://drive.google.com/file/d/1IpKk-gaCCqKBERxism9dEZprBgnDrg8i/view"
ID = re.compile(r"\b(?:P(?:10|[1-9])-\d{2}|PV-\d{2})\b")
RANGE = re.compile(r"\b(P(?:10|[1-9])-|PV-)(\d{2})\s*[–—…]\s*(\d{2})(?!\d)")
BLOCKS = {
    1: ("A1", "Сервер, доступ и ресурсы", ["02", "03", "13", "04", "05", "06", "08", "12", "09"]),
    2: ("A2", "GLM и ускорение инференса", ["01", "02", "04", "06", "05", "09", "10", "08", "07", "03"]),
    3: ("A2", "Ядра, маршрутизация и режимы", ["01", "02", "05", "03", "04", "20", "06"]),
    4: ("A3", "S03, долговременная память и восстановление", ["03", "01", "09", "02", "04", "05", "20"]),
    5: ("A4", "Личность, Soul и эмоции", ["01", "03", "04", "05", "06", "07", "08"]),
    6: ("A4", "Рассуждение и подтверждаемое самоулучшение", ["09", "12", "04", "01", "03", "06"]),
    7: ("A5", "Резонанс, веб и живой чат", ["02", "03", "04", "05", "06", "07", "08", "13", "14", "15"]),
    8: ("A6", "Голос, медиа и пользовательские интерфейсы", ["03", "02", "01", "04"]),
    9: ("A6", "Обучение Soul и передача результатов", ["01", "02", "03", "04", "05"]),
    10: ("A0", "STOP, бэкапы, журнал и выпуск", ["01", "03", "04", "09", "10", "02", "06"]),
}
OWNER = {"P1-01", "P5-02", "P9-02", "P10-06"}
ACTIONS = {
    "P1-03": "observe_s1",
    "P1-04": "pilot_s1_memfd",
    "P1-08": "observe_target",
    "P1-13": "observe_s1_memory",
    "P2-01": "stage_pinned_glm",
    "P2-02": "verify_mmap_backing",
    "P2-04": "start_glm_shadow",
    "P2-06": "run_glm_baseline",
    "P4-03": "restore_s03_isolated",
    "P7-02": "observe_chat_services",
    "PV-01": "capture_live_chat_evidence",
    "PV-03": "observe_scope_and_revoke",
    "PV-06": "compare_glm_quality",
    "PV-08": "owner_cutover",
}
LOCKS = {
    1: "maintenance", 2: "inference", 3: "inference", 4: "memory",
    5: "persona", 6: "learning_policy", 7: "chat_route", 8: "media",
    9: "training", 10: "operator_control",
}
OBSERVE_TASKS = {"P1-03", "P1-08", "P1-13", "P7-02"}
GLM_CRITERIA = {
    "PV-01": "Два живых обмена на утверждённой сборке GLM, один dialog_id, S03 readback, правка факта, reload и точечный STOP",
    "PV-06": "Один закреплённый GLM baseline и один профиль GLM, одинаковые случаи, p95, prefill/decode, качество, RAM/VRAM и STOP",
    "PV-08": "Единый маршрут GLM на S1, проверенный restore S03, один writer, подтверждённые STOP и безопасный откат конфигурации",
    "P7-18": "Доказательство P5-12 связано с фактическим событием в веб-чате. Отключение инициативы сохраняется после reload",
}


def dependencies(raw, card_id):
    raw = RANGE.sub(
        lambda m: " ".join(f"{m[1]}{n:02d}" for n in range(int(m[2]), int(m[3]) + 1)),
        raw,
    )
    deps = list(dict.fromkeys(ID.findall(raw)))
    if card_id in deps:
        raise ValueError(f"Self dependency in {card_id}")
    return deps


def make_card(raw):
    task = raw["id"]
    source = raw["source_card"]
    title_parts = source.split("·", 4)
    if len(title_parts) < 5 or "Зав:" not in source:
        raise ValueError(f"Incomplete source contract {task}")
    before, remainder = source.split("Зав:", 1)
    criterion = before.partition("Готово:")[2].strip().rstrip(".")
    dependency, original = remainder.split("Исх:", 1) if "Исх:" in remainder else (remainder, "")
    section = raw["section"]
    source_target = title_parts[3].strip()
    targets = sorted(set(re.findall(r"\bS[12]\b", source_target)))
    if task.startswith("PV-"):
        # Preserve the old wording and separately apply the owner's GLM launch priority.
        targets = ["S1"]
    if task in OWNER:
        targets = []
    role = BLOCKS[section][0]
    return {
        "id": task, "role": role, "section": section, "title": raw["title"],
        "source_target": source_target, "execution_targets": targets,
        "source_rank": title_parts[2].strip(), "source_dependencies": dependencies(dependency, task),
        "source_dependency_text": dependency.strip().rstrip("."),
        "source_original_refs": original.strip().rstrip("."),
        "physical_evidence": GLM_CRITERIA.get(task, criterion),
        "source_acceptance": criterion,
        "known_operation": ACTIONS.get(task), "resource_key": LOCKS[section],
        "read_only": task in OBSERVE_TASKS, "owner_card": task in OWNER,
        "canonical_url": CANON, "execution_kit_url": KIT,
    }


def build(data, sha):
    cards = [make_card(entry) for entry in data["cards"]]
    ids = [card["id"] for card in cards]
    if len(ids) != 208 or len(set(ids)) != 208:
        raise ValueError("Expected 208 exact distinct v5 cards")
    actual = set(ids)
    blocks = []
    for section, (role, name, prioritized) in BLOCKS.items():
        expected = {f"P{section}-{n:02d}" for n in range(1, 21)}
        entries = [c for c in cards if c["id"] in expected]
        if {c["id"] for c in entries} != expected:
            raise ValueError(f"Expected twenty exact cards in block {section}")
        ranks = {f"P{section}-{n}": position for position, n in enumerate(prioritized)}
        entries.sort(key=lambda c: (ranks.get(c["id"], 20), c["id"]))
        for rank, card in enumerate(entries, 1):
            card["rank"] = rank
        blocks.append({"block": section, "name": name, "role": role, "cards": entries})
    reviews = sorted((c for c in cards if c["id"].startswith("PV-")), key=lambda c: c["id"])
    for c in cards:
        c["unmapped_dependency_ids"] = [task for task in c["source_dependencies"] if task not in actual]
    return {
        "schema": "nox_owner_pareto_relay_v1", "canon_sha256": sha, "canon_url": CANON,
        "archive_url": ARCHIVE, "execution_kit_url": KIT, "blocks": blocks, "pv_gates": reviews,
        "active_model_plan": "GLM-5.3 on S1; physical serving subject to owner evidence",
        "s2_policy": "S2 is auxiliary. Soul training and independent control require separate admission. S1 exclusively serves GLM-5.3.",
        "native_execution_enabled": False,
    }


def markdown(plan):
    lines = [
        "# NOX · 200 карточек Парето и восемь ворот запуска", "",
        "Ранги внутри блока задают приоритет. В очередь попадает готовая карточка с подтверждённым исполнителем, зависимостями и ресурсом. Исторические цели и результаты сохранены в JSON.", "",
        "S1 — GLM‑5.3. S2 — учебный этап Soul и вспомогательные задачи по отдельному допуску.", "",
        f"[Канон v5]({CANON}) · [Архив]({ARCHIVE}) · [Комплект проверок]({KIT})", "",
    ]
    for block in plan["blocks"]:
        lines.extend([f"## P{block['block']} · {block['name']} · {block['role']}", "",
                      "| № | Карточка | Что подтверждает физический результат |",
                      "|---:|---|---|"])
        for row in block["cards"]:
            esc = lambda value: value.replace("|", "&#124;").replace("\n", " ")
            lines.append(f"| {row['rank']} | {row['id']} · {esc(row['title'])} | {esc(row['physical_evidence'])} |")
        lines.append("")
    lines.extend(["## Отдельные восемь проверок PV", ""])
    for c in plan["pv_gates"]:
        lines.append(f"- **{c['id']}** · {c['title']} → {c['physical_evidence']}.")
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("canon", type=Path)
    parser.add_argument("--markdown", action="store_true")
    args = parser.parse_args()
    source = args.canon.read_bytes()
    data = build(json.loads(source), hashlib.sha256(source).hexdigest())
    print(markdown(data) if args.markdown else json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
