from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import stat
import subprocess
import sys
import tempfile
import unittest

import relay_journal as journal


SCRIPT = Path(__file__).with_name("relay_journal.py")


def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()


class RelayJournalTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / "relay? #.sqlite"

    def observe_args(self, number, **changes):
        args = {"event_id": sha(f"event-{number}"), "task_id": "PV-03", "kind": "lesson",
                "code": "REVOKE_CHECKED", "source_sha256": sha("sealed-source"),
                "lesson_code": "REVOKE_BEFORE_RECALL", "evidence_sha256": sha(f"receipt-{number}")}
        args.update(changes)
        return args

    def cli_observe(self, number):
        command = [sys.executable, str(SCRIPT), "--db", str(self.path), "observe"]
        for key, value in self.observe_args(number).items():
            command.extend(("--" + key.replace("_", "-"), value))
        output = subprocess.run(command, capture_output=True, text=True, timeout=15)
        self.assertEqual(output.returncode, 0, output.stdout + output.stderr)
        return json.loads(output.stdout)["state"]

    def test_parallel_first_initialization_and_event_replay(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            outcomes = list(pool.map(self.cli_observe, (0, 0, 0, *range(1, 11))))
        self.assertEqual(outcomes.count("RECORDED"), 11)
        self.assertEqual(outcomes.count("ALREADY_RECORDED"), 2)
        state = journal.status(self.path, task_id="PV-03", limit=4)
        self.assertEqual(state["counts"], {"error": 0, "lesson": 11})
        self.assertEqual([row["seq"] for row in state["observations"]], [11, 10, 9, 8])
        self.assertEqual(state["lessons"], [{"task_id": "PV-03", "lesson_code": "REVOKE_BEFORE_RECALL",
                                            "observations": 11, "source_versions": 1, "last_seq": 11}])
        self.assertEqual(stat.S_IMODE(self.path.stat().st_mode), 0o600)

    def test_conflicting_event_never_changes_original(self):
        first = journal.observe(self.path, **self.observe_args(1))
        replay = journal.observe(self.path, **self.observe_args(1))
        self.assertEqual(replay["state"], "ALREADY_RECORDED")
        self.assertEqual(replay["observation"], first["observation"])
        with self.assertRaisesRegex(journal.Hold, "EVENT_ID_CONFLICT"):
            journal.observe(self.path, **self.observe_args(1, evidence_sha256=sha("different")))
        self.assertEqual(journal.status(self.path)["observations"], [first["observation"]])

    def test_empty_status_and_invalid_input_never_create_journal(self):
        self.assertEqual(journal.status(self.path)["state"], "EMPTY")
        with self.assertRaisesRegex(journal.Hold, "INVALID_OBSERVATION_CODE"):
            journal.observe(self.path, **self.observe_args(1, code="raw private observation"))
        self.assertFalse(self.path.exists())

    def test_status_filters_and_lesson_groups_across_source_revisions(self):
        journal.observe(self.path, **self.observe_args(1))
        journal.observe(self.path, **self.observe_args(2, source_sha256=sha("next-version")))
        journal.observe(self.path, **self.observe_args(3, task_id="P4-03", kind="error", code="RESTORE_HOLD",
                                                       lesson_code=None, evidence_sha256=None))
        self.assertEqual(journal.status(self.path)["lessons"][0]["source_versions"], 2)
        state = journal.status(self.path, task_id="P4-03")
        self.assertEqual(state["counts"], {"error": 1, "lesson": 0})
        self.assertEqual(state["lessons"], [])
        self.assertEqual(state["observations"][0]["code"], "RESTORE_HOLD")

    def test_other_database_and_path_alias_are_refused(self):
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("CREATE TABLE existing (id INTEGER)")
            db.commit()
        self.path.chmod(0o600)
        before = self.path.read_bytes()
        with self.assertRaisesRegex(journal.Hold, "JOURNAL_IDENTITY_MISMATCH"):
            journal.observe(self.path, **self.observe_args(1))
        self.assertEqual(self.path.read_bytes(), before)
        alias = self.path.with_suffix(".alias")
        alias.symlink_to(self.path)
        with self.assertRaisesRegex(journal.Hold, "JOURNAL_PATH_NOT_PRIVATE_REGULAR_FILE"):
            journal.status(alias)

    def test_cli_hold_does_not_echo_untrusted_value(self):
        command = [sys.executable, str(SCRIPT), "--db", str(self.path), "observe", "--event-id", sha("id"),
                   "--task-id", "PV-03", "--kind", "error", "--code", "synthetic secret content",
                   "--source-sha256", sha("source")]
        result = subprocess.run(command, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stderr, "")
        self.assertEqual(json.loads(result.stdout), {"state": "HOLD", "reason": "INVALID_OBSERVATION_CODE",
                                                     "advisory_only": True})

    def test_only_whitelisted_columns_can_be_returned(self):
        args = self.observe_args(1)
        journal.observe(self.path, **args)
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("ALTER TABLE observations ADD COLUMN unrelated TEXT")
            db.execute("UPDATE observations SET unrelated=?", ("synthetic private content",))
            db.commit()
        self.assertNotIn("unrelated", journal.observe(self.path, **args)["observation"])
        self.assertNotIn("unrelated", journal.status(self.path)["observations"][0])


if __name__ == "__main__":
    unittest.main()
