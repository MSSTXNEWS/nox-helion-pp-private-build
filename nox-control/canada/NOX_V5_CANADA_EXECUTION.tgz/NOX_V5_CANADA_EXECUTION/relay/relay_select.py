"""Offer one ready native task per role from an owner-reviewed NOX export, without claiming it."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

SHA = re.compile(r"[0-9a-f]{64}\Z")
ROLES = tuple(f"A{n}" for n in range(7))
MODELS = {
    "primary": {"instance": 61825960, "model": "GLM-5.3", "quant": "UD-Q4_K_XL"},
    "auxiliary": {"instance": 60509551},
}
H1 = "S1"
H2 = "S2"
RESOURCE_FIELDS = ("cpu_slots", "ram_bytes", "disk_bytes", "gpu_mib")


def digest(value):
    return isinstance(value, str) and SHA.fullmatch(value) is not None


def resources(value):
    if set(value) != set(RESOURCE_FIELDS) or not all(type(x) is int and x >= 0 for x in value.values()):
        raise ValueError("INVALID_RESOURCE_BUDGET")
    return dict(value)


def assess(card, binding, snapshot, accepted, free, locks, bound_targets):
    task = card["id"]
    if task in accepted:
        return "ACCEPTED_IN_SUPPLIED_EXPORT"
    if card["owner_card"]:
        return "OWNER_ACTION"
    if card["unmapped_dependency_ids"] or set(card["source_dependencies"]) - accepted:
        return "DEPENDENCIES"
    if binding is None:
        return "NO_REVIEWED_NATIVE_BINDING"
    target = binding["target"]
    if target not in card["execution_targets"] or target not in free:
        return "TARGET_OR_RESOURCES_UNAVAILABLE"
    if binding["native_task_id"] in bound_targets:
        return "NATIVE_ID_ALREADY_SELECTED"
    active = snapshot["hosts"][target]
    if (not digest(active.get("owner_observation_sha256")) or active.get("allows_work") is not True
            or active.get("stop_clear") is not True):
        return "HOST_OR_STOP_UNCONFIRMED"
    if active.get("instance_id") != MODELS["primary" if target == H1 else "auxiliary"]["instance"]:
        return "WRONG_INSTANCE"
    if target == H2 and binding.get("purpose") not in {"approved_soul_training", "s03_backup_readiness", "independent_control"}:
        return "AUXILIARY_SCOPE_ONLY"
    if task == "PV-08" and not digest(snapshot.get("owner_cutover_lease_sha256")):
        return "OWNER_CUTOVER_LEASE"
    if (not digest(binding.get("binding_sha256")) or not digest(binding.get("expected_effect_sha256"))
            or not binding.get("native_task_id") or binding.get("owner_reviewed") is not True):
        return "UNVERIFIED_NATIVE_BINDING"
    if (target, card["resource_key"]) in locks:
        return "RESOURCE_LEASE"
    required = resources(binding["requested"])
    if any(required[key] > free[target][key] for key in required):
        return "RESOURCE_BUDGET"
    return "CANDIDATE"


def select(plan, snapshot):
    if plan.get("schema") != "nox_owner_pareto_relay_v1" or snapshot.get("schema") != "nox_relay_owner_export_v1":
        raise ValueError("SCHEMA_MISMATCH")
    auxiliary = snapshot.get("auxiliary", MODELS["auxiliary"])
    if snapshot.get("primary") != MODELS["primary"] or auxiliary != MODELS["auxiliary"]:
        raise ValueError("MODEL_POLICY_MISMATCH")
    if not digest(snapshot["observation_sha256"]):
        raise ValueError("OWNER_OBSERVATION_MISSING")
    roles = {role: [] for role in ROLES}
    for review in plan["pv_gates"]:
        roles[review["role"]].append(review)
    experiments = plan.get("experiment_cards", [])
    for card in experiments:
        if card["priority"] == "P0":
            roles[card["role"]].append(card)
    for block in plan["blocks"]:
        roles[block["role"]].extend(block["cards"])
    for card in experiments:
        if card["priority"] != "P0":
            roles[card["role"]].append(card)

    history = snapshot["accepted_receipts"]
    accepted = {key for key, value in history.items() if digest(value)}
    if len(accepted) != len(history):
        raise ValueError("ACCEPTANCE_DIGEST_MISSING")
    free = {name: resources(host["free_for_relay"]) for name, host in snapshot["hosts"].items() if name in {H1, H2}}
    locks = {(row["target"], row["key"]) for row in snapshot["active_locks"]}
    bindings = snapshot["reviewed_bindings"]
    selected, blockers, bound_targets = [], {}, set()

    # Prioritize runnable release gates and the GLM/S03 path without serializing independent roles.
    priorities = ("A1", "A3", "A2", "A5", "A0", "A4", "A6")
    for role in priorities:
        reasons = Counter()
        for card in roles[role]:
            task = card["id"]
            binding = bindings.get(task)
            gate = assess(card, binding, snapshot, accepted, free, locks, bound_targets)
            if gate != "CANDIDATE":
                reasons[gate] += 1
                continue
            target = binding["target"]
            requested = binding["requested"]
            for key in requested:
                free[target][key] -= requested[key]
            locks.add((target, card["resource_key"]))
            bound_targets.add(binding["native_task_id"])
            identity = {
                "canonical_id": task, "native_id": binding["native_task_id"], "target": target,
                "binding_sha256": binding["binding_sha256"],
            }
            operation_key = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
            selected.append(identity | {
                "role": role, "title": card["title"], "idempotency_key": operation_key,
                "expected_effect_sha256": binding["expected_effect_sha256"],
                "physical_evidence": card["physical_evidence"],
            })
            break
        blockers[role] = dict(reasons)
    return {
        "schema": "nox_relay_native_candidates_v1", "state": "CANDIDATES" if selected else "HOLD",
        "selected": selected, "blockers": blockers, "remaining_budget": free,
        "owner_export_sha256": snapshot["observation_sha256"],
        "native_execution_enabled": False, "native_submissions": 0,
    }


def read_json(path):
    with path.open("rb") as stream:
        content = stream.read(4 * 1024**2 + 1)
    if len(content) > 4 * 1024**2:
        raise ValueError("INPUT_TOO_LARGE")
    return json.loads(content)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", type=Path)
    parser.add_argument("owner_export", type=Path)
    args = parser.parse_args(argv)
    try:
        report = select(read_json(args.plan), read_json(args.owner_export))
    except (OSError, ValueError, TypeError, AttributeError, KeyError, RecursionError):
        report = {"state": "HOLD", "reason": "OWNER_EXPORT_OR_PLAN_INVALID", "native_submissions": 0}
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 2 if report["state"] == "HOLD" else 0


if __name__ == "__main__":
    sys.exit(main())
