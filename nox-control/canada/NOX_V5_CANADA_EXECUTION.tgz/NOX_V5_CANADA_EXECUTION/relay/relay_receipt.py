"""Cross-check an existing NOX dispatcher result and independent effect readback.

Purely offline. The native dispatcher snapshot provides job/claim identity;
an authorized per-request execution exporter supplies fields absent from that
snapshot. An independently authenticated reader supplies the object states.
Sequence numbers must come from one ordered observation trace. This module
checks consistency, not exporter authenticity, deployment, or task acceptance.
See test_relay_receipt.py for the complete trace shape.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re


SCHEMA = "NOX_RELAY_EFFECT_RECEIPT_V1"
SHA = re.compile(r"[0-9a-f]{64}\Z")
BINDING = {"task_id", "request_id", "job_id", "scope_sha256", "claim_nonce", "claim_epoch", "source_sha256"}
OPERATIONS = {"create", "update", "delete"}
OBSERVED_CHECK_OPERATIONS = {"chat_health", "memory_schema", "training_prerequisites", "queue_regression"}
MAX_BYTES = 2 * 1024 * 1024


class Hold(ValueError):
    """A fixed diagnostic code safe to emit."""


def require(condition, code):
    if not condition:
        raise Hold(code)


def sha(value):
    return isinstance(value, str) and SHA.fullmatch(value) is not None


def identifier(value):
    return isinstance(value, str) and bool(value) and value.strip() == value


def sequence(value):
    return type(value) is int and value > 0


def digest(value):
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False,
                     separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def checked_binding(value):
    require(isinstance(value, dict) and set(value) == BINDING
            and all(identifier(value[key]) for key in ("task_id", "request_id", "job_id", "claim_nonce"))
            and all(sha(value[key]) for key in ("scope_sha256", "source_sha256"))
            and sequence(value["claim_epoch"]), "INVALID_REQUEST_BINDING")
    return value


def adapt_native_result(row, execution, expected, native_operation):
    """Match a NOX_MAINT_SCOPE_POST_TASK row to a supplied execution witness."""
    require(checked_binding(execution["binding"]) == expected, "DISPATCH_REQUEST_MISMATCH")
    require(execution["mode"] == "native_effect" and execution["outcome"] == "APPLIED"
            and execution["test_only"] is False and execution["dry_run"] is False
            and execution["no_op"] is False, "NO_APPLIED_NATIVE_EFFECT")
    receipt, result = row["receipt"], row["result"]
    require(row["status"] == "done" and row["receipt_sha_matches"] is True
            and row["receipt_claim_matches"] is True and result["verified"] is True
            and receipt["schema"] == "NOX_NATIVE_SUBAGENT_RECEIPT_V1", "DISPATCH_NOT_VERIFIED_TERMINAL")
    require(receipt["phase"] == "NATIVE_LEAF_COMPLETED_ORIGINAL_NOT_ACCEPTED"
            and row["handler"] == "owner_native_typed_leaf" and row["leaf_sha_matches"] is True
            and row["worker_result"]["state"] == "NATIVE_LEAF_COMPLETED"
            and identifier(native_operation) and native_operation not in OBSERVED_CHECK_OPERATIONS
            and execution["native_operation"] == row["leaf"]["operation"] == native_operation
            and not any(part.get(flag) is True for part in (row, receipt, result, row["leaf"])
                        for flag in ("test_only", "dry_run", "no_op")), "DISPATCH_CHECK_OR_REVIEW_ONLY")
    require(row["id"] == receipt["task_id"] == expected["task_id"]
            and receipt["job_id"] == expected["job_id"] and row["claim"]["nonce"] == expected["claim_nonce"]
            and receipt["source_sha256"] == expected["source_sha256"], "DISPATCH_NATIVE_IDENTITY_MISMATCH")
    require(sha(result["receipt_sha256"]) and result["receipt_sha256"] == execution["native_receipt_sha256"],
            "DISPATCH_RECEIPT_DIGEST_MISMATCH")
    require(identifier(execution["exporter"]) and sequence(execution["start_seq"])
            and sequence(execution["terminal_seq"]) and execution["start_seq"] < execution["terminal_seq"],
            "DISPATCH_ORDER_NOT_PROVEN")
    return execution


def observed_state(observation, object_id):
    require(observation["object_id_sha256"] == object_id and sequence(observation["seq"]), "OBJECT_OBSERVATION_MISMATCH")
    present, state = observation["present"], observation["state_sha256"]
    require((present is True and sha(state)) or (present is False and state is None), "INVALID_OBSERVED_STATE")
    return state


def verify(intent, dispatcher, readback):
    binding = checked_binding(intent["binding"])
    effect = intent["effect"]
    operation, obj = effect["operation"], effect["object_id_sha256"]
    before_pin, after_pin = effect["before_sha256"], effect["after_sha256"]
    require(isinstance(operation, str) and operation in OPERATIONS and sha(obj), "INVALID_EFFECT_INTENT")
    require((operation == "create" and before_pin is None and sha(after_pin))
            or (operation == "update" and sha(before_pin) and sha(after_pin) and before_pin != after_pin)
            or (operation == "delete" and sha(before_pin) and after_pin is None), "EXPECTED_EFFECT_IS_NO_OP_OR_INVALID")

    applied = adapt_native_result(dispatcher["row"], dispatcher["execution"], binding, intent["native_operation"])
    require(applied["effect"] == effect, "DISPATCH_EFFECT_MISMATCH")
    require(checked_binding(readback["binding"]) == binding and readback["native_receipt_sha256"] == applied["native_receipt_sha256"],
            "READBACK_REQUEST_MISMATCH")
    require(identifier(readback["exporter"]) and readback["exporter"] != applied["exporter"]
            and readback["mode"] == "native_object_readback", "INDEPENDENT_READBACK_REQUIRED")
    before, after = readback["before"], readback["after"]
    require(observed_state(before, obj) == before_pin and observed_state(after, obj) == after_pin,
            "PHYSICAL_EFFECT_MISMATCH_OR_NO_OP")
    require(before["seq"] < applied["start_seq"] < applied["terminal_seq"] < after["seq"],
            "READBACK_NOT_CAUSALLY_ORDERED")

    stable_event = {key: binding[key] for key in ("task_id", "request_id", "scope_sha256", "claim_nonce", "claim_epoch")}
    stable_event["slot"] = "terminal_effect_check_v1"
    return {"schema": SCHEMA, "state": "EFFECT_EVIDENCE_CONSISTENT",
            "journal_event_id": digest(stable_event),
            "evidence_sha256": digest({"intent": intent, "dispatcher_execution": applied, "readback": readback}),
            "native_receipt_sha256": applied["native_receipt_sha256"], "effect_operation": operation,
            "native_provenance_verified": False, "original_task_accepted": False}


def unique_object(items):
    value = dict(items)
    require(len(items) == len(value), "DUPLICATE_JSON_KEY")
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args(argv)
    try:
        with args.receipt.open("rb") as source:
            raw = source.read(MAX_BYTES + 1)
        require(len(raw) <= MAX_BYTES, "RECEIPT_LIMIT")
        trace = json.loads(raw, object_pairs_hook=unique_object)
        require(trace["schema"] == SCHEMA, "INVALID_SCHEMA")
        print(json.dumps(verify(trace["intent"], trace["dispatcher"], trace["readback"]), sort_keys=True))
        return 0
    except Hold as failure:
        code = str(failure)
    except (AttributeError, KeyError, OSError, TypeError, ValueError, RecursionError):
        code = "INVALID_RECEIPT"
    print(json.dumps({"schema": SCHEMA, "state": "HOLD", "error": code, "original_task_accepted": False}))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
