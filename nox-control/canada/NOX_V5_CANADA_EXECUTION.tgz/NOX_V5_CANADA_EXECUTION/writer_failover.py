"""Check one synthetic PV-08 writer failover, retry, STOP and rollback trace.

Reads an exported staging receipt only. The canonical reader must query the
complete rows under each tested exchange, including tombstones and duplicates.
State digests describe canonical records, not SQLite file bytes. Check the
referenced restore-revoke proof and authenticate the exporters and their
ordering witness outside this module.
The test module provides a complete synthetic receipt example.
"""

import argparse
import json
from pathlib import Path
import re


SCHEMA = "NOX_PV08_WRITER_FAILOVER_V1"
MAX_RECEIPT_BYTES = 1024 * 1024
SHA = re.compile(r"[0-9a-f]{64}\Z")
SCOPE = {"owner", "data_scope", "project", "core", "persona", "dialog"}
ORDER = (
    ("baseline", "canonical_reader"),
    ("restored_revocation", "restore_reader"),
    ("candidate_ready", "controller"),
    ("cutover", "controller"),
    ("old_epoch_rejected", "writer_client"),
    ("new_exchange", "writer_client"),
    ("first_readback", "canonical_reader"),
    ("same_exchange_retry", "writer_client"),
    ("retry_readback", "canonical_reader"),
    ("exact_stop", "backend"),
    ("rollback", "controller"),
    ("rollback_fenced_epochs", "writer_client"),
    ("rollback_readback", "canonical_reader"),
)


class FailoverError(ValueError):
    """A fixed diagnostic code without private identifiers."""


def require(condition, code):
    if not condition:
        raise FailoverError(code)


def is_id(value):
    return isinstance(value, str) and bool(value.strip())


def is_sha(value):
    return isinstance(value, str) and SHA.fullmatch(value) is not None


def is_epoch(value):
    return type(value) is int and value >= 1


def identity(data):
    require(isinstance(data, dict) and set(data) == {"writer_id", "epoch", "route_sha256"}
            and is_id(data["writer_id"]) and is_epoch(data["epoch"]) and is_sha(data["route_sha256"]),
            "INVALID_WRITER_IDENTITY")
    return data


def ordered_events(receipt):
    require(receipt["schema"] == SCHEMA and is_id(receipt["run_id"]), "INVALID_SCHEMA_OR_RUN")
    scope = receipt["scope"]
    require(isinstance(scope, dict) and set(scope) == SCOPE and all(is_id(v) for v in scope.values())
            and re.fullmatch(r"C0[1-8]", scope["core"]) is not None, "INVALID_SCOPE")
    observers = receipt["observers"]
    require(isinstance(observers, dict) and set(observers) == {role for _, role in ORDER}
            and all(is_id(v) for v in observers.values()) and len(set(observers.values())) == len(observers),
            "EXPORTERS_NOT_DISTINGUISHED")
    events = receipt["events"]
    require(isinstance(events, list) and len(events) == len(ORDER), "EVENT_COUNT")
    result = {}
    for seq, ((kind, role), event) in enumerate(zip(ORDER, events), start=1):
        require(isinstance(event, dict) and type(event["seq"]) is int and event["seq"] == seq
                and event["kind"] == kind and event["observer"] == observers[role]
                and event["run_id"] == receipt["run_id"] and event["scope"] == scope,
                "EVENT_ORDER_OR_BINDING_MISMATCH")
        result[kind] = event
    return result


def verify_rows(rows, exchange):
    require(isinstance(rows, list) and len(rows) == 2, "EXCHANGE_NOT_EXACTLY_ONCE")
    for row, role, key in zip(rows, ("user", "assistant"), ("user_sha256", "answer_sha256")):
        require(row["role"] == role and is_id(row["id"]) and is_epoch(row["sequence"])
                and row["sha256"] == exchange[key] and row["request_id"] == exchange["request_id"]
                and row["exchange_id"] == exchange["exchange_id"] and row["scope"] == exchange["scope"]
                and row["writer"] == exchange["writer"], "CANONICAL_ROW_MISMATCH")
    require(rows[0]["id"] != rows[1]["id"] and rows[1]["sequence"] == rows[0]["sequence"] + 1,
            "CANONICAL_ROW_ORDER")


def verify(receipt):
    events = ordered_events(receipt)
    base, restored = events["baseline"], events["restored_revocation"]
    old = identity(base["writer"])
    epoch, state = base["revocation_epoch"], base["canonical_state_sha256"]
    revoked = base["revoked_canary_sha256"]
    require(is_epoch(epoch) and is_sha(state) and is_sha(revoked), "INVALID_BASELINE")
    require(is_epoch(restored["archive_revocation_epoch"]) and restored["archive_revocation_epoch"] < epoch
            and type(restored["ledger_epoch"]) is int and restored["ledger_epoch"] == epoch
            and is_sha(restored["archive_sha256"]) and is_sha(restored["restored_state_sha256"])
            and is_sha(restored["restore_proof_sha256"]) and is_sha(restored["ledger_head_sha256"])
            and is_id(restored["isolated_run_id"]) and is_id(restored["affected_event_id"])
            and is_epoch(restored["applied_seq"]) and is_epoch(restored["ready_seq"])
            and restored["applied_seq"] < restored["ready_seq"] and restored["revoke_enforced_before_ready"] is True
            and restored["canonical_state_sha256"] == state and restored["revoked_canary_sha256"] == revoked
            and restored["revoked_keys_resolvable"] == [] and restored["positive_readback_verified"] is True,
            "RESTORED_REVOCATION_NOT_VERIFIED")

    ready, cut = events["candidate_ready"], events["cutover"]
    new = identity(ready["writer"])
    require(new["writer_id"] != old["writer_id"] and new["epoch"] > old["epoch"]
            and ready["restore_seq"] == restored["seq"]
            and all(ready[key] == restored[key] for key in ("restored_state_sha256", "restore_proof_sha256",
                                                            "ledger_head_sha256", "ledger_epoch", "isolated_run_id")),
            "READY_NOT_BOUND_TO_RESTORED_REVOCATION")
    require(cut["from_writer"] == old and cut["to_writer"] == new and cut["ready_seq"] == ready["seq"]
            and cut["active_writers"] == [new] and cut["outcome"] == "CAS_APPLIED", "CUTOVER_CAS_NOT_PROVEN")

    late, write = events["old_epoch_rejected"], events["new_exchange"]
    require(late["writer"] == old and is_id(late["request_id"]) and is_id(late["exchange_id"])
            and late["outcome"] == "FENCED_STALE_EPOCH" and late["before_state_sha256"] == state
            and late["after_state_sha256"] == state, "OLD_EPOCH_WAS_NOT_FENCED")
    require(write["writer"] == new and is_id(write["request_id"]) and is_id(write["exchange_id"])
            and write["request_id"] != late["request_id"] and write["exchange_id"] != late["exchange_id"]
            and all(is_sha(write[key]) for key in ("request_sha256", "user_sha256", "answer_sha256"))
            and is_id(write["commit_receipt_id"]) and is_id(write["backend_job_id"])
            and write["outcome"] == "ACK_LOST_AFTER_COMMIT", "NEW_EXCHANGE_NOT_BOUND")

    first, retry = events["first_readback"], events["same_exchange_retry"]
    rows = first["rows"]
    verify_rows(rows, write)
    new_state = first["canonical_state_sha256"]
    require(is_sha(new_state) and new_state != state and first["late_old_exchange_rows"] == []
            and first["commit_receipt_id"] == write["commit_receipt_id"], "FIRST_CANONICAL_COMMIT_NOT_PROVEN")
    keys = ("writer", "request_id", "exchange_id", "request_sha256", "commit_receipt_id", "backend_job_id")
    require(all(retry[key] == write[key] for key in keys) and retry["outcome"] == "RETURNED_EXISTING_RECEIPT"
            and retry["returned_row_ids"] == [row["id"] for row in rows], "RETRY_DID_NOT_RETURN_SAME_COMMIT")
    retried = events["retry_readback"]
    require(retried["rows"] == rows and retried["canonical_state_sha256"] == new_state
            and retried["late_old_exchange_rows"] == [] and retried["commit_receipt_id"] == write["commit_receipt_id"],
            "RETRY_MUTATED_CANONICAL_EXCHANGE")

    stop = events["exact_stop"]
    target, sibling = stop["target"], stop["unrelated"]
    require(all(is_id(signal[key]) for signal in (target, sibling) for key in ("request_id", "backend_job_id"))
            and len({target["request_id"], sibling["request_id"], write["request_id"], late["request_id"]}) == 4
            and len({target["backend_job_id"], sibling["backend_job_id"], write["backend_job_id"]}) == 3
            and stop["requested_request_id"] == target["request_id"] and stop["requested_backend_job_id"] == target["backend_job_id"]
            and target["state_before_stop"] == sibling["state_before_stop"] == "active"
            and target["terminal"] == "cancelled" and type(target["events_after_terminal"]) is int
            and target["events_after_terminal"] == 0
            and sibling["terminal"] == "done" and stop["write_exchange_backend_job_ids"] == [write["backend_job_id"]],
            "EXACT_STOP_OR_NO_REPLAY_NOT_PROVEN")

    rollback = events["rollback"]
    back = identity(rollback["to_writer"])
    require(back["writer_id"] == old["writer_id"] and back["route_sha256"] == old["route_sha256"]
            and back["epoch"] > new["epoch"] and rollback["from_writer"] == new and rollback["active_writers"] == [back]
            and rollback["outcome"] == "CAS_APPLIED", "ROLLBACK_REUSED_EPOCH_OR_LOST_AUTHORITY")

    fenced, final = events["rollback_fenced_epochs"], events["rollback_readback"]
    attempts = fenced["attempts"]
    require(fenced["active_writer"] == back and isinstance(attempts, list) and len(attempts) == 2,
            "SUPERSEDED_WRITER_STILL_ACTIVE_AFTER_ROLLBACK")
    rollback_attempt_ids = [attempt["exchange_id"] for attempt in attempts]
    require(all(attempt["writer"] == writer and attempt["outcome"] == "FENCED_STALE_EPOCH"
                and is_id(attempt["exchange_id"]) for attempt, writer in zip(attempts, (old, new)))
            and len(set(rollback_attempt_ids + [late["exchange_id"], write["exchange_id"]])) == 4,
            "SUPERSEDED_WRITER_STILL_ACTIVE_AFTER_ROLLBACK")
    require(final["writer"] == back and final["rows"] == rows and final["late_old_exchange_rows"] == []
            and final["commit_receipt_id"] == write["commit_receipt_id"]
            and final["revocation_epoch"] == epoch and final["revoked_canary_sha256"] == revoked
            and final["affected_event_id"] == restored["affected_event_id"]
            and final["revoked_keys_resolvable"] == [] and final["cancelled_request_id"] == target["request_id"]
            and final["cancelled_assistant_rows"] == []
            and final["stale_epoch_rows"] == {attempt_id: [] for attempt_id in rollback_attempt_ids},
            "ROLLBACK_LOST_COMMIT_OR_REVIVED_REVOKED_STATE")

    return {"state": "WRITER_FAILOVER_TRACE_CONSISTENT", "ordered_events": len(ORDER),
            "canonical_exchanges": 1, "canonical_rows": 2, "independent_exporter_auth_verified": False,
            "referenced_restore_proof_verified": False, "model_quality_verified": False, "live_acceptance": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args(argv)
    try:
        with args.receipt.open("rb") as source:
            raw = source.read(MAX_RECEIPT_BYTES + 1)
        require(len(raw) <= MAX_RECEIPT_BYTES, "RECEIPT_LIMIT")
        print(json.dumps(verify(json.loads(raw)), sort_keys=True))
        return 0
    except FailoverError as exc:
        code = str(exc)
    except (OSError, KeyError, TypeError, ValueError, AttributeError, RecursionError):
        code = "INVALID_RECEIPT"
    print(json.dumps({"state": "HOLD", "error": code, "live_acceptance": False}, sort_keys=True))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
