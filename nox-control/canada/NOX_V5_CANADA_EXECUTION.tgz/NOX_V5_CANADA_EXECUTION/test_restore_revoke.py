import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import model_handoff
from restore_revoke import SCHEMA, ledger_digest, verify


def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()


def fixture():
    target = {"owner": "test-owner", "data_scope": "private", "project": "test-project",
              "core": "C03", "persona": "KV", "dialog": "test-dialog"}
    negative = "nox-bench-" + "a" * 32
    positive = "nox-bench-" + "b" * 32
    revoked_id, retained_id = "evt-revoke", "evt-retain"
    archive_pin = sha("fixture-archive-bytes")
    restore_digest = sha("fixture-restored-state")
    ingress = model_handoff.observe_messages(b'{"messages":[{"role":"user","content":"Continue"}]}')
    wire = json.dumps({"messages": [{"role": "system", "content": positive},
                                   {"role": "user", "content": "Continue"}]}).encode()
    actual = model_handoff.observe_messages(wire)
    call_pins = {key: actual[key] for key in ("body_sha256", "context_sha256")}
    attempt = {"scope": target, "request_id": "req-restore", "exchange_id": "exchange-restore",
               "request_sha256": ingress["body_sha256"], "route_id": "restore-qa", "route_sha256": sha("route"),
               "runtime_sha256": sha("runtime"), "model_sha256": sha("model")}

    def row(event, revision, state, marker):
        return {"scope": target, "event_id": event, "revision": revision, "state": state,
                "canary_sha256": sha(marker)}

    older = [row(revoked_id, 1, "active", negative), row(retained_id, 1, "active", positive)]
    latest = [row(revoked_id, 2, "revoked", negative), row(retained_id, 1, "active", positive)]
    body = {"scope": target, "archive_sha256": archive_pin, "ledger_epoch": 9, "records": latest}
    body_pin = ledger_digest(body)
    archive = {"exporter": "archive-auditor", "archive_sha256": archive_pin, "scope": target,
               "ledger_epoch": 8, "records": older, "warm_kv": {
                   "slot_scope": target, "revocation_epoch": 8, "slot_generation": "before-slot",
                   "prefix_sha256": sha("old-prefix"), "cached_tokens": 30,
                   "cached_canary_sha256s": [sha(negative), sha(positive)]}}
    authority = {"exporter": "owner-ledger-auditor", "ledger_head_sha256": body_pin, "ledger_body": body}
    restore = {"exporter": "restore-auditor", "scope": target, "ledger_epoch": 9, "archive_sha256": archive_pin,
               "restored_state_sha256": restore_digest, "revoked_canary_sha256": sha(negative),
               "affected_event_id": revoked_id, "revoke_enforced_before_ready": True,
               "ledger_head_sha256": body_pin, "isolated_run_id": "restore-run", "applied_seq": 10,
               "ready_seq": 12}
    backend = {"attempt": attempt, "exporter": "backend-auditor", **call_pins, "model_call_id": "call-restore",
               "slot_generation": "restored-slot", "job_id": "job-restore"}
    trace = {"attempt": attempt, "expected_terminal": "done", "required_canary_sha256s": [sha(positive)],
             "ingress": {"attempt": attempt, "body_sha256": ingress["body_sha256"], "canary_sha256s": []},
             "ledger": {"attempt": attempt, "exporter": authority["exporter"], "revocation_epoch": 9,
                        "records": latest, "ledger_head_sha256": body_pin, "isolated_run_id": "restore-run",
                        "restored_state_sha256": restore_digest},
             "model_handoffs": [{"attempt": attempt, "exporter": "model-auditor", **actual,
                                 "model_call_id": "call-restore"}],
             "backend_kv": {**backend, "slot_scope": target, "revocation_epoch": 9,
                            "prefix_sha256": sha("restored-prefix"), "cached_tokens": 25,
                            "cached_canary_sha256s": [sha(positive)], "isolated_run_id": "restore-run",
                            "handoff_seq": 14},
             "backend_terminal": {**backend, "state": "done"}}
    return {"schema": SCHEMA, "archive": archive, "authority": authority, "restore": restore,
            "model_trace": trace}, archive_pin, body_pin


class RestoreRevokeTests(unittest.TestCase):
    def test_restored_warm_trace_certifies_consistency_only(self):
        receipt, archive, ledger = fixture()
        self.assertEqual(verify(receipt, archive, ledger), {
            "state": "RESTORE_REVOKE_TRACE_CONSISTENT", "schema": SCHEMA, "live_acceptance": False,
            "origin_authenticated": False, "ledger_head_sha256": ledger, "ledger_epoch": 9})

    def test_rejects_alternative_current_head_or_archive(self):
        receipt, archive, ledger = fixture()
        with self.assertRaisesRegex(model_handoff.TraceError, "LATEST_AUTHORITY_PIN"):
            verify(receipt, archive, sha("stale head"))
        with self.assertRaisesRegex(model_handoff.TraceError, "SNAPSHOT_SCOPE_OR_PIN"):
            verify(receipt, sha("different archive"), ledger)

    def test_newer_ledger_with_reactivated_event_cannot_pass(self):
        receipt, archive, _ = fixture()
        body = receipt["authority"]["ledger_body"]
        body["records"][0]["state"] = "active"
        pin = ledger_digest(body)
        receipt["authority"]["ledger_head_sha256"] = receipt["restore"]["ledger_head_sha256"] = pin
        with self.assertRaisesRegex(model_handoff.TraceError, "MISSING_NEWER_TOMBSTONE"):
            verify(receipt, archive, pin)

    def test_no_acceptance_if_model_run_precedes_revocation_or_uses_another_restore(self):
        for field, value in (("ready_seq", 14), ("isolated_run_id", "other-restore")):
            with self.subTest(field=field):
                receipt, archive, ledger = fixture()
                receipt["restore"][field] = value
                with self.assertRaisesRegex(model_handoff.TraceError, "RESTORE_BEFORE_MODEL_UNPROVEN"):
                    verify(receipt, archive, ledger)

    def test_revoked_marker_in_effective_input_or_cache_is_rejected(self):
        for target, field, reason in (("model_handoffs", "canary_sha256s", "CANARY_IN_MODEL_INPUT"),
                                      ("backend_kv", "cached_canary_sha256s", "STALE_KV_CANARY")):
            with self.subTest(target=target):
                receipt, archive, ledger = fixture()
                block = receipt["model_trace"][target]
                if target == "model_handoffs":
                    block = block[0]
                block[field].append(receipt["restore"]["revoked_canary_sha256"])
                with self.assertRaisesRegex(model_handoff.TraceError, reason):
                    verify(receipt, archive, ledger)

    def test_cold_cache_or_reused_generation_does_not_prove_warm_revoke(self):
        for kwargs in ({"cached_tokens": 0, "cached_canary_sha256s": []},
                       {"slot_generation": "before-slot"}):
            with self.subTest(fields=kwargs):
                receipt, archive, ledger = fixture()
                trace = receipt["model_trace"]
                trace["backend_kv"].update(kwargs)
                if "slot_generation" in kwargs:
                    trace["backend_terminal"].update(kwargs)
                with self.assertRaisesRegex(model_handoff.TraceError, "CURRENT_WARM_REVOKE_NOT_PROVEN"):
                    verify(receipt, archive, ledger)

    def test_cli_rejects_raw_fields_without_printing_them(self):
        receipt, archive, ledger = fixture()
        receipt["model_trace"]["model_handoffs"][0]["raw_text"] = "synthetic-private-secret"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "receipt.json"
            path.write_text(json.dumps(receipt), encoding="utf-8")
            script = Path(__file__).with_name("restore_revoke.py")
            result = subprocess.run([sys.executable, str(script), str(path), "--archive-sha256", archive,
                                     "--ledger-head-sha256", ledger], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stderr, "")
        self.assertEqual(json.loads(result.stdout), {"state": "HOLD", "reason": "UNEXPECTED_RECEIPT_FIELDS",
                                                      "live_acceptance": False})


if __name__ == "__main__":
    unittest.main()
