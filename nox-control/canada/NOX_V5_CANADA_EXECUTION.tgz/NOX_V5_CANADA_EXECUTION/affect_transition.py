"""Check NOX_AFFECT_STALE_V1 staging receipts for late affect after a persona switch.

The top-level document contains route/model SHA-256 pins, observer IDs, four
handoffs and five state events. The fixed order is baseline, three failures,
reflection, new persona's baseline, late result, replay, final new-persona call.
Each handoff describes the actual model boundary; each state event describes
the affect controller's transition. The two new-persona probes must reuse the
same frozen model input without appending either probe to conversation history.
An independent reviewer must authenticate the exporters and check the hashes
against the actual runtime, state and model input. This tool only checks their
receipt consistency offline.
"""

import argparse
import json
import re
from pathlib import Path


SCHEMA = "NOX_AFFECT_STALE_V1"
MAX_RECEIPT_BYTES = 64 * 1024
TOKEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}")
SHA256 = re.compile(r"[0-9a-f]{64}")
SCOPE = {"owner", "data_scope", "project", "core", "persona", "dialog"}
HANDOFF_DIGESTS = {"question_sha256", "context_sha256", "facts_sha256", "soul_sha256",
                   "acl_sha256", "affect_sha256", "route_sha256", "model_sha256"}
HANDOFF = HANDOFF_DIGESTS | {"observer", "request_id", "model_call_id", "scope", "epoch",
                            "step", "cause_event", "strategy"}
EVENT = {"observer", "scope", "epoch", "step", "event_id", "cause_event", "kind", "outcome",
         "source_receipt_sha256", "before_sha256", "after_sha256"}


class Hold(ValueError):
    pass


def check(value, reason):
    if not value:
        raise Hold(reason)


def matches(pattern, value):
    return type(value) is str and pattern.fullmatch(value) is not None


def shape(value, keys, reason):
    check(type(value) is dict and value.keys() == keys, reason)


def validate_stamp(value, observer, step):
    check(value["observer"] == observer and type(value["step"]) is int
          and value["step"] == step and type(value["epoch"]) is int
          and value["epoch"] > 0, "OBSERVER_OR_ORDER")
    scope = value["scope"]
    shape(scope, SCOPE, "SCOPE_SHAPE")
    check(all(matches(TOKEN, part) for part in scope.values()), "SCOPE_TOKEN")
    cause = value["cause_event"]
    check(cause is None or matches(TOKEN, cause), "CAUSE_TOKEN")


def same(left, right, *fields):
    return all(left[field] == right[field] for field in fields)


def verify(receipt):
    shape(receipt, {"schema", "route_sha256", "model_sha256", "observers", "handoffs", "events"},
          "RECEIPT_SHAPE")
    check(receipt["schema"] == SCHEMA, "RECEIPT_SCHEMA")
    observers = receipt["observers"]
    shape(observers, {"affect_controller", "model_handoff"}, "OBSERVER_SHAPE")
    affect, handoff = observers["affect_controller"], observers["model_handoff"]
    check(matches(TOKEN, affect) and matches(TOKEN, handoff) and affect != handoff, "OBSERVER_IDS")

    handoffs, events = receipt["handoffs"], receipt["events"]
    check(type(handoffs) is list and len(handoffs) == 4 and type(events) is list and len(events) == 5,
          "TRACE_CARDINALITY")
    for row, step in zip(handoffs, (0, 4, 5, 8), strict=True):
        shape(row, HANDOFF, "HANDOFF_SHAPE")
        validate_stamp(row, handoff, step)
        check(all(matches(SHA256, row[field]) for field in HANDOFF_DIGESTS)
              and same(row, receipt, "route_sha256", "model_sha256"), "HANDOFF_DIGEST_OR_PIN")
        check(matches(TOKEN, row["request_id"]) and matches(TOKEN, row["model_call_id"]), "HANDOFF_IDS")
    for key in ("request_id", "model_call_id"):
        check(len({row[key] for row in handoffs}) == 4, "HANDOFF_ID_REUSED")
    for row, step in zip(events, (1, 2, 3, 6, 7), strict=True):
        shape(row, EVENT, "EVENT_SHAPE")
        validate_stamp(row, affect, step)
        check(matches(TOKEN, row["event_id"]) and all(matches(SHA256, row[field]) for field in (
            "before_sha256", "after_sha256", "source_receipt_sha256")), "EVENT_DIGEST_OR_ID")

    baseline, reflected, new_scope, final = handoffs
    check((baseline["cause_event"], baseline["strategy"]) == (None, "act"), "BASELINE")
    check(same(baseline, reflected, "scope", "epoch", "question_sha256", "facts_sha256", "soul_sha256",
               "acl_sha256") and reflected["context_sha256"] != baseline["context_sha256"]
          and reflected["strategy"] == "reflect", "REFLECTION_CONTROL")
    previous = baseline["affect_sha256"]
    failures = events[:3]
    check(len({event["event_id"] for event in failures}) == 3
          and len({event["source_receipt_sha256"] for event in failures}) == 3, "FAILURE_REPLAY")
    for failure in failures:
        check(same(failure, baseline, "scope", "epoch")
              and (failure["kind"], failure["outcome"]) == ("verified_failure", "applied")
              and failure["cause_event"] == failure["event_id"] and failure["before_sha256"] == previous,
              "FAILURE_CHAIN")
        previous = failure["after_sha256"]
    check(reflected["cause_event"] == failures[-1]["event_id"]
          and reflected["affect_sha256"] == previous and previous != baseline["affect_sha256"],
          "REFLECTION_NOT_BOUND")

    old_keys, new_keys = baseline["scope"], new_scope["scope"]
    check(new_scope["epoch"] == baseline["epoch"] + 1
          and same(old_keys, new_keys, "owner", "data_scope", "project", "core")
          and old_keys["persona"] != new_keys["persona"]
          and (new_scope["cause_event"], new_scope["strategy"]) == (None, "act"), "SCOPE_SWITCH")
    delayed, replay = events[3:]
    check(all(same(event, baseline, "scope", "epoch") and event["kind"] == "slow_reflection"
              and event["cause_event"] == reflected["cause_event"]
              and event["before_sha256"] == event["after_sha256"] == new_scope["affect_sha256"]
              for event in (delayed, replay))
          and delayed["outcome"] == "rejected_stale" and replay["outcome"] in (
              "rejected_stale", "rejected_duplicate")
          and delayed["event_id"] not in {event["event_id"] for event in failures}
          and delayed["source_receipt_sha256"] not in {event["source_receipt_sha256"] for event in failures}
          and same(delayed, replay, "event_id", "source_receipt_sha256"), "STALE_OR_REPLAY_APPLIED")
    check(same(new_scope, final, "scope", "epoch", "question_sha256", "facts_sha256", "soul_sha256",
               "acl_sha256", "affect_sha256", "context_sha256", "cause_event", "strategy"), "NEW_SCOPE_DRIFT")
    return {"state": "EVIDENCE_CONSISTENT", "schema": SCHEMA, "live_acceptance": False,
            "origin_authenticated": False, "handoffs": 4, "confirmed_late_rejections": 2}


def unique_object(pairs):
    result = dict(pairs)
    check(len(result) == len(pairs), "DUPLICATE_JSON_FIELD")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args(argv)
    try:
        with args.receipt.open("rb") as source:
            raw = source.read(MAX_RECEIPT_BYTES + 1)
        check(len(raw) <= MAX_RECEIPT_BYTES, "RECEIPT_TOO_LARGE")
        result = verify(json.loads(raw, object_pairs_hook=unique_object))
    except Hold as error:
        print(json.dumps({"state": "HOLD", "reason": str(error), "live_acceptance": False}))
        return 2
    except (OSError, ValueError, UnicodeError):
        print(json.dumps({"state": "HOLD", "reason": "RECEIPT_INPUT", "live_acceptance": False}))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
