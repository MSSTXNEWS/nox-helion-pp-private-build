import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from evaluation import nox_eval


class EvalTests(unittest.TestCase):
    def setUp(self):
        self.cases = nox_eval.suite(8)
        self.expected = {case.messages: case.expected for case in self.cases}

    def report(self, mutate=None):
        def complete(messages):
            expected = self.expected[messages]
            if mutate and mutate(messages):
                expected = "incorrect"
            return {"text": expected, "first_visible_text_seconds": 0.2,
                    "first_generated_text_seconds": 0.1, "end_to_end_seconds": 0.4}
        report = nox_eval.score(self.cases, complete, 1)
        report["suite_fingerprint"] = nox_eval.suite_fingerprint(self.cases, 1)
        return report

    def test_acceptance_distinguishes_run_and_comparison(self):
        baseline = self.report()
        self.assertEqual(18, len(baseline["runs"]))
        self.assertEqual("PASS", nox_eval.acceptance(baseline, 0.8)["status"])
        target = self.cases[0].messages
        candidate = self.report(lambda prompt: prompt == target)
        self.assertEqual("PASS", nox_eval.acceptance(candidate, 0.8)["status"])
        self.assertIn("baseline_case_accuracy_regressed",
                      nox_eval.acceptance(candidate, 0.8, baseline)["failures"])
        candidate = self.report()
        candidate["timings"]["first_visible_text_seconds"]["p95"] = 0.8
        self.assertIn("first_visible_text_seconds_regressed",
                      nox_eval.acceptance(candidate, 0.8, baseline)["failures"])
        target_critical = next(case.messages for case in self.cases if case.critical)
        critical = self.report(lambda prompt: prompt == target_critical)
        self.assertIn("critical_case_failed", nox_eval.acceptance(critical, 0.8)["failures"])

    def test_loopback_only(self):
        self.assertEqual("http://127.0.0.1:1234/chat/completions",
                         nox_eval.local_endpoint("http://127.0.0.1:1234/chat/completions"))
        for url in ("http://8.8.8.8/chat/completions", "https://example.com/chat/completions",
                    "http://user:secret@localhost/chat/completions", "http://localhost/other"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                nox_eval.local_endpoint(url)

    def test_stream_adapter_keeps_reasoning_out_of_user_text(self):
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                size = int(self.headers["Content-Length"])
                payload = json.loads(self.rfile.read(size))
                if payload["model"] != "glm-5.3":
                    self.send_error(400)
                    return
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.end_headers()
                events = [
                    {"choices": [{"delta": {"reasoning_content": "scratch"}}]},
                    {"choices": [{"delta": {"content": "ИТОГ"}}]},
                    {"choices": [{"delta": {"content": "\nПРОВЕРКА"}}]},
                    {"choices": [{"delta": {}, "finish_reason": "stop"}]},
                    {"usage": {"prompt_tokens": 42, "completion_tokens": 9}, "choices": []},
                ]
                for event in events:
                    self.wfile.write(("data: " + json.dumps(event) + "\n\n").encode())
                self.wfile.write(b"data: [DONE]\n\n")

            def log_message(self, *args):
                pass

        with ThreadingHTTPServer(("127.0.0.1", 0), Handler) as server:
            thread = threading.Thread(target=server.serve_forever)
            thread.start()
            try:
                result = nox_eval.stream_completion(
                    f"http://127.0.0.1:{server.server_port}/v1/chat/completions",
                    "glm-5.3", (("user", "Пример."),), 2,
                )
            finally:
                server.shutdown()
                thread.join()
        self.assertEqual("ИТОГ\nПРОВЕРКА", result["text"])
        self.assertEqual(42, result["prompt_tokens"])
        self.assertLessEqual(result["first_generated_text_seconds"], result["first_visible_text_seconds"])


if __name__ == "__main__":
    unittest.main()
