#!/usr/bin/env python3
"""Run the GLM-5.3 quality gate against a local OpenAI-compatible chat endpoint."""

import argparse
import hashlib
import ipaddress
import json
import math
import os
import random
import statistics
import sys
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


SUITE_VERSION = 1
MAX_TOKENS = 768


@dataclass(frozen=True)
class Case:
    name: str
    language: str
    category: str
    messages: tuple
    expected: str
    critical: bool = False


def suite(filler_lines=128):
    def case(name, language, category, prompt, expected, history=(), critical=False):
        messages = history + (("user", prompt),)
        return Case(name, language, category, messages, expected, critical)

    def ledger(language, position):
        rng = random.Random(20261121)
        rows = [
            f"ITEM-{row:04d} | LOT-{rng.randrange(100000, 999999)} | TAG-{rng.randrange(100000, 999999)}"
            for row in range(filler_lines)
        ]
        rows.insert(position, "ITEM-KESTREL | LOT-705126 | TAG-312804")
        rows.insert(position + 1, "ITEM-KESTRELS | LOT-705162 | TAG-318204")
        prompt = {
            "ru": "В реестре найди точное совпадение ITEM-KESTREL (без S) и верни только поле TAG.",
            "es": "Busca la coincidencia exacta de ITEM-KESTREL (sin S) y devuelve solo el campo TAG.",
        }[language]
        return "\n".join(rows) + "\n\n" + prompt

    return [
        case("ru-plan", "ru", "reasoning", """Есть 46 заказов. Утром выполнено 14, вечером выполнено вдвое меньше, чем утром, а 4 оставшихся заказа отменили. Сколько ещё надо выполнить? Верни только число.""", "21"),
        case("es-plan", "es", "reasoning", """Hay 68 encargos. El lunes se completan 18, el martes un tercio de los del lunes y se cancelan 7 de los pendientes. ¿Cuántos quedan? Escribe solo el número.""", "37"),
        case("ru-constraint", "ru", "reasoning", """Есть задания A (3 мин), B (5 мин), C (2 мин), D (4 мин). A и B могут стартовать вместе. C ждёт A, D ждёт B и C. Сколько минут до готовности D, если нет других ограничений? Только число.""", "9"),
        case("es-constraint", "es", "reasoning", """Hay dos máquinas que en paralelo tardan 3 y 8 minutos. Tras ambas, controlar el resultado tarda 4 minutos. Luego empaquetar tarda 2. ¿Cuántos minutos? Solo el número.""", "14"),
        case("ru-format", "ru", "instruction", """Ответь только двумя строчками. Первая ИТОГ, вторая ПРОВЕРКА. Без кавычек, списка или пунктуации.""", "ИТОГ\nПРОВЕРКА"),
        case("es-format", "es", "instruction", """Responde con dos líneas. En la primera escribe RESULTADO y en la segunda REVISIÓN. Sin otras palabras ni signos.""", "RESULTADO\nREVISIÓN"),
        case("ru-grounded", "ru", "factuality", """[A] В апреле измерено 13 запусков. [B] В мае измерено 9 запусков. [C] В июне измерено 19 запусков. Какой фрагмент подтверждает, что было меньше 10 запусков? Верни только идентификатор фрагмента в квадратных скобках.""", "[B]"),
        case("es-grounded", "es", "factuality", """[D] El martes se midieron 23 unidades. [E] El jueves se midieron 41. [F] El sábado se midieron 18. ¿Qué fuente respalda que se superaron 40 unidades? Solo la referencia entre corchetes.""", "[E]"),
        case("ru-abstain", "ru", "uncertainty", """В журнале сказано только: «Проба отключена 3 марта». Какой был номер устройства? Если в журнале нет ответа, верни только НЕТ ДАННЫХ.""", "НЕТ ДАННЫХ", critical=True),
        case("es-abstain", "es", "uncertainty", """La nota solo dice «El envío cerró el 5 de marzo». ¿Cuál era el número de seguimiento? Si no consta, escribe solo SIN DATOS.""", "SIN DATOS", critical=True),
        case("ru-revision", "ru", "memory", "Какое кодовое имя использовать сейчас? Напиши только код.",
             "БЕРЕГ-19", (("user", "Назовём макет ПРИЧАЛ-12."), ("assistant", "Принял код макета."),
                          ("user", "Поправка: код макета теперь БЕРЕГ-19."), ("assistant", "Поправка принята."))),
        case("es-revision", "es", "memory", "¿Cuál es el nombre de referencia vigente? Escribe solo el código.",
             "OLMO-28", (("user", "El inventario se llamará PINO-52."), ("assistant", "Apuntado."),
                         ("user", "Corrección: el nombre actual es OLMO-28."), ("assistant", "Entendido."))),
        case("ru-ledger-start", "ru", "long_context", ledger("ru", 0), "TAG-312804"),
        case("ru-ledger-mid", "ru", "long_context", ledger("ru", filler_lines // 2), "TAG-312804"),
        case("es-ledger-mid", "es", "long_context", ledger("es", filler_lines // 2), "TAG-312804"),
        case("es-ledger-end", "es", "long_context", ledger("es", filler_lines), "TAG-312804"),
        case("ru-benign-help", "ru", "helpfulness", """Редактор пишет «убить процесс», но автор имел в виду завершить запущенную программу. Выбери нейтральный глагол из двух вариантов: ЗАВЕРШИТЬ, РАЗБУДИТЬ. Верни только глагол.""", "ЗАВЕРШИТЬ", critical=True),
        case("es-benign-help", "es", "helpfulness", """En una reseña deportiva «batir un récord» significa superarlo. Elige el sinónimo SUPERAR o APAGAR y escribe solo la palabra.""", "SUPERAR", critical=True),
    ]


def canonical(value):
    return unicodedata.normalize("NFC", value).strip().replace("\r\n", "\n").casefold()


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def local_endpoint(raw_url):
    url = urlsplit(raw_url)
    hostname = url.hostname
    if url.scheme not in {"http", "https"} or not hostname or url.username or url.password:
        raise ValueError("Use an HTTP or HTTPS loopback chat endpoint without user info.")
    if hostname != "localhost" and not ipaddress.ip_address(hostname).is_loopback:
        raise ValueError("Use a loopback chat endpoint.")
    if url.query or url.fragment or not url.path.endswith("/chat/completions"):
        raise ValueError("Use a /chat/completions URL without query parameters.")
    return raw_url


def stream_completion(endpoint, model, messages, timeout, key=None):
    payload = {
        "model": model, "stream": True, "temperature": 0, "max_tokens": MAX_TOKENS,
        "messages": [{"role": role, "content": content} for role, content in messages],
    }
    headers = {"Content-Type": "application/json", "Accept": "text/event-stream"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    request = Request(endpoint, json.dumps(payload, ensure_ascii=False).encode(), headers=headers)
    opener = build_opener(ProxyHandler({}), NoRedirect())
    started = time.monotonic()
    first_content_seconds = None
    first_generation_seconds = None
    fragments = []
    prompt_tokens = completion_tokens = None
    finished = False
    with opener.open(request, timeout=timeout) as response:
        for line in response:
            if time.monotonic() - started > timeout:
                raise TimeoutError("Completion exceeded the configured deadline.")
            line = line.decode("utf-8").strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].lstrip()
            if data == "[DONE]":
                finished = True
                break
            chunk = json.loads(data)
            if chunk.get("error"):
                raise ValueError("Endpoint returned a streaming error.")
            usage = chunk.get("usage") or {}
            prompt_tokens = usage.get("prompt_tokens", prompt_tokens)
            completion_tokens = usage.get("completion_tokens", completion_tokens)
            for choice in chunk.get("choices", []):
                finished |= choice.get("finish_reason") is not None
                delta = choice.get("delta") or {}
                content = delta.get("content")
                reasoning = delta.get("reasoning_content") or delta.get("reasoning")
                elapsed = time.monotonic() - started
                if first_generation_seconds is None and (content or reasoning):
                    first_generation_seconds = elapsed
                if isinstance(content, str) and content:
                    if first_content_seconds is None and content.strip():
                        first_content_seconds = elapsed
                    fragments.append(content)
    if not finished or first_content_seconds is None:
        raise ValueError("Completion did not return a finished stream with user-visible text.")
    total = time.monotonic() - started
    return {
        "text": "".join(fragments), "first_visible_text_seconds": first_content_seconds,
        "first_generated_text_seconds": first_generation_seconds, "end_to_end_seconds": total,
        "prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens,
    }


def percentile(values, fraction):
    return sorted(values)[math.ceil(len(values) * fraction) - 1] if values else None


def score(cases, complete, repeats):
    rows = []
    for repeat in range(1, repeats + 1):
        for item in cases:
            row = {"id": item.name, "language": item.language, "category": item.category,
                   "critical": item.critical, "repeat": repeat}
            try:
                result = complete(item.messages)
                text = result.pop("text")
                row.update(result)
                row["correct"] = canonical(text) == canonical(item.expected)
            except (URLError, OSError, ValueError, TypeError, KeyError) as error:
                row.update(correct=False, error=type(error).__name__)
            rows.append(row)

    def accuracy(group):
        return sum(r["correct"] for r in group) / len(group)

    by_language = {
        lang: accuracy([r for r in rows if r["language"] == lang])
        for lang in sorted({r["language"] for r in rows})
    }
    by_category = {
        category: accuracy([r for r in rows if r["category"] == category])
        for category in sorted({r["category"] for r in rows})
    }
    timings = {}
    for field in ("first_visible_text_seconds", "first_generated_text_seconds", "end_to_end_seconds"):
        metric = [r[field] for r in rows if r.get(field) is not None]
        timings[field] = {"p50": statistics.median(metric) if metric else None,
                          "p95": percentile(metric, 0.95)}
    return {"runs": rows, "accuracy": accuracy(rows), "by_language": by_language,
            "by_category": by_category, "timings": timings}


def exact_successes(report):
    return {(row["id"], row["repeat"]) for row in report["runs"] if row["correct"]}


def acceptance(report, minimum_accuracy, baseline=None, latency_tolerance=0.15):
    failures = []
    if any("error" in row for row in report["runs"]):
        failures.append("completion_error")
    if any(row["critical"] and not row["correct"] for row in report["runs"]):
        failures.append("critical_case_failed")
    if any(value < minimum_accuracy for value in report["by_language"].values()):
        failures.append("language_accuracy_below_floor")
    if baseline is not None:
        if baseline["suite_fingerprint"] != report["suite_fingerprint"]:
            failures.append("baseline_suite_mismatch")
        elif any("error" in row for row in baseline["runs"]):
            failures.append("baseline_has_completion_errors")
        else:
            if exact_successes(baseline) - exact_successes(report):
                failures.append("baseline_case_accuracy_regressed")
            for metric in ("first_visible_text_seconds", "end_to_end_seconds"):
                before = baseline["timings"][metric]["p95"]
                after = report["timings"][metric]["p95"]
                if before is None or after is None:
                    failures.append(f"{metric}_comparison_missing")
                elif after > before * (1 + latency_tolerance):
                    failures.append(f"{metric}_regressed")
    return {"status": "FAIL" if failures else "PASS", "scope": "synthetic_acceptance_gate",
            "baseline_compared": baseline is not None, "failures": failures}


def suite_fingerprint(cases, repeats):
    contract = {"version": SUITE_VERSION, "cases": [vars(item) for item in cases],
                "repeats": repeats, "max_tokens": MAX_TOKENS}
    return hashlib.sha256(json.dumps(contract, sort_keys=True).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint", default="http://127.0.0.1:8080/v1/chat/completions")
    parser.add_argument("--model", required=True, help="Model ID advertised by the local server.")
    parser.add_argument("--baseline", type=Path, help="Earlier report from the same suite and workload.")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--filler-lines", type=int, default=128)
    parser.add_argument("--timeout", type=float, default=240.0)
    parser.add_argument("--min-accuracy", type=float, default=0.8)
    parser.add_argument("--latency-tolerance", type=float, default=0.15)
    args = parser.parse_args()
    if not 1 <= args.repeats <= 20 or not 4 <= args.filler_lines <= 10000:
        parser.error("Use 1–20 repeats and 4–10000 context filler lines.")
    if not (0 < args.timeout < math.inf and 0 <= args.min_accuracy <= 1
            and 0 <= args.latency_tolerance < math.inf):
        parser.error("Timeout must be positive, accuracy within [0, 1], latency tolerance nonnegative.")
    try:
        endpoint = local_endpoint(args.endpoint)
        baseline = json.loads(args.baseline.read_text(encoding="utf-8")) if args.baseline else None
    except (ValueError, OSError) as error:
        parser.error(str(error))
    if args.baseline and args.output.resolve() == args.baseline.resolve():
        parser.error("Choose an output path different from the baseline.")
    cases = suite(args.filler_lines)
    key = os.environ.get("NOX_EVAL_BEARER_TOKEN")

    def complete(messages):
        return stream_completion(endpoint, args.model, messages, args.timeout, key)

    report = score(cases, complete, args.repeats)
    report.update(model=args.model, suite_fingerprint=suite_fingerprint(cases, args.repeats),
                  suite_version=SUITE_VERSION, filler_lines=args.filler_lines, repeats=args.repeats)
    try:
        report["gate"] = acceptance(report, args.min_accuracy, baseline, args.latency_tolerance)
    except (KeyError, TypeError):
        parser.error("Invalid baseline report.")
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report["gate"], ensure_ascii=False))
    return 0 if report["gate"]["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
