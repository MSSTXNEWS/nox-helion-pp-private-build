import os
import unittest

from memfd_pilot import exercise, ram_admission, CHUNK


class MemfdPilotTest(unittest.TestCase):
    @unittest.skipUnless(hasattr(os, "memfd_create"), "memfd requires Linux")
    def test_maps_actual_payload_and_releases_it(self):
        calls = []
        self.assertEqual(len(exercise(CHUNK + 8, calls.append)), 64)
        self.assertEqual(calls, [CHUNK + 8])

    def test_high_and_provider_ancestors_are_held(self):
        group = {"status": "OK", "ancestors_visibility": "VISIBLE_MOUNT_SUBTREE", "ancestors": [{
            "limit_kind": "finite", "limit_bytes": 100, "current_bytes": 20,
            "high_kind": "finite", "high_bytes": 35,
        }]}
        self.assertEqual(ram_admission(group, 100, 10, 10, None), [
            "CGROUP_HIGH", "CGROUP_ANCESTOR_UNVERIFIED",
        ])
        self.assertEqual(ram_admission(group, 100, 4, 10, 50), [])
