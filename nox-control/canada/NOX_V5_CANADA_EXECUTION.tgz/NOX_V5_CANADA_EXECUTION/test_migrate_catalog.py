import unittest

from migrate_catalog import classify, make_register


class MigrationTests(unittest.TestCase):
    def test_scope_preserves_windows_target_and_external_authority(self):
        self.assertEqual(classify("Windows драйвер CUDA", [])[0], "WINDOWS_PC")
        self.assertEqual(classify("Windows: платеж владельца", [])[0], "REVIEW_EXTERNAL_SCOPE")
        self.assertEqual(classify("Замер V100 для GLM", [])[0], "REVIEW_HARDWARE")

    def test_category_and_unknown_scope(self):
        self.assertEqual(classify("Подготовить стенд", ["Обучение и веса"])[0], "S2_GPU_STAGING")
        self.assertEqual(classify("Проверить A", [])[0], "UNMAPPED_REVIEW")

    def test_legacy_pass_never_enables_native_action(self):
        source = {"id": "NH2-0001", "title": "Проверить S03", "old": "PASS", "origin": "October"}
        row = make_register([source], "id", "title", "old", (), ("origin",))[0]
        self.assertEqual(row["source_id"], "NH2-0001")
        self.assertEqual(row["historical_status"], "PASS")
        self.assertEqual(row["source_metadata"], {"origin": "October"})
        self.assertFalse(row["binding_verified"])
        self.assertFalse(row["native_execution_enabled"])

    def test_duplicate_is_rejected(self):
        row = {"id": "NH2-0001", "title": "Проверить S03", "old": "PASS"}
        with self.assertRaisesRegex(ValueError, "duplicate"):
            make_register([row, row], "id", "title", "old", ())


if __name__ == "__main__":
    unittest.main()
