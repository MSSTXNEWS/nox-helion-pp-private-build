#!/usr/bin/env python3
"""Build a read-only readiness manifest for the 150 pinned NOX optimizations."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys


LANES = {
    "S1": "Квебек, RTX 5060 Ti, закрытый GLM-кандидат",
    "S2": "Вспомогательные задачи и учебный этап на двух V100 после отдельного допуска",
    "PORTABLE": "Общий контракт, независимая проверка на каждом целевом контуре",
    "HISTORICAL": "Сохранённый материал, неприменимый как автоматическая настройка",
    "HOLD": "Нужен отдельный допуск, совместимость или изолированная проверка",
}

# A shared group means the same evidence requirements, not one new tuning per ID.
GATES = (
    ("PORTABLE", "hardware_observation", "A01 A38 A51", "Свежая привязка инстанса, CPU и cgroup-цепочка, диски и shm, драйвер/SM/VRAM, PSI/OOM. Использовать raw memory.current и эффективный лимит. shmem не добавлять к доступному page cache."),
    ("PORTABLE", "performance_protocol", "A02 A39 A46 B08", "Закрепить входы, release SHA и фазы холодного/тёплого прогона. Снять физическую полосу RAM, prefill/decode ток/с, видимый TTFT p50/p95, качество и пики ресурсов. Расчёт A02 сверить с замером."),
    ("S1", "binary_support", "A03 A04 A05", "Фактические SM 12.0, драйвер и CUDA, SHA бинарника и исходников, подтверждение glm-dsa и нужных параметров на этом бинарнике, корректный малый GGUF и реальный smoke CUDA/FA."),
    ("HOLD", "alternative_engine", "A06", "Показать поддержку точной архитектуры, совместимость весов и восстановление. Затем один отдельный A/B с теми же входами; не подменять основной движок."),
    ("S1", "glm_baseline", "A07 A20 A30", "Полные SHA и размеры 11 шардов, точный шаблон и токенизатор, исходный UD-Q4_K_XL и утверждённый профиль. Один закрытый запуск с проверкой качества и ресурсного пика; смена кванта только по отдельному сравнению."),
    ("S1", "model_placement", "A08 A09 A10", "Проверить точные поддержанные флаги, фактическое размещение тензоров/экспертов, свободную VRAM и пики. Изменять только один рычаг, отдельно прочитать hit-rate кэша."),
    ("S1", "prefill_batch", "A11", "На неизменных входах и контексте сравнить один batch или microbatch, TTFT, decode, пики RAM/VRAM. Обе настройки одновременно не менять."),
    ("S1", "cpu_placement", "A12 A13 A48", "Физические ядра, NUMA/PCIe, CPU quota/affinity и выделенный резерв UI/S03/голоса. Отдельно сравнить потоки и размещение процессов при неизменном профиле модели."),
    ("HOLD", "privileged_host_tuning", "A14 A15 A16 A34", "Чтение текущей политики, разрешение владельца и точный откат. Затем отдельное изолированное сравнение на температуре и частотах в допустимом диапазоне. Параметры ядра, питания и GPU не менять по умолчанию."),
    ("S1", "model_capacity", "A17 A18 A21", "467 289 116 837 байт весов плюс KV, scratch, сервисы и резерв в реальном cgroup/томе. Сначала факт места и тест mmap корректного малого GGUF и отдельная проверка наполнения RAM."),
    ("HOLD", "cold_restore", "A19 A56", "Полный SHA источника вне хоста, восстановление в отдельном контуре, время загрузки и проверка генерации. Сценарий потери держателя memfd только на учебной копии."),
    ("HISTORICAL", "s2_baseline_observation", "A22 A23 A29 A37", "Сохранить источник, точную модель и тип носителя исторического наблюдения. Page-cache, keepalive и отрицательный draft относятся к прежнему контексту. RPC отложен, оснований для его запуска на S1 нет."),
    ("PORTABLE", "prefix_cache", "A24 B35", "Измерить cache/prompt token counters и холодный/тёплый видимый TTFT на тех же запросах. Личность, история и прежний канонический Scope сохраняются. Qwen-свидетельство не доказывает GLM."),
    ("S1", "kv_and_context", "A25 A26", "База f16 KV и полный длинный контекст с воспроизводимым экзаменом. Замерить пиковую память и стабильность. GLM-квант KV только отдельно после экзамена."),
    ("S1", "parallel_slots", "A27", "Закрепить один serving-слот GLM. Дополнительные слоты рассматривать только отдельно при полном контексте на слот, ресурсном бюджете и стабильной второй реплике S03."),
    ("HOLD", "mtp", "A28", "Реально подтвердить MTP-слои в точном GGUF и поддержку точного бинарника. Только однофакторный тест с ресурсоёмкостью, качеством и целевым приростом не ниже 15%."),
    ("PORTABLE", "reasoning_budget", "A31 A53", "Отдельные профили модели и тот же многоходовой экзамен. Сравнить полезный TTFT, полноту, глубину и длину истории. Одной переменной выбрать reasoning-профиль либо бюджет, а не оба."),
    ("S2", "judge_admission", "A32 B17 B65 B85", "Доказать точную роль и модель судьи, размещение и квоты, раздельный слот для S2. Замерить полосу/VRAM и отсутствие регрессии основного GLM-маршрута; черновик не становится вердиктом без независимого экзамена."),
    ("HOLD", "extra_judge_on_s1", "A33 B69", "Проверить свободную VRAM и время выгрузки, только отдельное окно и точный A/B. Старший судья не делит S1 GPU с обслуживанием по умолчанию, Gemma постоянно не загружается."),
    ("PORTABLE", "link_measurement", "A35 A55", "С разрешённого маршрута снять RTT, пропускную способность и хвосты при загрузке, раздельно S1↔S2 и к складу. Сетевые настройки по умолчанию не менять."),
    ("HOLD", "network_authority", "A36", "Владелец подтверждает конкретные хосты и ACL. Затем read-only проверка по обе стороны, отсутствие лишних маршрутов и подготовленный откат."),
    ("PORTABLE", "supervision_observation", "A40 B18", "Сверить supervisor, PID/start_ticks, сокет и health. Сигнал проверки не равен праву на рестарт. Watchdog и лимиты восстановления испытать на копии."),
    ("HOLD", "failover_fence", "A41 A49", "Доказать восстановление, STOP и writer epoch. На копии оборвать обмен, отвергнуть позднюю запись старой эпохи и подтвердить один восстановленный обмен и неизменный STOP."),
    ("HOLD", "protected_assets", "A42", "Хеши, inode/mmap и независимое восстановление резервной копии. Прогон политики очистки только на копии. Права и владение текущими файлами не менять."),
    ("HOLD", "billing_authority", "A43", "Точный инстанс, владелец, тариф и проверенная панель. Оплата или автопополнение требуют отдельного решения владельца."),
    ("PORTABLE", "baseline_invariants", "A44 B54 B56", "Сверить точную конфигурацию и хеши с ограничениями v5. Сохранить закреплённые веса GLM, f16 KV, полный контекст и глубину, одну активную основную модель и защищённое ядро."),
    ("S2", "scheduled_resource_admission", "A45 B49 B83", "Проверить загрузку обоих V100, лимит GPU-времени/VRAM и паузу с восстановлением checkpoint. Обучение после соответствующего PV-гейта; TTFT живого S2 не растёт более чем на 10%."),
    ("S1", "cache_persistence", "A47", "Размер актуального KV слота на том же движке, свободный диск и резерв. Тёплый A/B prefix cache A24 отдельный от перезагрузки; восстановление проверяется с тем же хешем префикса."),
    ("S1", "owner_priority", "A50", "Доказать отсутствие фоновой работы в serving слоте при запросе владельца. Проверить последовательность приёма, нагрузку и возврат фонового слота на изолированном планировщике."),
    ("PORTABLE", "contradiction_and_judgment", "A52 B07 B09 B10 B11 B12 B16 B81 B82", "Зафиксировать независимую рубрику и источник, пары ошибок/контрпримеров, предел попыток и бюджет. Измерить, где сигнал обнаружен и где вывод обоснован."),
    ("S2", "memory_consolidation", "A54 B21 B90", "Проверка качества чанков и консолидации на отдельной копии S03. Сверять полноту, provenance, scope и хранить резерв до подтверждения результата."),
    ("PORTABLE", "routing_and_reasoning", "B01 B02 B03 B04 B13 B15 B86 B91", "Один действующий роутер и воспроизводимые случаи. Проверить выбор ступени, эскалацию, глубину, видимый TTFT и честный режим на точных model/route SHA."),
    ("S2", "bounded_reasoning_alternatives", "B05 B06", "Изолированное учебное сравнение с дешёвой базой, внешним верификатором и бюджетом. Сохранить serving ресурсы; не включать многократные выборки как общий режим."),
    ("PORTABLE", "fast_and_reusable_skills", "B14 B78 B79 B92", "На одинаковой задаче сравнить быстрый путь и модель. Для повторного навыка подтвердить тесты, происхождение, scope и отсутствие лишнего model call. Локальные вычисления проверить отдельно."),
    ("PORTABLE", "retrieval_quality", "B19 B20 B22 B24 B25", "Золотые запросы и источник корпуса. Измерить recall, rerank, задержку и факт наличия точного результата в реальном входе модели. Нужны отрицательные scope cases."),
    ("HOLD", "whole_corpus_prompt", "B23", "Доказать разрешённый scope всех данных, укладывание полного входа в окно, RAM и TTFT. До этого действующая выборочная S03-подача сохраняется."),
    ("PORTABLE", "memory_integrity", "B26 B27 B28 B29 B30 B31 B32 B33 B34 B89", "Фикстура записи, provenance, времени действия, отзыва, конфликта и сохранения точных ID при reload. Нужны независимый S03 readback и scope gate; предыдущие source-тесты не равны установленной связке."),
    ("PORTABLE", "owner_persona", "B36 B37 B38 B39 B40 B41 B42 B43 B44 B45 B46 B84", "Один закреплённый профиль и эталонные многоходовые случаи. Проверить причины и границы эмоций, согласованность PersonaID, дрейф и отсутствие скрытых изменений личности."),
    ("PORTABLE", "event_presence_and_affect", "B47 B48 B74 B87 B88", "Фикстура изменения состояния с доказанным событием и пригодной к проверке репликой/UI. Проверить дедуп, паузу, отсутствие навязчивости и неповреждённый поток."),
    ("S2", "adapter_validation", "B50 B51 B52 B53", "Привязать V100 FP16-стек, датасет с provenance, checkpoint и изменение весов к точным SHA. До переноса — отдельный holdout, отрицательные тесты дрейфа и восстановление optimizer/scaler/RNG."),
    ("PORTABLE", "dispatcher_contract", "B55 B57 B64 B93", "Доказать источник задачи, один fenced writer, heartbeat, идемпотентность и STOP. Терминальная квитанция плюс независимая проверка требуемого результата перед приёмкой."),
    ("PORTABLE", "grounded_tools", "B58 B60 B61 B62 B63 B67", "На разрешённом тестовом объекте связать точный вызов, результат, логи, реалистичный браузерный снимок и права. Проверить негативные пути без использования личной памяти."),
    ("HOLD", "external_advisor_authority", "B59", "Отдельная авторизация провайдера и policy отправки данных. Проверить обезличенный запрос, отсутствие S03 и цену/таймаут. Внешний API не получает память по умолчанию."),
    ("S2", "media_and_voice", "B66 B72", "Точный генератор/голос и права, доступный слот, артефакт результата, задержка, RU/ES и подтверждённая отмена. Проверить, что медиа не вытесняет живой чат."),
    ("PORTABLE", "language_exam", "B68 B70 B71 B94", "Одинаковый рубрицированный RU-набор, число токенов и независимая оценка. Скрытые цели тестировать на подходящих синтетических данных, фиксируя доказанный исход."),
    ("PORTABLE", "visible_chat", "B73 B75 B76 B77", "Реальный браузерный SSE, видимый полезный первый текст, истинный terminal, одна история. Для быстрого тира свой TTFT, точечный STOP и ноль повторных отправок; нагрузку префетча измерить."),
    ("PORTABLE", "learning_timeline", "B80", "Проверить связку точного TaskID с этапом, артефактом и независимой квитанцией. Учебные карточки и уведомления не должны опережать подтверждённое состояние, а действия должны переживать reload без дублей."),
)

# These IDs refer to the same underlying behavior or measurement. Scheduling
# must use the anchor once and attach evidence to the related requirements.
OVERLAP = {
    "A46": "A39", "A51": "A01", "B35": "A24", "B84": "B44",
}

BASE_IDS = {f"A{i:02d}" for i in range(1, 46)} | {f"B{i:02d}" for i in range(1, 81)}
SUPPLEMENT_IDS = {f"A{i:02d}" for i in range(46, 57)} | {f"B{i:02d}" for i in range(81, 95)}


def gated_ids():
    mapping = {}
    for lane, group, ids, evidence in GATES:
        for item_id in ids.split():
            if item_id in mapping:
                raise ValueError(f"duplicate readiness rule for {item_id}")
            mapping[item_id] = (lane, group, evidence)
    if mapping.keys() != BASE_IDS | SUPPLEMENT_IDS:
        raise ValueError(f"readiness rules do not cover exact IDs: {sorted(mapping.keys() ^ (BASE_IDS | SUPPLEMENT_IDS))}")
    return mapping


def source_section(document, field, expected):
    rows = document.get(field)
    if not isinstance(rows, list) or any(not isinstance(row, dict) or not isinstance(row.get("id"), str) for row in rows):
        raise ValueError(f"invalid source section {field}")
    ids = {row["id"] for row in rows}
    if ids != expected or len(rows) != len(ids):
        raise ValueError(f"missing, duplicate, or foreign ID in {field}")
    return rows


def build_manifest(raw, lane_filter=None, expected_source_sha256=None):
    digest = hashlib.sha256(raw).hexdigest()
    if expected_source_sha256 is not None and expected_source_sha256 != digest:
        raise ValueError("source SHA-256 does not match the supplied pin")
    document = json.loads(raw)
    if not isinstance(document, dict) or lane_filter not in (None, *LANES):
        raise ValueError("expected a source object and a known lane")
    mapping = gated_ids()
    base = source_section(document, "optimizations", BASE_IDS)
    supplements = source_section(document, "canon_v5_supplement", SUPPLEMENT_IDS)
    overrides = document.get("override_notes")
    if not isinstance(overrides, dict) or any(
        not set(key.split("/")) <= mapping.keys() or not isinstance(value, str) or not value.strip()
        for key, value in overrides.items()
    ):
        raise ValueError("source override_notes must reference known optimization IDs")
    notes = {item_id: note for keys, note in overrides.items() for item_id in keys.split("/")}
    result = []
    for row in (*base, *supplements):
        item_id = row["id"]
        lane, group, evidence = mapping[item_id]
        title = row.get("title", row.get("source_text"))
        source_reference = row.get("source_ref", row.get("source"))
        if not all(isinstance(value, str) and value.strip() for value in (title, source_reference, row.get("execution_class"))):
            raise ValueError(f"incomplete provenance for {item_id}")
        result.append({
            "id": item_id,
            "title": title,
            "lane": lane,
            "gate": group,
            "evidence_required": evidence,
            "source_reference": source_reference,
            "source_class": row["execution_class"],
            "source_claim": row.get("source_evidence", "предложение канона v5 §17"),
            "source_expectation": row.get("source_expected"),
            "source_caveat": row.get("source_caveat"),
            "source_override": notes.get(item_id),
            "experiment_anchor": OVERLAP.get(item_id, item_id),
            "state": "REFERENCE_ONLY" if lane == "HISTORICAL" else "EVIDENCE_REQUIRED",
            "measured_current_target": False,
            "execution_enabled": False,
        })
    counts = Counter(row["lane"] for row in result)
    selected = [row for row in result if lane_filter is None or row["lane"] == lane_filter]
    return {
        "schema": "nox_optimization_readiness_v1",
        "source_sha256": digest,
        "input_rows": len(result),
        "selected_rows": len(selected),
        "confirmed_current_target_count": 0,
        "execution_enabled": False,
        "lanes": LANES,
        "counts": dict(counts),
        "rows": selected,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("register", type=Path)
    parser.add_argument("--lane", choices=LANES)
    parser.add_argument("--expected-source-sha256")
    args = parser.parse_args()
    try:
        manifest = build_manifest(args.register.read_bytes(), args.lane, args.expected_source_sha256)
    except (OSError, ValueError) as error:
        print(json.dumps({"state": "HOLD", "reason": str(error), "execution_enabled": False}, ensure_ascii=False))
        return 2
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
