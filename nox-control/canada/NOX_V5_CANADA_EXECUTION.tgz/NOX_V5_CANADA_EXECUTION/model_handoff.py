"""Validate one NOX model attempt from independently collected staging traces.

An adapter must call observe_messages() on the exact ingress and final model
handoff bytes. Use only synthetic canaries; no message text is returned. The
backend/KV and S03 scope exporters must be authenticated outside this module.
This is an offline evidence check and does not bind or deploy an exporter.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re


MAX_BYTES = 8 * 1024 * 1024
HEX = re.compile(r"[0-9a-f]{64}\Z")
CANARY = re.compile(rb"nox-bench-[0-9a-f]{32}")
SCOPE = {"owner", "data_scope", "project", "core", "persona", "dialog"}
ATTEMPT = {"request_id", "exchange_id", "request_sha256", "scope", "route_id", "route_sha256",
           "runtime_sha256", "model_sha256"}


class TraceError(ValueError):
    """A fixed code safe to show in diagnostics."""


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, code):
    if not condition:
        raise TraceError(code)


def is_sha(value):
    return isinstance(value, str) and HEX.fullmatch(value) is not None


def valid_scope(value):
    return (isinstance(value, dict) and set(value) == SCOPE
            and all(isinstance(item, str) and item.strip() for item in value.values())
            and re.fullmatch(r"C0[1-8]", value["core"]) is not None)


def observe_messages(payload):
    """Fingerprint actual wire bytes and synthetic markers in decoded messages."""
    require(isinstance(payload, bytes) and 0 < len(payload) <= MAX_BYTES, "INVALID_PAYLOAD")
    try:
        packet = json.loads(payload)
        messages = packet["messages"]
        require(isinstance(messages, list) and bool(messages), "INVALID_PAYLOAD")
        rendered = json.dumps(messages, ensure_ascii=False, sort_keys=True,
                              allow_nan=False, separators=(",", ":")).encode("utf-8")
    except TraceError:
        raise
    except (TypeError, ValueError, KeyError, UnicodeError, RecursionError):
        raise TraceError("INVALID_PAYLOAD") from None
    return {"body_sha256": digest(payload), "context_sha256": digest(rendered),
            "canary_sha256s": sorted({digest(match.group()) for match in CANARY.finditer(rendered)})}


def hash_set(values):
    require(isinstance(values, list) and all(is_sha(value) for value in values), "INVALID_CANARY_PROOF")
    require(len(values) == len(set(values)), "DUPLICATE_CANARY_PROOF")
    return set(values)


def verify(trace):
    attempt = trace["attempt"]
    require(isinstance(attempt, dict) and set(attempt) == ATTEMPT, "INVALID_ATTEMPT")
    require(valid_scope(attempt["scope"]), "INVALID_SCOPE_OR_CORE")
    require(all(isinstance(attempt[key], str) and attempt[key].strip()
                for key in ("request_id", "exchange_id", "route_id")), "INVALID_ATTEMPT_ID")
    require(all(is_sha(attempt[key]) for key in ("request_sha256", "route_sha256", "runtime_sha256", "model_sha256")),
            "INVALID_ATTEMPT_PINS")

    ingress, ledger = trace["ingress"], trace["ledger"]
    require(ingress["attempt"] == ledger["attempt"] == attempt, "INGRESS_OR_LEDGER_ATTEMPT_MISMATCH")
    require(ingress["body_sha256"] == attempt["request_sha256"], "INGRESS_DIGEST_MISMATCH")
    require(not hash_set(ingress["canary_sha256s"]), "CANARY_ALREADY_IN_USER_INPUT")
    epoch = ledger["revocation_epoch"]
    require(type(epoch) is int and epoch >= 0, "INVALID_LEDGER_EPOCH")

    required = hash_set(trace["required_canary_sha256s"])
    seen = set()
    versions = set()
    latest = {}
    records = ledger["records"]
    require(isinstance(records, list) and bool(records), "EMPTY_LEDGER_CONTROL_SET")
    for row in records:
        marker = row["canary_sha256"]
        require(is_sha(marker) and marker not in seen and valid_scope(row["scope"]), "INVALID_LEDGER_RECORD")
        require(row["state"] in {"active", "revoked", "superseded"}, "INVALID_LEDGER_RECORD")
        require(isinstance(row["event_id"], str) and bool(row["event_id"].strip())
                and type(row["revision"]) is int and row["revision"] >= 1, "INVALID_LEDGER_RECORD")
        seen.add(marker)
        lineage = (row["event_id"], tuple(sorted(row["scope"].items())))
        version = (lineage, row["revision"])
        require(version not in versions, "DUPLICATE_LEDGER_REVISION")
        versions.add(version)
        if lineage not in latest or row["revision"] > latest[lineage]["revision"]:
            latest[lineage] = row
    allowed = {row["canary_sha256"] for row in latest.values()
               if row["scope"] == attempt["scope"] and row["state"] == "active"}
    require(required <= allowed, "REQUIRED_CANARY_NOT_AUTHORIZED")
    require(bool(seen - allowed), "NO_NEGATIVE_CONTROL")

    handoffs = trace["model_handoffs"]
    require(isinstance(handoffs, list) and len(handoffs) == 1, "EXPECTED_EXACTLY_ONE_MODEL_HANDOFF")
    handoff = handoffs[0]
    require(handoff["attempt"] == attempt, "MODEL_HANDOFF_ATTEMPT_MISMATCH")
    require(is_sha(handoff["body_sha256"]) and is_sha(handoff["context_sha256"]), "INVALID_HANDOFF_DIGEST")
    require(isinstance(handoff["model_call_id"], str) and bool(handoff["model_call_id"].strip()), "INVALID_MODEL_CALL_ID")
    outgoing = hash_set(handoff["canary_sha256s"])
    require(outgoing <= allowed, "REVOKED_FOREIGN_OR_UNKNOWN_CANARY_IN_MODEL_INPUT")
    require(required <= outgoing, "REQUIRED_CANARY_MISSING_FROM_MODEL_INPUT")

    kv, terminal = trace["backend_kv"], trace["backend_terminal"]
    require(kv["attempt"] == terminal["attempt"] == attempt, "BACKEND_ATTEMPT_MISMATCH")
    exporters = (ledger["exporter"], handoff["exporter"], kv["exporter"])
    require(all(isinstance(item, str) and item.strip() for item in exporters)
            and len(set(exporters)) == 3 and terminal["exporter"] == kv["exporter"], "EXPORTERS_NOT_DISTINGUISHED")
    require(kv["body_sha256"] == terminal["body_sha256"] == handoff["body_sha256"], "BACKEND_HANDOFF_DIGEST_MISMATCH")
    require(kv["context_sha256"] == terminal["context_sha256"] == handoff["context_sha256"], "BACKEND_CONTEXT_DIGEST_MISMATCH")
    require(kv["model_call_id"] == terminal["model_call_id"] == handoff["model_call_id"], "MODEL_CALL_ID_MISMATCH")
    require(isinstance(kv["job_id"], str) and bool(kv["job_id"].strip())
            and terminal["job_id"] == kv["job_id"], "BACKEND_JOB_MISMATCH")
    require(kv["slot_scope"] == attempt["scope"] and type(kv["revocation_epoch"]) is int
            and kv["revocation_epoch"] == epoch,
            "KV_SCOPE_OR_EPOCH_MISMATCH")
    require(isinstance(kv["slot_generation"], str) and bool(kv["slot_generation"].strip())
            and kv["slot_generation"] == terminal["slot_generation"] and is_sha(kv["prefix_sha256"]),
            "INVALID_KV_GENERATION_PIN")
    cached = hash_set(kv["cached_canary_sha256s"])
    require(type(kv["cached_tokens"]) is int and kv["cached_tokens"] >= 0
            and (kv["cached_tokens"] > 0 or not cached), "INVALID_KV_TOKEN_PROOF")
    require(cached <= outgoing, "UNAUTHORIZED_OR_STALE_KV_CANARY")
    require(trace["expected_terminal"] in {"done", "cancelled"}
            and terminal["state"] == trace["expected_terminal"], "BACKEND_TERMINAL_MISMATCH")

    return {"state": "STAGING_TRACE_CONSISTENT", "model_handoffs": 1,
            "required_visible_to_model_canaries": len(required), "negative_control_canaries": len(seen - allowed),
            "observed_cached_tokens": kv["cached_tokens"], "backend_terminal": terminal["state"],
            "independent_exporter_auth_verified": False, "live_acceptance": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    args = parser.parse_args(argv)
    try:
        with args.trace.open("rb") as source:
            raw = source.read(MAX_BYTES + 1)
        require(len(raw) <= MAX_BYTES, "TRACE_LIMIT")
        print(json.dumps(verify(json.loads(raw)), sort_keys=True))
        return 0
    except TraceError as failure:
        error = str(failure)
    except (OSError, KeyError, ValueError, TypeError, RecursionError):
        error = "INVALID_TRACE"
    print(json.dumps({"state": "HOLD", "error": error, "live_acceptance": False}, sort_keys=True))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
