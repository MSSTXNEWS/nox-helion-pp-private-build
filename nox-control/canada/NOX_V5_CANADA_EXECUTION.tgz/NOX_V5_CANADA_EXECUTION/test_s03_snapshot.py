from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

import s03_snapshot


SCRIPT = Path(__file__).with_name("s03_snapshot.py")
PRIVATE_TEXT = "синтетическая закрытая память"


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.source = self.root / "source? #.sqlite"
        self.archive = self.root / "archive? #.sqlite"

    def run_cli(self, *arguments, expected=0):
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, arguments)],
            capture_output=True, text=True, timeout=15,
        )
        self.assertEqual(completed.returncode, expected, completed.stderr)
        self.assertEqual(completed.stderr, "")
        self.assertNotIn(PRIVATE_TEXT, completed.stdout)
        self.assertNotIn(str(self.root), completed.stdout)
        return json.loads(completed.stdout)

    def make_source(self):
        with closing(sqlite3.connect(self.source)) as db:
            db.execute("CREATE TABLE s03_items (body TEXT NOT NULL)")
            db.execute("INSERT INTO s03_items VALUES (?)", (PRIVATE_TEXT,))
            db.commit()

    def test_wal_commits_survive_without_modifying_source_bytes(self):
        with closing(sqlite3.connect(self.source)) as writer:
            writer.execute("PRAGMA journal_mode=WAL")
            writer.execute("PRAGMA wal_autocheckpoint=0")
            writer.execute("CREATE TABLE s03_items (body TEXT NOT NULL)")
            writer.execute("INSERT INTO s03_items VALUES (?)", (PRIVATE_TEXT,))
            writer.commit()
            self.assertNotIn(PRIVATE_TEXT.encode(), self.source.read_bytes())
            wal = self.source.with_name(self.source.name + "-wal")
            before = self.source.read_bytes(), wal.read_bytes()
            receipt = self.run_cli("backup", self.source, self.archive, "--apply")
            self.assertEqual(before, (self.source.read_bytes(), wal.read_bytes()))
        self.assertEqual(stat.S_IMODE(self.archive.stat().st_mode), 0o600)
        self.assertEqual(receipt["sha256"], hashlib.sha256(self.archive.read_bytes()).hexdigest())
        self.assertEqual(receipt["bytes"], self.archive.stat().st_size)
        self.assertEqual(receipt, self.run_cli("verify", self.archive, "--sha256", receipt["sha256"]))
        with closing(sqlite3.connect(self.archive)) as snapshot:
            self.assertEqual(snapshot.execute("SELECT body FROM s03_items").fetchall(), [(PRIVATE_TEXT,)])

    def test_requires_apply_and_never_overwrites_existing_file(self):
        self.make_source()
        self.assertEqual(self.run_cli("backup", self.source, self.archive, expected=2)["reason"],
                         "APPLY_REQUIRED")
        self.assertFalse(self.archive.exists())
        self.archive.write_bytes(b"existing")
        self.assertEqual(self.run_cli("backup", self.source, self.archive, "--apply", expected=2)["reason"],
                         "DESTINATION_EXISTS")
        self.assertEqual(self.archive.read_bytes(), b"existing")

    def test_snapshot_pins_read_generation_while_wal_writer_commits(self):
        connect = sqlite3.connect
        with closing(connect(self.source)) as writer:
            writer.execute("PRAGMA journal_mode=WAL")
            writer.execute("CREATE TABLE s03_items (body TEXT)")
            writer.execute("INSERT INTO s03_items VALUES ('old')")
            writer.commit()

            class Reader(sqlite3.Connection):
                def backup(self, *args, **kwargs):
                    writer.execute("INSERT INTO s03_items VALUES ('new')")
                    writer.commit()
                    return super().backup(*args, **kwargs)

            def connect_reader(path, *args, **kwargs):
                if path == s03_snapshot.database_uri(self.source):
                    kwargs["factory"] = Reader
                return connect(path, *args, **kwargs)

            with mock.patch.object(sqlite3, "connect", side_effect=connect_reader):
                s03_snapshot.create_snapshot(self.source, self.archive)
            self.assertEqual(writer.execute("SELECT body FROM s03_items").fetchall(), [("old",), ("new",)])
        with closing(connect(self.archive)) as db:
            self.assertEqual(db.execute("SELECT body FROM s03_items").fetchall(), [("old",)])

    def test_standalone_archive_and_exact_hash_are_required(self):
        self.make_source()
        receipt = self.run_cli("backup", self.source, self.archive, "--apply")
        check = self.run_cli("verify", self.archive, "--sha256", "0" * 64, expected=2)
        self.assertEqual(check["reason"], "ARCHIVE_SHA256_MISMATCH")
        sidecar = self.archive.with_name(self.archive.name + "-wal")
        sidecar.touch()
        self.assertEqual(self.run_cli("verify", self.archive, "--sha256", receipt["sha256"], expected=2)["reason"],
                         "ARCHIVE_NOT_STANDALONE")

    def test_bad_source_does_not_publish_or_leave_temp_files(self):
        self.source.write_bytes(b"not a database")
        r = self.run_cli("backup", self.source, self.archive, "--apply", expected=2)
        self.assertEqual(r["reason"], "SOURCE_NOT_SQLITE")
        self.assertEqual(list(self.root.iterdir()), [self.source])

    def test_closed_wal_without_sidecars_is_not_modified(self):
        with closing(sqlite3.connect(self.source)) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("CREATE TABLE s03_items (body TEXT)")
            db.commit()
        r = self.run_cli("backup", self.source, self.archive, "--apply", expected=2)
        self.assertEqual(r["reason"], "SOURCE_WAL_SIDECARS_INCOMPLETE")
        self.assertEqual(list(self.root.iterdir()), [self.source])

    def test_symlink_at_source_or_destination_fails_closed(self):
        self.make_source()
        link = self.root / "link.sqlite"
        link.symlink_to(self.source)
        self.assertEqual(self.run_cli("backup", link, self.archive, "--apply", expected=2)["reason"],
                         "NOT_REGULAR_FILE")
        self.archive.symlink_to(self.root / "missing")
        self.assertEqual(self.run_cli("backup", self.source, self.archive, "--apply", expected=2)["reason"],
                         "DESTINATION_EXISTS")
        self.assertTrue(self.archive.is_symlink())


if __name__ == "__main__":
    unittest.main()
