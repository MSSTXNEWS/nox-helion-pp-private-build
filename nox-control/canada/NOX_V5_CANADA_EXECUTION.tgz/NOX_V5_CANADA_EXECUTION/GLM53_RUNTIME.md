# GLM‑5.3 на локальном сервере llama.cpp

Целевой экспорт NOX — `unsloth/GLM-5.3-GGUF:UD-Q4_K_XL`, 11 файлов и 467 289 116 837 байт по комплектному манифесту. Ревизия `346b3591c7f28d1a23716f97a065ecf12ec14771` совпадает с метаданными издателя. Первый файл содержит метаданные, включая исправленный шаблон для обработки вызовов инструментов. Пин и SHA берутся из существующего `glm53_ud_q4_k_xl_manifest.json`. [Метаданные Hugging Face](https://huggingface.co/api/models/unsloth/GLM-5.3-GGUF) · [Экспорт UD‑Q4_K_XL](https://huggingface.co/unsloth/GLM-5.3-GGUF/tree/346b3591c7f28d1a23716f97a065ecf12ec14771/UD-Q4_K_XL)

| Изменение | Что проверять |
| --- | --- |
| Сохранять встроенный GLM Jinja на поддерживаемой сборке | Точное имя модели, GLM-маркеры и аргументы двух синтетических вызовов из `/apply-template`. [llama.cpp](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md#post-apply-template-apply-chat-template-to-a-conversation) |
| Передавать `low`, `high`, `max` по задаче | Три разные строки `Reasoning Effort` в отрендеренном шаблоне. Начинать с `low` для простых запросов, сравнивать точность и p95 на сложных. [Z.ai](https://huggingface.co/zai-org/GLM-5.3/blob/main/README.md) |
| Включать `clear_thinking=true` в многоходовом чате | Старые размышления убраны из префикса, предыдущие видимые ответы и размышления внутри текущего вызова инструмента доступны шаблону. [Экспорт шаблона](https://huggingface.co/api/models/unsloth/GLM-5.3-GGUF) |
| Сохранять пары вызов–результат по `tool_call_id` | Передать тестовые результаты в обратном порядке и проверить порядок в рендере. [Экспорт шаблона](https://huggingface.co/api/models/unsloth/GLM-5.3-GGUF) |
| Раздельно измерять первый видимый токен и завершение | Двухходовой русский SSE, точный полезный текст, закрывающий `[DONE]` и подтверждённый model ID. [llama.cpp SSE](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md#post-v1chatcompletions-openai-compatible-chat-completions-api) |
| Генерировать структурированные ответы по JSON Schema | Разобрать ответ на испанский запрос и проверить JSON без лишних полей. [llama.cpp JSON Schema](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md#post-v1chatcompletions-openai-compatible-chat-completions-api) |
| Измерять повторное использование общего префикса | Сравнить холодный и повторный запросы по `timings.cache_n`, времени prefill и видимому TTFT. `cache_prompt=true` включён в профиль запроса. [Тайминги llama.cpp](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md#timings-and-context-usage) |
| Проверять ёмкость KV-кэша отдельно от качества кванта весов | A/B `f16`, `q8_0`, затем `q4_1` на нескольких длинах с одинаковыми запросами. Для приёмки сравнить память, TTFT и извлечение точных фактов из длинного контекста. [Unsloth](https://unsloth.ai/docs/models/GLM-5.3#long-context-via-kv-cache-quantization) |

Модель поддерживает до 1 048 576 токенов контекста. Начальный размер рабочего контекста следует подобрать на реальном сервере по доступной памяти, длине ответа и скорости prefill. Опубликованный рецепт vLLM для FP8 указывает конфигурации H200/H20/B200 и является отдельным путём развёртывания. [Unsloth](https://unsloth.ai/docs/models/GLM-5.3) · [vLLM](https://recipes.vllm.ai/zai-org/GLM-5.3)

## Проверка установленного процесса

Команды выполняются из корневого каталога пакета. Без `--apply` программа выводит план. Порт ниже — пример отдельного тестового процесса, его следует заменить портом фактически запущенного тестового процесса.

```sh
python3 -m unittest -v test_glm_runtime_probe.py
python3 glm_runtime_probe.py
python3 glm_runtime_probe.py --apply --with-generation \
  --endpoint http://127.0.0.1:19005/v1/chat/completions --model nox-glm53
```

Скрипт использует синтетические запросы и уже существующий SSE-бенчмарк. Без `--with-generation` он проверяет статус сервера, имя модели и шаблон. Три режима и два значения `clear_thinking` проверяются фактическим рендером на сервере. В отчёт попадают статусы и задержки, а исходный текст и токен доступа остаются в процессе. Для сервера с ключом используется `NOX_CHAT_BENCH_API_KEY`.

Успех этой проверки подтверждает совместимость синтетического сценария с тестовым сервером. Для выпуска нужны отдельная сверка весов по манифесту, серверный замер задержки и приёмка реального разговора Резонанса с памятью S03.
