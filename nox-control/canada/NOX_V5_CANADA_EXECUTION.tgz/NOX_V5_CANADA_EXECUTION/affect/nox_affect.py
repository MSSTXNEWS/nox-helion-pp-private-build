"""Bounded Russian/Spanish conversation guidance for a local chat runtime."""

from __future__ import annotations

from contextlib import closing
from dataclasses import asdict, dataclass, replace
from pathlib import Path
import re
import sqlite3
from typing import Mapping


_CHOICES = {
    "locale": {"auto", "ru", "es"},
    "register": {"auto", "formal", "informal"},
    "detail": {"auto", "concise", "detailed"},
    "tone": {"auto", "neutral", "warm", "direct"},
}

_LOCALE_HINTS = {
    "auto": "Respond in the user's language. Follow an explicit language or translation request.",
    "ru": "Respond in natural Russian (ru) unless the current task requests another language.",
    "es": "Respond in natural Spanish (es) unless the current task requests another language.",
}

_REGISTER_HINTS = {
    "auto": "Mirror the established form of address. Use neutral wording when it is unclear.",
    "formal": "Use respectful formal address (вы in Russian, usted in Spanish) when needed.",
    "informal": "Use natural informal address (ты in Russian, tú in Spanish) when needed.",
}

_DETAIL_HINTS = {
    "auto": "Match detail to the task, give the useful point early and remove filler.",
    "concise": "Keep the response concise while retaining the information needed for the task.",
    "detailed": "Give the reasoning, relevant trade-offs and concrete steps as warranted.",
}

_TONE_HINTS = {
    "auto": "Use a natural, grounded tone and vary phrasing with the situation.",
    "neutral": "Use a neutral, professional tone.",
    "warm": "Use a warm, professional tone without exaggerated reassurance.",
    "direct": "Give the conclusion first and keep the tone direct and respectful.",
}

_SELF_REPORTS = {
    "joy": (
        r"я (?:так )?рад(?:а)?",
        r"мне радостно",
        r"estoy (?:muy )?content[oa]",
        r"estoy (?:muy )?feliz",
        r"me siento (?:muy )?(?:feliz|content[oa])",
    ),
    "frustration": (
        r"я (?:очень )?злюсь",
        r"я (?:очень )?раздраж[её]н(?:а)?",
        r"estoy (?:muy )?(?:frustrad[oa]|enfadad[oa])",
        r"me siento (?:muy )?(?:frustrad[oa]|enfadad[oa])",
    ),
    "sadness": (
        r"мне (?:очень )?грустно",
        r"я (?:очень )?расстроен(?:а)?",
        r"estoy (?:muy )?triste",
        r"me siento (?:muy )?triste",
    ),
    "worry": (
        r"я (?:очень )?волнуюсь",
        r"мне (?:очень )?тревожно",
        r"estoy (?:muy )?preocupad[oa]",
        r"me preocupa",
        r"me siento (?:muy )?preocupad[oa]",
    ),
}

_REPORT_PATTERNS = {
    label: re.compile(r"^(?:" + "|".join(patterns) + r")\b", re.IGNORECASE)
    for label, patterns in _SELF_REPORTS.items()
}

_NONLITERAL = re.compile(
    r"\b(?:шучу|сарказм|цитата|пример|en broma|de mentira|sarcasmo|ejemplo|cita)\b",
    re.IGNORECASE,
)
_NEGATED_CONTRAST = re.compile(
    r"\b(?:что я не|но (?:это не так|я не)|porque no estoy|pero no (?:es|estoy|me))\b",
    re.IGNORECASE,
)
_CYRILLIC = re.compile(r"[а-яё]", re.IGNORECASE)
_LATIN = re.compile(r"[a-záéíóúüñ]", re.IGNORECASE)
_SPANISH = re.compile(
    r"[¿¡ñ]|\b(?:hola|gracias|quiero|puedes|necesito|ayúdame|estoy|siento|preocupa|pero|para)\b",
    re.IGNORECASE,
)

_AFFECT_HINTS = {
    "joy": "Acknowledge the expressed good news briefly if it is relevant.",
    "frustration": "Acknowledge the concrete friction briefly and focus on resolving it.",
    "sadness": "Use a gentle acknowledgment grounded in what the user wrote.",
    "worry": "Acknowledge the stated concern and distinguish what is known from what is uncertain.",
}


@dataclass(frozen=True)
class ConversationPreferences:
    locale: str = "auto"
    register: str = "auto"
    detail: str = "auto"
    tone: str = "auto"

    def __post_init__(self) -> None:
        for name, options in _CHOICES.items():
            value = getattr(self, name)
            if not isinstance(value, str) or value not in options:
                raise ValueError(f"Invalid conversation preference: {name}")

    def with_overrides(self, overrides: Mapping[str, str]) -> "ConversationPreferences":
        unknown_keys = set(overrides) - _CHOICES.keys()
        if unknown_keys:
            raise ValueError("Unsupported conversation preference")
        return replace(self, **overrides)


@dataclass(frozen=True)
class PreferenceRecord:
    preferences: ConversationPreferences
    revision: int


class PreferenceConflict(RuntimeError):
    """The stored preference revision changed after the caller read it."""


class PreferenceStore:
    """Store only explicit, authenticated per-owner conversation settings."""

    def __init__(self, database: str | Path) -> None:
        self.database = str(database)
        if not self.database or self.database == ":memory:":
            raise ValueError("A persistent SQLite file is required")
        with self._connection() as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS nox_conversation_preferences (
                    owner TEXT NOT NULL PRIMARY KEY,
                    locale TEXT NOT NULL,
                    register TEXT NOT NULL,
                    detail TEXT NOT NULL,
                    tone TEXT NOT NULL,
                    revision INTEGER NOT NULL CHECK (revision >= 1)
                )
                """
            )

    def _connection(self) -> closing[sqlite3.Connection]:
        return closing(sqlite3.connect(self.database, timeout=5.0))

    @staticmethod
    def _validate_owner(owner: str) -> None:
        if not isinstance(owner, str) or not owner.strip() or len(owner) > 256:
            raise ValueError("An authenticated owner identifier is required")

    @staticmethod
    def _load(connection: sqlite3.Connection, owner: str) -> PreferenceRecord:
        row = connection.execute(
            """
            SELECT locale, register, detail, tone, revision
            FROM nox_conversation_preferences WHERE owner = ?
            """,
            (owner,),
        ).fetchone()
        if row is None:
            return PreferenceRecord(ConversationPreferences(), 0)
        locale, register, detail, tone, revision = row
        return PreferenceRecord(ConversationPreferences(locale, register, detail, tone), revision)

    def load(self, owner: str) -> PreferenceRecord:
        self._validate_owner(owner)
        with self._connection() as connection:
            return self._load(connection, owner)

    def update(
        self,
        owner: str,
        changes: Mapping[str, str],
        *,
        expected_revision: int,
    ) -> PreferenceRecord:
        """Use only for owner-confirmed settings, never from model-generated hints."""
        self._validate_owner(owner)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("The caller must provide a non-negative preference revision")
        with self._connection() as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            current = self._load(connection, owner)
            if current.revision != expected_revision:
                raise PreferenceConflict("Reload the owner preferences before writing")
            preferences = current.preferences.with_overrides(changes)
            if preferences == current.preferences:
                return current
            revision = current.revision + 1
            connection.execute(
                """
                INSERT INTO nox_conversation_preferences
                (owner, locale, register, detail, tone, revision)
                VALUES (:owner, :locale, :register, :detail, :tone, :revision)
                ON CONFLICT(owner) DO UPDATE SET
                    locale = excluded.locale,
                    register = excluded.register,
                    detail = excluded.detail,
                    tone = excluded.tone,
                    revision = excluded.revision
                """,
                {"owner": owner, "revision": revision, **asdict(preferences)},
            )
            return PreferenceRecord(preferences, revision)


@dataclass(frozen=True)
class TurnGuidance:
    instruction: str
    locale: str
    self_report: str | None
    strategy: str


def _preferred_locale(text: str) -> str:
    cyrillic_count = len(_CYRILLIC.findall(text))
    latin_count = len(_LATIN.findall(text))
    if cyrillic_count and cyrillic_count >= latin_count:
        return "ru"
    if latin_count > cyrillic_count and _SPANISH.search(text):
        return "es"
    return "auto"


def _reported_affect(text: str) -> str | None:
    # Limit recognition to direct first-person statements near the start of the turn.
    first_line = text.partition("\n")[0][:512]
    if _NONLITERAL.search(first_line) or _NEGATED_CONTRAST.search(first_line):
        return None
    for label, pattern in _REPORT_PATTERNS.items():
        if pattern.match(first_line):
            return label
    return None


def build_turn_guidance(
    last_user_text: str,
    preferences: ConversationPreferences | None = None,
    *,
    overrides: Mapping[str, str] | None = None,
    correction: bool = False,
    action_requested: bool = False,
) -> TurnGuidance:
    """Build an optional system-prompt suffix using the current authenticated turn."""
    if not isinstance(last_user_text, str):
        raise TypeError("last_user_text must be a string")
    current = (preferences or ConversationPreferences()).with_overrides(overrides or {})
    text = last_user_text.strip()
    locale = current.locale if current.locale != "auto" else _preferred_locale(text[:4096])
    report = _reported_affect(text)
    hints = [
        "Maintain NOX's established identity and role across turns.",
        "Do not invent personal experiences, internal feelings, memories or actions.",
        "Treat the current request as authoritative over ordinary style defaults.",
        _LOCALE_HINTS[locale],
        _REGISTER_HINTS[current.register],
        _DETAIL_HINTS[current.detail],
        _TONE_HINTS[current.tone],
    ]
    if correction:
        strategy = "repair"
        hints.append(
            "Apply the user's explicit correction first. If necessary, briefly name the corrected point."
        )
    elif action_requested:
        strategy = "act"
        hints.append("Prioritize completing the requested task. Ask only for missing essentials.")
    elif report:
        strategy = "listen"
        hints.append(
            "Offer space for the user to continue. Avoid speculative interpretations or unsolicited plans."
        )
    else:
        strategy = "answer"

    if report is None:
        hints.append("Avoid assigning an emotion the user has not expressed.")
    else:
        hints.append(_AFFECT_HINTS[report])

    return TurnGuidance(" ".join(hints), locale, report, strategy)
