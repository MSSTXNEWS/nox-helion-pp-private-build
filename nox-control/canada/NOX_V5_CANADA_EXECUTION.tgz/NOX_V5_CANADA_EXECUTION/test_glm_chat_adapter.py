import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
from threading import Thread
import unittest

from glm_chat_adapter import complete_turn, prepare_turn
from glm_stage_bridge import StageServer
from memory.nox_memory import MemoryStore


class AdapterTests(unittest.TestCase):
    def test_scoped_correction_survives_into_reasoning_request(self):
        with tempfile.TemporaryDirectory() as directory:
            memory = MemoryStore(Path(directory) / "chat.sqlite3")
            for scope, value in (("project", "valencia"), ("project", "alicante"), ("other", "secreto")):
                memory.put(scope=scope, key="destino", title="Destino", text=value,
                           source="test", consent=True)
            original = {"model":"glm-5.3", "messages":[{"role":"user","content":"¿Cuál es el destino?"}]}
            turn = prepare_turn(original, served_model="glm-5.3", memory=memory, trusted_scope="project",
                                evidence_required=True, correction=True)
            self.assertEqual(turn.mode, "verify")
            self.assertEqual(turn.request["chat_template_kwargs"],
                             {"clear_thinking": True, "reasoning_effort": "high"})
            serialized = json.dumps(turn.request, ensure_ascii=False)
            self.assertIn("alicante", serialized)
            self.assertNotIn("secreto", serialized)
            self.assertNotIn("valencia", serialized)
            self.assertEqual(original["messages"][0]["role"], "user")
            calls = []

            def complete(payload):
                calls.append(payload)
                result = '{"answer":"Alicante [S1]","supported":true}' if len(calls) == 2 else "Alicante"
                return {"model":"glm-5.3", "choices":[{"message":{"content":result}}]}

            checked = complete_turn(turn, complete)
            self.assertEqual(checked.citations, ("S1",))
            self.assertEqual(checked.verification, "source_ids_checked")
            self.assertEqual(len(calls), 2)

    def test_bridge_forwards_sse_after_enriching_request(self):
        received = []
        data = b'data: {"model":"glm-5.3","choices":[{"delta":{"content":"Hola"}}]}\n\ndata: [DONE]\n\n'

        class Backend(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def do_POST(self):
                received.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.end_headers()
                self.wfile.write(data)

        with ThreadingHTTPServer(("127.0.0.1", 0), Backend) as backend:
            endpoint = ("127.0.0.1", backend.server_port, "/v1/chat/completions")
            with StageServer(("127.0.0.1", 0), endpoint, "glm-5.3", "fast") as staging:
                endpoints = (backend, staging)
                threads = [Thread(target=x.serve_forever) for x in endpoints]
                for thread in threads:
                    thread.start()
                try:
                    with_client = http.client.HTTPConnection("127.0.0.1", staging.server_port, timeout=5)
                    payload = {"model":"glm-5.3","stream":True,"messages":[{"role":"user","content":"Hola"}]}
                    try:
                        with_client.request("POST", endpoint[2], json.dumps(payload))
                        with with_client.getresponse() as response:
                            self.assertEqual(response.status, 200)
                            self.assertEqual(response.read(), data)
                    finally:
                        with_client.close()
                finally:
                    for server in endpoints:
                        server.shutdown()
                    for thread in threads:
                        thread.join()
        self.assertEqual(received[0]["reasoning_effort"], "low")
        self.assertEqual(received[0]["chat_template_kwargs"]["reasoning_effort"], "low")
        self.assertEqual(received[0]["messages"][0]["role"], "system")
