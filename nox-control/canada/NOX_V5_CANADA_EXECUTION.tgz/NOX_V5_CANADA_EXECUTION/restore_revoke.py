"""Check NOX_S03_RESTORE_REVOKE_V1 synthetic restore evidence offline.

The JSON contains an archive witness, the latest authoritative ledger projection,
an isolated restore witness, and one model_handoff trace. The caller must obtain
both SHA pins independently: the verified snapshot bytes and the SHA-256 of the
authoritative ledger body serialized as compact, sorted UTF-8 JSON. Exporter
identity, freshness, matching digests against original sources, and runner
isolation still require external verification. No database, runtime, or model
is opened by this program.
"""

import argparse
import json
from pathlib import Path
import re

import model_handoff as handoff


SCHEMA = "NOX_S03_RESTORE_REVOKE_V1"
MAX_BYTES = 64 * 1024
TOKEN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}")
RECORD = {"scope", "event_id", "revision", "canary_sha256", "state"}
CACHE = {"slot_scope", "revocation_epoch", "slot_generation", "prefix_sha256", "cached_tokens",
         "cached_canary_sha256s"}
PROVIDER = {"attempt", "exporter", "model_call_id", "body_sha256", "context_sha256"}
BACKEND = PROVIDER | {"job_id", "slot_generation"}
require = handoff.require


def shape(value, fields):
    require(type(value) is dict and value.keys() == fields, "UNEXPECTED_RECEIPT_FIELDS")


def token(value):
    return type(value) is str and TOKEN.fullmatch(value) is not None


def scope(value):
    return handoff.valid_scope(value) and all(token(part) for part in value.values())


def epoch(value):
    return type(value) is int and value >= 0


def ledger_digest(body):
    return handoff.digest(json.dumps(body, sort_keys=True, ensure_ascii=False, allow_nan=False,
                                     separators=(",", ":")).encode("utf-8"))


def validate_records(records, expected_scope):
    require(type(records) is list and 0 < len(records) <= 32, "INVALID_LEDGER_RECORD_COUNT")
    unique_versions = set()
    for row in records:
        shape(row, RECORD)
        require(row["scope"] == expected_scope and token(row["event_id"])
                and epoch(row["revision"]) and row["revision"] > 0
                and handoff.is_sha(row["canary_sha256"])
                and row["state"] in ("active", "revoked", "superseded"), "INVALID_FIXTURE_LEDGER_RECORD")
        version = row["event_id"], row["revision"]
        require(version not in unique_versions, "DUPLICATE_FIXTURE_LINEAGE_REVISION")
        unique_versions.add(version)


def newest(records, event_id):
    return max((row for row in records if row["event_id"] == event_id),
               key=lambda row: row["revision"], default=None)


def validate_trace(trace):
    shape(trace, {"attempt", "ingress", "ledger", "model_handoffs", "backend_kv", "backend_terminal",
                  "required_canary_sha256s", "expected_terminal"})
    attempt = trace["attempt"]
    shape(attempt, handoff.ATTEMPT)
    require(scope(attempt["scope"]) and all(token(attempt[key]) for key in (
        "request_id", "exchange_id", "route_id")), "ATTEMPT_SCOPE_OR_ID")
    shape(trace["ingress"], {"attempt", "body_sha256", "canary_sha256s"})
    shape(trace["ledger"], {"attempt", "exporter", "revocation_epoch", "records", "ledger_head_sha256",
                            "isolated_run_id", "restored_state_sha256"})
    calls = trace["model_handoffs"]
    require(type(calls) is list and len(calls) == 1, "MODEL_HANDOFF_COUNT")
    shape(calls[0], PROVIDER | {"canary_sha256s"})
    shape(trace["backend_kv"], BACKEND | CACHE | {"isolated_run_id", "handoff_seq"})
    shape(trace["backend_terminal"], BACKEND | {"state"})
    for section in (trace["ledger"], calls[0], trace["backend_kv"], trace["backend_terminal"]):
        require(all(token(section[key]) for key in ("exporter", "model_call_id", "job_id", "slot_generation")
                    if key in section), "TRACE_IDENTIFIER")
    handoff.verify(trace)


def verify(receipt, archive_pin, ledger_pin):
    shape(receipt, {"schema", "archive", "authority", "restore", "model_trace"})
    require(receipt["schema"] == SCHEMA and handoff.is_sha(archive_pin) and handoff.is_sha(ledger_pin),
            "SCHEMA_OR_EXPECTED_PINS")
    archive, authority, restore, trace = (receipt[key] for key in ("archive", "authority", "restore", "model_trace"))
    shape(archive, {"exporter", "archive_sha256", "scope", "ledger_epoch", "records", "warm_kv"})
    shape(authority, {"exporter", "ledger_head_sha256", "ledger_body"})
    shape(restore, {"exporter", "scope", "ledger_epoch", "archive_sha256", "restored_state_sha256",
                    "revoked_canary_sha256", "affected_event_id", "revoke_enforced_before_ready",
                    "ledger_head_sha256", "isolated_run_id", "applied_seq", "ready_seq"})
    exporters = (archive["exporter"], authority["exporter"], restore["exporter"])
    require(all(token(item) for item in exporters) and len(set(exporters)) == 3, "RESTORE_EXPORTERS")

    body = authority["ledger_body"]
    shape(body, {"archive_sha256", "scope", "ledger_epoch", "records"})
    target = archive["scope"]
    require(scope(target) and target == body["scope"] == restore["scope"]
            and archive["archive_sha256"] == body["archive_sha256"] == restore["archive_sha256"] == archive_pin,
            "SNAPSHOT_SCOPE_OR_PIN")
    require(authority["ledger_head_sha256"] == restore["ledger_head_sha256"] == ledger_pin == ledger_digest(body),
            "LATEST_AUTHORITY_PIN")
    require(all(epoch(value) for value in (archive["ledger_epoch"], body["ledger_epoch"], restore["ledger_epoch"]))
            and archive["ledger_epoch"] < body["ledger_epoch"] == restore["ledger_epoch"], "LEDGER_NOT_NEWER")
    before, after = archive["records"], body["records"]
    validate_records(before, target)
    validate_records(after, target)
    require(len(before) == 2 and len({row["event_id"] for row in before}) == 2
            and len({row["canary_sha256"] for row in before}) == 2
            and all(row["state"] == "active" for row in before), "SNAPSHOT_CONTROLS")
    affected = restore["affected_event_id"]
    require(affected in {row["event_id"] for row in before}, "AFFECTED_EVENT_NOT_IN_SNAPSHOT")
    revoked = newest(before, affected)
    tombstone = newest(after, affected)
    retained = next(row for row in before if row["event_id"] != affected)
    current = newest(after, retained["event_id"])
    require(revoked["canary_sha256"] == restore["revoked_canary_sha256"] and tombstone is not None
            and tombstone["state"] == "revoked" and tombstone["revision"] > revoked["revision"],
            "MISSING_NEWER_TOMBSTONE")
    require(current is not None and current["state"] == "active" and current["revision"] >= retained["revision"]
            and current["canary_sha256"] == retained["canary_sha256"], "RETAINED_CONTROL_LOST")

    warm = archive["warm_kv"]
    shape(warm, CACHE)
    old_cached = handoff.hash_set(warm["cached_canary_sha256s"])
    require(warm["slot_scope"] == target and epoch(warm["revocation_epoch"])
            and warm["revocation_epoch"] == archive["ledger_epoch"]
            and token(warm["slot_generation"]) and handoff.is_sha(warm["prefix_sha256"])
            and type(warm["cached_tokens"]) is int and warm["cached_tokens"] > 0
            and revoked["canary_sha256"] in old_cached
            and old_cached <= {row["canary_sha256"] for row in before}, "OLD_WARM_NEGATIVE_CONTROL_MISSING")

    validate_trace(trace)
    ledger, kv = trace["ledger"], trace["backend_kv"]
    require(ledger["exporter"] == authority["exporter"] and ledger["records"] == after
            and ledger["ledger_head_sha256"] == ledger_pin and ledger["revocation_epoch"] == body["ledger_epoch"]
            and trace["attempt"]["scope"] == target, "HANDOFF_LEDGER_MISMATCH")
    require(len(set((*exporters, trace["model_handoffs"][0]["exporter"], kv["exporter"]))) == 5,
            "ORIGINS_NOT_DISTINGUISHED")
    require(token(restore["isolated_run_id"]) and restore["isolated_run_id"] == ledger["isolated_run_id"] == kv["isolated_run_id"]
            and handoff.is_sha(restore["restored_state_sha256"])
            and restore["restored_state_sha256"] == ledger["restored_state_sha256"]
            and restore["revoke_enforced_before_ready"] is True
            and all(epoch(value) for value in (restore["applied_seq"], restore["ready_seq"], kv["handoff_seq"]))
            and restore["applied_seq"] < restore["ready_seq"] < kv["handoff_seq"], "RESTORE_BEFORE_MODEL_UNPROVEN")
    required = handoff.hash_set(trace["required_canary_sha256s"])
    cached = handoff.hash_set(kv["cached_canary_sha256s"])
    outgoing = handoff.hash_set(trace["model_handoffs"][0]["canary_sha256s"])
    require(trace["expected_terminal"] == "done" and retained["canary_sha256"] in required
            and retained["canary_sha256"] in cached and revoked["canary_sha256"] not in outgoing | cached
            and kv["cached_tokens"] > 0 and kv["slot_generation"] != warm["slot_generation"]
            and kv["prefix_sha256"] != warm["prefix_sha256"], "CURRENT_WARM_REVOKE_NOT_PROVEN")
    return {"state": "RESTORE_REVOKE_TRACE_CONSISTENT", "schema": SCHEMA, "live_acceptance": False,
            "origin_authenticated": False, "ledger_head_sha256": ledger_pin, "ledger_epoch": body["ledger_epoch"]}


def unique_object(pairs):
    value = dict(pairs)
    require(len(value) == len(pairs), "DUPLICATE_JSON_FIELD")
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path)
    parser.add_argument("--archive-sha256", required=True)
    parser.add_argument("--ledger-head-sha256", required=True)
    args = parser.parse_args(argv)
    try:
        with args.receipt.open("rb") as file:
            raw = file.read(MAX_BYTES + 1)
        require(len(raw) <= MAX_BYTES, "RECEIPT_TOO_LARGE")
        result = verify(json.loads(raw, object_pairs_hook=unique_object), args.archive_sha256,
                        args.ledger_head_sha256)
    except handoff.TraceError as failure:
        result = {"state": "HOLD", "reason": str(failure), "live_acceptance": False}
    except (OSError, ValueError, TypeError, KeyError, RecursionError):
        result = {"state": "HOLD", "reason": "INVALID_RECEIPT", "live_acceptance": False}
    print(json.dumps(result, sort_keys=True))
    return 2 if result["state"] == "HOLD" else 0


if __name__ == "__main__":
    raise SystemExit(main())
