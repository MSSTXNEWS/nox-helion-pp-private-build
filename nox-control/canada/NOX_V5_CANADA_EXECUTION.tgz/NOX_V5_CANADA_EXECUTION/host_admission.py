#!/usr/bin/env python3
"""Evaluate NOX staging capacity from a read-only server_probe JSON receipt."""

import argparse
import json
from pathlib import Path, PurePosixPath
import sys

from model_plan import MODEL_BYTES


LOCAL_DISK_FILESYSTEMS = {'btrfs', 'ext4', 'overlay', 'xfs', 'zfs'}


def byte_count(value):
    return type(value) is int and value >= 0


def object_or_empty(value):
    return value if isinstance(value, dict) else {}


def items_or_empty(value):
    return value if isinstance(value, list) else []


def cgroup_budget(rows, limit_key, kind_key):
    if not rows:
        return 'UNKNOWN', None
    free = []
    for row in rows:
        kind = row.get(kind_key)
        if kind == 'unlimited' and row.get(limit_key) is None:
            continue
        threshold, current = row.get(limit_key), row.get('current_bytes')
        if kind != 'finite' or not byte_count(threshold) or not byte_count(current):
            return 'UNKNOWN', None
        free.append(max(0, threshold - current))
    return ('FINITE', min(free)) if free else ('UNLIMITED', None)


def evaluate(report, *, destination, required_payload_bytes, filesystem_reserve_bytes,
             memory_reserve_bytes, expected_instance, minimum_gpu_free_mib=None,
             provider_headroom_bytes=None):
    """Return whether the exact stage increment fits the supplied observations."""
    counts = (required_payload_bytes, filesystem_reserve_bytes, memory_reserve_bytes,
              expected_instance, minimum_gpu_free_mib, provider_headroom_bytes)
    if (not all(byte_count(value) for value in counts[:4]) or not expected_instance
            or any(value is not None and not byte_count(value) for value in counts[4:])):
        raise ValueError('expected instance and byte budgets must be non-negative integers; instance must be positive')
    path = PurePosixPath(destination)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('destination must be the exact resolved absolute path from preflight')

    report = object_or_empty(report)
    reasons = []
    if (report.get('schema') != 'nox_server_probe_v1' or report.get('status') != 'OBSERVED'
            or report.get('read_only') is not True):
        reasons.append('PREFLIGHT_RECEIPT_UNAVAILABLE')
    identity = object_or_empty(report.get('identity'))
    if identity.get('instance_id') != expected_instance:
        reasons.append('INSTANCE_LABEL_MISMATCH')

    directories = [row for row in items_or_empty(report.get('filesystems'))
                   if isinstance(row, dict) and row.get('path') == str(path)]
    location = directories[0] if directories and all(row == directories[0] for row in directories) else {}
    filesystem, available = location.get('filesystem'), location.get('available_bytes')
    destination_kind = 'UNKNOWN'
    if filesystem == 'tmpfs':
        destination_kind = 'TMPFS'
    elif isinstance(filesystem, str) and filesystem in LOCAL_DISK_FILESYSTEMS:
        destination_kind = 'LOCAL_DISK'
    required_disk = required_payload_bytes + filesystem_reserve_bytes
    if location.get('status') != 'OK' or not byte_count(available):
        reasons.append('DESTINATION_UNOBSERVED')
    elif location.get('read_only_mount') is not False or destination_kind == 'UNKNOWN':
        reasons.append('DESTINATION_UNSUPPORTED')
    elif available < required_disk:
        reasons.append('DESTINATION_CAPACITY')

    required_ram = memory_reserve_bytes
    if destination_kind == 'TMPFS':
        required_ram += required_payload_bytes
    cgroup = object_or_empty(report.get('cgroup'))
    rows = [object_or_empty(row) for row in items_or_empty(cgroup.get('ancestors'))]
    hard_kind, hard_free = cgroup_budget(rows, 'limit_bytes', 'limit_kind')
    high_kind, high_free = cgroup_budget(rows, 'high_bytes', 'high_kind')
    if cgroup.get('status') != 'OK' or hard_kind == 'UNKNOWN':
        reasons.append('CGROUP_HARD_HEADROOM_UNKNOWN')
    elif hard_free is not None and hard_free < required_ram:
        reasons.append('CGROUP_HARD_HEADROOM')
    if high_kind == 'UNKNOWN':
        reasons.append('CGROUP_HIGH_HEADROOM_UNKNOWN')
    elif high_free is not None and high_free < required_ram:
        reasons.append('CGROUP_HIGH_HEADROOM')
    visibility = cgroup.get('ancestors_visibility')
    if visibility != 'VISIBLE_NAMESPACE' and provider_headroom_bytes is None:
        reasons.append('CGROUP_ANCESTORS_UNVERIFIED')
    elif provider_headroom_bytes is not None and provider_headroom_bytes < required_ram:
        reasons.append('PROVIDER_HEADROOM')

    host_free = object_or_empty(report.get('host_memory')).get('available_bytes')
    if not byte_count(host_free):
        reasons.append('HOST_AVAILABLE_UNKNOWN')
    elif host_free < required_ram:
        reasons.append('HOST_AVAILABLE')

    gpu = object_or_empty(report.get('gpu'))
    devices = [row for row in items_or_empty(gpu.get('devices')) if isinstance(row, dict)]
    device_facts = [{key: row.get(key) for key in ('index', 'name', 'compute_capability', 'total_mib', 'free_mib')}
                    for row in devices]
    free_values = [row['free_mib'] for row in device_facts if byte_count(row['free_mib'])
                   and byte_count(row['total_mib']) and row['free_mib'] <= row['total_mib']]
    gpu_free = max(free_values) if gpu.get('status') == 'OK' and free_values else None
    if minimum_gpu_free_mib is not None and (gpu_free is None or gpu_free < minimum_gpu_free_mib):
        reasons.append('GPU_FREE_UNOBSERVED_OR_INSUFFICIENT')

    return {
        'schema': 'nox_host_admission_v1',
        'state': 'HOLD' if reasons else 'STAGING_CAPACITY_CONFIRMED',
        'reasons': reasons, 'mode': 'dry_assessment', 'observed_at': report.get('observed_at'),
        'instance_label': identity.get('instance_id'),
        'destination': {'path': str(path), 'kind': destination_kind, 'filesystem': filesystem,
                        'available_bytes': available, 'required_bytes': required_disk},
        'memory': {'required_additional_bytes': required_ram, 'host_available_bytes': host_free,
                   'cgroup_ancestors_visibility': visibility, 'cgroup_hard_kind': hard_kind,
                   'cgroup_hard_headroom_bytes': hard_free, 'cgroup_high_kind': high_kind,
                   'cgroup_high_headroom_bytes': high_free, 'provider_headroom_bytes': provider_headroom_bytes},
        'gpu': {'facts_status': gpu.get('status'), 'devices': device_facts,
                'maximum_per_device_free_mib': gpu_free, 'minimum_requested_free_mib': minimum_gpu_free_mib},
        'payload_bytes': required_payload_bytes,
        'filesystem_reserve_bytes': filesystem_reserve_bytes, 'memory_reserve_bytes': memory_reserve_bytes,
        'assessment_scope': 'Staging only. Recheck live before writing; VRAM facts do not certify engine startup.',
    }


def nonnegative(value):
    try:
        result = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError('use a non-negative integer') from exc
    if result < 0:
        raise argparse.ArgumentTypeError('use a non-negative integer')
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('preflight', type=Path)
    parser.add_argument('--destination', required=True)
    parser.add_argument('--expected-instance', type=nonnegative, required=True)
    parser.add_argument('--required-payload-bytes', type=nonnegative, default=MODEL_BYTES,
                        help='remaining verified staging bytes; default is the full pinned GLM payload')
    parser.add_argument('--filesystem-reserve-bytes', type=nonnegative, required=True)
    parser.add_argument('--memory-reserve-bytes', type=nonnegative, required=True)
    parser.add_argument('--minimum-gpu-free-mib', type=nonnegative)
    parser.add_argument('--provider-headroom-bytes', type=nonnegative,
                        help='separately observed headroom for ancestors hidden from the container probe')
    args = parser.parse_args(argv)
    try:
        with args.preflight.open(encoding='utf-8') as stream:
            report = json.load(stream)
        result = evaluate(
            report, destination=args.destination, required_payload_bytes=args.required_payload_bytes,
            expected_instance=args.expected_instance, filesystem_reserve_bytes=args.filesystem_reserve_bytes,
            memory_reserve_bytes=args.memory_reserve_bytes, minimum_gpu_free_mib=args.minimum_gpu_free_mib,
            provider_headroom_bytes=args.provider_headroom_bytes,
        )
    except (OSError, ValueError) as exc:
        result = {'schema': 'nox_host_admission_v1', 'state': 'HOLD', 'reasons': ['INPUT_INVALID'],
                  'detail': str(exc)}
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result['state'] == 'STAGING_CAPACITY_CONFIRMED' else 2


if __name__ == '__main__':
    sys.exit(main())
