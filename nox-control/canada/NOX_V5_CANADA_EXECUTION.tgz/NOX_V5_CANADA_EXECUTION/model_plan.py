#!/usr/bin/env python3
"""Print or verify the pinned NOX GLM-5.3 GGUF plan without changing files."""

import argparse
import hashlib
import json
import mmap
import os
import stat
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


REPOSITORY = 'unsloth/GLM-5.3-GGUF'
REVISION = '346b3591c7f28d1a23716f97a065ecf12ec14771'
QUANT = 'UD-Q4_K_XL'
MODEL_BYTES = 467_289_116_837
CHUNK_BYTES = 1 << 20
LOCAL_FILESYSTEMS = {
    'btrfs', 'erofs', 'ext2', 'ext3', 'ext4', 'f2fs', 'overlay', 'ramfs', 'squashfs',
    'tmpfs', 'xfs', 'zfs',
}


@dataclass(frozen=True)
class Shard:
    name: str
    size_bytes: int
    sha256: str


SHARDS = tuple(
    Shard(f'GLM-5.3-{QUANT}-{index:05d}-of-00011.gguf', size, digest)
    for index, (size, digest) in enumerate((
        (9_428_677, '02a3e367e8b5f5ee3341d556211faa2cc956c3e77ad0e298c6805323bfaeb02d'),
        (49_433_942_336, '374daff9e093b362a12ca89904fd0511df38b2a9794029e272c8639587a13402'),
        (48_566_415_136, '9a13948a0c7747e374766ab32272e8bf5ee2ac260ed581419cc980c00df1bb9c'),
        (48_566_415_136, '1fee29db6ab247f97e42cc7dd4132ce35f15f41fb42ba9110b73c25471171f9b'),
        (48_566_415_136, '7d38557e09934a3f6cf4eb7aa7ea8c04929bf2d40db8ba8494529d51be04bb4e'),
        (48_566_415_136, '3f6c47e4e32f7b1f9b844124622cc8d506facdb58e3304b9b4429b6c3af4f53d'),
        (48_566_415_136, '03114618ca505e4dbd63e0c8fb478cb54db86ff32ddd3681160589d8a958db8e'),
        (48_566_415_136, 'e202e8679571572ae5ab490d021e3f0d0ada4794521464e6735e62516bedff96'),
        (48_566_415_136, '05d81908bc8ffd1e2ff6bb6a4e7a347c455ce87d7d6c473415d37f1749f0a337'),
        (48_566_415_136, '252eac782187e63ffdbf0650eb79538a53626991f7dfd06106cfbbd5eb1a0bb3'),
        (29_314_424_736, 'd69bc418b2a08103d1b42340e803e1a98582d3766e4593c4a490475ac5bb811b'),
    ), start=1)
)


def manifest():
    return {
        'upstream_model': 'https://huggingface.co/zai-org/GLM-5.3',
        'repository': REPOSITORY, 'revision': REVISION, 'quantization': QUANT,
        'tree_url': f'https://huggingface.co/{REPOSITORY}/tree/{REVISION}/{QUANT}',
        'digest_source': 'Hugging Face pinned tree LFS SHA-256 OIDs',
        'bytes': MODEL_BYTES, 'first_shard_role': 'metadata only, contains zero tensors',
        'shards': [asdict(shard) for shard in SHARDS],
    }


def open_root(path):
    absolute = Path(os.path.abspath(path))
    flags = os.O_DIRECTORY | os.O_PATH | os.O_CLOEXEC | os.O_NOFOLLOW
    fd = os.open('/', flags)
    try:
        for name in absolute.parts[1:]:
            child = os.open(name, flags, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except OSError:
        os.close(fd)
        raise


def mount_types():
    entries = {}
    with open('/proc/self/mountinfo', encoding='utf-8') as stream:
        for row in stream:
            metadata, separator, source = row.partition(' - ')
            if separator:
                entries[metadata.split()[0]] = source.split()[0]
    return entries


def filesystem(fd, mounts):
    with open(f'/proc/self/fdinfo/{fd}', encoding='utf-8') as stream:
        for row in stream:
            key, _, value = row.partition(':')
            if key == 'mnt_id':
                return mounts.get(value.strip())
    return None


def fingerprint(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


def verify_shard(root_fd, shard, mounts, *, mapped=False):
    result = {'name': shard.name, 'expected_bytes': shard.size_bytes}
    try:
        pinned = os.open(shard.name, os.O_PATH | os.O_CLOEXEC | os.O_NOFOLLOW, dir_fd=root_fd)
    except FileNotFoundError:
        return {**result, 'state': 'missing'}
    except OSError as exc:
        return {**result, 'state': 'unreadable', 'errno': exc.errno}
    try:
        before = os.fstat(pinned)
        if not stat.S_ISREG(before.st_mode):
            return {**result, 'state': 'not_regular'}
        kind = filesystem(pinned, mounts)
        if kind not in LOCAL_FILESYSTEMS:
            return {**result, 'state': 'unsupported_filesystem', 'filesystem': kind}
        if before.st_size != shard.size_bytes:
            return {**result, 'state': 'size_mismatch', 'actual_bytes': before.st_size}

        digest = hashlib.sha256()
        remaining = shard.size_bytes
        with open(f'/proc/self/fd/{pinned}', 'rb', buffering=0) as stream:
            if fingerprint(os.fstat(stream.fileno())) != fingerprint(before):
                return {**result, 'state': 'changed_during_verification'}
            if mapped:
                with mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as view:
                    digest.update(view)
            else:
                while remaining:
                    chunk = stream.read(min(CHUNK_BYTES, remaining))
                    if not chunk:
                        return {**result, 'state': 'changed_during_verification'}
                    digest.update(chunk)
                    remaining -= len(chunk)
            after = os.fstat(stream.fileno())
        named = os.stat(shard.name, dir_fd=root_fd, follow_symlinks=False)
        if any(fingerprint(info) != fingerprint(before) for info in (after, named)):
            return {**result, 'state': 'changed_during_verification'}
        observed = digest.hexdigest()
        return {**result, 'sha256': observed, 'read_mode': 'mmap' if mapped else 'stream',
                'state': 'verified' if observed == shard.sha256 else 'sha256_mismatch'}
    except FileNotFoundError:
        return {**result, 'state': 'changed_during_verification'}
    except OSError as exc:
        return {**result, 'state': 'unreadable', 'errno': exc.errno}
    finally:
        os.close(pinned)


def verify(path, only=None, *, mmap_pilot=False):
    if mmap_pilot and only != 1:
        raise ValueError('only the pinned small first shard can be mapped by this verifier')
    selected = SHARDS if only is None else (SHARDS[only - 1],)
    root_fd = open_root(path)
    try:
        mounts = mount_types()
        results = [verify_shard(root_fd, shard, mounts, mapped=mmap_pilot) for shard in selected]
    finally:
        os.close(root_fd)
    complete = all(item['state'] == 'verified' for item in results)
    return {
        'root': os.path.abspath(path), 'revision': REVISION, 'results': results,
        'selection_verified': complete, 'all_11_shards_verified': complete and only is None,
    }


def compare(available, reserve=None):
    required = MODEL_BYTES if reserve is None else MODEL_BYTES + reserve
    return {'available_bytes': available, 'model_bytes': MODEL_BYTES, 'reserve_bytes': reserve,
            'required_bytes': required, 'fits': None if available is None else available >= required}


def capacity_plan(args):
    limit, current = args.memory_limit_bytes, args.memory_current_bytes
    memory_available = max(0, limit - current) if limit is not None and current is not None else None
    return {
        'revision': REVISION,
        'capacity_assessment': 'New copy only. No runtime allocation or benchmark is performed.',
        's1_documented_disk_example': compare(122_000_000_000),
        'capacity': {
            'cgroup_headroom': compare(memory_available, args.runtime_reserve_bytes),
            'tmpfs_space': compare(args.tmpfs_free_bytes),
            'ssd_space': compare(args.ssd_free_bytes, args.disk_reserve_bytes),
            'gpu_free_bytes_for_runtime_profiling': args.gpu_free_bytes,
        },
        'inputs_needed': [
            'Effective cgroup limit, including ancestors, and matching observed memory.current.',
            'Available bytes and filesystem at the real destination; plan runtime and disk reserves explicitly.',
            'Free GPU VRAM, driver/toolkit compatibility, pinned llama.cpp version and supported flags.',
        ],
        'launch_plan': {
            'model_first_shard': SHARDS[0].name,
            'load_mode': 'shared file-backed mmap; retain any memfd holders across loader exits',
            'v4_initial_profile': {'context_tokens': 32768, 'kv_key': 'f16', 'kv_value': 'f16',
                                   'parallel_slots': 1, 'jinja': True},
            'pilot': 'Start with MTP and MoE cache disabled. Select GPU layers and batch from measured VRAM.',
            'acceptance': 'Verify all shards, then check streaming, speed, S03 roundtrip and full restoration before switching.',
        },
    }


def nonnegative(value):
    try:
        amount = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError('must be a non-negative byte count') from exc
    if amount < 0:
        raise argparse.ArgumentTypeError('must be a non-negative byte count')
    return amount


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('manifest', help='print the immutable publisher manifest')
    checker = commands.add_parser('verify', help='hash only regular local files in a candidate directory')
    checker.add_argument('root', type=Path)
    checker.add_argument('--only', type=int, choices=range(1, 12), metavar='SHARD',
                         help='verify just one shard by number (1–11)')
    checker.add_argument('--mmap-pilot', action='store_true', help='read the pinned small shard via mmap')
    plan = commands.add_parser('plan', help='calculate against supplied observed capacities')
    for field in ('memory-limit-bytes', 'memory-current-bytes', 'runtime-reserve-bytes',
                  'tmpfs-free-bytes', 'ssd-free-bytes', 'disk-reserve-bytes', 'gpu-free-bytes'):
        plan.add_argument('--' + field, type=nonnegative)
    args = parser.parse_args()

    if args.command == 'manifest':
        result, code = manifest(), 0
    elif args.command == 'plan':
        result, code = capacity_plan(args), 0
    else:
        if args.mmap_pilot and args.only != 1:
            parser.error('--mmap-pilot requires --only 1')
        try:
            result = verify(args.root, args.only, mmap_pilot=args.mmap_pilot)
            code = 0 if result['selection_verified'] else 1
        except OSError as exc:
            result, code = {'root': str(args.root), 'state': 'unreadable_root', 'errno': exc.errno}, 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return code


if __name__ == '__main__':
    sys.exit(main())
