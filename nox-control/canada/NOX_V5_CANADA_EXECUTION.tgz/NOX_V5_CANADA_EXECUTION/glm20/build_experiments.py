"""Convert sourced GLM experiment cards into candidate follow-ups for the existing relay."""

import argparse
import json
from pathlib import Path
import re


def load_table(path):
    roles = {"A1": "maintenance", "A2": "inference", "A3": "memory", "A4": "persona",
             "A5": "chat_route", "A6": "training", "A0": "operator_control"}
    cards = []
    for line in path.read_text().splitlines():
        number, priority, role, parent, title, change, evidence, url, artifact = line.split("|")
        if not re.fullmatch(r"\d{2}", number) or not url.startswith("https://") or priority not in ("P0", "P1", "P2"):
            raise ValueError("invalid research card")
        cards.append({
            "id": f"GLM20-{number}", "title": title, "priority": priority, "role": role,
            "execution_targets": ["S1"], "source_dependencies": parent.split(","),
            "unmapped_dependency_ids": [], "resource_key": roles[role], "owner_card": False,
            "known_operation": None, "physical_evidence": evidence,
            "proposed_change": change, "public_source": url, "local_artifact": artifact,
        })
    if len(cards) != 20 or len({c["id"] for c in cards}) != len(cards):
        raise ValueError("expected twenty unique improvement cards")
    return cards


def append_to_relay(plan, cards):
    known = {x["id"] for b in plan["blocks"] for x in b["cards"]} | {x["id"] for x in plan["pv_gates"]}
    if set(x["id"] for x in cards) & known or any(set(x["source_dependencies"]) - known for x in cards):
        raise ValueError("experiment IDs or dependencies do not match canonical relay")
    return plan | {"experiment_cards": cards, "experiment_native_count": 0}


def markdown(cards):
    out = ["# GLM‑5.3 · двадцать улучшений для исполнения", "",
           "Главная модель S1, 11 закреплённых шардов UD‑Q4_K_XL. Базовый профиль сохраняет веса, контекст, историю, S03 и KV f16. Ни одна карточка сама не включает серверную настройку.", "",
           "| ID | Улучшение | Приёмка на S1 | Источник |", "|---|---|---|---|"]
    for c in cards:
        out.append(f"| {c['id']} · {c['priority']} | {c['title']} | {c['physical_evidence']} | [Первоисточник]({c['public_source']}) |")
    return "\n".join(out) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cards", type=Path)
    parser.add_argument("--relay", type=Path)
    parser.add_argument("--markdown", action="store_true")
    args = parser.parse_args()
    cards = load_table(args.cards)
    if args.markdown:
        print(markdown(cards), end="")
    else:
        data = append_to_relay(json.loads(args.relay.read_text()), cards) if args.relay else cards
        print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
