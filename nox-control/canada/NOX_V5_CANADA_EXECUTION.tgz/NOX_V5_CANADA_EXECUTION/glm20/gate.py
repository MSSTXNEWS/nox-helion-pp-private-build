"""Pure GLM request contracts for synthetic fixtures and scoped S03 retrieval."""

from collections import defaultdict
import hashlib
import json
import re


def unique_ids(items):
    result = set()
    for item in items:
        if not isinstance(item, str) or not item or item in result:
            raise ValueError("missing or duplicate identity")
        result.add(item)
    return result


def ordered_observations(request_id, calls, observations):
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("request identity required")
    call_ids = [call["id"] for call in calls]
    expected = unique_ids(call_ids)
    received = unique_ids(row["tool_call_id"] for row in observations)
    if received != expected or any(row["request_id"] != request_id for row in observations):
        raise ValueError("tool call/observation binding changed")
    by_id = {row["tool_call_id"]: row for row in observations}
    return [by_id[identity] for identity in call_ids]


def requested_tools(registry, references, allowed):
    """Resolve pre-authorized tool schemas while preserving declared order."""
    unique_ids(references)
    if any(name not in allowed or name not in registry for name in references):
        raise ValueError("unknown or unavailable tool reference")
    # Always-loaded tools still require the same current access check.
    return [schema for name, schema in registry.items()
            if name in allowed and (not schema.get("defer_loading", False) or name in references)]


def sentence_window(anchor, rows, before, after, allowed):
    """Expand exact neighboring sentence IDs under a previously computed current ACL."""
    if type(before) is not int or type(after) is not int or min(before, after) < 0:
        raise ValueError("invalid requested window")
    signature = (anchor["source_sha256"], anchor["revision"], anchor["scope"])
    candidates = {}
    for row in rows:
        if ((row["source_sha256"], row["revision"], row["scope"]) != signature
                or row["id"] not in allowed or row.get("revoked") is not False):
            continue
        index = row["ordinal"]
        if type(index) is not int or index < 0 or index in candidates:
            raise ValueError("ambiguous source order")
        candidates[index] = row
    start = anchor["ordinal"]
    if start not in candidates or candidates[start]["id"] != anchor["id"]:
        raise ValueError("anchor is unavailable")
    low = high = start
    while low > start - before and low - 1 in candidates:
        low -= 1
    while high < start + after and high + 1 in candidates:
        high += 1
    return [candidates[i] for i in range(low, high + 1)]


def reciprocal_rank(rankings, allowed, k=60):
    """RRF over already permission-filtered document identities."""
    if type(k) is not int or k <= 0:
        raise ValueError("invalid RRF constant")
    scores = defaultdict(float)
    for ranking in rankings:
        seen = set()
        for item in ranking:
            if item in allowed and item not in seen:
                seen.add(item)
                scores[item] += 1 / (k + len(seen))
    return sorted(scores, key=lambda key: (-scores[key], key))


def token_admission_key(wire, *, model_sha256, template_sha256, scope_sha256, revocation_epoch):
    """Hash the exact full input. The caller must bind the live scope and revoke epoch."""
    if not isinstance(wire, bytes) or not wire or type(revocation_epoch) is not int or revocation_epoch < 0:
        raise ValueError("invalid input or revocation epoch")
    fields = (model_sha256, template_sha256, scope_sha256)
    if not all(isinstance(s, str) and re.fullmatch(r"[0-9a-f]{64}", s) for s in fields):
        raise ValueError("missing exact model/template/scope pins")
    meta = json.dumps([*fields, revocation_epoch], separators=(",", ":")).encode()
    return hashlib.sha256(meta + b"\x00" + wire).hexdigest()
