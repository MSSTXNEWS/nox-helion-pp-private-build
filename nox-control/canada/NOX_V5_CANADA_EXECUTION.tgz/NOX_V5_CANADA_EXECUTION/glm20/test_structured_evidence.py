import copy
import json
import unittest

import structured_evidence as checks


def encoded(data):
    return json.dumps(data, sort_keys=True).encode("utf-8")


def fixture():
    contract = {
        "schema": checks.CASE,
        "binding": {"case_id": "P7-05", "source_sha256": "1" * 64, "fixture_sha256": "2" * 64,
                    "route_sha256": "3" * 64, "workload_sha256": "4" * 64},
        "references": [{"id": "CANON-WEB6", "sha256": "5" * 64}],
        "checks": [{"check_id": "visible_sse", "required_reference_ids": ["CANON-WEB6"]}],
        "browser_producer_sha256": "6" * 64,
    }
    contract_pin = checks.sha(encoded(contract))
    proposal = {"schema": checks.PROPOSAL, "case_id": "P7-05", "contract_sha256": contract_pin,
                "status": "PROPOSED", "checks": [{"check_id": "visible_sse", "reference_ids": ["CANON-WEB6"]}]}
    browser = {
        "schema": checks.BROWSER, "mode": "local_fixture", "contract_sha256": contract_pin,
        "binding": copy.deepcopy(contract["binding"]), "producer_sha256": "6" * 64,
        "checks": [{"check_id": "visible_sse", "result": "PASS", "trace_sha256": "7" * 64,
                    "reference_sha256": {"CANON-WEB6": "5" * 64}}],
    }
    return contract, proposal, browser


def verify(contract, proposal, browser=None):
    c, p = encoded(contract), encoded(proposal)
    b = encoded(browser) if browser is not None else None
    return checks.verify(p, c, checks.sha(c), b, checks.sha(b) if b is not None else None)


class StructuredEvidenceTest(unittest.TestCase):
    def test_shape_or_model_proposal_alone_cannot_claim_browser_or_native_pass(self):
        contract, proposal, _ = fixture()
        result = verify(contract, proposal)
        self.assertEqual(result["state"], "PROPOSAL_ONLY")
        self.assertEqual(result["browser_checks_matched"], 0)
        self.assertFalse(result["native_effect_verified"])
        proposal["status"] = "PASS"
        with self.assertRaisesRegex(checks.Hold, "MODEL_CANNOT_DECLARE_A_PASS"):
            verify(contract, proposal)

    def test_consistent_browser_fixture_matches_checks_without_promoting(self):
        result = verify(*fixture())
        self.assertEqual(result["state"], "BROWSER_EVIDENCE_CONSISTENT")
        self.assertEqual(result["browser_mode"], "local_fixture")
        self.assertEqual(result["browser_checks_matched"], 1)
        self.assertFalse(result["evidence_provenance_authenticated"])
        self.assertFalse(result["original_task_accepted"])

    def test_distinguishes_invalid_bindings_digests_and_checks(self):
        for field in ("source_sha256", "route_sha256", "fixture_sha256", "workload_sha256"):
            with self.subTest(field=field):
                contract, proposal, browser = fixture()
                browser["binding"][field] = "f" * 64
                with self.assertRaisesRegex(checks.Hold, "BROWSER_SOURCE_SCOPE_MISMATCH"):
                    verify(contract, proposal, browser)
        contract, proposal, browser = fixture()
        with self.assertRaisesRegex(checks.Hold, "EVIDENCE_SHA_MISMATCH"):
            c = encoded(contract)
            checks.verify(encoded(proposal), c, checks.sha(c), encoded(browser), "e" * 64)
        browser["checks"][0]["reference_sha256"]["CANON-WEB6"] = "8" * 64
        with self.assertRaisesRegex(checks.Hold, "BROWSER_REFERENCE_SHA_MISMATCH"):
            verify(contract, proposal, browser)

    def test_rejects_unbound_reference_unknown_action_and_duplicate_check(self):
        contract, proposal, browser = fixture()
        proposal["checks"][0]["reference_ids"] = ["FABRICATED"]
        with self.assertRaisesRegex(checks.Hold, "UNBOUND_MODEL_REFERENCE"):
            verify(contract, proposal, browser)
        _, allowed, _ = fixture()
        with self.assertRaisesRegex(checks.Hold, "INVALID_PROPOSAL_SHAPE"):
            verify(contract, allowed | {"command": "outside the schema"})
        allowed["checks"] += allowed["checks"]
        with self.assertRaisesRegex(checks.Hold, "DUPLICATE_CHECK_OR_REFERENCE"):
            verify(contract, allowed, browser)

    def test_strict_json_rejects_duplicate_keys_and_infinite_numeric_tokens(self):
        for token in (b"NaN", b"Infinity", b"1e600"):
            with self.subTest(token=token), self.assertRaisesRegex(checks.Hold, "NONFINITE_JSON_NUMBER"):
                checks.read_json(b'{"unexpected":' + token + b'}')
        with self.assertRaisesRegex(checks.Hold, "DUPLICATE_JSON_KEY"):
            checks.read_json(b'{"status":"PROPOSED","status":"PASS"}')

    def test_absent_browser_proof_and_failed_browser_proof_are_distinct(self):
        contract, proposal, browser = fixture()
        insufficient = proposal | {"status": "INSUFFICIENT_EVIDENCE", "checks": []}
        self.assertEqual(verify(contract, insufficient)["state"], "HOLD_INSUFFICIENT_MODEL_EVIDENCE")
        browser["checks"][0]["result"] = "FAIL"
        with self.assertRaisesRegex(checks.Hold, "BROWSER_CHECK_DID_NOT_PASS"):
            verify(contract, proposal, browser)


if __name__ == "__main__":
    unittest.main()
