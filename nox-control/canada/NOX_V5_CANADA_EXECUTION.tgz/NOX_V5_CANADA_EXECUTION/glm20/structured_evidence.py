"""Validate a GLM proposal and separately supplied browser evidence offline.

The JSON response schema constrains proposal shape. Independent, SHA-bound
browser output and the case contract determine whether checks are consistent.
Nothing here performs an action or accepts an original/native task.
"""

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys


CASE = "NOX_WEB_STRUCTURED_CASE_V1"
PROPOSAL = "NOX_WEB_STRUCTURED_PROPOSAL_V1"
BROWSER = "NOX_WEB_STRUCTURED_BROWSER_V1"
RESULT = "NOX_WEB_STRUCTURED_CHECK_V1"
MAX_BYTES = 128 * 1024
HASH = re.compile(r"[a-f0-9]{64}\Z")
ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}\Z")
BINDING = {"case_id", "source_sha256", "fixture_sha256", "route_sha256", "workload_sha256"}

# This small, non-recursive grammar shape is suitable for a decoder smoke
# test. Check cardinality, proof provenance and consistency again below.
PROPOSAL_SCHEMA = {
    "type": "object",
    "properties": {
        "schema": {"const": PROPOSAL},
        "case_id": {"type": "string"},
        "contract_sha256": {"type": "string"},
        "status": {"enum": ["PROPOSED", "INSUFFICIENT_EVIDENCE"]},
        "checks": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "check_id": {"type": "string"},
                    "reference_ids": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["check_id", "reference_ids"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["schema", "case_id", "contract_sha256", "status", "checks"],
    "additionalProperties": False,
}


class Hold(ValueError):
    """An intentionally fixed diagnostic code with no browser or prompt data."""


def require(condition, code):
    if not condition:
        raise Hold(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hex_digest(value):
    return isinstance(value, str) and HASH.fullmatch(value) is not None


def identifier(value):
    return isinstance(value, str) and ID.fullmatch(value) is not None


def exact_keys(value, keys):
    return isinstance(value, dict) and value.keys() == keys


def unique_json_object(pairs):
    value = dict(pairs)
    require(len(pairs) == len(value), "DUPLICATE_JSON_KEY")
    return value


def reject_constant(_constant):
    raise Hold("NONFINITE_JSON_NUMBER")


def finite_float(number):
    value = float(number)
    require(math.isfinite(value), "NONFINITE_JSON_NUMBER")
    return value


def read_json(raw):
    require(isinstance(raw, bytes) and len(raw) <= MAX_BYTES, "INPUT_LIMIT")
    return json.loads(raw, object_pairs_hook=unique_json_object, parse_constant=reject_constant, parse_float=finite_float)


def indexed(rows, keys, key, maximum=20):
    require(isinstance(rows, list) and 0 < len(rows) <= maximum, "INVALID_CHECK_COUNT")
    result = {}
    for row in rows:
        require(exact_keys(row, keys) and identifier(row[key]), "INVALID_CHECK_ROW")
        require(row[key] not in result, "DUPLICATE_CHECK_OR_REFERENCE")
        result[row[key]] = row
    return result


def check_contract(contract):
    require(exact_keys(contract, {"schema", "binding", "references", "checks", "browser_producer_sha256"})
            and contract["schema"] == CASE, "INVALID_CASE_CONTRACT")
    binding = contract["binding"]
    require(exact_keys(binding, BINDING) and identifier(binding["case_id"])
            and all(hex_digest(binding[key]) for key in BINDING - {"case_id"})
            and hex_digest(contract["browser_producer_sha256"]), "INVALID_CASE_PINS")
    references = indexed(contract["references"], {"id", "sha256"}, "id", maximum=64)
    require(all(hex_digest(item["sha256"]) for item in references.values()), "INVALID_REFERENCE_SHA")
    checks = indexed(contract["checks"], {"check_id", "required_reference_ids"}, "check_id")
    for item in checks.values():
        ids = item["required_reference_ids"]
        require(isinstance(ids, list) and ids and all(identifier(key) for key in ids)
                and len(set(ids)) == len(ids) and set(ids) <= references.keys(), "INVALID_CHECK_REFERENCES")
    return binding, checks, references


def check_proposal(proposal, binding, contract_pin, checks, references):
    require(exact_keys(proposal, set(PROPOSAL_SCHEMA["required"])) and proposal["schema"] == PROPOSAL,
            "INVALID_PROPOSAL_SHAPE")
    require(proposal["case_id"] == binding["case_id"] and proposal["contract_sha256"] == contract_pin,
            "PROPOSAL_CASE_OR_SHA_MISMATCH")
    if proposal["status"] == "INSUFFICIENT_EVIDENCE" and proposal["checks"] == []:
        return False
    require(proposal["status"] == "PROPOSED", "MODEL_CANNOT_DECLARE_A_PASS")
    claims = indexed(proposal["checks"], {"check_id", "reference_ids"}, "check_id")
    require(claims.keys() == checks.keys(), "INCOMPLETE_OR_FOREIGN_CHECK_SET")
    for key, claim in claims.items():
        ids = claim["reference_ids"]
        require(isinstance(ids, list) and ids and all(identifier(item) for item in ids)
                and len(set(ids)) == len(ids) and set(ids) <= references.keys()
                and set(checks[key]["required_reference_ids"]) <= set(ids), "UNBOUND_MODEL_REFERENCE")
    return True


def check_browser(browser, contract, contract_pin, binding, checks, references):
    require(exact_keys(browser, {"schema", "mode", "contract_sha256", "binding", "producer_sha256", "checks"})
            and browser["schema"] == BROWSER, "INVALID_BROWSER_EVIDENCE")
    require(browser["mode"] in ("local_fixture", "owner_export"), "BROWSER_MODE_UNKNOWN")
    require(browser["contract_sha256"] == contract_pin and browser["binding"] == binding
            and browser["producer_sha256"] == contract["browser_producer_sha256"], "BROWSER_SOURCE_SCOPE_MISMATCH")
    proven = indexed(browser["checks"], {"check_id", "result", "trace_sha256", "reference_sha256"}, "check_id")
    require(proven.keys() == checks.keys(), "BROWSER_PROOF_INCOMPLETE")
    for key, item in proven.items():
        require(item["result"] == "PASS" and hex_digest(item["trace_sha256"]), "BROWSER_CHECK_DID_NOT_PASS")
        expected = {ref: references[ref]["sha256"] for ref in checks[key]["required_reference_ids"]}
        require(item["reference_sha256"] == expected, "BROWSER_REFERENCE_SHA_MISMATCH")
    return browser["mode"]


def verify(proposal_raw, contract_raw, contract_pin, browser_raw=None, browser_pin=None):
    require(hex_digest(contract_pin) and sha(contract_raw) == contract_pin, "CASE_CONTRACT_SHA_MISMATCH")
    contract = read_json(contract_raw)
    binding, checks, references = check_contract(contract)
    proposed = check_proposal(read_json(proposal_raw), binding, contract_pin, checks, references)
    report = {
        "schema": RESULT,
        "case_id": binding["case_id"],
        "case_sha256": contract_pin,
        "proposal_sha256": sha(proposal_raw),
        "state": "PROPOSAL_ONLY" if proposed else "HOLD_INSUFFICIENT_MODEL_EVIDENCE",
        "browser_checks_matched": 0,
        "evidence_provenance_authenticated": False,
        "native_effect_verified": False,
        "original_task_accepted": False,
    }
    if browser_raw is None and browser_pin is None:
        return report
    require(proposed, "NO_COMPLETE_PROPOSAL")
    require(browser_raw is not None and hex_digest(browser_pin) and sha(browser_raw) == browser_pin,
            "BROWSER_EVIDENCE_SHA_MISMATCH")
    mode = check_browser(read_json(browser_raw), contract, contract_pin, binding, checks, references)
    report.update(state="BROWSER_EVIDENCE_CONSISTENT", browser_mode=mode,
                  browser_checks_matched=len(checks), browser_evidence_sha256=browser_pin)
    return report


def read_file(path):
    with path.open("rb") as stream:
        raw = stream.read(MAX_BYTES + 1)
    require(len(raw) <= MAX_BYTES, "INPUT_LIMIT")
    return raw


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    methods = parser.add_subparsers(dest="method", required=True)
    methods.add_parser("schema", help="print the small proposal grammar schema")
    check = methods.add_parser("verify")
    check.add_argument("contract", type=Path)
    check.add_argument("proposal", type=Path)
    check.add_argument("--contract-sha256", required=True)
    check.add_argument("--browser-evidence", type=Path)
    check.add_argument("--browser-sha256")
    args = parser.parse_args(argv)
    if args.method == "schema":
        print(json.dumps(PROPOSAL_SCHEMA, indent=2, sort_keys=True))
        return 0
    try:
        report = verify(read_file(args.proposal), read_file(args.contract), args.contract_sha256,
                        read_file(args.browser_evidence) if args.browser_evidence else None, args.browser_sha256)
        print(json.dumps(report, sort_keys=True))
        return 2 if report["state"].startswith("HOLD") else 0
    except Hold as error:
        reason = str(error)
    except (KeyError, OSError, ValueError, TypeError, RecursionError):
        reason = "INVALID_STRUCTURED_EVIDENCE"
    print(json.dumps({"schema": RESULT, "state": "HOLD", "reason": reason,
                      "native_effect_verified": False, "original_task_accepted": False}, sort_keys=True))
    return 2


if __name__ == "__main__":
    sys.exit(main())
