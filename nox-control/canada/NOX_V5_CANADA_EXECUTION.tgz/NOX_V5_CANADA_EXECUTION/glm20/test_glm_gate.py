import unittest

from gate import ordered_observations, reciprocal_rank, requested_tools, sentence_window, token_admission_key


class GateTests(unittest.TestCase):
    def test_order_is_bound_to_request(self):
        calls = [{"id": "a"}, {"id": "b"}]
        rows = [{"tool_call_id": "b", "request_id": "r"}, {"tool_call_id": "a", "request_id": "r"}]
        self.assertEqual([x["tool_call_id"] for x in ordered_observations("r", calls, rows)], ["a", "b"])
        with self.assertRaises(ValueError):
            ordered_observations("r2", calls, rows)
        with self.assertRaises(ValueError):
            ordered_observations("r", calls, rows[:1] * 2)

    def test_defer_and_current_access(self):
        schemas = {"a": {}, "b": {"defer_loading": True}, "private": {}}
        self.assertEqual(requested_tools(schemas, [], {"a", "b"}), [{}])
        self.assertEqual(len(requested_tools(schemas, ["b"], {"a", "b"})), 2)
        with self.assertRaises(ValueError):
            requested_tools(schemas, ["private"], {"a", "b"})

    def test_no_crossing_gap_or_revoke(self):
        common = {"source_sha256": "a", "scope": "s", "revision": 1, "revoked": False}
        rows = [dict(common, id=str(i), ordinal=i) for i in range(4)]
        rows[1]["revoked"] = True
        rows[3]["scope"] = "other"
        self.assertEqual(sentence_window(rows[2], rows, 2, 1, {"0", "1", "2", "3"}), [rows[2]])

    def test_fusion_filters_and_deduplicates(self):
        self.assertEqual(reciprocal_rank([["a", "a", "secret", "b"], ["b", "c"]], {"a", "b", "c"}),
                         ["b", "a", "c"])

    def test_memo_rekeys_revocation_and_exact_bytes(self):
        pins = dict(model_sha256="a"*64, template_sha256="b"*64, scope_sha256="c"*64)
        self.assertNotEqual(token_admission_key(b"prompt", **pins, revocation_epoch=1),
                            token_admission_key(b"prompt", **pins, revocation_epoch=2))
        self.assertNotEqual(token_admission_key(b"prompt", **pins, revocation_epoch=1),
                            token_admission_key(b"prompt ", **pins, revocation_epoch=1))
