"""Start a pinned GLM on vacant loopback port 18098 on the S1 candidate only."""

import argparse
import hashlib
import json
import os
import re
import socket
import stat
import subprocess
from pathlib import Path

from model_plan import SHARDS, verify
from server_probe import cgroup_probe, gpu_probe, host_memory, instance_identity, stat_identity


def engine_environment(env):
    names = {"PATH", "HOME", "TMPDIR", "CUDA_VISIBLE_DEVICES", "NVIDIA_VISIBLE_DEVICES", "LD_LIBRARY_PATH"}
    return {**{name: env[name] for name in names if name in env}, "LC_ALL": "C"}


def explicit_mmap_flag(help_text):
    flags = set(re.findall(r"(?<![\w-])--[a-z][a-z0-9-]*", help_text))
    if "--load-mode" in flags and re.search(r"\bmmap\s*:", help_text):
        return ["--load-mode", "mmap"]
    if "--mmap" in flags:
        return ["--mmap"]
    raise ValueError("pinned engine does not advertise an explicit mmap mode")


def observed_budget(ram_bytes, gpu_mib, provider_headroom=None):
    identity = instance_identity()
    if identity["instance_id"] != 61825960:
        raise ValueError("local container label does not match S1 61825960")
    group = cgroup_probe()
    free = group.get("effective_memory_headroom_bytes")
    soft = group.get("effective_memory_high_headroom_bytes")
    host_free = host_memory().get("available_bytes")
    if group.get("status") != "OK" or (free is not None and free < ram_bytes):
        raise ValueError("measured cgroup RAM does not cover the selected runtime budget")
    if group.get("memory_high_status") != "OK" or (soft is not None and soft < ram_bytes):
        raise ValueError("runtime RAM would cross the observed cgroup memory.high threshold")
    if type(host_free) is not int or host_free < ram_bytes:
        raise ValueError("host RAM does not cover the selected runtime budget")
    if ((group.get("ancestors_visibility") != "VISIBLE_NAMESPACE" and provider_headroom is None)
            or (provider_headroom is not None and provider_headroom < ram_bytes)):
        raise ValueError("runtime RAM headroom for hidden cgroup ancestors is unconfirmed")
    gpu = gpu_probe()
    devices = gpu.get("devices", [])
    if (gpu.get("status") != "OK" or len(devices) != 1
            or devices[0].get("compute_capability") != "12.0"
            or devices[0]["free_mib"] < gpu_mib):
        raise ValueError("S1 GPU identity or free VRAM could not be established")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, help="verified owner-only GLM staging directory")
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--binary-sha256", required=True)
    for name in ("context", "threads", "batch", "ubatch", "gpu-layers", "min-ram-gib", "min-vram-mib"):
        parser.add_argument("--" + name, type=int, required=True)
    parser.add_argument("--cpu-moe", action="store_true")
    parser.add_argument("--provider-headroom-bytes", type=int,
                        help="independently observed headroom above the visible cgroup subtree")
    parser.add_argument("--apply", action="store_true", help="start the isolated foreground candidate")
    args = parser.parse_args()
    basic = (args.context, args.threads, args.batch, args.ubatch, args.min_ram_gib, args.min_vram_mib)
    if (min(basic) <= 0 or args.context < 32768 or args.gpu_layers < 0 or args.ubatch > args.batch
            or args.provider_headroom_bytes is not None and args.provider_headroom_bytes < 0):
        parser.error("positive measured budgets and batches, ubatch <= batch, context >= 32768 are required")
    if not re.fullmatch(r"[0-9a-f]{64}", args.binary_sha256):
        parser.error("--binary-sha256 requires an exact lower-case SHA-256")
    root = args.root.absolute()
    path = args.binary.absolute()
    arguments = [
        str(path), "--host", "127.0.0.1", "--port", "18098",
        "--model", str(root / SHARDS[0].name), "--ctx-size", str(args.context),
        "--parallel", "1", "--threads", str(args.threads), "--batch-size", str(args.batch),
        "--ubatch-size", str(args.ubatch), "--n-gpu-layers", str(args.gpu_layers),
        "--cache-type-k", "f16", "--cache-type-v", "f16", "--jinja",
    ]
    if args.cpu_moe:
        arguments.append("--cpu-moe")
    print(json.dumps({"state": "SHADOW_PLAN", "arguments": arguments,
                      "model_load_mode": "explicit mmap chosen from pinned engine help",
                      "production_route_change": False}), flush=True)
    if not args.apply:
        return 0
    try:
        budget = args.min_ram_gib * 1024**3, args.min_vram_mib, args.provider_headroom_bytes
        observed_budget(*budget)
        if root.resolve() != root or root.stat().st_mode & 0o077 or root.stat().st_uid != os.geteuid():
            raise ValueError("use an owner-only real staging directory")
        with socket.socket() as candidate:
            candidate.bind(("127.0.0.1", 18098))
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as file:
            before = os.fstat(fd)
            if not stat.S_ISREG(before.st_mode) or before.st_mode & 0o022:
                raise ValueError("binary must be a regular file without group/world write access")
            if hashlib.file_digest(file, "sha256").hexdigest() != args.binary_sha256:
                raise ValueError("binary does not match the requested SHA-256")
            receipt = verify(root)
            if not receipt["all_11_shards_verified"]:
                raise ValueError("all 11 local shards require verified SHA-256")
            observed_budget(*budget)
            env = engine_environment(os.environ)
            help_run = subprocess.run([f"/proc/self/fd/{fd}", "--help"], pass_fds=(fd,),
                                      timeout=12, capture_output=True, text=True, check=False, env=env)
            flags = set(re.findall(r"(?<![\w-])--[a-z][a-z0-9-]*", help_run.stdout))
            if help_run.returncode or not {a for a in arguments if a.startswith("--")} <= flags:
                raise ValueError("one or more arguments are absent from the pinned engine help")
            arguments.extend(explicit_mmap_flag(help_run.stdout))
            if stat_identity(os.fstat(fd)) != stat_identity(before):
                raise ValueError("engine changed during verification")
            os.execve(fd, arguments, env)
    except (OSError, ValueError, subprocess.TimeoutExpired, TypeError) as exc:
        print(json.dumps({"state": "HOLD", "reason": str(exc), "production_route_change": False}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
