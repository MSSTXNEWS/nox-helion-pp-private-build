from pathlib import Path
import tempfile
import unittest

from service_state import inspect


class ServiceStateTest(unittest.TestCase):
    def test_stopped_model_holds_even_without_health_failure(self):
        with tempfile.TemporaryDirectory() as local:
            proc = Path(local)
            self.add_stat(proc, "T", 500)
            result = inspect(123, 500, 8098, proc=proc, ping=lambda _: self.fail("health tried on stopped service"))
            self.assertEqual(result["state"], "HOLD_KERNEL")
            self.assertFalse(result["live_chat_verified"])

    def test_generation_and_health_remain_separate(self):
        with tempfile.TemporaryDirectory() as local:
            proc = Path(local)
            self.add_stat(proc, "S", 500)
            with self.assertRaisesRegex(ValueError, "GENERATION"):
                inspect(123, 499, None, proc=proc)
            result = inspect(123, 500, 8098, proc=proc, ping=lambda _: {"ok": True})
            self.assertEqual(result["state"], "HEALTH_OBSERVED")
            self.assertFalse(result["live_chat_verified"])

    @staticmethod
    def add_stat(proc, state, ticks):
        target = proc / "123"
        target.mkdir()
        (target / "stat").write_text("123 (llama ) server) " + state + " 0" * 18 + " " + str(ticks))
