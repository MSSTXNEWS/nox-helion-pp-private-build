from contextlib import redirect_stdout
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
import tempfile
import unittest

import writer_failover as failover


def fixture():
    scope = {"owner": "fixture-owner", "data_scope": "fixture-scope", "project": "fixture-project",
             "core": "C03", "persona": "fixture-persona", "dialog": "fixture-dialog"}
    old = {"writer_id": "s2-writer", "epoch": 41, "route_sha256": "a" * 64}
    new = {"writer_id": "s1-writer", "epoch": 42, "route_sha256": "b" * 64}
    back = {**old, "epoch": 43}
    baseline_state, after_commit, tombstone = "c" * 64, "d" * 64, "e" * 64
    archive, restored_state = "f" * 64, "0" * 64
    restore_proof = {"restored_state_sha256": restored_state, "restore_proof_sha256": "5" * 64,
                     "ledger_head_sha256": "6" * 64, "ledger_epoch": 12, "isolated_run_id": "isolated-restore"}
    observers = {role: f"staging-{role}" for _, role in failover.ORDER}
    run_id = "isolated-pv08-fixture"
    exchange = {"writer": new, "request_id": "request-committed", "exchange_id": "exchange-committed",
                "request_sha256": "1" * 64, "user_sha256": "2" * 64, "answer_sha256": "3" * 64,
                "commit_receipt_id": "receipt-one", "backend_job_id": "only-generation"}
    rows = [{"id": f"row-{role}", "role": role, "sequence": seq, "sha256": exchange[digest],
             "scope": scope, "request_id": exchange["request_id"], "exchange_id": exchange["exchange_id"],
             "writer": new} for seq, role, digest in [(20, "user", "user_sha256"), (21, "assistant", "answer_sha256")]]
    readback = {"rows": rows, "canonical_state_sha256": after_commit, "late_old_exchange_rows": [],
                "commit_receipt_id": exchange["commit_receipt_id"]}
    bodies = {
        "baseline": {"writer": old, "revocation_epoch": 12, "canonical_state_sha256": baseline_state,
                     "revoked_canary_sha256": tombstone},
        "restored_revocation": {**restore_proof, "archive_sha256": archive, "archive_revocation_epoch": 11,
                                "canonical_state_sha256": baseline_state, "affected_event_id": "retired-fact",
                                "revoke_enforced_before_ready": True, "applied_seq": 7, "ready_seq": 8,
                                "revoked_canary_sha256": tombstone, "revoked_keys_resolvable": [],
                                "positive_readback_verified": True},
        "candidate_ready": {**restore_proof, "writer": new, "restore_seq": 2},
        "cutover": {"from_writer": old, "to_writer": new, "ready_seq": 3,
                    "active_writers": [new], "outcome": "CAS_APPLIED"},
        "old_epoch_rejected": {"writer": old, "request_id": "request-late", "exchange_id": "exchange-late",
                               "outcome": "FENCED_STALE_EPOCH", "before_state_sha256": baseline_state,
                               "after_state_sha256": baseline_state},
        "new_exchange": {**exchange, "outcome": "ACK_LOST_AFTER_COMMIT"},
        "first_readback": readback,
        "same_exchange_retry": {**exchange, "outcome": "RETURNED_EXISTING_RECEIPT",
                                "returned_row_ids": [row["id"] for row in rows]},
        "retry_readback": readback,
        "exact_stop": {"requested_request_id": "request-stop", "requested_backend_job_id": "job-stop",
                       "target": {"request_id": "request-stop", "backend_job_id": "job-stop",
                                  "state_before_stop": "active", "terminal": "cancelled", "events_after_terminal": 0},
                       "unrelated": {"request_id": "request-sibling", "backend_job_id": "job-sibling",
                                     "state_before_stop": "active", "terminal": "done"},
                       "write_exchange_backend_job_ids": ["only-generation"]},
        "rollback": {"from_writer": new, "to_writer": back, "active_writers": [back], "outcome": "CAS_APPLIED"},
        "rollback_fenced_epochs": {"active_writer": back, "attempts": [
            {"writer": old, "exchange_id": "old-original-after-rollback", "outcome": "FENCED_STALE_EPOCH"},
            {"writer": new, "exchange_id": "old-candidate-after-rollback", "outcome": "FENCED_STALE_EPOCH"},
        ]},
        "rollback_readback": {**readback, "writer": back, "revocation_epoch": 12,
                              "revoked_canary_sha256": tombstone, "revoked_keys_resolvable": [], "affected_event_id": "retired-fact",
                              "cancelled_request_id": "request-stop", "cancelled_assistant_rows": [],
                              "stale_epoch_rows": {"old-original-after-rollback": [], "old-candidate-after-rollback": []}},
    }
    # JSON receipts do not share mutable Python references between events.
    events = [deepcopy({**bodies[kind], "seq": seq, "kind": kind, "observer": observers[role],
                        "run_id": run_id, "scope": scope})
              for seq, (kind, role) in enumerate(failover.ORDER, start=1)]
    return {"schema": failover.SCHEMA, "scope": scope, "run_id": run_id, "observers": observers, "events": events}


def event(receipt, kind):
    return next(item for item in receipt["events"] if item["kind"] == kind)


class WriterFailoverTest(unittest.TestCase):
    def assert_hold(self, receipt, code):
        with self.assertRaises(failover.FailoverError) as exc:
            failover.verify(receipt)
        self.assertEqual(str(exc.exception), code)

    def test_exact_writer_exchange_retry_stop_and_rollback(self):
        result = failover.verify(fixture())
        self.assertEqual(result["state"], "WRITER_FAILOVER_TRACE_CONSISTENT")
        self.assertEqual((result["ordered_events"], result["canonical_exchanges"], result["canonical_rows"]), (13, 1, 2))
        self.assertFalse(result["live_acceptance"])

    def test_ready_before_restore_cannot_be_relabelled_as_pass(self):
        receipt = fixture()
        events = receipt["events"]
        events[1], events[2] = events[2], events[1]
        events[1]["seq"], events[2]["seq"] = 2, 3
        self.assert_hold(receipt, "EVENT_ORDER_OR_BINDING_MISMATCH")
        receipt = fixture()
        event(receipt, "candidate_ready")["restored_state_sha256"] = "4" * 64
        self.assert_hold(receipt, "READY_NOT_BOUND_TO_RESTORED_REVOCATION")
        receipt = fixture()
        event(receipt, "candidate_ready")["restore_proof_sha256"] = "4" * 64
        self.assert_hold(receipt, "READY_NOT_BOUND_TO_RESTORED_REVOCATION")

    def test_restore_must_reject_revoked_and_keep_positive_record(self):
        for key, value in [("revoked_keys_resolvable", ["revoked-alias"]), ("positive_readback_verified", False),
                           ("revoke_enforced_before_ready", False), ("applied_seq", 9)]:
            with self.subTest(key=key):
                receipt = fixture()
                event(receipt, "restored_revocation")[key] = value
                self.assert_hold(receipt, "RESTORED_REVOCATION_NOT_VERIFIED")

    def test_old_writer_cannot_commit_after_cutover(self):
        receipt = fixture()
        event(receipt, "old_epoch_rejected")["after_state_sha256"] = "4" * 64
        self.assert_hold(receipt, "OLD_EPOCH_WAS_NOT_FENCED")
        receipt = fixture()
        event(receipt, "first_readback")["late_old_exchange_rows"] = [{"id": "stale-write"}]
        self.assert_hold(receipt, "FIRST_CANONICAL_COMMIT_NOT_PROVEN")

    def test_retry_must_keep_request_digest_receipt_and_one_generation(self):
        for key in ("request_sha256", "commit_receipt_id", "backend_job_id", "request_id"):
            with self.subTest(key=key):
                receipt = fixture()
                event(receipt, "same_exchange_retry")[key] = "9" * 64
                self.assert_hold(receipt, "RETRY_DID_NOT_RETURN_SAME_COMMIT")
        receipt = fixture()
        event(receipt, "exact_stop")["write_exchange_backend_job_ids"].append("unexpected-replay")
        self.assert_hold(receipt, "EXACT_STOP_OR_NO_REPLAY_NOT_PROVEN")

    def test_independent_rows_must_have_exact_order_contents_and_count(self):
        receipt = fixture()
        event(receipt, "first_readback")["rows"].reverse()
        self.assert_hold(receipt, "CANONICAL_ROW_MISMATCH")
        receipt = fixture()
        rows = event(receipt, "retry_readback")["rows"]
        rows.append(deepcopy(rows[-1]))
        self.assert_hold(receipt, "RETRY_MUTATED_CANONICAL_EXCHANGE")

    def test_stop_must_target_exact_backend_job_without_harming_sibling(self):
        receipt = fixture()
        event(receipt, "exact_stop")["unrelated"]["terminal"] = "cancelled"
        self.assert_hold(receipt, "EXACT_STOP_OR_NO_REPLAY_NOT_PROVEN")
        receipt = fixture()
        event(receipt, "exact_stop")["requested_backend_job_id"] = "job-sibling"
        self.assert_hold(receipt, "EXACT_STOP_OR_NO_REPLAY_NOT_PROVEN")

    def test_rollback_must_use_new_epoch_and_reject_both_stale_epochs(self):
        receipt = fixture()
        rollback = event(receipt, "rollback")
        rollback["to_writer"]["epoch"] = 41
        self.assert_hold(receipt, "ROLLBACK_REUSED_EPOCH_OR_LOST_AUTHORITY")
        receipt = fixture()
        event(receipt, "rollback_fenced_epochs")["attempts"][1]["outcome"] = "COMMITTED"
        self.assert_hold(receipt, "SUPERSEDED_WRITER_STILL_ACTIVE_AFTER_ROLLBACK")

    def test_rollback_must_not_rewind_canonical_exchange_or_revocation(self):
        for key, value in [("rows", []), ("revoked_keys_resolvable", ["revoked-alias"]),
                           ("cancelled_assistant_rows", [{"id": "late-assistant"}])]:
            with self.subTest(key=key):
                receipt = fixture()
                event(receipt, "rollback_readback")[key] = value
                self.assert_hold(receipt, "ROLLBACK_LOST_COMMIT_OR_REVIVED_REVOKED_STATE")

    def test_cli_does_not_echo_malformed_receipt_text(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "fixture.json"
            path.write_text('{"credential":"PRIVATE_SECRET",}', encoding="utf-8")
            stdout = StringIO()
            with redirect_stdout(stdout):
                self.assertEqual(failover.main([str(path)]), 2)
            self.assertNotIn("PRIVATE_SECRET", stdout.getvalue())
            self.assertEqual(json.loads(stdout.getvalue())["error"], "INVALID_RECEIPT")


if __name__ == "__main__":
    unittest.main()
