from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from affect_transition import Hold, SCHEMA, verify


def sha(name):
    return hashlib.sha256(name.encode()).hexdigest()


def receipt_fixture():
    original = {"owner": "test-owner", "data_scope": "private", "project": "sandbox", "core": "PERSONA",
                "persona": "A", "dialog": "dialog-A"}
    current = dict(original, persona="B", dialog="dialog-B")
    pins = {"route_sha256": sha("route"), "model_sha256": sha("model")}

    def handoff(step, scope, epoch, state, context, cause=None, strategy="act"):
        return {**pins, "observer": "model-recorder", "request_id": f"request-{step}",
                "model_call_id": f"call-{step}", "scope": scope, "epoch": epoch, "step": step,
                "cause_event": cause, "strategy": strategy, "question_sha256": sha("question"),
                "context_sha256": sha(context), "facts_sha256": sha("facts-" + scope["persona"]),
                "soul_sha256": sha("soul-" + scope["persona"]), "acl_sha256": sha("acl-" + scope["persona"]),
                "affect_sha256": sha(state)}

    failures = [{"observer": "affect-recorder", "scope": original, "epoch": 10, "step": step,
                 "event_id": f"failure-{step}", "cause_event": f"failure-{step}", "kind": "verified_failure",
                 "outcome": "applied", "source_receipt_sha256": sha(f"failure-receipt-{step}"),
                 "before_sha256": sha(f"state-{step - 1}"), "after_sha256": sha(f"state-{step}")}
                for step in (1, 2, 3)]
    delayed = {"observer": "affect-recorder", "scope": original, "epoch": 10, "step": 6,
               "event_id": "late-1", "cause_event": "failure-3", "kind": "slow_reflection",
               "outcome": "rejected_stale", "source_receipt_sha256": sha("late-receipt"),
               "before_sha256": sha("state-B"), "after_sha256": sha("state-B")}
    return {**pins, "schema": SCHEMA,
            "observers": {"affect_controller": "affect-recorder", "model_handoff": "model-recorder"},
            "handoffs": [handoff(0, original, 10, "state-0", "context-A"),
                         handoff(4, original, 10, "state-3", "context-reflect", "failure-3", "reflect"),
                         handoff(5, current, 11, "state-B", "context-B"),
                         handoff(8, current, 11, "state-B", "context-B")],
            "events": [*failures, delayed, dict(delayed, step=7, outcome="rejected_duplicate")]}


class AffectTransitionTests(unittest.TestCase):
    def test_consistent_stale_and_replay_receipts_remain_offline_evidence(self):
        self.assertEqual(verify(receipt_fixture()), {
            "state": "EVIDENCE_CONSISTENT", "schema": SCHEMA, "live_acceptance": False,
            "origin_authenticated": False, "handoffs": 4, "confirmed_late_rejections": 2})

    def test_three_failures_must_have_different_provenance(self):
        data = receipt_fixture()
        data["events"][2]["source_receipt_sha256"] = data["events"][1]["source_receipt_sha256"]
        with self.assertRaisesRegex(Hold, "FAILURE_REPLAY"):
            verify(data)

    def test_reflection_keeps_question_facts_identity_and_acl(self):
        fixture = receipt_fixture()
        for field in ("facts_sha256", "soul_sha256", "acl_sha256", "question_sha256"):
            with self.subTest(field=field):
                data = deepcopy(fixture)
                data["handoffs"][1][field] = sha("drift")
                with self.assertRaisesRegex(Hold, "REFLECTION_CONTROL"):
                    verify(data)

    def test_stale_event_cannot_write_even_if_label_says_rejected(self):
        data = receipt_fixture()
        data["events"][3]["after_sha256"] = sha("unexpected state")
        with self.assertRaisesRegex(Hold, "STALE_OR_REPLAY_APPLIED"):
            verify(data)

    def test_provider_input_or_old_cause_cannot_change_in_new_scope(self):
        for field, value in (("context_sha256", sha("stale payload")), ("cause_event", "failure-3")):
            with self.subTest(field=field):
                data = receipt_fixture()
                data["handoffs"][3][field] = value
                with self.assertRaisesRegex(Hold, "NEW_SCOPE_DRIFT"):
                    verify(data)

    def test_model_call_id_cannot_be_reused_across_handoffs(self):
        data = receipt_fixture()
        data["handoffs"][3]["model_call_id"] = data["handoffs"][2]["model_call_id"]
        with self.assertRaisesRegex(Hold, "HANDOFF_ID_REUSED"):
            verify(data)

    def test_cli_rejects_duplicate_json_fields_without_echo(self):
        with tempfile.TemporaryDirectory() as directory:
            receipt = Path(directory) / "receipt.json"
            receipt.write_text('{"scope":"private-synthetic-content","scope":"second"}', encoding="utf-8")
            script = Path(__file__).with_name("affect_transition.py")
            result = subprocess.run([sys.executable, str(script), str(receipt)],
                                    capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(result.stderr, "")
            self.assertEqual(json.loads(result.stdout), {
                "state": "HOLD", "reason": "DUPLICATE_JSON_FIELD", "live_acceptance": False})


if __name__ == "__main__":
    unittest.main()
