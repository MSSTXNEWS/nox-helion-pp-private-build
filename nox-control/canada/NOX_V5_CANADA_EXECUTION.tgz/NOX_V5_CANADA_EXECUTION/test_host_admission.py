import copy
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from host_admission import evaluate
from model_plan import MODEL_BYTES


GB = 10**9
INSTANCE = 61825960


def fixture():
    return {
        'schema': 'nox_server_probe_v1', 'status': 'OBSERVED', 'read_only': True,
        'identity': {'instance_id': INSTANCE},
        'host_memory': {'available_bytes': 600 * GB},
        'cgroup': {'status': 'OK', 'ancestors_visibility': 'VISIBLE_NAMESPACE', 'ancestors': [
            {'current_bytes': 50 * GB, 'limit_kind': 'finite', 'limit_bytes': 762 * GB,
             'high_kind': 'finite', 'high_bytes': 750 * GB},
            {'current_bytes': 100 * GB, 'limit_kind': 'finite', 'limit_bytes': 900 * GB,
             'high_kind': 'finite', 'high_bytes': 890 * GB},
        ]},
        'filesystems': [
            {'path': '/dev/shm', 'filesystem': 'tmpfs', 'status': 'OK',
             'available_bytes': 500 * GB, 'read_only_mount': False},
            {'path': '/data', 'filesystem': 'ext4', 'status': 'OK',
             'available_bytes': 122 * GB, 'read_only_mount': False},
        ],
        'gpu': {'status': 'OK', 'devices': [
            {'index': 0, 'name': 'RTX 5060 Ti', 'compute_capability': '12.0',
             'total_mib': 16384, 'free_mib': 14000},
        ]},
    }


class HostAdmissionTests(unittest.TestCase):
    def evaluate(self, report, destination='/dev/shm', payload=MODEL_BYTES, **requirements):
        return evaluate(report, destination=destination, required_payload_bytes=payload,
                        filesystem_reserve_bytes=2 * GB, memory_reserve_bytes=16 * GB,
                        expected_instance=INSTANCE, **requirements)

    def test_tmpfs_full_fit_and_local_disk_different_ram_charge(self):
        receipt = self.evaluate(fixture())
        self.assertEqual(receipt['state'], 'STAGING_CAPACITY_CONFIRMED')
        self.assertEqual(receipt['memory']['required_additional_bytes'], MODEL_BYTES + 16 * GB)
        self.assertEqual(receipt['gpu']['maximum_per_device_free_mib'], 14000)
        disk = self.evaluate(fixture(), '/data')
        self.assertEqual(disk['reasons'], ['DESTINATION_CAPACITY'])
        self.assertEqual(disk['memory']['required_additional_bytes'], 16 * GB)

    def test_larger_parent_with_heavier_usage_can_bind(self):
        report = fixture()
        report['cgroup']['ancestors'][1]['current_bytes'] = 425 * GB
        receipt = self.evaluate(report)
        self.assertEqual(receipt['memory']['cgroup_hard_headroom_bytes'], 475 * GB)
        self.assertEqual(receipt['memory']['cgroup_high_headroom_bytes'], 465 * GB)
        self.assertEqual(receipt['reasons'], ['CGROUP_HARD_HEADROOM', 'CGROUP_HIGH_HEADROOM'])

    def test_high_unknown_or_throttling_holds(self):
        report = fixture()
        report['cgroup']['ancestors'][0]['high_bytes'] = 520 * GB
        self.assertEqual(self.evaluate(report)['reasons'], ['CGROUP_HIGH_HEADROOM'])
        report['cgroup']['ancestors'][0]['high_kind'] = 'unknown'
        self.assertEqual(self.evaluate(report)['reasons'], ['CGROUP_HIGH_HEADROOM_UNKNOWN'])
        report['cgroup']['ancestors'][0].update(high_bytes=None, high_kind='unlimited')
        self.assertEqual(self.evaluate(report)['reasons'], [])

    def test_resume_and_provider_hidden_ancestor(self):
        report = fixture()
        report['filesystems'][0]['available_bytes'] = 11 * GB
        report['cgroup']['ancestors_visibility'] = 'VISIBLE_MOUNT_SUBTREE'
        self.assertEqual(self.evaluate(report, payload=8 * GB)['reasons'], ['CGROUP_ANCESTORS_UNVERIFIED'])
        resumed = self.evaluate(report, payload=8 * GB, provider_headroom_bytes=25 * GB)
        self.assertEqual(resumed['state'], 'STAGING_CAPACITY_CONFIRMED')
        self.assertEqual(resumed['memory']['required_additional_bytes'], 24 * GB)
        self.assertEqual(resumed['destination']['required_bytes'], 10 * GB)

    def test_host_and_gpu_are_independent_observations(self):
        report = fixture()
        report['host_memory']['available_bytes'] = 12 * GB
        self.assertEqual(self.evaluate(report, '/data', 1 * GB, minimum_gpu_free_mib=15000)['reasons'],
                         ['HOST_AVAILABLE', 'GPU_FREE_UNOBSERVED_OR_INSUFFICIENT'])
        report['gpu'] = {'status': 'GPU_QUERY_FAILED', 'devices': []}
        self.assertEqual(self.evaluate(report, '/data', 1 * GB)['reasons'], ['HOST_AVAILABLE'])

    def test_cli_consumes_schema_and_observed_destination(self):
        with TemporaryDirectory() as root:
            path = Path(root) / 'report.json'
            path.write_text(json.dumps(copy.deepcopy(fixture())))
            result = subprocess.run([
                sys.executable, str(Path(__file__).with_name('host_admission.py')), str(path),
                '--destination', '/dev/shm', '--expected-instance', str(INSTANCE),
                '--filesystem-reserve-bytes', str(2 * GB), '--memory-reserve-bytes', str(16 * GB),
            ], capture_output=True, text=True, check=True)
            self.assertEqual(json.loads(result.stdout)['state'], 'STAGING_CAPACITY_CONFIRMED')


if __name__ == '__main__':
    unittest.main()
