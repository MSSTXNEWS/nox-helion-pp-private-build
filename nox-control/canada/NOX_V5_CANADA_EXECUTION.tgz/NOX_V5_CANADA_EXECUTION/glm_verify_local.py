"""Run the complete local v5 test suite in one report."""
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent

if __name__ == "__main__":
    directories = (ROOT, ROOT / "relay", ROOT / "glm20")
    sys.path.extend(str(path) for path in directories[1:])
    suite = unittest.TestSuite(
        unittest.TestLoader().discover(str(path)) for path in directories
    )
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
