from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import server_probe as probe


class ServerProbeTests(unittest.TestCase):
    def make_cgroup(self, root, *, parent_present=True, parent_high='305'):
        proc = root / 'proc'
        (proc / 'self').mkdir(parents=True)
        (proc / 'self/cgroup').write_text('0::/container/service\n')
        mount = root / 'cg'
        leaf = mount / 'service'
        leaf.mkdir(parents=True)
        (proc / 'self/mountinfo').write_text(f'3 1 0:24 /container {mount} rw - cgroup2 cgroup rw\n')
        for path, name, value in (
            (leaf, 'memory.current', '90'), (leaf, 'memory.max', '200'),
            (leaf, 'memory.high', '180'),
            (leaf, 'cpu.max', '200000 100000'), (leaf, 'cpuset.cpus.effective', '0-1'),
            (leaf, 'memory.stat', 'anon 35\nshmem 4\nfile 22'),
            (mount, 'memory.current', '300'), (mount, 'cpu.max', '100000 100000'),
        ):
            (path / name).write_text(value)
        if parent_present:
            (mount / 'memory.max').write_text('320')
        if parent_high is not None:
            (mount / 'memory.high').write_text(parent_high)
        return proc

    def test_ancestor_headroom_and_cpu_quota_are_binding(self):
        with TemporaryDirectory() as directory:
            result = probe.cgroup_probe(self.make_cgroup(Path(directory)))
        self.assertEqual(result['status'], 'OK')
        self.assertEqual(result['effective_memory_limit_bytes'], 200)
        self.assertEqual(result['effective_memory_headroom_bytes'], 20)
        self.assertEqual(result['effective_memory_high_headroom_bytes'], 5)
        self.assertEqual(result['ancestors'][0]['high_headroom_bytes'], 90)
        self.assertEqual(result['cpu_quota_cores'], 1)
        self.assertEqual(result['cpuset'], '0-1')
        self.assertEqual(result['ancestors'][0]['memory_stat_bytes']['shmem'], 4)
        self.assertEqual(result['ancestors_visibility'], 'VISIBLE_MOUNT_SUBTREE')

    def test_missing_ancestor_limit_does_not_certify_effective_headroom(self):
        with TemporaryDirectory() as directory:
            result = probe.cgroup_probe(self.make_cgroup(Path(directory), parent_present=False))
        self.assertEqual(result['status'], 'PARTIAL')
        self.assertEqual(result['visible_memory_headroom_bytes'], 110)
        self.assertIsNone(result['effective_memory_headroom_bytes'])
        self.assertIsNone(result['effective_memory_limit_bytes'])

    def test_unknown_high_is_distinct_from_unlimited_and_hard_limit(self):
        with TemporaryDirectory() as directory:
            unknown = probe.cgroup_probe(self.make_cgroup(Path(directory), parent_high=None))
        with TemporaryDirectory() as directory:
            unlimited = probe.cgroup_probe(self.make_cgroup(Path(directory), parent_high='max'))
        self.assertEqual(unknown['effective_memory_headroom_bytes'], 20)
        self.assertEqual(unknown['memory_high_status'], 'PARTIAL')
        self.assertIsNone(unknown['effective_memory_high_headroom_bytes'])
        self.assertEqual(unknown['visible_memory_high_headroom_bytes'], 90)
        self.assertEqual(unlimited['memory_high_status'], 'OK')
        self.assertEqual(unlimited['effective_memory_high_headroom_bytes'], 90)

    def test_expected_instance_mismatch_stops_further_checks(self):
        output = io.StringIO()
        with patch.dict(probe.os.environ, {'VAST_CONTAINERLABEL': 'C.60509551'}, clear=True), \
                patch.object(probe, 'mounts') as read_mounts, redirect_stdout(output):
            self.assertEqual(probe.main(['--expected-instance', '61825960']), 2)
        read_mounts.assert_not_called()
        self.assertEqual(json.loads(output.getvalue())['status'], 'HOLD_INSTANCE')

    def test_only_exact_llama_sha_can_run_help(self):
        with TemporaryDirectory() as directory:
            binary = Path(directory) / 'llama-server'
            data = b'fixture'
            binary.write_bytes(data)
            with patch.object(probe, 'capture') as capture:
                self.assertEqual(probe.llama_probe(binary, None)['status'], 'HASH_ONLY')
                self.assertEqual(probe.llama_probe(binary, '0' * 64)['status'], 'SHA256_MISMATCH')
                capture.assert_not_called()
                capture.return_value = subprocess.CompletedProcess([], 0, '--flash-attn --cache-reuse-extra')
                result = probe.llama_probe(binary, hashlib.sha256(data).hexdigest())
        self.assertEqual(result['status'], 'OK')
        self.assertTrue(result['capabilities']['--flash-attn'])
        self.assertFalse(result['capabilities']['--cache-reuse'])
        self.assertEqual(capture.call_args.args[0][1:], ['--help'])

    def test_gpu_csv_keep_units_and_compute_capability(self):
        response = subprocess.CompletedProcess([], 0, '0, Tesla V100, 580.6, 32768, 16000, 16500, 0000:00:01.0, 7.0\n')
        with patch.object(probe.shutil, 'which', return_value='/usr/bin/nvidia-smi'), \
                patch.object(probe, 'capture', return_value=response):
            result = probe.gpu_probe()
        self.assertEqual(result['status'], 'OK')
        self.assertEqual(result['devices'][0]['free_mib'], 16500)
        self.assertEqual(result['devices'][0]['compute_capability'], '7.0')

    def test_health_only_requests_loopback_and_does_not_follow_redirect(self):
        with patch.object(probe.http.client, 'HTTPConnection') as connect:
            connection = connect.return_value
            connection.getresponse.return_value.__enter__.return_value.status = 302
            result = probe.health_probe(8098)
        connect.assert_called_once_with('127.0.0.1', 8098, timeout=2)
        connection.request.assert_called_once_with('GET', '/health')
        self.assertEqual(result, {'port': 8098, 'http_status': 302, 'ok': False})


if __name__ == '__main__':
    unittest.main()
