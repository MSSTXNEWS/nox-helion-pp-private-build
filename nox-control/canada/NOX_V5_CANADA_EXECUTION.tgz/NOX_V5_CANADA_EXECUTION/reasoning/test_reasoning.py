import unittest

from reasoning.nox_reasoning import (
    Evidence, ReasoningStopped, build_chat_request, exact_arithmetic,
    majority_answer, reasoned_answer, select_mode,
)


def completion(text):
    return {"choices": [{"message": {"role": "assistant", "content": text}}]}


class ReasoningTest(unittest.TestCase):
    payload = {"model": "local-glm", "messages": [{"role": "user", "content": "Каков результат?"}]}

    def test_mode_defaults_preserve_payload_and_stream(self):
        original = self.payload | {"stream": True, "max_completion_tokens": 12, "reasoning_effort": "max"}
        request = build_chat_request(original, mode="fast")
        self.assertTrue(request["stream"])
        self.assertTrue(request["chat_template_kwargs"]["clear_thinking"])
        self.assertEqual(request["reasoning_effort"], "max")
        self.assertNotIn("max_tokens", request)
        self.assertNotIn("chat_template_kwargs", original)
        self.assertEqual(select_mode(evidence_required=True, complex_task=True), "verify")
        self.assertEqual(build_chat_request(self.payload, mode="deep")["reasoning_effort"], "max")

    def test_grounding_is_independent_and_preserves_native_envelope(self):
        calls = []

        def model(request):
            calls.append(request)
            if len(calls) == 1:
                return completion("черновик")
            return completion('{"supported": true, "answer": "Результат 9 [S1]."}') | {"model": "local-glm"}

        result = reasoned_answer(self.payload, model, mode="verify", evidence=[Evidence("S1", "Вывод равен 9")])
        self.assertEqual(result.verification, "source_ids_checked")
        self.assertEqual(result.citations, ("S1",))
        self.assertEqual(result.calls, 2)
        self.assertEqual(result.response["model"], "local-glm")
        self.assertEqual(result.response["choices"][0]["message"]["content"], "Результат 9 [S1].")
        self.assertNotIn("черновик", str(calls[1]["messages"]))

    def test_missing_and_fabricated_sources(self):
        answers = iter([completion("черновик"), completion('{"supported": true, "answer": "ошибка [S9]"}')])
        result = reasoned_answer(self.payload, lambda _: next(answers), mode="verify", evidence=[Evidence("S1", "источник")])
        self.assertEqual(result.verification, "unconfirmed")
        result = reasoned_answer(self.payload, lambda _: completion("черновик"), mode="verify")
        self.assertEqual(result.calls, 1)
        self.assertEqual(result.verification, "no_evidence")

    def test_stop_prevents_followup(self):
        signals = iter([False, True])
        calls = []

        def model(request):
            calls.append(request)
            return completion("черновик")

        with self.assertRaises(ReasoningStopped):
            reasoned_answer(self.payload, model, mode="verify", evidence=[Evidence("S1", "источник")], stopped=lambda: next(signals))
        self.assertEqual(len(calls), 1)

    def test_closed_form_vote_and_arithmetic(self):
        self.assertEqual(majority_answer(["A", " a", "B"]), "a")
        self.assertIsNone(majority_answer(["A", "B", "C"]))
        self.assertEqual(str(exact_arithmetic("(2 + 5) / -3")), "-7/3")
        with self.assertRaises(ValueError):
            exact_arithmetic("int(1)")


if __name__ == "__main__":
    unittest.main()
