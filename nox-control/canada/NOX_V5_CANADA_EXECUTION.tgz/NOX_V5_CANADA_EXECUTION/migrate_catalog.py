"""Produce a reversible S1/S2 candidate mapping without enabling historical cards."""

import argparse
import csv
import json
import re
from collections import Counter
from pathlib import Path


RULES = [
    ("REVIEW_HARDWARE", r"\b(?:V100|A40|RTX\s*\d+|A100|H100|CUDA|BF16|FP16|NVFP4|AMX|Volta|Blackwell|NUMA|NVLink|vram|cgroup|GPU|PCIe|SAFE70)\b|памят[ьи].?(?:gpu|видеокарт)|аппаратн\w*\s+паспорт"),
    ("WINDOWS_PC", r"\b(?:Windows|Win32|WPF|WebView2|NSIS|WiX|Ollama\s+local|AutoHotkey)\b|\.exe\b|\bc:\\|установщик|деинсталл|системн\w*\s+тре[йя]|локальн\w*\s+пк|управлени\w*\s+компьютер"),
    ("S2_GPU_STAGING", r"\b(?:LoRA|QLoRA|DPO|ComfyUI|SFT)\b|дистилляц|дообуч|датасет|чекпоинт|optimizer|обучени\w*\s+(?:вес|суд|модел|самого\s+NOX)|генераци\w*\s+(?:видео|музык|фото|аудио|изображен)"),
    ("S1_CANDIDATE", r"\b(?:llama-server|glm[ -]?5(?:\.3)?|memfd|gguf|inference|prefill|decode|TTFT)\b|маршрутиз\w+\s+(?:запрос|чат)|загру\w+\s+(?:вес|модел)|инференс|\bчат\b.{0,25}\bruntime\b"),
    ("SHARED_MEMORY_CONTROL", r"\b(?:S03|sqlite|fts5|ACL|STOP|PersonaID|RAG|retention|restore|backup|RBAC|health)\b|согласи[еяю]|бэкап|отзыв\s+прав|авторизац|фактическ\w*\s+состояни|резервн\w*\s+копи|память|баз\w*\s+знани|разграничен\w*\s+доступ|каноническ\w*\s+хранилищ"),
    ("PORTABLE_WEB", r"\b(?:SSE|browser|CSS|HTML|PWA|DOM|WebSocket|SPA|dock|WEB)\b|браузер|мини.?чат|палитр|мессенджер|виджет|размер\w*\s+экран|интерфейс|субтитр|анимац|резонанс|экран|тем\w*\s+оформлен"),
    ("REVIEW_EXTERNAL_SCOPE", r"платеж|монетизац|покуп\w+|публикац|внешн\w*\s+отправ|распознава\w*\s+лиц|биометри|подписк|oauth|\b(?:PSTN|SIP|телефонный оператор)\b"),
    ("PORTABLE_CHAT_SOUL", r"личност|персонаж|эмоци|самоосознан|самописан|сознани|биографи|\b(?:soul|persona|reflection|affect|PAD|OCC)\b|мыслительн|рассужден|самоулучш|восьм\w*\s+(?:яд|подъяд)|\beight\s+cores\b"),
    ("PORTABLE_TOOLS_MEDIA", r"\b(?:TTS|ASR|STT|OCR|API)\b|перевод|голос|аудио|звучан|громкост|слайд|метаданн|поисков|инструмент|распознав|изображен|медиа|виде[оó]|документ|таблиц"),
    ("CLIENT_DEVICE_REVIEW", r"\b(?:VUNEO|SMART|DLNA|HDMI|Bluetooth|AirPlay|Chromecast|PSTN|IoT|GPIO|ADB)\b|ноутбук|телевизор|проектор|ресивер|автозагрузк|устройств|датчик|локальн\w*\s+оператор|реестр\s+драйвер"),
    ("PORTABLE_RUNTIME", r"поручени|очеред|повторн\w*\s+(?:отправ|генераци)|обрыв\w*\s+генераци|оборванн\w*\s+генераци|запрос|ответ|сценар|разрешени|уведомлен|прав\w*\s+доступ|состояни\w*\s+задач|зависимост\w*\s+между"),
    ("PORTABLE_VISUAL", r"сцен\w*\s+(?:[визуал]|аним)|клик|персонаж|рисов|рендер|обложк|портрет|освещен|цветов\w+|графич|инфографик|визуал|композиц|оформлени|шрифт|пиксел"),
    ("DEFER_DOMAIN_CONTENT", r"\b(?:curriculum|literacy|russian|biology|mathematics|economic|physics|history)\b|учебн\w*\s+(?:план|курс)|предметн\w*\s+знани|обучение\s+пользовател"),
    ("SHARED_QUALITY_RELEASE", r"\b(?:qa|reliability|release|diagnostics|observability)\b|интеграци\w+\s+и\s+при[её]мк|версионир|совместимост|откат|(?:проверка|контроль)\s+качеств|\bgap_analysis\b|повторн\w*\s+провер"),
]
HINT_LANES = {
    "Интеграция и приёмка": "SHARED_QUALITY_RELEASE",
    "Память и знания": "SHARED_MEMORY_CONTROL",
    "Большой архив Drive": "SHARED_MEMORY_CONTROL",
    "Обучение и веса": "S2_GPU_STAGING",
    "Обучение самого NOX": "S2_GPU_STAGING",
    "Живой диалог и Резонанс": "PORTABLE_WEB",
    "Эмоциональное понимание": "PORTABLE_CHAT_SOUL",
    "Личность и персонализация": "PORTABLE_CHAT_SOUL",
    "Проверка фактов и качества": "SHARED_QUALITY_RELEASE",
    "Самостоятельная работа": "SHARED_QUALITY_RELEASE",
    "Планирование и выполнение задач": "SHARED_QUALITY_RELEASE",
    "Личные проекты, дела и обязательства": "SHARED_MEMORY_CONTROL",
    "CORE_QA_AND_RELIABILITY": "SHARED_QUALITY_RELEASE",
    "docs/HELION_RELEASE_BLOCKERS_32.csv": "SHARED_QUALITY_RELEASE",
    "docs/HELION_C20_EVOLUTION_76_TASKS.csv": "DEFER_DOMAIN_CONTENT",
}
GUIDANCE = {
    "REVIEW_HARDWARE": "Separate source-host figures from current truth. Probe actual SM, driver, PCIe, RAM, VRAM and mounts. Rebuild same-model one-knob A/B.",
    "WINDOWS_PC": "Keep for the authorized owner Windows path, separate acceptance. No S1 activation.",
    "S2_GPU_STAGING": "Candidate on S2 with exact dependency support and pause/resume proof.",
    "S1_CANDIDATE": "Rebind to verified S1 paths, GLM manifest/A-B and truthful model label. Compare a pinned GLM baseline and candidate in the S1 staging window.",
    "SHARED_MEMORY_CONTROL": "Reuse through existing gateway/writer/STOP with independently verified scope, authority and rollback.",
    "PORTABLE_WEB": "Reuse the browser UI against the one authorized route. Validate live stream, reload, permissions and STOP independently.",
    "PORTABLE_CHAT_SOUL": "Verify the same synthetic scenario through the pinned GLM baseline and S1 candidate. Require persona and source consistency after reload; preserve trust boundaries.",
    "PORTABLE_TOOLS_MEDIA": "Review the actual client/server integration, local support and runtime resource budget. Exercise the adapter with scoped synthetic input before assignment.",
    "CLIENT_DEVICE_REVIEW": "Keep the owner endpoint and its device permissions separate from S1. Review the current device map and approved command set, then rerun the client check.",
    "PORTABLE_RUNTIME": "Rebind through the current dispatcher and conversation routing. Require real scoped terminal evidence, idempotent submit/reconnect and exact cancellation where relevant.",
    "PORTABLE_VISUAL": "Verify the current Resonance Web and device scope. Reuse licensed assets and verify layout and motion without changing the active chat route.",
    "DEFER_DOMAIN_CONTENT": "Review after core chat acceptance. Keep the original ID and reuse material only after source, relevance and quality review.",
    "SHARED_QUALITY_RELEASE": "Attach the original evidence, identify a named target and rerun acceptance on its exact build. Recheck recovery or rollback where applicable.",
    "REVIEW_EXTERNAL_SCOPE": "Clarify ownership, rights, provider and specific authority before any side effect.",
    "CROSS_SCOPE_REVIEW": "Sources invoke several targets. Split evidence per target; retain this original ID and its legacy status.",
    "UNMAPPED_REVIEW": "Retain historical scope and provenance. Review contract and related v5 IDs manually before creating any runnable task.",
}


def classify(title, hints):
    explicit = [lane for lane, pattern in RULES if re.search(pattern, title, re.IGNORECASE)]
    categories = [HINT_LANES[hint] for hint in hints if hint in HINT_LANES]
    detailed = [lane for lane, pattern in RULES if any(re.search(pattern, hint, re.IGNORECASE) for hint in hints)]
    lanes = explicit or categories or detailed
    if "REVIEW_EXTERNAL_SCOPE" in lanes:
        primary = "REVIEW_EXTERNAL_SCOPE"
    elif "WINDOWS_PC" in lanes:
        primary = "WINDOWS_PC"
    elif "CLIENT_DEVICE_REVIEW" in lanes:
        primary = "CLIENT_DEVICE_REVIEW"
    elif "REVIEW_HARDWARE" in lanes:
        primary = "REVIEW_HARDWARE"
    elif "PORTABLE_RUNTIME" in lanes and len(lanes) == 2:
        primary = next(lane for lane in lanes if lane != "PORTABLE_RUNTIME")
    elif len(lanes) > 1:
        primary = "CROSS_SCOPE_REVIEW"
    else:
        primary = lanes[0] if lanes else "UNMAPPED_REVIEW"
    return primary, lanes


def make_register(rows, id_key, title_key, status_key, hint_keys, detail_keys=()):
    result = []
    seen = set()
    for source in rows:
        source_id = (source.get(id_key) or "").strip()
        title = (source.get(title_key) or "").strip()
        if not source_id or not title or source_id in seen:
            raise ValueError("blank title or duplicate/missing source ID")
        seen.add(source_id)
        hints = [source.get(key) or "" for key in hint_keys]
        primary, lanes = classify(title, hints)
        result.append({
            "source_id": source_id, "source_title": title,
            "historical_status": source.get(status_key), "review_lanes": lanes,
            "proposed_scope": primary, "adaptation": GUIDANCE[primary],
            "source_metadata": {key: source.get(key) for key in detail_keys},
            "binding_verified": False, "native_execution_enabled": False,
        })
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--id", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--status", required=True)
    parser.add_argument("--hint", action="append", default=[])
    parser.add_argument("--detail", action="append", default=[])
    args = parser.parse_args()
    try:
        with args.csv.open(encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            if not {args.id, args.title, args.status, *args.hint, *args.detail} <= set(reader.fieldnames or ()):
                raise ValueError("selected source columns do not exist")
            register = make_register(reader, args.id, args.title, args.status, args.hint, args.detail)
        if not register:
            raise ValueError("source contains no verified named rows")
    except (OSError, ValueError, csv.Error) as exc:
        print(json.dumps({"state": "HOLD", "reason": str(exc)}))
        return 2
    print(json.dumps({"state": "ROUTING_CANDIDATE_ONLY", "native_execution_enabled": False,
                      "row_count": len(register), "distribution": dict(Counter(r["proposed_scope"] for r in register)),
                      "rows": register}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
