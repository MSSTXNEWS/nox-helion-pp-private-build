import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest

import queue_binding


def case_catalog():
    originals = [{"id": f"V14-{i:03d}", "origin": "ORIGINAL_295"} for i in range(295)]
    return {"cards": originals + [{"id": "WOW-001", "origin": "WOW_240_24_AREAS"},
                                 {"id": "I-X", "origin": "OWNER_IDEAS_89"}]}


class QueueBindingTests(unittest.TestCase):
    def test_only_original_ids_are_counted_and_parent_bindings_are_separate(self):
        direct = {"id": "V14-000", "status": "done"}
        rows = [direct, dict(direct),
                {"task_id": "leaf-1", "parent_task_id": "V14-000"},
                {"TaskID": "leaf-2", "original_task_id": "V14-001", "parent_task_id": "V14-001"},
                {"id": "WOW-001", "status": "ACCEPTED", "terminal_receipt": "claimed"},
                {"id": "I-X"},
                {"id": "proposal-leaf", "parent_task_id": "WOW-001"},
                {"id": "unbound", "title": "Like an original task"}]
        self.assertEqual(queue_binding.count_bindings({"tasks": rows}, case_catalog()), {
            "snapshot_records": 8,
            "unique_native_ids": 7,
            "identical_duplicate_rows": 1,
            "original295_catalog_count": 295,
            "original295_ids_matched": 2,
            "original295_direct_rows": 1,
            "original295_linked_rows": 2,
            "outside_original295_rows": 4,
        })

    def test_conflicting_duplicate_is_rejected_regardless_of_order(self):
        rows = [{"id": "leaf", "original_task_id": "V14-001"},
                {"id": "leaf", "original_task_id": "V14-002"}]
        for ordering in (rows, list(reversed(rows))):
            with self.assertRaisesRegex(queue_binding.Hold, "CONFLICTING_DUPLICATE_NATIVE_ID"):
                queue_binding.count_bindings({"items": ordering}, case_catalog())

    def test_conflicting_types_and_catalog_id_collisions_are_rejected(self):
        for left, right in ((True, 1), (1, 1.0)):
            rows = [{"id": "leaf", "observed": left}, {"id": "leaf", "observed": right}]
            with self.assertRaisesRegex(queue_binding.Hold, "CONFLICTING_DUPLICATE_NATIVE_ID"):
                queue_binding.count_bindings({"items": rows}, case_catalog())
        catalog = case_catalog()
        catalog["cards"].append({"id": "V14-000", "origin": "OWNER_IDEAS_89"})
        with self.assertRaisesRegex(queue_binding.Hold, "DUPLICATE_CATALOG_ID"):
            queue_binding.count_bindings({"items": []}, catalog)

    def test_aggregate_and_combined_snapshots_are_rejected(self):
        for snapshot in ({"catalog_count": 1000}, {"items": [], "jobs": []}):
            with self.assertRaisesRegex(queue_binding.Hold, "EXPECTED_ONE_NATIVE_RECORD_ARRAY"):
                queue_binding.count_bindings(snapshot, case_catalog())

    def test_exported_original_295_rows_and_empty_snapshot(self):
        originals = [{"id": row["id"]} for row in case_catalog()["cards"] if row["origin"] == "ORIGINAL_295"]
        counts = queue_binding.count_bindings({"jobs": []}, {"original_295_rows": originals})
        self.assertEqual(counts["original295_ids_matched"], 0)
        self.assertEqual(counts["original295_catalog_count"], 295)

    def test_incomplete_catalog_and_conflicting_native_aliases_are_rejected(self):
        incomplete = {"cards": case_catalog()["cards"][1:]}
        with self.assertRaisesRegex(queue_binding.Hold, "ORIGINAL295_CARDINALITY_OR_DUPLICATE"):
            queue_binding.count_bindings({"items": []}, incomplete)
        with self.assertRaisesRegex(queue_binding.Hold, "CONFLICTING_NATIVE_ID_ALIASES"):
            queue_binding.count_bindings({"items": [{"TaskID": "different", "task_id": "V14-000"}]}, case_catalog())
        with self.assertRaisesRegex(queue_binding.Hold, "CONFLICTING_DIRECT_ORIGINAL_BINDING"):
            direct = {"id": "V14-000", "original_task_id": "V14-001"}
            queue_binding.count_bindings({"items": [direct]}, case_catalog())
        with self.assertRaisesRegex(queue_binding.Hold, "CONFLICTING_DECLARED_PARENT_IDS"):
            linked = {"id": "leaf", "original_task_id": "V14-000", "parent_task_id": "V14-001"}
            queue_binding.count_bindings({"items": [linked]}, case_catalog())

    def test_cli_pins_bytes_and_never_exports_receipt_claims(self):
        with tempfile.TemporaryDirectory() as folder:
            catalog, snapshot = Path(folder) / "catalog.json", Path(folder) / "snapshot.json"
            catalog.write_text(json.dumps(case_catalog()), encoding="utf-8")
            snapshot.write_text(json.dumps({"jobs": [{"id": "V14-000", "status": "ACCEPTED",
                                                     "terminal_receipt": "secret-like-value"}]}), encoding="utf-8")
            args = [str(snapshot), "--catalog", str(catalog), "--snapshot-sha256"]
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                status = queue_binding.main(args + [hashlib.sha256(snapshot.read_bytes()).hexdigest()])
            report = json.loads(output.getvalue())
            self.assertEqual(status, 0)
            self.assertEqual(report["state"], "BINDINGS_COUNTED")
            self.assertFalse(report["acceptance_verified"])
            self.assertFalse(report["native_execution_enabled"])
            self.assertNotIn("secret-like-value", output.getvalue())
            self.assertNotIn("V14-000", output.getvalue())
            with contextlib.redirect_stdout(io.StringIO()) as error:
                self.assertEqual(queue_binding.main(args + ["a" * 64]), 2)
            self.assertEqual(json.loads(error.getvalue())["reason"], "INPUT_SHA256_MISMATCH")

    def test_duplicate_json_key_rejected_before_binding(self):
        with tempfile.TemporaryDirectory() as folder:
            snapshot = Path(folder) / "snapshot.json"
            snapshot.write_text('{"items": [{"id": "one", "id": "two"}]}', encoding="utf-8")
            with self.assertRaisesRegex(queue_binding.Hold, "DUPLICATE_JSON_KEY"):
                queue_binding.read_json(snapshot, None)
            snapshot.write_text('{"items": [{"id": "one", "value": NaN}]}', encoding="utf-8")
            with self.assertRaisesRegex(queue_binding.Hold, "INVALID_JSON_NUMBER"):
                queue_binding.read_json(snapshot, None)


if __name__ == "__main__":
    unittest.main()
