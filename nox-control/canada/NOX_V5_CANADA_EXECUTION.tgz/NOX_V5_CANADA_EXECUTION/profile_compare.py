"""Compare paired chat experiments from one isolated replica at a time, without making changes."""

import argparse
import json
import math
from pathlib import Path
import statistics
import sys

from chat_bench import SHA256, distribution


def digest(value):
    return isinstance(value, str) and SHA256.fullmatch(value) is not None


def valid_trace(row, field):
    value = row[field]
    return type(value) in (float, int) and math.isfinite(value) and value > 0


def paired_comparison(trial):
    instance = trial["instance"]
    if type(instance) is not int or instance not in (60509551, 61825960):
        raise ValueError("TARGET_INSTANCE")
    primary = trial["primary"]
    if primary not in ("visible_ttft", "decode", "ram"):
        raise ValueError("UNKNOWN_PRIMARY")
    if any(not digest(trial[field]) for field in (
        "fixture_sha256", "workload_sha256", "engine_sha256", "context_contract_sha256",
        "model_manifest_sha256", "stop_receipt_sha256", "budget_receipt_sha256",
    )):
        raise ValueError("MISSING_EXPERIMENT_PIN")
    baseline, candidate = trial["baseline"], trial["candidate"]
    if any(not digest(x["config_sha256"]) for x in (baseline, candidate)):
        raise ValueError("CONFIG_PIN")
    first, second = baseline["settings"], candidate["settings"]
    knob = trial["knob"]
    if (not isinstance(first, dict) or not isinstance(second, dict) or first.keys() != second.keys()
            or knob not in first or {k for k in first if first[k] != second[k]} != {knob}
            or knob in ("model", "model_sha256", "weights", "context", "context_tokens", "kv_type",
                        "kv_key", "kv_value", "reasoning_effort", "chat_template")
            or baseline["config_sha256"] == candidate["config_sha256"]):
        raise ValueError("EXPECTED_ONE_PROFILE_CHANGE")

    pairs = trial["pairs"]
    if not isinstance(pairs, list) or not 20 <= len(pairs) <= 10000:
        raise ValueError("NEED_20_OR_MORE_PAIRED_EXCHANGES")
    seen, phases = set(), {"cold": [[], []], "warm": [[], []]}
    failures = set()
    for index, pair in enumerate(pairs):
        phase, case_id, repeat = pair["phase"], pair["case_sha256"], pair["repeat"]
        first_run = "baseline" if index % 2 == 0 else "candidate"
        if (phase not in phases or not digest(case_id) or type(repeat) is not int or repeat < 1
                or (phase, case_id, repeat) in seen or pair["first"] != first_run):
            raise ValueError("PAIR_ID_PHASE_OR_ORDER")
        seen.add((phase, case_id, repeat))
        for column, profile in enumerate(("baseline", "candidate")):
            sample = pair[profile]
            if not all(valid_trace(sample, field) for field in ("ttft_ms", "decode_tps", "ram_peak_bytes")):
                raise ValueError("MISSING_OBSERVATION")
            if not digest(sample["runtime_receipt_sha256"]):
                raise ValueError("MISSING_SAMPLE_RUNTIME_PIN")
            if any(sample[k] is not True for k in ("quality_pass", "stayed_in_budget", "terminal_done")):
                failures.add("QUALITY_TERMINAL_OR_BUDGET")
            phases[phase][column].append(sample)
    if any(min(map(len, runs)) < 10 for runs in phases.values()):
        raise ValueError("NEED_10_PAIRS_COLD_AND_WARM")
    if trial["stop_verified"] is not True:
        failures.add("EXACT_STOP")
    metrics = {}
    for phase, runs in phases.items():
        before, after = summaries = [{
            "ttft": distribution(row["ttft_ms"] for row in rows),
            "decode_tps_p50": statistics.median(row["decode_tps"] for row in rows),
            "ram_peak_bytes": max(row["ram_peak_bytes"] for row in rows),
        } for rows in runs]
        gain = {
            "visible_ttft": 1 - after["ttft"]["p95_ms"] / before["ttft"]["p95_ms"],
            "decode": after["decode_tps_p50"] / before["decode_tps_p50"] - 1,
            "ram": 1 - after["ram_peak_bytes"] / before["ram_peak_bytes"],
        }
        if gain[primary] < 0.05 or any(value < -0.05 for item, value in gain.items() if item != primary):
            failures.add("INSUFFICIENT_GAIN_OR_COLLATERAL_REGRESSION")
        metrics[phase] = {"baseline": summaries[0], "candidate": summaries[1], "fractional_gain": gain}

    return {
        "schema": "nox_profile_comparison_v1",
        "state": "KEEP_BASELINE" if failures else "READY_FOR_OWNER_REVIEW",
        "reasons": sorted(failures), "instance": instance, "pairs": len(pairs),
        "primary": primary, "knob": knob, "metrics": metrics,
        "fixture_sha256": trial["fixture_sha256"], "workload_sha256": trial["workload_sha256"],
        "baseline_config_sha256": baseline["config_sha256"], "candidate_config_sha256": candidate["config_sha256"],
        "origin_authenticated": False, "production_modified": False,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trial", type=Path)
    args = parser.parse_args(argv)
    try:
        with args.trial.open("rb") as stream:
            raw = stream.read(16 * 1024**2 + 1)
        if len(raw) > 16 * 1024**2:
            raise ValueError("INPUT_LIMIT")
        result = paired_comparison(json.loads(raw))
    except (OSError, ValueError, TypeError, KeyError, RecursionError):
        result = {"state": "HOLD", "reason": "INVALID_OR_INCOMPLETE_PAIRED_EVIDENCE", "production_modified": False}
    print(json.dumps(result, sort_keys=True, allow_nan=False))
    return 2 if result["state"] == "HOLD" else 0


if __name__ == "__main__":
    sys.exit(main())
