"""Scoped, time-aware retrieval for approved NOX records."""

from __future__ import annotations

import json
import os
import re
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
from typing import Sequence


_SCHEMA = """
CREATE TABLE IF NOT EXISTS memory_records (
    id INTEGER PRIMARY KEY,
    scope TEXT NOT NULL,
    fact_key TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    context TEXT NOT NULL,
    source TEXT NOT NULL,
    importance REAL NOT NULL CHECK (importance >= 0 AND importance <= 1),
    valid_from INTEGER NOT NULL,
    valid_to INTEGER CHECK (valid_to IS NULL OR valid_to > valid_from),
    revoked INTEGER NOT NULL DEFAULT 0 CHECK (revoked IN (0, 1))
);
CREATE UNIQUE INDEX IF NOT EXISTS memory_revision
ON memory_records(scope, fact_key, valid_from) WHERE revoked = 0;
CREATE UNIQUE INDEX IF NOT EXISTS memory_current
ON memory_records(scope, fact_key) WHERE valid_to IS NULL AND revoked = 0;
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    title, body, context, content='memory_records', content_rowid='id',
    tokenize='unicode61 remove_diacritics 2'
);
CREATE TRIGGER IF NOT EXISTS memory_index_insert AFTER INSERT ON memory_records
WHEN new.revoked = 0 BEGIN
    INSERT INTO memory_fts(rowid, title, body, context)
    VALUES(new.id, new.title, new.body, new.context);
END;
CREATE TRIGGER IF NOT EXISTS memory_index_revoke AFTER UPDATE OF revoked ON memory_records
WHEN old.revoked = 0 AND new.revoked = 1 BEGIN
    INSERT INTO memory_fts(memory_fts, rowid, title, body, context)
    VALUES('delete', old.id, old.title, old.body, old.context);
END;
"""


@dataclass(frozen=True, slots=True)
class MemoryHit:
    id: int
    key: str
    title: str
    excerpt: str
    source: str
    valid_from: str
    valid_to: str | None
    score: float


def _timestamp(value: datetime | None) -> int:
    date = datetime.now(timezone.utc) if value is None else value
    if date.tzinfo is None or date.utcoffset() is None:
        raise ValueError("Use a timezone-aware datetime")
    elapsed = date.astimezone(timezone.utc) - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return (elapsed.days * 86_400 + elapsed.seconds) * 1_000_000 + elapsed.microseconds


def _date(timestamp: int) -> str:
    seconds, microseconds = divmod(timestamp, 1_000_000)
    return datetime.fromtimestamp(seconds, timezone.utc).replace(
        microsecond=microseconds
    ).isoformat()


def _nonempty(value: str, label: str, limit: int) -> str:
    clean = value.strip()
    if not clean or len(clean) > limit or "\x00" in clean:
        raise ValueError(f"{label} must contain 1–{limit} characters and no NUL")
    return clean


def _match_expression(query: str) -> str:
    terms = re.findall(r"[^\W_]+", query.lower()[:2_000], flags=re.UNICODE)
    return " OR ".join(f'"{term}"' for term in sorted(list(dict.fromkeys(terms))[:24]))


def _excerpt(snippet: str, body: str) -> str:
    short = " ".join(snippet.split())
    if short:
        return short[:1_400]
    return " ".join(body.split())[:1_400]


class MemoryStore:
    """Use one SQLite file per trusted owner for isolation between owners."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        if str(self.path) == ":memory:":
            raise ValueError("Use a file path so records survive separate connections")
        try:
            handle = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            pass
        else:
            os.close(handle)
        with closing(self._connect()) as connection:
            try:
                connection.executescript(_SCHEMA)
            except sqlite3.OperationalError as error:
                if "fts5" in str(error).lower():
                    raise RuntimeError("This Python SQLite build requires FTS5") from error
                raise

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=5)
        connection.row_factory = sqlite3.Row
        return connection

    def put(
        self,
        *,
        scope: str,
        key: str,
        title: str,
        text: str,
        source: str,
        consent: bool,
        context: str = "",
        importance: float = 0.5,
        effective_at: datetime | None = None,
    ) -> int:
        """Record an approved fact or close its validity interval on correction."""
        if consent is not True:
            raise PermissionError("Persistent memory requires explicit consent")
        scope = _nonempty(scope, "scope", 200)
        key = _nonempty(key, "key", 200)
        title = _nonempty(title, "title", 500)
        text = _nonempty(text, "text", 24_000)
        source = _nonempty(source, "source", 500)
        context = context.strip()
        if len(context) > 2_000 or "\x00" in context:
            raise ValueError("context must have up to 2,000 characters and no NUL")
        if not 0 <= importance <= 1:
            raise ValueError("importance must be between 0 and 1")
        values = (title, text, context, source, importance)
        with closing(self._connect()) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            valid_from = _timestamp(effective_at)
            if effective_at is not None:
                replay = connection.execute(
                    """
                    SELECT id, title, body, context, source, importance
                    FROM memory_records
                    WHERE scope = ? AND fact_key = ? AND valid_from = ? AND revoked = 0
                    """,
                    (scope, key, valid_from),
                ).fetchone()
                if replay:
                    if tuple(replay)[1:] == values:
                        return int(replay["id"])
                    raise ValueError("A different revision already has this exact effective_at")
            current = connection.execute(
                """
                SELECT id, valid_from, title, body, context, source, importance
                FROM memory_records
                WHERE scope = ? AND fact_key = ? AND valid_to IS NULL AND revoked = 0
                """,
                (scope, key),
            ).fetchone()
            if current:
                if effective_at is None and tuple(current)[2:] == values:
                    return int(current["id"])
                if valid_from <= current["valid_from"]:
                    raise ValueError("A new revision must follow the current revision")
                connection.execute(
                    "UPDATE memory_records SET valid_to = ? WHERE id = ?",
                    (valid_from, current["id"]),
                )
            cursor = connection.execute(
                """
                INSERT INTO memory_records(
                    scope, fact_key, title, body, context, source, importance, valid_from
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (scope, key, *values, valid_from),
            )
            return int(cursor.lastrowid)

    def revoke(self, *, scope: str, key: str) -> int:
        """Exclude every revision of a withdrawn fact from retrieval."""
        scope = _nonempty(scope, "scope", 200)
        key = _nonempty(key, "key", 200)
        with closing(self._connect()) as connection, connection:
            cursor = connection.execute(
                """
                UPDATE memory_records SET revoked = 1
                WHERE scope = ? AND fact_key = ? AND revoked = 0
                """,
                (scope, key),
            )
            return cursor.rowcount

    def search(
        self,
        query: str,
        *,
        scope: str,
        limit: int = 5,
        as_of: datetime | None = None,
        variants: Sequence[str] = (),
    ) -> list[MemoryHit]:
        """Retrieve matching evidence, valid at the given time, for one scope."""
        scope = _nonempty(scope, "scope", 200)
        if type(limit) is not int or not 1 <= limit <= 25:
            raise ValueError("limit must be an integer from 1 to 25")
        if isinstance(variants, str) or len(variants) > 4:
            raise ValueError("Pass up to four separate query variants")
        point = _timestamp(as_of)
        expressions = list(dict.fromkeys(map(_match_expression, (query, *variants))))
        scores: dict[int, float] = {}
        evidence: dict[int, sqlite3.Row] = {}
        with closing(self._connect()) as connection:
            # All variants share one SQLite read snapshot.
            connection.execute("BEGIN")
            for expression in filter(None, expressions):
                rows = connection.execute(
                    """
                    SELECT r.id, r.fact_key, r.title, r.body, r.source, r.importance,
                           r.valid_from, r.valid_to,
                           snippet(memory_fts, 1, '', '', ' … ', 28) AS excerpt
                    FROM memory_fts
                    JOIN memory_records AS r ON r.id = memory_fts.rowid
                    WHERE memory_fts MATCH ?
                      AND r.scope = ? AND r.revoked = 0
                      AND r.valid_from <= ? AND (r.valid_to IS NULL OR r.valid_to > ?)
                      AND memory_fts.rank MATCH 'bm25(2.0, 1.0, 1.2)'
                    ORDER BY memory_fts.rank, r.id
                    LIMIT ?
                    """,
                    (expression, scope, point, point, min(100, 5 * limit)),
                )
                for rank, row in enumerate(rows, 1):
                    record_id = row["id"]
                    scores[record_id] = scores.get(record_id, 0.0) + 1 / (60 + rank)
                    evidence.setdefault(record_id, row)

        ranked = []
        for record_id, row in evidence.items():
            age_days = (point - row["valid_from"]) / 86_400_000_000
            freshness = 2 ** (-age_days / 90)
            score = scores[record_id] * (1 + 0.12 * row["importance"] + 0.06 * freshness)
            ranked.append(
                MemoryHit(
                    id=record_id,
                    key=row["fact_key"],
                    title=row["title"],
                    excerpt=_excerpt(row["excerpt"], row["body"]),
                    source=row["source"],
                    valid_from=_date(row["valid_from"]),
                    valid_to=None if row["valid_to"] is None else _date(row["valid_to"]),
                    score=score,
                )
            )
        return sorted(ranked, key=lambda hit: (-hit.score, hit.id))[:limit]


def render_context(hits: Sequence[MemoryHit], *, max_chars: int = 3_000) -> str:
    """Convert ranked records to bounded, separately labeled evidence."""
    if max_chars < 0:
        raise ValueError("max_chars must be non-negative")
    blocks: list[str] = []
    remaining = max_chars
    for hit in hits:
        record = {
            "memory_id": hit.id,
            "title": hit.title,
            "source": hit.source,
            "valid_from": hit.valid_from,
            "valid_to": hit.valid_to,
            "excerpt": hit.excerpt,
        }
        block = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
        cost = len(block) + bool(blocks)
        if cost <= remaining:
            blocks.append(block)
            remaining -= cost
    return "\n".join(blocks)
