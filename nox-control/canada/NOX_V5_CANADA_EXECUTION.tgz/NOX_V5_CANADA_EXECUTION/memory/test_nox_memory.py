import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from memory.nox_memory import MemoryStore, render_context


class MemoryTest(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.store = MemoryStore(Path(self.directory.name) / "test.sqlite3")
        self.before = datetime(2025, 1, 1, tzinfo=timezone.utc)
        self.after = datetime(2025, 2, 1, tzinfo=timezone.utc)

    def put(self, key="color", *, scope="project", text="Кнопка синяя", **kwargs):
        return self.store.put(
            scope=scope,
            key=key,
            title=kwargs.pop("title", "Резонанс"),
            text=text,
            source="owner:decision-1",
            consent=kwargs.pop("consent", True),
            **kwargs,
        )

    def test_explicit_consent_and_scope(self):
        with self.assertRaises(PermissionError):
            self.put(consent=False)
        self.put(scope="other", text="Кнопка секретная")
        self.assertEqual(self.store.search("секретная", scope="project"), [])
        self.assertEqual(len(self.store.search("секретная", scope="other")), 1)

    def test_temporal_correction_and_replay(self):
        old = self.put(effective_at=self.before)
        new = self.put(text="Кнопка красная", effective_at=self.after)
        self.assertEqual(self.put(effective_at=self.before), old)
        self.assertNotEqual(old, new)
        old_hits = self.store.search("Кнопка", scope="project", as_of=self.before)
        new_hits = self.store.search("Кнопка", scope="project", as_of=self.after)
        self.assertIn("синяя", old_hits[0].excerpt)
        self.assertIn("красная", new_hits[0].excerpt)
        self.assertEqual(old_hits[0].valid_to, self.after.isoformat())
        self.assertEqual(self.store.search("синяя", scope="project", as_of=self.after), [])
        with self.assertRaises(ValueError):
            self.put(text="Кнопка белая", effective_at=self.before)

    def test_revoke_excludes_previous_intervals_and_permits_new_consent(self):
        self.put(effective_at=self.before)
        self.put(text="Кнопка красная", effective_at=self.after)
        self.assertEqual(self.store.revoke(scope="project", key="color"), 2)
        self.assertEqual(self.store.revoke(scope="project", key="color"), 0)
        self.assertEqual(self.store.search("Кнопка", scope="project", as_of=self.before), [])
        self.put(text="Кнопка зелёная", effective_at=self.after)
        self.assertIn("зелёная", self.store.search("Кнопка", scope="project")[0].excerpt)

    def test_contextual_retrieval_and_query_variants(self):
        self.put(text="Mantener el contenido en la máquina.", context="almacenamiento local")
        self.put(key="other", text="Servidor alternativo", context="almacenamiento")
        results = self.store.search(
            "almacenamiento", variants=["máquina", "MÁQUINA"], scope="project"
        )
        self.assertEqual(results[0].key, "color")
        self.assertIn("máquina", results[0].excerpt)

    def test_plain_query_and_safe_render_budget(self):
        record = self.put(text="Кнопка синяя\nВторая строка", title="Название\\\"")
        self.assertEqual(self.store.search("(() [] * ^", scope="project"), [])
        hits = self.store.search('Кнопка" OR *', scope="project")
        self.assertEqual(hits[0].id, record)
        context = render_context(hits)
        self.assertEqual(json.loads(context)["title"], "Название\\\"")
        self.assertEqual(render_context(hits, max_chars=1), "")


if __name__ == "__main__":
    unittest.main()
