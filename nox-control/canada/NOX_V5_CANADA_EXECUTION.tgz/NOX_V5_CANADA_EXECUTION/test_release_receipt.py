import io
import json
import unittest
from zipfile import ZIP_DEFLATED, ZipFile

from release_receipt import make_receipt, sha256


COMMIT = "a" * 40


def archive_fixture(manifest_lines=None, extra=()):
    buffer = io.BytesIO()
    payload = b"fixture"
    if manifest_lines is None:
        manifest_lines = f"{sha256(payload)}  source.txt\n"
    with ZipFile(buffer, "w", compression=ZIP_DEFLATED) as archive:
        archive.writestr("kit/source.txt", payload)
        archive.writestr("kit/SHA256SUMS", manifest_lines)
        for name, data in extra:
            archive.writestr(name, data)
    return buffer.getvalue()


def bindings_fixture(**overrides):
    binding = {
        "schema": "NOX_NATIVE_QUEUE_BINDING_V1", "state": "BINDINGS_COUNTED",
        "snapshot_sha256": "1" * 64, "catalog_sha256": "2" * 64,
        "native_execution_enabled": False, "acceptance_verified": False,
        "snapshot_records": 3, "unique_native_ids": 2, "identical_duplicate_rows": 1,
        "original295_catalog_count": 295, "original295_ids_matched": 1,
        "original295_direct_rows": 1, "original295_linked_rows": 0, "outside_original295_rows": 1,
        "private_extra": "this field cannot appear in the detached receipt",
    }
    return json.dumps(binding | overrides).encode()


class ReceiptTests(unittest.TestCase):
    def test_archive_only_never_promotes_or_invents_tests(self):
        result = make_receipt(archive_fixture(), COMMIT)
        self.assertEqual(result["stage"], "SOURCE_ONLY")
        self.assertEqual(result["archive"]["manifest_entries"], 1)
        self.assertEqual(result["source_tests"]["status"], "NO_TEST_LOG_SUPPLIED")
        self.assertFalse(result["native_execution_enabled"])
        self.assertEqual(result["original_acceptance_added"], 0)

    def test_rejects_bad_manifest_or_unlisted_archive_member(self):
        with self.assertRaisesRegex(ValueError, "differs from manifest"):
            make_receipt(archive_fixture("0" * 64 + "  source.txt\n"), COMMIT)
        with self.assertRaisesRegex(ValueError, "do not match exactly"):
            make_receipt(archive_fixture(extra=[("kit/extra.txt", b"extra")]), COMMIT)

    def test_rejects_traversal_and_case_conflict(self):
        with self.assertRaisesRegex(ValueError, "safe unencrypted files"):
            make_receipt(archive_fixture(extra=[("kit/../escape.txt", b"extra")]), COMMIT)
        with self.assertRaisesRegex(ValueError, "case-conflicting"):
            make_receipt(archive_fixture(extra=[("kit/SOURCE.txt", b"extra")]), COMMIT)

    def test_unittest_log_is_strictly_bound_to_archive(self):
        archive = archive_fixture()
        log = b"..................\nRan 18 tests in 1.001s\n\nOK\n"
        with self.assertRaisesRegex(ValueError, "exact archive"):
            make_receipt(archive, COMMIT, test_log=log, tested_archive_sha256="0" * 64)
        with self.assertRaisesRegex(ValueError, "successful complete"):
            make_receipt(archive, COMMIT, test_log=log.replace(b"OK", b"FAILED"), tested_archive_sha256=sha256(archive))
        receipt = make_receipt(archive, COMMIT, test_log=log, tested_archive_sha256=sha256(archive))
        self.assertEqual(receipt["source_tests"]["tests_reported_passed"], 18)
        self.assertEqual(receipt["source_tests"]["log_sha256"], sha256(log))

    def test_binding_trace_requires_matching_digest_and_true_counts(self):
        binding = bindings_fixture()
        with self.assertRaisesRegex(ValueError, "SHA-256 mismatch"):
            make_receipt(archive_fixture(), COMMIT, binding_receipt=binding, binding_sha256="0" * 64)
        invalid = bindings_fixture(original295_linked_rows=3)
        with self.assertRaisesRegex(ValueError, "do not reconcile"):
            make_receipt(archive_fixture(), COMMIT, binding_receipt=invalid, binding_sha256=sha256(invalid))
        hold = bindings_fixture(state="HOLD")
        with self.assertRaisesRegex(ValueError, "not a completed source-only audit"):
            make_receipt(archive_fixture(), COMMIT, binding_receipt=hold, binding_sha256=sha256(hold))
        receipt = make_receipt(archive_fixture(), COMMIT, binding_receipt=binding, binding_sha256=sha256(binding))
        self.assertEqual(receipt["old_id_trace"]["original295_ids_matched"], 1)
        self.assertEqual(receipt["old_id_trace"]["snapshot_authority"], "NOT_ATTESTED_OFFLINE")
        self.assertNotIn("private_extra", receipt["old_id_trace"])
        self.assertEqual(receipt["original_acceptance_added"], 0)


if __name__ == "__main__":
    unittest.main()
