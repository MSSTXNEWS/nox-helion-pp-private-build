import unittest

from profile_compare import paired_comparison


def fixture():
    baseline = dict(ttft_ms=1000, decode_tps=20, ram_peak_bytes=2000, quality_pass=True,
                    stayed_in_budget=True, terminal_done=True, runtime_receipt_sha256="c" * 64)
    trial = {
        "instance": 61825960, "primary": "visible_ttft", "knob": "batch_size", "stop_verified": True,
        "baseline": {"config_sha256": "a" * 64, "settings": {"batch_size": 32, "context": 32768}},
        "candidate": {"config_sha256": "b" * 64, "settings": {"batch_size": 64, "context": 32768}},
        "pairs": [{
            "phase": "cold" if i < 10 else "warm", "case_sha256": "%064x" % i, "repeat": 1,
            "first": "baseline" if i % 2 == 0 else "candidate", "baseline": baseline.copy(),
            "candidate": dict(baseline, ttft_ms=800, runtime_receipt_sha256="d" * 64),
        } for i in range(20)],
    }
    for field in ("fixture_sha256", "workload_sha256", "engine_sha256", "context_contract_sha256",
                  "model_manifest_sha256", "stop_receipt_sha256", "budget_receipt_sha256"):
        trial[field] = "f" * 64
    return trial


class CompareTest(unittest.TestCase):
    def test_paired_gain_can_only_request_review(self):
        result = paired_comparison(fixture())
        self.assertEqual(result["state"], "READY_FOR_OWNER_REVIEW")
        self.assertFalse(result["origin_authenticated"])
        self.assertFalse(result["production_modified"])

    def test_mean_improvement_does_not_hide_bad_tail_and_memory(self):
        data = fixture()
        data["pairs"][0]["candidate"].update(ttft_ms=1500, ram_peak_bytes=3000)
        self.assertEqual(paired_comparison(data)["state"], "KEEP_BASELINE")

    def test_quality_regression_blocks_faster_profile(self):
        data = fixture()
        data["pairs"][13]["candidate"]["quality_pass"] = False
        self.assertIn("QUALITY_TERMINAL_OR_BUDGET", paired_comparison(data)["reasons"])

    def test_disallows_crossed_order_and_second_change(self):
        data = fixture()
        data["pairs"][0]["first"] = "candidate"
        with self.assertRaisesRegex(ValueError, "PAIR_ID"):
            paired_comparison(data)
        data = fixture()
        data["candidate"]["settings"]["context"] = 8192
        with self.assertRaisesRegex(ValueError, "ONE_PROFILE"):
            paired_comparison(data)
