#!/usr/bin/env python3
"""Create and verify a standalone, owner-private SQLite snapshot on POSIX."""

import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import tempfile
import time


SQLITE_HEADER = b"SQLite format 3\0"
SIDECARS = ("-wal", "-shm", "-journal")
TIMEOUT_SECONDS = 60


class Hold(Exception):
    """A bounded status that does not contain filesystem paths or record data."""


def plain_file(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise Hold("NOT_REGULAR_FILE")
    return info


def fingerprint(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


def file_identity(info):
    return info.st_dev, info.st_ino


def require_absent(path, status):
    try:
        path.lstat()
    except FileNotFoundError:
        return
    raise Hold(status)


def check_source(source):
    info = plain_file(source)
    with source.open("rb") as handle:
        if file_identity(os.fstat(handle.fileno())) != file_identity(info):
            raise Hold("SOURCE_CHANGED")
        header = handle.read(20)
    if len(header) != 20 or not header.startswith(SQLITE_HEADER):
        raise Hold("SOURCE_NOT_SQLITE")
    present = set()
    for suffix in SIDECARS:
        try:
            plain_file(source.with_name(source.name + suffix))
        except FileNotFoundError:
            continue
        present.add(suffix)
    if (header[18:20] == b"\x02\x02" or "-wal" in present) and not {
        "-wal", "-shm"
    }.issubset(present):
        # Do not make a read-only open initialize sidecars in the source directory.
        raise Hold("SOURCE_WAL_SIDECARS_INCOMPLETE")
    return info


def database_uri(path, *, immutable=False):
    return path.as_uri() + ("?mode=ro&immutable=1" if immutable else "?mode=ro")


def elapsed_guard(deadline):
    if time.monotonic() > deadline:
        raise Hold("SQLITE_TIMEOUT")


def copy_sqlite(source, output):
    before = check_source(source)
    deadline = time.monotonic() + TIMEOUT_SECONDS

    def progress(_status, _remaining, _total):
        elapsed_guard(deadline)

    with closing(sqlite3.connect(database_uri(source), uri=True, timeout=1)) as original:
        original.execute("PRAGMA query_only=ON")
        original.execute("BEGIN")
        original.execute("SELECT 1 FROM sqlite_schema LIMIT 1").fetchone()
        if file_identity(plain_file(source)) != file_identity(before):
            raise Hold("SOURCE_CHANGED")
        with closing(sqlite3.connect(output, timeout=1)) as snapshot:
            snapshot.execute("PRAGMA synchronous=FULL")
            original.backup(snapshot, pages=128, progress=progress, sleep=0.05)
            if snapshot.execute("PRAGMA journal_mode=DELETE").fetchone() != ("delete",):
                raise Hold("ARCHIVE_NOT_STANDALONE")
    if file_identity(plain_file(source)) != file_identity(before):
        raise Hold("SOURCE_CHANGED")


def require_standalone(path):
    for suffix in SIDECARS:
        require_absent(path.with_name(path.name + suffix), "ARCHIVE_NOT_STANDALONE")


def inspect_archive(path, expected=None):
    require_standalone(path)
    before = fingerprint(plain_file(path))
    with path.open("rb") as handle:
        if fingerprint(os.fstat(handle.fileno())) != before:
            raise Hold("ARCHIVE_CHANGED")
        header = handle.read(20)
        if len(header) != 20 or not header.startswith(SQLITE_HEADER):
            raise Hold("ARCHIVE_NOT_SQLITE")
        if header[18:20] != b"\x01\x01":
            raise Hold("ARCHIVE_NOT_STANDALONE")
        handle.seek(0)
        digest = hashlib.file_digest(handle, "sha256").hexdigest()
        if expected is not None and digest != expected:
            raise Hold("ARCHIVE_SHA256_MISMATCH")
        deadline = time.monotonic() + TIMEOUT_SECONDS
        with closing(sqlite3.connect(database_uri(path, immutable=True), uri=True)) as db:
            db.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
            if db.execute("PRAGMA quick_check(1)").fetchall() != [("ok",)]:
                raise Hold("ARCHIVE_QUICK_CHECK_FAILED")
        require_standalone(path)
        if fingerprint(os.fstat(handle.fileno())) != before or fingerprint(plain_file(path)) != before:
            raise Hold("ARCHIVE_CHANGED")
    return {"sha256": digest, "bytes": before[2], "quick_check": "ok"}


def create_snapshot(source, destination):
    require_absent(destination, "DESTINATION_EXISTS")
    require_standalone(destination)
    parent = os.open(destination.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        parent_identity = file_identity(os.fstat(parent))
        with tempfile.TemporaryDirectory(prefix=".s03-snapshot-", dir=destination.parent) as work:
            temporary = Path(work) / "archive.sqlite"
            with os.fdopen(os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600), "wb"):
                pass
            copy_sqlite(source, temporary)
            result = inspect_archive(temporary)
            with temporary.open("rb") as handle:
                os.fsync(handle.fileno())
            require_standalone(destination)
            if file_identity(destination.parent.stat()) != parent_identity:
                raise Hold("DESTINATION_DIRECTORY_CHANGED")
            try:
                os.link(temporary, destination.name, dst_dir_fd=parent, follow_symlinks=False)
            except FileExistsError:
                raise Hold("DESTINATION_EXISTS") from None
            os.fsync(parent)
            if file_identity(destination.parent.stat()) != parent_identity:
                raise Hold("DESTINATION_DIRECTORY_CHANGED")
        return result
    finally:
        os.close(parent)


def sha256_arg(value):
    if not re.fullmatch(r"[0-9a-fA-F]{64}", value):
        raise argparse.ArgumentTypeError("expected a 64-digit SHA-256")
    return value.lower()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    backup = commands.add_parser("backup", help="create a new snapshot")
    backup.add_argument("source", type=Path)
    backup.add_argument("archive", type=Path)
    backup.add_argument("--apply", action="store_true")
    verify = commands.add_parser("verify", help="verify bytes and standalone SQLite integrity")
    verify.add_argument("archive", type=Path)
    verify.add_argument("--sha256", required=True, type=sha256_arg)
    args = parser.parse_args(argv)

    try:
        if args.command == "backup":
            if not args.apply:
                raise Hold("APPLY_REQUIRED")
            result = create_snapshot(args.source.absolute(), args.archive.absolute())
        else:
            result = inspect_archive(args.archive.absolute(), args.sha256)
    except Hold as error:
        print(json.dumps({"status": "HOLD", "reason": str(error)}))
        return 2
    except (OSError, sqlite3.Error):
        print(json.dumps({"status": "HOLD", "reason": "SQLITE_OR_IO_ERROR"}))
        return 2
    print(json.dumps({"status": "VERIFIED", **result}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
