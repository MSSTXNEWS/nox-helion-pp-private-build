import contextlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
from threading import Thread
import unittest

import glm_runtime_probe as probe


class GLMFixture(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, value, content_type="application/json"):
        raw = value if isinstance(value, bytes) else json.dumps(value).encode()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/health":
            self.reply({"status": "ok"})
        elif self.path == "/v1/models":
            self.reply({"data": [{"id": "nox-glm53"}]})
        else:
            self.send_error(404)

    def do_POST(self):
        request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path == "/apply-template":
            kwargs = request["chat_template_kwargs"]
            effort = kwargs["reasoning_effort"]
            if self.server.ignore_effort:
                effort = "max"
            head = f"[gMASK]<sop>Reasoning Effort: {effort.capitalize()}"
            if request.get("tools"):
                prompt = (
                    head + probe.TOOL_THOUGHT
                    + "<arg_value>alpha</arg_value><arg_value>beta</arg_value>"
                    + "NOX_TOOL_RESULT_ALPHA NOX_TOOL_RESULT_BETA"
                )
            else:
                retained = "" if kwargs["clear_thinking"] else probe.HISTORY_THOUGHT
                prompt = head + retained + "NOX_SYNTHETIC_VISIBLE_HISTORY"
            self.reply({"prompt": prompt})
        elif self.path == probe.CHAT_PATH and request.get("stream"):
            parts = [
                {"delta": {"reasoning_content": probe.HISTORY_THOUGHT}},
                {"delta": {"content": probe.VISIBLE_MARKER[:7]}},
                {"delta": {"content": probe.VISIBLE_MARKER[7:]}, "finish_reason": "stop"},
            ]
            if self.server.leak_reasoning:
                parts[0] = {"delta": {"content": "<think>hidden</think>"}}
            events = [json.dumps({"model": "nox-glm53", "choices": [part]}) for part in parts]
            payload = "".join(f"data: {event}\n\n" for event in events) + "data: [DONE]\n\n"
            self.reply(payload.encode(), "text/event-stream")
        elif self.path == probe.CHAT_PATH:
            self.reply({"model": "nox-glm53", "choices": [{
                "finish_reason": "stop", "message": {"content": '{"status":"ready"}'},
            }]})
        else:
            self.send_error(404)


class RuntimeProbeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), GLMFixture)
        cls.thread = Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def setUp(self):
        self.server.leak_reasoning = False
        self.server.ignore_effort = False
        self.endpoint = f"http://127.0.0.1:{self.server.server_port}{probe.CHAT_PATH}"

    def run_probe(self, *flags):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            status = probe.main(list(flags))
        return status, json.loads(output.getvalue())

    def test_full_synthetic_http_and_stream(self):
        status, result = self.run_probe("--apply", "--with-generation", "--endpoint", self.endpoint)
        self.assertEqual(status, 0)
        self.assertTrue(result["template_verified"])
        self.assertTrue(result["generation_verified"])
        self.assertNotIn(probe.HISTORY_THOUGHT, json.dumps(result))
        self.assertNotIn(probe.VISIBLE_MARKER, json.dumps(result))
        self.assertIsNotNone(result["checks"]["generation"]["two_turn_visible_sse"]["ttft_visible_ms"])

    def test_rejects_effort_ignored_by_backend(self):
        self.server.ignore_effort = True
        status, result = self.run_probe("--apply", "--endpoint", self.endpoint)
        self.assertEqual(status, 1)
        self.assertEqual(result["error"], "GLM53_TEMPLATE_MISMATCH")

    def test_detects_raw_reasoning_in_visible_stream(self):
        self.server.leak_reasoning = True
        status, result = self.run_probe("--apply", "--with-generation", "--endpoint", self.endpoint)
        self.assertEqual(status, 1)
        self.assertEqual(result["error"], "GLM53_GENERATION_PROBE_MISMATCH")

    def test_loopback_and_model_required(self):
        status, result = self.run_probe("--apply", "--endpoint", "https://example.com/v1/chat/completions")
        self.assertEqual(status, 1)
        self.assertEqual(result["error"], "ENDPOINT_NOT_DIRECT_HTTP_LOOPBACK")
        status, result = self.run_probe("--apply", "--endpoint", self.endpoint, "--model", "nox-glm53-test")
        self.assertEqual(status, 1)
        self.assertEqual(result["error"], "GLM53_STAGING_NOT_READY")

    def test_valid_effort_and_dry_run(self):
        self.assertTrue(probe.glm_request_settings("nox-glm53", "low")["chat_template_kwargs"]["clear_thinking"])
        with self.assertRaisesRegex(ValueError, "INVALID_GLM_REASONING_EFFORT"):
            probe.glm_request_settings("nox-glm53", "none")
        status, result = self.run_probe()
        self.assertEqual(status, 0)
        self.assertEqual(result["mode"], "offline_plan")


if __name__ == "__main__":
    unittest.main()
