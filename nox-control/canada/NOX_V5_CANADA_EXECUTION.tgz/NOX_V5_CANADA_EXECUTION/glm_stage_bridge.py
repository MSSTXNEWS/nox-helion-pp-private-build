"""Run the GLM request adapter against a local synthetic staging endpoint."""
from __future__ import annotations

import argparse
from contextlib import closing
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os

from chat_bench import json_bytes, loopback_endpoint
from glm_chat_adapter import complete_turn, prepare_turn

CHAT_PATH = "/v1/chat/completions"
MAX_BODY = 1024 * 1024
MAX_STREAM_LINE = 256 * 1024


class StageServer(ThreadingHTTPServer):
    def __init__(self, host_port, upstream, model, mode, api_key=None):
        super().__init__(host_port, StageHandler)
        self.upstream = upstream
        self.model = model
        self.mode = mode
        self.api_key = api_key


class StageHandler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def _json_response(self, status, payload):
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _post(self, conn, payload):
        headers = {"Accept": "text/event-stream" if payload.get("stream") else "application/json",
                   "Content-Type": "application/json", "Connection": "close"}
        if self.server.api_key:
            headers["Authorization"] = f"Bearer {self.server.api_key}"
        conn.request("POST", self.server.upstream[2], body=json_bytes(payload), headers=headers)

    def _complete(self, payload):
        host, port, _ = self.server.upstream
        with _connection(host, port) as conn:
            self._post(conn, payload)
            with conn.getresponse() as upstream:
                raw = upstream.read(MAX_BODY + 1)
                if upstream.status != 200 or len(raw) > MAX_BODY:
                    raise RuntimeError("UPSTREAM_COMPLETION_REJECTED")
        result = json.loads(raw)
        if not isinstance(result, dict) or result.get("model") != self.server.model:
            raise RuntimeError("UPSTREAM_MODEL_MISMATCH")
        return result

    def _stream(self, payload):
        host, port, _ = self.server.upstream
        with _connection(host, port) as conn:
            self._post(conn, payload)
            with conn.getresponse() as upstream:
                mime = upstream.headers.get_content_type()
                if upstream.status != 200 or mime != "text/event-stream":
                    self._json_response(502, {"error": "UPSTREAM_SSE_REJECTED"})
                    return
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.end_headers()
                self.close_connection = True
                try:
                    while line := upstream.readline(MAX_STREAM_LINE + 1):
                        if len(line) > MAX_STREAM_LINE:
                            return
                        if line.startswith(b"data:"):
                            frame = line[5:].strip()
                            if frame and frame != b"[DONE]":
                                data = json.loads(frame)
                                if not isinstance(data, dict) or data.get("model", self.server.model) != self.server.model:
                                    return
                        self.wfile.write(line)
                        self.wfile.flush()
                except (ValueError, OSError, http.client.HTTPException):
                    return

    def do_POST(self):
        if self.path != CHAT_PATH:
            self._json_response(404, {"error": "UNKNOWN_STAGING_ROUTE"})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 1 <= size <= MAX_BODY:
                self._json_response(413, {"error": "REQUEST_SIZE_LIMIT"})
                return
            payload = json.loads(self.rfile.read(size))
            if not isinstance(payload, dict):
                raise ValueError("Expected JSON object")
            turn = prepare_turn(payload, served_model=self.server.model, mode=self.server.mode)
        except (TypeError, ValueError, RecursionError):
            self._json_response(400, {"error": "INVALID_GLM_REQUEST"})
            return
        try:
            if turn.request.get("stream") is True:
                self._stream(turn.request)
            else:
                result = complete_turn(turn, self._complete)
                self._json_response(200, result.response)
        except (BrokenPipeError, ConnectionResetError):
            return
        except (OSError, ValueError, RuntimeError, http.client.HTTPException):
            self._json_response(502, {"error": "UPSTREAM_GLM_ERROR"})


def _connection(host, port):
    return closing(http.client.HTTPConnection(host, port, timeout=180))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--upstream", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--port", type=int, default=18099)
    parser.add_argument("--mode", choices=("fast", "balanced", "deep"), default="balanced")
    args = parser.parse_args()
    endpoint = loopback_endpoint(args.upstream)
    if not 1 <= args.port <= 65535 or args.port == endpoint[1]:
        parser.error("Use a distinct staging port between 1 and 65535")
    if not args.model.strip():
        parser.error("The exact served GLM model ID is required")
    with StageServer(("127.0.0.1", args.port), endpoint, args.model, args.mode,
                     os.environ.get("NOX_CHAT_BENCH_API_KEY")) as server:
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            return


if __name__ == "__main__":
    main()
