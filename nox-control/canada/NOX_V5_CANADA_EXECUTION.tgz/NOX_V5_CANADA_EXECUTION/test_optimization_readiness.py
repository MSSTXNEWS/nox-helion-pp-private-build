import json
from pathlib import Path
import unittest

from optimization_readiness import BASE_IDS, SUPPLEMENT_IDS, build_manifest


SOURCE = Path(__file__).with_name("optimization-register.json")


class OptimizationReadinessTests(unittest.TestCase):
    def setUp(self):
        self.raw = SOURCE.read_bytes()
        self.report = build_manifest(self.raw)
        self.rows = {row["id"]: row for row in self.report["rows"]}

    def test_exact_inventory_has_no_automatic_promotion(self):
        self.assertEqual(len(self.rows), 150)
        self.assertEqual(self.rows.keys(), BASE_IDS | SUPPLEMENT_IDS)
        self.assertEqual(sum(self.report["counts"].values()), 150)
        self.assertEqual(self.report["confirmed_current_target_count"], 0)
        self.assertFalse(self.report["execution_enabled"])
        for row in self.rows.values():
            self.assertFalse(row["execution_enabled"])
            self.assertFalse(row["measured_current_target"])
            self.assertTrue(row["evidence_required"])

    def test_source_evidence_and_overrides_do_not_invent_proof(self):
        self.assertEqual(self.rows["A22"]["state"], "REFERENCE_ONLY")
        self.assertIn("ИЗМЕРЕНО (S2)", self.rows["A22"]["source_claim"])
        self.assertEqual(self.rows["A28"]["lane"], "HOLD")
        self.assertIn("15%", self.rows["A28"]["evidence_required"])
        self.assertIn("f16", self.rows["A25"]["source_override"])
        self.assertEqual(self.rows["B05"]["source_override"], self.rows["B06"]["source_override"])
        self.assertTrue(self.rows["B30"]["source_claim"].endswith("13/13)"))
        self.assertEqual(self.rows["B30"]["state"], "EVIDENCE_REQUIRED")

    def test_filter_preserves_digest_and_canonical_experiment_references(self):
        portable = build_manifest(self.raw, "PORTABLE", self.report["source_sha256"])
        self.assertEqual(portable["input_rows"], 150)
        self.assertEqual(portable["selected_rows"], self.report["counts"]["PORTABLE"])
        self.assertEqual(self.rows["B35"]["experiment_anchor"], "A24")
        self.assertEqual(self.rows["A46"]["experiment_anchor"], "A39")
        self.assertEqual(self.rows["B93"]["experiment_anchor"], "B93")
        self.assertEqual(portable["source_sha256"], self.report["source_sha256"])

    def test_missing_duplicate_foreign_or_unpinned_input_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "source SHA-256"):
            build_manifest(self.raw, expected_source_sha256="0" * 64)
        for replacement in (None, "A47", "A99"):
            document = json.loads(self.raw)
            if replacement is None:
                document["canon_v5_supplement"].pop(0)
            else:
                document["canon_v5_supplement"][0]["id"] = replacement
            with self.assertRaisesRegex(ValueError, "missing, duplicate, or foreign ID"):
                build_manifest(json.dumps(document).encode())


if __name__ == "__main__":
    unittest.main()
