#!/usr/bin/env python3
"""Plan an isolated, single-variable NOX profile experiment from JSON evidence.

Run with a JSON filename, or omit the filename to read stdin. The program only
reads its input and prints JSON. The telemetry format is nox_server_probe_v1.
Engine features map names to SHA-256 receipts from the exact probed binary.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import re
import sys


MIB = 1024**2
TARGETS = {
    "S1": ("61825960", r"\bRTX\s+5060\s+Ti\b", 1, 15_000, "12.0", "glm-dsa"),
}
KNOBS = {
    "decode_threads": "threads",
    "prefill_threads": "batch_threads",
    "batch_size": "batch_size",
    "microbatch_size": "microbatch_size",
    "parallel_slots": "parallel_slots",
    "scratch_budget_bytes": "scratch_budget",
    "moe_cache_mib": "moe_cache",
    "prefix_cache": "prefix_cache",
    "profile": "reasoning_profile",
    "model": "architecture",
}
MODEL_FIELDS = ("manifest_sha256", "tokenizer_sha256", "template_sha256")
STEPS = [
    "Confirm the owner-approved isolated test window and verify the rollback config digest.",
    "Keep the serving process and S03 intact. Use one isolated replica with one exact engine and input suite.",
    "Collect paired cold and warm cases in interleaved order. Record samples, visible TTFT p50/p95, decode tok/s, quality, RAM/VRAM high-water marks, errors and STOP receipt.",
    "Hold the request context and budgets fixed. Restore the pinned baseline config at experiment end and verify its readback.",
]


def _object(value):
    return value if isinstance(value, dict) else {}


def _digest(value, lengths=(64,)):
    return isinstance(value, str) and len(value) in lengths and re.fullmatch(r"[a-f0-9]+", value) is not None


def _integer(value, minimum=1):
    return type(value) is int and value >= minimum


def _number(value, minimum=0):
    return _integer(value, minimum) or type(value) is float and math.isfinite(value) and value >= minimum


def _same(left, right):
    return _canonical_json(left) == _canonical_json(right)


def _canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def telemetry_digest(telemetry):
    """Hash the telemetry object as UTF-8 canonical JSON (sorted keys)."""
    return hashlib.sha256(_canonical_json(telemetry).encode("utf-8")).hexdigest()


def _fresh(value, now):
    if not isinstance(value, str):
        return False
    try:
        timestamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return timestamp.tzinfo is not None and 0 <= (now - timestamp).total_seconds() <= 900


def _model_is_pinned(value, architecture):
    model = _object(value)
    quantization = model.get("quantization")
    if model.get("architecture") != architecture or not _integer(model.get("weights_bytes")):
        return False
    if not all(_digest(model.get(field)) for field in MODEL_FIELDS):
        return False
    return model.get("family") == "GLM-5.3" and quantization in ("UD-Q4_K_XL", "UD-IQ4_XS")


def _feature_is_pinned(engine, name):
    proof = _object(_object(engine.get("features")).get(name))
    return (
        proof.get("supported") is True
        and _digest(engine.get("binary_sha256"))
        and proof.get("binary_sha256") == engine["binary_sha256"]
        and _digest(proof.get("evidence_sha256"))
    )


def _resource_errors(telemetry, request, devices):
    errors = []
    cgroup = _object(telemetry.get("cgroup"))
    limits = _object(request.get("resource_budget"))
    ram_limit = cgroup.get("effective_memory_limit_bytes")
    ram_available = cgroup.get("effective_memory_headroom_bytes")
    host_ram = _object(telemetry.get("host_memory")).get("available_bytes")
    ram_delta = limits.get("additional_ram_bytes")
    ram_reserve = limits.get("reserve_ram_bytes")
    if not _digest(limits.get("evidence_sha256")):
        errors.append("missing same-profile resource-budget evidence SHA-256")
    if not (
        cgroup.get("status") == "OK"
        and _integer(ram_limit)
        and _integer(ram_available, 0)
        and ram_available <= ram_limit
        and _integer(ram_delta, 0)
        and _integer(ram_reserve, 256 * MIB)
        and ram_delta + ram_reserve <= ram_available
        and (not _integer(host_ram, 0) or ram_delta + ram_reserve <= host_ram)
    ):
        errors.append("effective cgroup RAM headroom does not prove the stated additional peak plus reserve")
    filesystems = telemetry.get("filesystems")
    if not isinstance(filesystems, list):
        filesystems = []
    filesystem = next(
        (
            item for item in filesystems
            if isinstance(item, dict)
            and item.get("status") == "OK"
            and isinstance(limits.get("disk_path"), str)
            and limits["disk_path"].startswith("/")
            and item.get("path") == limits["disk_path"]
        ),
        {},
    )
    disk_available = filesystem.get("available_bytes")
    disk_delta = limits.get("additional_disk_bytes")
    disk_reserve = limits.get("reserve_disk_bytes")
    if not (
        _integer(disk_available, 0) and _integer(disk_delta, 0) and _integer(disk_reserve)
        and disk_delta + disk_reserve <= disk_available
    ):
        errors.append("no measured free-space proof for the specified scratch filesystem and reserve")
    gpu_budget = _object(limits.get("gpu_mib"))
    if set(gpu_budget) != {str(device.get("index")) for device in devices}:
        errors.append("GPU budget indices must match exactly the measured devices")
    for device in devices:
        index = str(device.get("index"))
        budget = _object(gpu_budget.get(index))
        extra, reserve = budget.get("additional"), budget.get("reserve")
        free = device.get("free_mib")
        if not (
            _integer(free, 0) and _integer(extra, 0) and _integer(reserve)
            and extra + reserve <= free
        ):
            errors.append(f"GPU {index} does not have measured free VRAM for the additional peak plus reserve")
    return errors


def _knob_errors(knob, candidate, baseline, telemetry, request, architecture):
    current = _object(baseline.get("settings"))
    previous = baseline.get("model") if knob == "model" else current.get(knob)
    if _same(previous, candidate):
        return ["candidate equals baseline"]
    if knob == "model":
        if not _model_is_pinned(candidate, architecture):
            return ["candidate GLM model lacks exact allowed variant, weights, tokenizer or template pins"]
        if (
            _object(candidate).get("quantization") != _object(previous).get("quantization")
            and request.get("quantization_comparison_approved") is not True
        ):
            return ["GLM quantization comparisons require explicit approval and the same quality exam"]
        if not all(_digest(request.get(key)) for key in ("candidate_restore_sha256", "baseline_restore_sha256")):
            return ["both models require verified cold-restore receipts and sequential load"]
        if request.get("single_model_residency_verified") is not True:
            return ["model A/B requires proof that the first exact model is fully unmapped before loading the next"]
        return []
    if knob == "profile":
        profiles = ("auto", "deep", "maximum")
        if previous in profiles and candidate in profiles and request.get("quality_profile_comparison_approved") is True:
            return []
        return ["profile A/B requires named baseline and candidate profiles plus explicit quality comparison approval"]
    if knob == "prefix_cache":
        return [] if type(previous) is bool and type(candidate) is bool else ["prefix cache needs two explicit boolean values"]
    if not _integer(previous, 0 if knob == "moe_cache_mib" else 1) or not _integer(candidate, 0 if knob == "moe_cache_mib" else 1):
        return ["numeric experiment requires measured integer baseline and candidate values"]
    cpu = _object(telemetry.get("cpu"))
    quota = _object(telemetry.get("cgroup")).get("cpu_quota_cores")
    if knob in ("decode_threads", "prefill_threads"):
        key = "physical_affinity_cores" if knob == "decode_threads" else "logical_affinity_count"
        available = cpu.get(key)
        reserved = request.get("reserved_cpu_cores")
        if not (_integer(available) and _number(quota, 1) and _integer(reserved) and candidate + reserved <= min(available, quota)):
            return ["thread count requires measured affinity and cgroup quota plus explicit service CPU reserve"]
    if knob == "batch_size":
        microbatch = current.get("microbatch_size")
        if not (_integer(microbatch) and microbatch <= candidate):
            return ["candidate batch size must preserve a proven microbatch size at or below it"]
    if knob == "microbatch_size" and not (_integer(current.get("batch_size")) and candidate <= current["batch_size"]):
        return ["candidate microbatch must fit the unchanged baseline batch"]
    if knob == "parallel_slots":
        if request.get("per_slot_full_context_verified") is not True:
            return ["parallel slots require parity at full context per slot"]
    budget = _object(request.get("resource_budget"))
    if knob == "scratch_budget_bytes" and candidate > previous + (budget.get("additional_ram_bytes") if _integer(budget.get("additional_ram_bytes"), 0) else 0):
        return ["scratch-budget growth exceeds proven additional RAM"]
    if knob == "moe_cache_mib" and candidate > previous:
        gpu_budgets = _object(budget.get("gpu_mib"))
        extra = [_object(value).get("additional") for value in gpu_budgets.values()]
        if not extra or not all(_integer(value, 0) for value in extra) or candidate - previous > sum(extra):
            return ["MoE cache growth exceeds proven aggregate additional VRAM"]
    return []


def _result(measurement, baseline, engine, candidate, candidate_config_sha256, metric):
    groups = [_object(measurement.get(phase)) for phase in ("baseline", "candidate")]
    models = [baseline["model"], candidate]
    configs = [baseline["config_sha256"], candidate_config_sha256]
    for group, model, config in zip(groups, models, configs):
        if not (
            group.get("engine_sha256") == engine["binary_sha256"]
            and group.get("config_sha256") == config
            and group.get("model_manifest_sha256") == model["manifest_sha256"]
            and group.get("workload_sha256") == baseline["workload_sha256"]
            and _digest(group.get("run_receipt_sha256"))
            and _integer(group.get("cases"), 20)
            and all(_number(group.get(field), 0.001) for field in ("ttft_p50_ms", "ttft_p95_ms", "decode_tps"))
            and group["ttft_p50_ms"] <= group["ttft_p95_ms"]
            and _integer(group.get("quality_passes"), 0)
            and group["quality_passes"] <= group["cases"]
            and _integer(group.get("errors"), 0)
        ):
            return "HOLD", "invalid or unpaired measurement receipt"
    old, new = groups
    if old["cases"] != new["cases"] or measurement.get("paired_order_verified") is not True:
        return "HOLD", "measurements must cover the same exact cases in a paired order"
    if any(group["errors"] or group.get("stop_verified") is not True for group in groups):
        return "KEEP_BASELINE", "STOP or error gate failed"
    if new["quality_passes"] < old["quality_passes"] or measurement.get("quality_no_case_regressions") is not True:
        return "KEEP_BASELINE", "quality regression or missing case-level quality parity"
    ttft_gain = (old["ttft_p95_ms"] - new["ttft_p95_ms"]) / old["ttft_p95_ms"]
    speed_gain = (new["decode_tps"] - old["decode_tps"]) / old["decode_tps"]
    gain, collateral = (ttft_gain, speed_gain) if metric == "ttft_p95_ms" else (speed_gain, ttft_gain)
    if gain < 0.05 or collateral < -0.05 or measurement.get("resource_peak_within_budget") is not True:
        return "KEEP_BASELINE", "gain below 5% or unacceptable latency, throughput or resource trade-off"
    return "OWNER_REVIEW", "paired result passed the planned gates; approval and deployment are separate"


def plan_profile(data, now=None):
    """Return HOLD, READY_TO_MEASURE, KEEP_BASELINE or OWNER_REVIEW without writes."""
    try:
        _canonical_json(data)
    except (TypeError, ValueError, RecursionError):
        return {"schema": "nox_profile_hints_v1", "status": "HOLD", "host_mutations": 0, "blockers": ["invalid JSON evidence object"]}
    data = _object(data)
    target = data.get("target")
    result = {"schema": "nox_profile_hints_v1", "target": target if isinstance(target, str) else None, "status": "HOLD", "host_mutations": 0}
    if not isinstance(target, str) or target not in TARGETS:
        return result | {"blockers": ["select the GLM target S1"]}
    instance, gpu_pattern, expected_count, gpu_mib, compute, architecture = TARGETS[target]
    telemetry, engine, baseline, request = (_object(data.get(key)) for key in ("telemetry", "engine", "baseline", "request"))
    identity = _object(telemetry.get("identity"))
    attestation = _object(data.get("attestation"))
    gpu = _object(telemetry.get("gpu"))
    devices = gpu.get("devices")
    devices = [_object(value) for value in devices] if isinstance(devices, list) else []
    server = _object(telemetry.get("llama_server"))
    errors = []
    if (
        str(identity.get("instance_id")) != instance
        or telemetry.get("schema") != "nox_server_probe_v1"
        or telemetry.get("status") != "OBSERVED"
    ):
        errors.append(f"expected owner-authorized, fresh server probe for Vast {instance}")
    if not (
        str(attestation.get("instance_id")) == instance
        and _digest(attestation.get("owner_receipt_sha256"))
        and attestation.get("telemetry_sha256") == telemetry_digest(telemetry)
    ):
        errors.append("provider environment label needs an independent owner receipt tied to this canonical telemetry SHA-256")
    if not _fresh(telemetry.get("observed_at"), now or datetime.now(timezone.utc)):
        errors.append("telemetry timestamp missing, future-dated or older than 15 minutes")
    if gpu.get("status") != "OK" or len(devices) != expected_count or not all(
        re.search(gpu_pattern, str(device.get("name", "")), re.IGNORECASE)
        and str(device.get("compute_capability")) == compute
        and _integer(device.get("total_mib"), gpu_mib)
        and _integer(device.get("index"), 0)
        and _integer(device.get("free_mib"), 0) and device["free_mib"] <= device["total_mib"]
        for device in devices
    ) or len({str(device.get("index")) for device in devices}) != len(devices):
        errors.append(f"GPU count, CUDA compute capability {compute}, or measured VRAM does not match {target}")
    if not (
        _digest(engine.get("commit"), (40, 64))
        and _digest(engine.get("binary_sha256"))
        and server.get("status") == "OK"
        and server.get("sha256") == engine["binary_sha256"]
        and server.get("pin_matches") is True
        and engine.get("compute_capability") == compute
        and engine.get("architecture") == architecture
        and _feature_is_pinned(engine, "architecture")
    ):
        errors.append(f"missing exact target binary, source commit or tested {architecture} support on SM {compute}")
    if not _model_is_pinned(baseline.get("model"), architecture):
        errors.append("baseline lacks exact GLM model, weight, tokenizer and template pins")
    for field in ("config_sha256", "workload_sha256", "rollback_receipt_sha256"):
        if not _digest(baseline.get(field)):
            errors.append(f"missing baseline {field}")
    if not _digest(request.get("candidate_config_sha256")) or request.get("candidate_config_sha256") == baseline.get("config_sha256"):
        errors.append("candidate needs its own exact config SHA-256")
    if not _digest(request.get("one_change_receipt_sha256")):
        errors.append("missing diff-verifier receipt proving exactly one config change and held-constant full context")
    metric = request.get("primary_metric")
    if metric not in ("ttft_p95_ms", "decode_tps"):
        errors.append("select primary metric ttft_p95_ms or decode_tps")
    knob = request.get("knob")
    candidate = request.get("value")
    if not isinstance(knob, str) or knob not in KNOBS:
        errors.append("select one supported knob: " + ", ".join(KNOBS))
    else:
        if not _feature_is_pinned(engine, KNOBS[knob]):
            errors.append(f"missing exact-binary feature proof for {knob}")
        old_settings = _object(baseline.get("settings"))
        new_settings = request.get("settings")
        expected = old_settings if knob == "model" else old_settings | {knob: candidate}
        if not (
            isinstance(new_settings, dict)
            and new_settings.keys() == expected.keys()
            and all(_same(new_settings[key], value) for key, value in expected.items())
        ):
            errors.append("candidate settings must preserve all entries except the selected change")
        errors += _knob_errors(knob, candidate, baseline, telemetry, request, architecture)
    errors += _resource_errors(telemetry, request, devices)
    if errors:
        return result | {"blockers": errors}

    model = baseline["model"]
    previous = model if knob == "model" else baseline["settings"][knob]
    target_step = (
        "Preserve full GLM context and measure CPU and GPU separately. Load one exact GLM set at a time. "
        "Confirm mmap, shard bytes, freed residency and rollback before each new load."
    )
    result |= {
        "status": "READY_TO_MEASURE",
        "instance_id": instance,
        "engine_sha256": engine["binary_sha256"],
        "experiment": {"knob": knob, "baseline": previous, "candidate": candidate, "primary_metric": metric},
        "steps": [*STEPS[:2], target_step, *STEPS[2:]],
        "rollback_config_sha256": baseline["config_sha256"],
        "workload_sha256": baseline["workload_sha256"],
    }
    if "measurement" in data:
        result["status"], result["decision"] = _result(
            _object(data["measurement"]), baseline, engine, candidate if knob == "model" else model,
            request["candidate_config_sha256"], metric,
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", type=argparse.FileType("r", encoding="utf-8"), default=sys.stdin)
    args = parser.parse_args()
    try:
        result = plan_profile(json.load(args.input))
    except (ValueError, OSError) as exc:
        result = {"schema": "nox_profile_hints_v1", "status": "HOLD", "host_mutations": 0, "blockers": [str(exc)]}
    print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
    return 2 if result["status"] == "HOLD" else 0


if __name__ == "__main__":
    sys.exit(main())
