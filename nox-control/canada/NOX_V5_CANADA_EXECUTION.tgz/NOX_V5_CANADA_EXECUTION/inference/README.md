# GLM‑5.3 — замер скорости и подбор параметров

`benchmark.py` запускает короткие синтетические запросы к уже работающему OpenAI-совместимому SSE-эндпоинту. Python 3.9+, сторонние зависимости отсутствуют. `NOX_API_KEY` используется при необходимости и не попадает в квитанцию.

```bash
python inference/benchmark.py --base-url http://127.0.0.1:18885 \
  --model glm-5.3 --expect-model glm-5.3 --scenario interactive \
  --samples 20 --label baseline --output glm53-baseline.json
```

- `first_model_delta_ms` — первый фрагмент содержимого, размышления или инструмента. `first_visible_text_ms` — первый фрагмент ответа с видимым текстом.
- `decode_tokens_per_second` и `prompt_tokens_per_second` берутся из таймингов сервера. Если сервер не передаёт метрику, значение остаётся `null`.
- `--paired-cache` последовательно измеряет запрос с выключенным кэшем, прогревает тот же запрос и записывает повтор. Для подтверждения попадания нужна метрика `cached_prompt_tokens` или журнал сервера. Это проверка кэша запросов, без измерения холодного старта весов.
- `--concurrency 2` создаёт два одновременно выполняемых запроса. `--samples 20` даёт ограниченную оценку p95. Для допуска к реальному трафику используйте более длинную выборку и одинаковую конкуренцию в A и B.
- `observed` подтверждает завершившиеся SSE-запросы. `truncated_by_token_limit` показывает обрезку. Качество содержания сверяется отдельным набором задач.

`trial.py` показывает варианты из `runtime_trials.json` и печатает массивы аргументов для сервера и замера.

```bash
python inference/trial.py
python inference/trial.py LLM-S07 2
```

В A/B меняйте одну настройку за раз. Начальная и экспериментальная конфигурации используют один и тот же снимок весов, шаблон, бинарник, профиль входа и подсистему памяти. Приведённые числа для потоков, слоёв и VRAM — точки замера. Сверьте ключи с `llama-server --help` именно установленной сборки. Снимайте пиковую RAM и VRAM на запускающем хосте и сравнивайте с одинаковым свободным запасом. Принимать изменение по ускорению можно после проверки качества на том же наборе и отсутствия ошибок или роста обрезки.

На хосте с V100 нужна сборка CUDA backend для Volta `sm_70`. При самостоятельной сборке используйте совместимый CUDA Toolkit 12.x и укажите архитектуру `70`; NVIDIA убрала офлайн-компиляцию и поддержку библиотек Volta из Toolkit 13.0. [Таблица GPU NVIDIA](https://developer.nvidia.com/cuda/gpus/legacy) · [CUDA 13.0 release notes](https://docs.nvidia.com/cuda/archive/13.0.1/cuda-toolkit-release-notes/index.html)

Первичные источники — [параметры llama-server](https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md), [llama-bench](https://github.com/ggml-org/llama.cpp/blob/master/tools/llama-bench/README.md), [speculative decoding](https://github.com/ggml-org/llama.cpp/blob/master/docs/speculative.md), [публикация GLM‑5.3 GGUF](https://huggingface.co/unsloth/GLM-5.3-GGUF).
