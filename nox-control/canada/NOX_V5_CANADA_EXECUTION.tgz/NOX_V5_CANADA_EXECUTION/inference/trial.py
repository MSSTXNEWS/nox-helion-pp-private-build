#!/usr/bin/env python3
"""Render the extra server and benchmark arguments for one GLM-5.3 trial."""

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trial", nargs="?")
    parser.add_argument("variant", type=int, nargs="?", default=1, help="variant number starting at 1")
    args = parser.parse_args()
    with Path(__file__).with_name("runtime_trials.json").open(encoding="utf-8") as file:
        trials = json.load(file)["trials"]
    if args.trial is None:
        for trial in trials:
            print(f'{trial["id"]}  {trial["title"]}  [{len(trial["variants"])}]')
        return
    for trial in trials:
        if trial["id"] != args.trial:
            continue
        if not 1 <= args.variant <= len(trial["variants"]):
            parser.error(f'variant for {trial["id"]} must be from 1 to {len(trial["variants"])}')
        variant_index = args.variant - 1
        benchmark_args = ["--scenario", trial["scenario"]]
        if "benchmark_variant_args" in trial:
            benchmark_args.extend(trial["benchmark_variant_args"][variant_index])
        if trial["id"] == "LLM-S08":
            benchmark_args.append("--paired-cache")
        selected = {
            "trial": trial["id"],
            "variant": args.variant,
            "server_args": trial["variants"][variant_index],
            "benchmark_args": benchmark_args,
            "acceptance": trial["acceptance"],
            "sources": trial["sources"],
        }
        print(json.dumps(selected, ensure_ascii=False, indent=2))
        return
    parser.error(f"unknown trial: {args.trial}")


if __name__ == "__main__":
    main()
