#!/usr/bin/env python3
"""Measure streaming GLM-5.3 against an already running chat endpoint."""

import argparse
import concurrent.futures
import datetime
import json
import math
import os
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request


SCENARIOS = {
    "interactive": (
        "low", 160,
        "У клиента перестал работать Wi-Fi на одном ноутбуке. Дай три коротких и обратимых шага диагностики.",
    ),
    "reasoning": (
        "high", 2048,
        "Склад отгружает 18 коробок в час первой линией и 12 второй. После одного часа вторая линия "
        "останавливается на 30 минут. Обе начали одновременно. Когда будут готовы 105 коробок? "
        "Дай итог, расчёт по интервалам и независимую проверку.",
    ),
    "long-context": (
        "low", 384,
        "Прочитай журнал и укажи единственный код критической записи.\n"
        + "\n".join(
            f"Запись {i}: штатная проверка; температура 42 °C; статус НОРМА."
            if i != 91 else "Запись 91: аварийная проверка; статус КРИТИЧЕСКИЙ; код SABLE-37."
            for i in range(1, 181)
        ) + "\nНазови код и номер критической записи.",
    ),
    "repetition": (
        "low", 768,
        "Повтори каждую строку два раза, не меняя её текст, затем добавь общий итог.\n"
        + "\n".join(f"Секция {i}: План работ согласован. Исполнители готовы. Результат проверяется." for i in range(1, 12)),
    ),
}


class BadStream(ValueError):
    """The endpoint failed to produce a complete visible answer."""


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        return None


def endpoint_url(base_url):
    url = urllib.parse.urlsplit(base_url)
    if not url.hostname or url.scheme not in {"http", "https"}:
        raise ValueError("--base-url must be an http(s) URL")
    if url.username or url.password or url.query or url.fragment:
        raise ValueError("URL credentials, query strings and fragments are unsupported")
    _ = url.port
    path = url.path.rstrip("/")
    if not path.endswith("/v1/chat/completions"):
        path += "/chat/completions" if path.endswith("/v1") else "/v1/chat/completions"
    return urllib.parse.urlunsplit((url.scheme, url.netloc, path, "", ""))


def data_events(lines):
    fields = []
    for raw in lines:
        line = raw.decode("utf-8").rstrip("\r\n")
        if not line:
            if fields:
                yield "\n".join(fields)
                fields.clear()
        elif line == "data" or line.startswith("data:"):
            fields.append(line[5:].removeprefix(" "))
    if fields:
        yield "\n".join(fields)


def number(record, key):
    value = record.get(key) if isinstance(record, dict) else None
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0:
        return value
    return None


def seconds_ms(seconds):
    return round(seconds * 1000, 2)


def measure_stream(lines, start, *, expected_model=None, clock=time.monotonic):
    metrics = {
        "first_model_delta_ms": None,
        "first_visible_text_ms": None,
        "finish_reason": None,
        "prompt_tokens": None,
        "completion_tokens": None,
        "cached_prompt_tokens": None,
        "prompt_tokens_per_second": None,
        "decode_tokens_per_second": None,
        "response_model": None,
    }
    done = False
    visible_chars = 0
    finish = None
    for data in data_events(lines):
        elapsed = seconds_ms(clock() - start)
        if data == "[DONE]":
            done = True
            break
        try:
            frame = json.loads(data)
        except json.JSONDecodeError as error:
            raise BadStream("invalid JSON in SSE stream") from error
        if not isinstance(frame, dict) or frame.get("error"):
            raise BadStream("endpoint emitted an error frame")
        response_model = frame.get("model")
        if isinstance(response_model, str):
            if metrics["response_model"] not in (None, response_model):
                raise BadStream("response model changed during the stream")
            metrics["response_model"] = response_model
        usage = frame.get("usage")
        if isinstance(usage, dict):
            for key in ("prompt_tokens", "completion_tokens"):
                value = number(usage, key)
                if value is not None:
                    metrics[key] = value
            cached = number(usage.get("prompt_tokens_details"), "cached_tokens")
            if cached is not None:
                metrics["cached_prompt_tokens"] = cached
        timings = frame.get("timings")
        if isinstance(timings, dict):
            for source, target in (
                ("cache_n", "cached_prompt_tokens"),
                ("prompt_per_second", "prompt_tokens_per_second"),
                ("predicted_per_second", "decode_tokens_per_second"),
            ):
                value = number(timings, source)
                if value is not None:
                    metrics[target] = value
        choices = frame.get("choices") or []
        if not isinstance(choices, list) or any(not isinstance(choice, dict) for choice in choices):
            raise BadStream("invalid SSE choices")
        for choice in choices:
            if choice.get("index", 0) != 0:
                continue
            delta = choice.get("delta") or {}
            if not isinstance(delta, dict):
                raise BadStream("invalid SSE delta")
            content = delta.get("content")
            reasoning = delta.get("reasoning_content") or delta.get("reasoning")
            visible = isinstance(content, str) and bool(content.strip())
            model_delta = bool(content) or bool(reasoning) or bool(delta.get("tool_calls"))
            if model_delta and metrics["first_model_delta_ms"] is None:
                metrics["first_model_delta_ms"] = elapsed
            if isinstance(content, str):
                visible_chars += len(content)
            if visible and metrics["first_visible_text_ms"] is None:
                metrics["first_visible_text_ms"] = elapsed
            if choice.get("finish_reason"):
                metrics["finish_reason"] = choice["finish_reason"]
                finish = elapsed
    if not done and finish is None:
        raise BadStream("SSE stream truncated before completion")
    if metrics["first_visible_text_ms"] is None:
        raise BadStream("SSE completed without a visible text response")
    if expected_model is not None and metrics["response_model"] != expected_model:
        raise BadStream("response model did not match --expect-model")
    metrics["total_ms"] = seconds_ms(clock() - start)
    metrics["visible_chars"] = visible_chars
    metrics["sse_done"] = done
    return metrics


def completion(args, endpoint, use_prompt_cache, request_key):
    sample_effort, sample_tokens, prompt = SCENARIOS[args.scenario]
    anchored_prompt = f"Проверка {request_key}. Ответь на запрос ниже.\n{prompt}"
    payload = {
        "model": args.model,
        "messages": [{"role": "user", "content": anchored_prompt}],
        "stream": True,
        "reasoning_effort": args.effort or sample_effort,
        "max_tokens": args.max_tokens or sample_tokens,
        "temperature": args.temperature,
        "seed": args.seed,
        "chat_template_kwargs": {"clear_thinking": True},
        "cache_prompt": use_prompt_cache,
    }
    if args.include_usage:
        payload["stream_options"] = {"include_usage": True}
    headers = {"Content-Type": "application/json", "Accept": "text/event-stream"}
    if os.environ.get("NOX_API_KEY"):
        headers["Authorization"] = "Bearer " + os.environ["NOX_API_KEY"]
    request = urllib.request.Request(endpoint, json.dumps(payload, ensure_ascii=False).encode(), headers)
    start = time.monotonic()
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=args.timeout) as response:
        if response.headers.get_content_type() != "text/event-stream":
            raise BadStream("endpoint did not respond with text/event-stream")
        return measure_stream(response, start, expected_model=args.expect_model)


def run_sample(args, endpoint, index):
    phases = {"uncached_request": False, "warm_request": True} if args.paired_cache else {
        "request": args.prompt_cache,
    }
    result = {}
    for phase, prompt_cache in phases.items():
        try:
            if phase == "warm_request":
                completion(args, endpoint, True, f"S{index}")
            result[phase] = completion(args, endpoint, prompt_cache, f"S{index}")
        except urllib.error.HTTPError as error:
            result[phase] = {"error": f"HTTP {error.code}"}
        except BadStream as error:
            result[phase] = {"error": str(error)}
        except (OSError, ValueError) as error:
            result[phase] = {"error": type(error).__name__}
    return result


def summarize(results):
    reported_keys = (
        "first_model_delta_ms", "first_visible_text_ms", "total_ms", "prompt_tokens",
        "completion_tokens", "cached_prompt_tokens", "prompt_tokens_per_second", "decode_tokens_per_second",
    )
    summary = {"count": len(results), "completed": 0, "truncated_by_token_limit": 0}
    for item in results:
        if "error" not in item:
            summary["completed"] += 1
        if item.get("finish_reason") == "length":
            summary["truncated_by_token_limit"] += 1
    for key in reported_keys:
        values = [item[key] for item in results if item.get(key) is not None]
        if values:
            values.sort()
            summary[key] = {"p50": statistics.median(values),
                            "p95": values[math.ceil(len(values) * 0.95) - 1], "n": len(values)}
    return summary


def run(args):
    endpoint = endpoint_url(args.base_url)
    start = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        samples = list(executor.map(lambda index: run_sample(args, endpoint, index), range(args.samples)))
    elapsed = time.monotonic() - start
    summary = {phase: summarize([item[phase] for item in samples]) for phase in samples[0]}
    receipt = {
        "schema_version": 1,
        "suite": "nox-glm-5.3-speed",
        "recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "configuration": {
            "label": args.label, "model": args.model, "scenario": args.scenario, "samples": args.samples,
            "concurrency": args.concurrency, "seed": args.seed, "stream_usage_requested": args.include_usage,
            "paired_cache": args.paired_cache, "prompt_cache": args.prompt_cache, "temperature": args.temperature,
            "reasoning_effort": args.effort or SCENARIOS[args.scenario][0],
            "max_tokens": args.max_tokens or SCENARIOS[args.scenario][1],
        },
        "status": "observed" if all(row["count"] == row["completed"] for row in summary.values()) else "incomplete",
        "workload_wall_ms": seconds_ms(elapsed),
        "summary": summary,
        "samples": samples,
    }
    formatted = json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        with open(args.output, "x", encoding="utf-8") as file:
            file.write(formatted)
    else:
        print(formatted, end="")
    return 0 if receipt["status"] == "observed" else 1


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--expect-model", help="required model identifier returned by the endpoint")
    parser.add_argument("--label", default="baseline")
    parser.add_argument("--scenario", choices=SCENARIOS, default="interactive")
    parser.add_argument("--samples", type=int, default=5)
    parser.add_argument("--concurrency", type=int, default=1)
    parser.add_argument("--seed", type=int, default=1729)
    parser.add_argument("--effort", choices=("low", "high", "max"))
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--temperature", type=float, default=0.5)
    parser.add_argument("--timeout", type=float, default=180)
    parser.add_argument("--prompt-cache", action="store_true")
    parser.add_argument("--paired-cache", action="store_true")
    parser.add_argument("--include-usage", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--output", help="new path for a JSON receipt, or stdout when omitted")
    args = parser.parse_args(argv)
    if not 1 <= args.concurrency <= args.samples <= 100:
        parser.error("require 1 <= concurrency <= samples <= 100")
    if args.max_tokens is not None and args.max_tokens < 1:
        parser.error("--max-tokens must be positive")
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error("--timeout must be positive and finite")
    if not math.isfinite(args.temperature) or args.temperature < 0:
        parser.error("--temperature must be nonnegative and finite")
    if args.paired_cache and args.concurrency != 1:
        parser.error("--paired-cache requires --concurrency 1")
    return args


if __name__ == "__main__":
    try:
        sys.exit(run(parse_args()))
    except (OSError, ValueError) as error:
        sys.exit(str(error))
