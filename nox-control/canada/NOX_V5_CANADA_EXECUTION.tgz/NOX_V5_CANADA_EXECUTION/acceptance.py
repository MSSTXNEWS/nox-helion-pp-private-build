"""Cross-check independently exported staging receipts without creating or accepting a live deployment."""

import argparse
import json
import re
from pathlib import Path

HEX = re.compile(r"[0-9a-f]{64}")
SCOPE_KEYS = {"owner", "data_scope", "project", "persona", "dialog"}


def verify(data):
    scope = data["scope"]
    if set(scope) != SCOPE_KEYS or any(not isinstance(v, str) or not v for v in scope.values()):
        raise ValueError("invalid scope")
    turns = data["browser_turns"]
    canonical = data["canonical_readback"]
    if len(turns) != 2 or len(canonical) != 4:
        raise ValueError("expected exactly two browser turns and four canonical messages")
    producer = data["observer_ids"]
    if set(producer) != {"browser", "s03_readback", "runner"} or len(set(producer.values())) != 3:
        raise ValueError("browser, runner, and independent S03 reader must be distinguished")
    ids = set()
    for index, turn in enumerate(turns):
        exchange = turn["exchange"]
        if not isinstance(exchange, str) or not exchange or exchange in ids or turn["scope"] != scope:
            raise ValueError("browser exchange duplicated or scope changed")
        if turn["terminal"] != "done" or turn["visible_content"] is not True:
            raise ValueError("browser turn has no visible content and terminal receipt")
        ids.add(exchange)
        for offset, (role, digest) in enumerate((("user", turn["input_sha256"]), ("assistant", turn["answer_sha256"]))):
            row = canonical[2 * index + offset]
            if not isinstance(digest, str) or not HEX.fullmatch(digest):
                raise ValueError("message digest missing")
            if (row["exchange"], row["role"], row["sha256"], row["scope"]) != (exchange, role, digest, scope):
                raise ValueError("canonical S03 message does not match the browser transcript and scope")
    rows = [row["id"] for row in canonical]
    if len(set(rows)) != 4 or any(not isinstance(row, str) or not row for row in rows):
        raise ValueError("canonical rows must each have a unique identity")
    continuation = data["continuation"]
    if (continuation["dialog"] != scope["dialog"] or continuation["canonical_rows_after_reload"] != rows
            or continuation["same_exchange_replays_without_new_job"] is not True):
        raise ValueError("reload/reconnect does not preserve the original dialog and exchanges")
    guard = data["scope_probe"]
    if (guard["foreign_scope_seen_by_model"] is not False
            or guard["positive_scoped_evidence_seen_by_model"] is not True
            or not isinstance(guard["foreign_before_sha256"], str)
            or not HEX.fullmatch(guard["foreign_before_sha256"])
            or guard["foreign_before_sha256"] != guard["foreign_after_sha256"]):
        raise ValueError("scope isolation or foreign-state stability not demonstrated")
    stop = data["stop"]
    if (not isinstance(stop["request"], str) or not stop["request"]
            or stop["request"] != stop["backend_request"]
            or stop["backend_terminal"] != "cancelled" or stop["events_after_terminal"] != 0
            or stop["unrelated_request_unchanged"] is not True):
        raise ValueError("server STOP has not been confirmed for exactly the selected request")
    return {"state": "EVIDENCE_CONSISTENT", "live_acceptance": False,
            "browser_turns": 2, "canonical_rows": 4,
            "limit": "This checks receipt consistency. Authenticate each exporter and the deployed model/writer independently."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args()
    try:
        with args.receipt.open("rb") as file:
            raw = file.read((1 << 20) + 1)
        if len(raw) > 1 << 20:
            raise ValueError("receipt exceeds 1 MiB")
        result = verify(json.loads(raw))
    except (KeyError, TypeError, ValueError, OSError) as exc:
        # Show the check name or field label, never remote error text or user content.
        reason = str(exc) if type(exc) is ValueError else type(exc).__name__
        print(json.dumps({"state": "HOLD", "reason": reason, "live_acceptance": False}))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
