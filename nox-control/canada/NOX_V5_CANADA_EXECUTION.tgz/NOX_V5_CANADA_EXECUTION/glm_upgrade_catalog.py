"""Bind six source streams to executable checks and the existing GLM relay."""
import argparse
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
CHECKS = {
    "runtime": ("A2", "inference", ["P2-06"], "inference/trial.py"),
    "reasoning": ("A4", "learning_policy", ["P2-06"], "reasoning/nox_reasoning.py"),
    "memory": ("A3", "memory", ["P4-03"], "memory/nox_memory.py"),
    "affect": ("A4", "persona", ["P5-04"], "affect/nox_affect.py"),
    "quality": ("A5", "chat_route", ["P2-06"], "evaluation/nox_eval.py"),
}


def read_json(name):
    return json.loads((ROOT / name).read_text())


def source_table(path, marker):
    for line in (ROOT / path).read_text().splitlines():
        if not line.startswith("| "):
            continue
        columns = [part.strip() for part in line.strip("|").split("|")]
        if not re.fullmatch(marker, columns[0]):
            continue
        urls = re.findall(r"https://[^\s)]+", line)
        if not urls:
            raise ValueError(f"No source URL in {path} for {columns[0]}")
        yield columns[0], columns[1], re.sub(r"\s*\[[^\]]+\]\(https?://[^)]+\)", "", columns[2]).strip(), urls[0]


def build_cards():
    pending = []
    for trial in read_json("inference/runtime_trials.json")["trials"]:
        pending.append(("runtime", trial["id"], trial["title"], trial["acceptance"],
                        trial["sources"][0], "AB_CANDIDATE"))
    for row in read_json("reasoning/sources.json"):
        pending.append(("reasoning", row["id"], row["name"], row["acceptance"], row["source"],
                        {"implemented": "CODE_CHECK", "callable": "CALLABLE", "prompt": "PROMPT",
                         "experiment": "AB_CANDIDATE"}[row["status"]]))
    for number, title, acceptance, url in source_table("memory/README.md", r"(?:10|[1-9])"):
        state = "AB_CANDIDATE" if number == "9" else "CODE_CHECK"
        pending.append(("memory", f"M{int(number):02}", title, acceptance, url, state))
    for aid, title, acceptance, url in source_table("affect/README.md", r"AF0[1-9]"):
        state = "DATASET" if aid == "AF05" else "EVAL_CASE" if aid in {"AF04", "AF09"} else "CODE_CHECK"
        pending.append(("affect", aid, title, acceptance, url, state))
    for eid, title, acceptance, url in source_table("evaluation/README.md", r"E0[1-9]"):
        state = "EVAL_CASE" if eid in {"E01", "E03", "E04", "E06", "E09"} else "EVAL_PROTOCOL"
        pending.append(("quality", eid, title, acceptance, url, state))

    cards = []
    first = {"LLM-S08", "R01", "R03", "M01", "M05", "AF02", "AF07", "E01", "E03", "E06"}
    for index, (track, ref, title, evidence, source, status) in enumerate(pending, 1):
        role, resource_key, prerequisites, artifact = CHECKS[track]
        cards.append({
            "id": f"GLM50-{index:02}", "title": title, "role": role, "track": track,
            "priority": "P0" if ref in first else "P1",
            "status": status, "source_ref": ref, "resource_key": resource_key,
            "source_dependencies": prerequisites, "unmapped_dependency_ids": [],
            "public_source": source, "physical_evidence": evidence,
            "local_artifact": artifact, "execution_targets": ["S1"], "owner_card": False,
            "known_operation": None,
        })
    if len(cards) != 50 or len({card["source_ref"] for card in cards}) != 50:
        raise ValueError(f"Expected 50 distinct improvements, got {len(cards)}")
    return cards


def append_cards(plan, cards):
    previous = plan["experiment_cards"]
    canonical_ids = {card["id"] for block in plan["blocks"] for card in block["cards"]}
    canonical_ids.update(card["id"] for card in plan["pv_gates"])
    all_ids = canonical_ids | {card["id"] for card in previous}
    if any(card["id"] in all_ids or set(card["source_dependencies"]) - canonical_ids for card in cards):
        raise ValueError("Card ID collision or absent prerequisite")
    return plan | {"experiment_cards": previous + cards, "experiment_native_count": 0}


def markdown(cards):
    lines = [
        "# GLM‑5.3 · 50 улучшений и проверок", "",
        "Сводка шести исполнителей. Проба фактического шаблона, API и SSE вынесена в GLM53_RUNTIME.md.",
        "Карточка описывает изменение или метод измерения. Пакет не засчитывает живой результат без квитанции.",
        "",
        "| ID | Приоритет | Направление | Улучшение | Готовность | Первоисточник |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    ready = {
        "AB_CANDIDATE": "A/B на стенде", "CODE_CHECK": "Код и локальная проверка",
        "CALLABLE": "Функция", "PROMPT": "Промпт для испытания", "DATASET": "Данные загружены",
        "EVAL_CASE": "Сценарий проверки", "EVAL_PROTOCOL": "Протокол отдельного экзамена",
    }
    groups = {"runtime":"Инференс", "reasoning":"Рассуждение", "memory":"Память",
              "affect":"Личность и тон", "quality":"Качество"}
    for c in cards:
        lines.append(
            f"| {c['id']} | {c['priority']} | {groups[c['track']]} | {c['title']} | "
            f"{ready[c['status']]} | [Источник]({c['public_source']}) |"
        )
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--relay", type=Path)
    parser.add_argument("--markdown", action="store_true")
    args = parser.parse_args()
    cards = build_cards()
    if args.markdown:
        print(markdown(cards), end="")
    else:
        payload = append_cards(json.loads(args.relay.read_text()), cards) if args.relay else cards
        print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
