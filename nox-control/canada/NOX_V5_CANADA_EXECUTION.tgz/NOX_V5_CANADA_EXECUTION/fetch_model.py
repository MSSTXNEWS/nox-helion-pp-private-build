"""Resume and verify the exact published GLM shards in an owner-selected staging directory."""

import argparse
import fcntl
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path

from host_admission import evaluate
from model_plan import QUANT, REPOSITORY, REVISION, SHARDS, filesystem, mount_types, verify_shard
from server_probe import cgroup_probe, host_memory, instance_identity

GIB = 1024**3
ALLOWED_FS = {"tmpfs", "ext4", "xfs", "btrfs", "zfs", "overlay"}


def note(state, **details):
    print(json.dumps({"state": state, **details}, ensure_ascii=False), flush=True)


def check_capacity(root, root_fd, filesystem_type, needed, reserve, identity, provider_headroom):
    volume = os.fstatvfs(root_fd)
    free = volume.f_bavail * volume.f_frsize
    if volume.f_flag & os.ST_RDONLY:
        raise ValueError("destination is mounted read-only")
    if free < needed + reserve:
        raise ValueError(f"destination needs {needed + reserve} bytes, free {free}")
    if filesystem_type == "tmpfs":
        if not identity.get("instance_id"):
            raise ValueError("tmpfs staging requires an observed instance label")
        report = {
            "schema": "nox_server_probe_v1", "status": "OBSERVED", "read_only": True,
            "identity": identity, "cgroup": cgroup_probe(), "host_memory": host_memory(),
            "filesystems": [{"path": str(root), "status": "OK", "filesystem": filesystem_type,
                             "available_bytes": free, "read_only_mount": False}],
        }
        admission = evaluate(report, destination=str(root), required_payload_bytes=needed,
                             filesystem_reserve_bytes=reserve, memory_reserve_bytes=reserve,
                             expected_instance=identity["instance_id"], provider_headroom_bytes=provider_headroom)
        if admission["state"] != "STAGING_CAPACITY_CONFIRMED":
            raise ValueError("tmpfs staging capacity: " + ", ".join(admission["reasons"]))
    return free


def file_size(path):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return 0
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.geteuid():
        raise ValueError("staging path is not an ordinary single-link file owned by the operator")
    return info.st_size


def staged_bytes(root, shard):
    final = root / shard.name
    path = final if final.exists() or final.is_symlink() else root / (shard.name + ".partial")
    size = file_size(path)
    if size > shard.size_bytes:
        raise ValueError(f"{shard.name}: existing data exceeds expected size")
    return size


def fetch_shard(root, root_fd, shard, curl, mounts):
    final = root / shard.name
    part = root / (shard.name + ".partial")
    if final.exists() or final.is_symlink():
        if verify_shard(root_fd, shard, mounts)["state"] != "verified":
            raise ValueError(f"{shard.name}: existing final file does not match the pinned manifest")
        return
    if file_size(part) > shard.size_bytes:
        raise ValueError(f"{shard.name}: partial file exceeds expected size")
    url = f"https://huggingface.co/{REPOSITORY}/resolve/{REVISION}/{QUANT}/{shard.name}"
    if file_size(part) != shard.size_bytes:
        completed = subprocess.run([
            curl, "--disable", "--fail", "--location", "--max-redirs", "5",
            "--proto", "=https", "--proto-redir", "=https", "--connect-timeout", "20",
            "--speed-time", "60", "--speed-limit", "1024", "--retry", "2",
            "--continue-at", "-", "--output", str(part), "--silent", url,
        ], check=False).returncode
        if completed:
            raise ValueError(f"{shard.name}: download stopped (curl {completed}); partial file retained")
    if file_size(part) != shard.size_bytes:
        raise ValueError(f"{shard.name}: partial file is incomplete")
    part_fd = os.open(part, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        with os.fdopen(part_fd, "rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
            if digest != shard.sha256:
                raise ValueError(f"{shard.name}: SHA-256 mismatch; partial file retained")
            os.fsync(stream.fileno())
        os.link(part, final, follow_symlinks=False)
        part.unlink()
        os.fsync(root_fd)
    except FileExistsError as exc:
        raise ValueError(f"{shard.name}: final file appeared during transfer") from exc


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--only", type=int, choices=range(1, len(SHARDS) + 1))
    parser.add_argument("--reserve-gib", type=int, default=16)
    parser.add_argument("--expected-instance", type=int, help="require agreement with the local Vast label")
    parser.add_argument("--provider-headroom-bytes", type=int,
                        help="independently observed headroom above the visible cgroup subtree")
    parser.add_argument("--apply", action="store_true", help="Download into this directory; default is a capacity plan")
    args = parser.parse_args()
    os.umask(0o077)
    if (args.reserve_gib < 0 or args.expected_instance is not None and args.expected_instance <= 0
            or args.provider_headroom_bytes is not None and args.provider_headroom_bytes < 0):
        parser.error("amounts must be non-negative and the instance must be positive")
    root = args.root.absolute()
    chosen = SHARDS if args.only is None else (SHARDS[args.only - 1],)
    try:
        identity = instance_identity()
        if args.expected_instance is not None and identity["instance_id"] != args.expected_instance:
            raise ValueError("local instance label disagrees with the requested target")
        root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            info = os.fstat(root_fd)
            if root.resolve() != root or info.st_uid != os.geteuid() or info.st_mode & 0o077:
                raise ValueError("use an existing owner-only real staging directory (0700)")
            mounts = mount_types()
            filesystem_type = filesystem(root_fd, mounts)
            if filesystem_type not in ALLOWED_FS:
                raise ValueError("destination is not a supported local disk or tmpfs")
            reserve = args.reserve_gib * GIB
            missing = sum(shard.size_bytes - staged_bytes(root, shard) for shard in chosen)
            available = check_capacity(root, root_fd, filesystem_type, missing, reserve, identity,
                                       args.provider_headroom_bytes)
            note("PLAN", shard_count=len(chosen), filesystem=filesystem_type,
                 remaining_bytes=missing, reserve_bytes=reserve, free_bytes=available)
            if not args.apply:
                return 0
            curl = shutil.which("curl")
            if not curl or sys.version_info < (3, 11):
                raise ValueError("staging requires curl and Python >= 3.11")
            lock_fd = os.open(".nox-model-stage.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600, dir_fd=root_fd)
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                missing = sum(shard.size_bytes - staged_bytes(root, shard) for shard in chosen)
                for shard in chosen:
                    check_capacity(root, root_fd, filesystem_type, missing, reserve, identity,
                                   args.provider_headroom_bytes)
                    done = staged_bytes(root, shard)
                    fetch_shard(root, root_fd, shard, curl, mounts)
                    missing -= shard.size_bytes - done
                    note("SHARD_VERIFIED", name=shard.name)
            finally:
                os.close(lock_fd)
            note("STAGED", shard_count=len(chosen), all_shards=args.only is None, active_model_changed=False)
            return 0
        finally:
            os.close(root_fd)
    except (OSError, ValueError) as exc:
        note("HOLD", reason=str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
