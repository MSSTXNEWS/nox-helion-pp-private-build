#!/usr/bin/env python3
"""Emit a detached, source-only NOX release receipt to stdout.

Verifies the archive CRC and its complete SHA256SUMS manifest. Optional local
unittest and queue-binding records are linked by digest. No code from the ZIP
is executed, and no local or remote state is changed.
"""

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
from zipfile import BadZipFile, ZipFile


MAX_ARCHIVE_BYTES = 32 * 1024**2
MAX_RECEIPT_BYTES = 2 * 1024**2
HEX = re.compile(r"[0-9a-f]{64}\Z")
GIT = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64})\Z")
MANIFEST_ENTRY = re.compile(r"([0-9a-f]{64}) [ *](.+)\Z")
TEST_SUMMARY = re.compile(r"Ran ([1-9]\d*) tests? in [0-9.]+s\Z")


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_bounded(path, limit):
    with path.open("rb") as handle:
        payload = handle.read(limit + 1)
    if len(payload) > limit:
        raise ValueError("input exceeds the supported size")
    return payload


def safe_path(name):
    path = PurePosixPath(name)
    parts = name.split("/")
    if not name or path.is_absolute() or any(part in ("", ".", "..") for part in parts):
        return False
    return not any(char in name for char in ("\\", ":", "\x00", "\r", "\n"))


def inspect_archive(payload):
    with ZipFile(io.BytesIO(payload)) as archive:
        members = archive.infolist()
        if not 2 <= len(members) <= 256 or sum(member.file_size for member in members) > MAX_ARCHIVE_BYTES:
            raise ValueError("archive member count or expanded size outside supported bounds")
        names = [member.filename for member in members]
        if len(set(name.casefold() for name in names)) != len(names):
            raise ValueError("archive contains duplicate or case-conflicting members")
        roots = {PurePosixPath(name).parts[0] for name in names if safe_path(name)}
        if len(roots) != 1 or any(
            not safe_path(member.filename)
            or len(PurePosixPath(member.filename).parts) < 2
            or stat.S_IFMT(member.external_attr >> 16) not in (0, stat.S_IFREG)
            or member.flag_bits & 1
            for member in members
        ):
            raise ValueError("archive must contain only safe unencrypted files under one root")
        if archive.testzip() is not None:
            raise ValueError("archive CRC failed")
        root = next(iter(roots))
        manifest_name = f"{root}/SHA256SUMS"
        if manifest_name not in names:
            raise ValueError("archive SHA256SUMS is missing")
        manifest = archive.read(manifest_name)
        declared = {}
        for line in manifest.decode("utf-8").splitlines():
            match = MANIFEST_ENTRY.fullmatch(line)
            if not match:
                raise ValueError("malformed SHA256SUMS entry")
            digest, name = match.groups()
            if not safe_path(name) or name in declared:
                raise ValueError("unsafe or duplicate SHA256SUMS entry")
            declared[name] = digest
        actual = {name.removeprefix(f"{root}/") for name in names if name != manifest_name}
        if actual != declared.keys():
            raise ValueError("SHA256SUMS and ZIP members do not match exactly")
        for name, expected in declared.items():
            if sha256(archive.read(f"{root}/{name}")) != expected:
                raise ValueError("archive member SHA-256 differs from manifest")
        return {
            "bytes": len(payload),
            "sha256": sha256(payload),
            "zip_members": len(members),
            "zip_crc": "PASS",
            "manifest_entries": len(declared),
            "manifest_sha256": sha256(manifest),
        }


def inspect_unittest_log(payload, supplied_archive_sha256, exact_archive_sha256):
    if supplied_archive_sha256 != exact_archive_sha256:
        raise ValueError("test log must explicitly reference the exact archive SHA-256")
    lines = [line.strip() for line in payload.decode("utf-8").splitlines() if line.strip()]
    matches = [match for line in lines if (match := TEST_SUMMARY.fullmatch(line))]
    if len(matches) != 1 or len(lines) < 2 or lines[-2] != matches[0].group() or lines[-1] != "OK":
        raise ValueError("test log must contain one successful complete unittest summary")
    return {
        "status": "SUPPLIED_LOCAL_TEST_LOG_PINNED",
        "tests_reported_passed": int(matches[0].group(1)),
        "log_sha256": sha256(payload),
        "tested_archive_sha256": supplied_archive_sha256,
    }


def inspect_binding_receipt(payload, expected_sha256):
    if expected_sha256 != sha256(payload):
        raise ValueError("queue-binding receipt SHA-256 mismatch")
    result = json.loads(payload, object_pairs_hook=unique_object)
    if not (
        isinstance(result, dict)
        and result.get("schema") == "NOX_NATIVE_QUEUE_BINDING_V1"
        and result.get("state") == "BINDINGS_COUNTED"
        and result.get("native_execution_enabled") is False
        and result.get("acceptance_verified") is False
        and all(isinstance(result.get(key), str) and HEX.fullmatch(result[key]) for key in ("snapshot_sha256", "catalog_sha256"))
    ):
        raise ValueError("queue-binding receipt is not a completed source-only audit")
    fields = ("snapshot_records", "unique_native_ids", "identical_duplicate_rows", "original295_catalog_count",
              "original295_ids_matched", "original295_direct_rows", "original295_linked_rows", "outside_original295_rows")
    if any(type(result.get(key)) is not int or result[key] < 0 for key in fields):
        raise ValueError("queue-binding receipt is missing exact nonnegative counters")
    if (
        result["original295_catalog_count"] != 295
        or not result["original295_direct_rows"] <= result["original295_ids_matched"] <= min(
            295, result["original295_direct_rows"] + result["original295_linked_rows"]
        )
        or result["original295_direct_rows"] + result["original295_linked_rows"] + result["outside_original295_rows"] != result["unique_native_ids"]
        or result["unique_native_ids"] + result["identical_duplicate_rows"] != result["snapshot_records"]
    ):
        raise ValueError("queue-binding receipt counters do not reconcile")
    return {
        "status": "DETACHED_ROUTING_RECEIPT_PINNED",
        "receipt_sha256": expected_sha256,
        "snapshot_sha256": result["snapshot_sha256"],
        "catalog_sha256": result["catalog_sha256"],
        "snapshot_authority": "NOT_ATTESTED_OFFLINE",
        **{key: result[key] for key in fields},
    }


def unique_object(pairs):
    fields = dict(pairs)
    if len(fields) != len(pairs):
        raise ValueError("queue-binding receipt contains duplicate JSON keys")
    return fields


def make_receipt(archive, source_commit, *, test_log=None, tested_archive_sha256=None,
                 binding_receipt=None, binding_sha256=None):
    if not isinstance(source_commit, str) or not GIT.fullmatch(source_commit):
        raise ValueError("a full lowercase source commit hash is required")
    if (test_log is None) != (tested_archive_sha256 is None):
        raise ValueError("provide both the test log and tested archive SHA-256")
    if (binding_receipt is None) != (binding_sha256 is None):
        raise ValueError("provide both the queue-binding receipt and its expected SHA-256")
    release = inspect_archive(archive)
    summary = {
        "schema": "nox_detached_release_receipt_v1",
        "stage": "SOURCE_ONLY",
        "declared_source_commit": source_commit,
        "archive": release,
        "source_tests": {"status": "NO_TEST_LOG_SUPPLIED"},
        "old_id_trace": {"status": "NO_ROUTING_RECEIPT_SUPPLIED"},
        "native_execution_enabled": False,
        "native_deployed": False,
        "original_acceptance_added": 0,
    }
    if test_log is not None:
        summary["source_tests"] = inspect_unittest_log(test_log, tested_archive_sha256, release["sha256"])
    if binding_receipt is not None:
        summary["old_id_trace"] = inspect_binding_receipt(binding_receipt, binding_sha256)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--unittest-log", type=Path)
    parser.add_argument("--tested-archive-sha256")
    parser.add_argument("--queue-binding-receipt", type=Path)
    parser.add_argument("--queue-binding-sha256")
    args = parser.parse_args()
    try:
        summary = make_receipt(
            read_bounded(args.archive, MAX_ARCHIVE_BYTES), args.source_commit,
            test_log=read_bounded(args.unittest_log, MAX_RECEIPT_BYTES) if args.unittest_log else None,
            tested_archive_sha256=args.tested_archive_sha256,
            binding_receipt=read_bounded(args.queue_binding_receipt, MAX_RECEIPT_BYTES) if args.queue_binding_receipt else None,
            binding_sha256=args.queue_binding_sha256,
        )
    except (BadZipFile, OSError, UnicodeError, ValueError, RuntimeError) as error:
        reason = str(error) if type(error) is ValueError else type(error).__name__
        print(json.dumps({"stage": "HOLD", "reason": reason, "original_acceptance_added": 0}))
        return 2
    print(json.dumps(summary, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
