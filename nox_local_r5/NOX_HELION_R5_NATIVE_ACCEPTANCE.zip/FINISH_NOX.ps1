[CmdletBinding()]
param(
  [string]$InstallRoot = 'C:\NOX_HELION\NOX_NEW',
  [switch]$NoLaunch
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$ProgressPreference = 'SilentlyContinue'
$package = $PSScriptRoot
$source = Join-Path $package 'src'
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$releases = Join-Path $InstallRoot 'releases'
$release = Join-Path $releases "NOX_R5_$stamp"
$previousRelease = Join-Path $InstallRoot 'release'
$originalModel = 'nox-qwen-clean:latest'
$endpoint = 'http://127.0.0.1:11436'
$modelStorage = 'C:\NOX_OLLAMA_CLEAN\models'
$buildOK = $false
$windowOK = $false
$providerOK = $false
$providerAnswer = ''
$databaseOK = $false
$webviewOK = $false
$knowledgeOK = $false
$nativeOK = $false
$nativeReceipt = $null
$exeSha = ''
$runErr = $null

function Assert-Package {
  $files = @('App.xaml','App.xaml.cs','MainWindow.xaml','MainWindow.xaml.cs','KnowledgeStore.cs','NOX.HELION.csproj','index.html','icon.ico')
  $manifestFile = Join-Path $package 'MANIFEST_SHA256.json'
  if (!(Test-Path -LiteralPath $manifestFile -PathType Leaf)) { throw 'NOX_PACKAGE_MANIFEST_MISSING' }
  $manifest = Get-Content -LiteralPath $manifestFile -Raw | ConvertFrom-Json
  foreach ($name in $files) {
    $path = Join-Path $source $name
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw "NOX_SOURCE_MISSING: $name" }
    $prop = 'src/' + $name
    $expected = [string]$manifest.files.$prop
    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if (!$expected -or $expected -cne $actual) { throw "NOX_SOURCE_HASH_MISMATCH: $name" }
  }
}
function Get-Engine {
  try { return Invoke-RestMethod "$endpoint/api/tags" -TimeoutSec 3 }
  catch { return $null }
}
function Ensure-Engine {
  $tags = Get-Engine
  if ($null -eq $tags) {
    if (!(Test-Path -LiteralPath $modelStorage -PathType Container)) { throw 'EXISTING_QWEN_STORE_MISSING; NO DOWNLOAD WILL BE ATTEMPTED' }
    if (Get-NetTCPConnection -LocalPort 11436 -State Listen -ErrorAction SilentlyContinue) {
      throw 'PORT_11436_OCCUPIED; NO SERVICE WAS STOPPED'
    }
    $cmd = Get-Command ollama -ErrorAction Stop
    $oldHost = $env:OLLAMA_HOST; $oldModels = $env:OLLAMA_MODELS
    try {
      $env:OLLAMA_HOST = '127.0.0.1:11436'
      $env:OLLAMA_MODELS = $modelStorage
      Start-Process -FilePath $cmd.Source -ArgumentList 'serve' -WindowStyle Minimized | Out-Null
    } finally {
      $env:OLLAMA_HOST = $oldHost
      $env:OLLAMA_MODELS = $oldModels
    }
    for ($i = 0; $i -lt 24; $i++) {
      Start-Sleep -Milliseconds 750
      $tags = Get-Engine
      if ($null -ne $tags) { break }
    }
  }
  if ($null -eq $tags) { throw 'QWEN_SERVER_NOT_READY' }
  $names = @($tags.models | ForEach-Object { $_.name })
  if ($names -notcontains $originalModel) { throw 'QWEN_NOT_REGISTERED_ON_11436' }
}
function Test-Qwen {
  $payload = @{
    model = $originalModel; prompt = 'What is 3 plus 5? Answer with the numeral only.';
    stream = $false; keep_alive = '10m'; options = @{ num_predict = 18 }
  } | ConvertTo-Json -Depth 5
  $r = Invoke-RestMethod "$endpoint/api/generate" -Method Post -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($payload)) -TimeoutSec 180
  if (!$r.done -or [string]::IsNullOrWhiteSpace($r.response)) { throw 'QWEN_NO_COMPLETED_RESPONSE' }
  return [string]$r.response
}

Write-Host 'NOX HELION · FINAL LOCAL BUILD + REALITY CHECK' -ForegroundColor Cyan
Write-Host 'Source is immutable; old releases and local learning are not touched.'
try {
  Assert-Package
  if (!(Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'DOTNET_8_SDK_MISSING' }
  $v = (& dotnet --version).Trim()
  if ($LASTEXITCODE -ne 0 -or [int]($v.Split('.')[0]) -lt 8) { throw 'DOTNET_8_OR_NEWER_REQUIRED' }
  New-Item -ItemType Directory -Force -Path $release | Out-Null
  Write-Host "BUILDING: $release" -ForegroundColor Cyan
  & dotnet publish (Join-Path $source 'NOX.HELION.csproj') -c Release -r win-x64 --self-contained false -o $release
  if ($LASTEXITCODE -ne 0) { throw "DOTNET_PUBLISH_FAILED:$LASTEXITCODE" }
  $exe = Join-Path $release 'NOX.HELION.exe'
  if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'EXE_NOT_CREATED' }
  $exeSha = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash
  Copy-Item -LiteralPath (Join-Path $package 'START_NOX.ps1') -Destination $release -Force
  $buildOK = $true
  Write-Host 'EXE COMPILED AND HASHED' -ForegroundColor Green
  try {
    if (!$NoLaunch) { Ensure-Engine }
    Write-Host 'LOCAL MODEL FOUND; native end-to-end inference will prove its execution.' -ForegroundColor Cyan
  } catch {
    $runErr = "LOCAL_QWEN: $($_.Exception.Message)"
    Write-Host $runErr -ForegroundColor Yellow
  }
  if (!$NoLaunch) {
    # Native smoke uses the compiled Windows binary, live WebView2 button events,
    # local Qwen streaming and real SQLite. A source-only PASS cannot bypass it.
    $runId = 'NOX-R5-' + $stamp + '-' + (Get-Random -Minimum 100000 -Maximum 999999)
    $smokeStart = [DateTime]::UtcNow
    $smokeProcess = Start-Process -FilePath $exe -WorkingDirectory $release -ArgumentList @('--nox-selftest', "--nox-runid=$runId") -PassThru
    $receiptPath = Join-Path $env:LOCALAPPDATA ("NOX_HELION\native_selftest_$($smokeProcess.Id).json")
    try {
      Wait-Process -Id $smokeProcess.Id -Timeout 350 -ErrorAction Stop
      $smokeProcess.Refresh()
      if (Test-Path -LiteralPath $receiptPath -PathType Leaf) {
        $nativeReceipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
        $receiptTime = [DateTimeOffset]::Parse([string]$nativeReceipt.checkedAt).UtcDateTime
        $nativeOK = (
          $nativeReceipt.schema -eq 'NOX_WPF_E2E_NATIVE_R5_V1' -and
          $nativeReceipt.runId -ceq $runId -and
          [int]$nativeReceipt.pid -eq $smokeProcess.Id -and
          $nativeReceipt.nativeCoreAccepted -eq $true -and
          $smokeProcess.ExitCode -eq 0 -and
          $receiptTime -ge $smokeStart -and
          [string]::Equals([string]$nativeReceipt.exe, [string]$exe, [StringComparison]::OrdinalIgnoreCase) -and
          [string]::Equals([string]$nativeReceipt.exeSha256, [string]$exeSha, [StringComparison]::OrdinalIgnoreCase)
        )
      }
      $providerOK = $nativeOK -and $nativeReceipt.checks.real_chat_from_webview_to_qwen_to_sqlite -eq 'PASS'
      if ($providerOK) { $providerAnswer = 'Confirmed by real WebView2 -> Qwen -> SQLite receipt' }
      if ($nativeOK) { Write-Host 'NATIVE E2E: PASS' -ForegroundColor Green } else { Write-Host 'NATIVE E2E: HOLD' -ForegroundColor Yellow }
    } catch {
      $runErr = "NATIVE_E2E_HOLD: $($_.Exception.Message)"
      Write-Host $runErr -ForegroundColor Yellow
      if (!$smokeProcess.HasExited) { try { Stop-Process -Id $smokeProcess.Id -Force } catch {} }
    }

    if ($nativeOK) {
      # Only after complete real acceptance of chat/STOP/SQLite, launch user UI.
      $appProcess = Start-Process -FilePath $exe -WorkingDirectory $release -PassThru
      for ($i = 0; $i -lt 25; $i++) {
        Start-Sleep -Milliseconds 500
        $appProcess.Refresh()
        if ($appProcess.HasExited) { break }
        if ($appProcess.MainWindowHandle -ne [IntPtr]::Zero) { $windowOK = $true; break }
      }
      if ($windowOK) { Write-Host "WINDOW OPEN: PID=$($appProcess.Id)" -ForegroundColor Green }
      else { $runErr = 'WPF_RUNTIME_WINDOW_NOT_VERIFIED' }
      $database = Join-Path $env:LOCALAPPDATA 'NOX_HELION\chat.sqlite3'
      $databaseOK = (Test-Path -LiteralPath $database -PathType Leaf)
      $runtimeReceipt = Join-Path $env:LOCALAPPDATA 'NOX_HELION\runtime_ready.json'
      $runtime = $null
      for ($i = 0; $i -lt 25; $i++) {
        if (Test-Path $runtimeReceipt -PathType Leaf) {
          try {
            $runtime = Get-Content $runtimeReceipt -Raw | ConvertFrom-Json
            if ($runtime.schema -eq 'NOX_WPF_WEBVIEW2_RUNTIME_V1' -and
                [int]$runtime.pid -eq $appProcess.Id -and
                $runtime.webview2Ready -eq $true -and
                [string]::Equals([string]$runtime.assemblyPath, [string]$exe, [StringComparison]::OrdinalIgnoreCase)) {
              $webviewOK = $true
              break
            }
          } catch { }
        }
        Start-Sleep -Milliseconds 500
      }
      if ($webviewOK -and $null -ne $runtime -and $null -ne $runtime.indexedKnowledge) {
        $knowledgeOK = ([int64]$runtime.indexedKnowledge.documents -ge 0 -and
                        [int64]$runtime.indexedKnowledge.chunks -ge 0 -and
                        $runtime.indexedKnowledge.localOnly -eq $true)
      }
    }
  }
  # Single receipt records only what was really observed on this PC.
  @{
    product = 'NOX HELION R5'; timestamp_utc = (Get-Date).ToUniversalTime().ToString('o');
    exe = $exe; sha256 = $exeSha; source_manifest = 'MANIFEST_SHA256.json';
    checks = @{
      source_hashes = 'PASS'; dotnet_publish = 'PASS';
      qwen_inference = $(if ($providerOK) {'PASS'} else {'HOLD'});
      wpf_main_window = $(if ($windowOK) {'PASS'} else {'NOT_VERIFIED'});
      webview2_runtime_receipt = $(if ($webviewOK) {'PASS'} else {'NOT_VERIFIED'});
      sqlite_file_exists = $(if ($databaseOK) {'PASS'} else {'NOT_VERIFIED'});
      knowledge_fts_runtime = $(if ($knowledgeOK) {'PASS'} else {'NOT_VERIFIED'});
      stop_ui = $(if ($nativeOK) {'PASS'} else {'HOLD'}); memory_ui = $(if ($nativeOK) {'PASS'} else {'HOLD'}); native_e2e = $(if ($nativeOK) {'PASS'} else {'HOLD'}); d02_visual_acceptance = 'NOT_TESTED';
      full_autonomous_development = 'NOT_IMPLEMENTED'
    };
    native_receipt = $nativeReceipt; provider_response = $providerAnswer; error = $runErr; accepted_full_release = $false;
    previous_release_preserved = (Test-Path $previousRelease)
  } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $release 'BUILD_RECEIPT.json') -Encoding UTF8
  Write-Host "NOX_WINDOWS_BUILD_COMPLETE $exe" -ForegroundColor Green
  Write-Host "SHA256=$exeSha" -ForegroundColor Green
  if ($NoLaunch) {
    Write-Host 'RUNTIME_NOT_TESTED: -NoLaunch selected. Not a verified installation.' -ForegroundColor Yellow
  } elseif ($nativeOK -and $windowOK -and $webviewOK -and $providerOK -and $databaseOK -and $knowledgeOK) {
    Write-Host 'NOX_LOCAL_RUNTIME_CORE_VERIFIED (NOT FULL V16 ACCEPTANCE)' -ForegroundColor Green
  } else {
    Write-Host 'NOX_LOCAL_RUNTIME_HOLD: CHECK BUILD_RECEIPT.json' -ForegroundColor Red
    exit 2
  }
} catch {
  Write-Host "NOX_BUILD_FAILED $($_.Exception.Message)" -ForegroundColor Red
  Write-Host 'All existing NOX releases, models and user data are left unchanged.' -ForegroundColor Yellow
  exit 1
}
