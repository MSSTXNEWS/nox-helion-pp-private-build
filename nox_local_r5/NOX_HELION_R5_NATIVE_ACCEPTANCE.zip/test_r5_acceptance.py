"""Validate the native acceptance protocol's fail-closed binding and syntax.
This is NOT a replacement for an actual Windows WPF smoke run.
"""
from pathlib import Path
from pygments import lex
from pygments.lexers.dotnet import CSharpLexer
from pygments.token import Token
import json, hashlib, xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent
cs=(p/'src/MainWindow.xaml.cs').read_text(encoding='utf-8')
ps=(p/'FINISH_NOX.ps1').read_text(encoding='utf-8')
app=(p/'src/App.xaml.cs').read_text(encoding='utf-8')
assert 'NOX_WPF_E2E_NATIVE_R5_V1' in cs and 'NOX_WPF_E2E_NATIVE_R5_V1' in ps
assert 'stopSignalCount' in cs and 'lastGenerationStopped' in cs
assert "stop_ui = $(if ($nativeOK) {'PASS'} else {'HOLD'})" in ps
assert 'real_webview_stop_cancel_no_partial_persistence' in cs
assert 'real_chat_from_webview_to_qwen_to_sqlite' in cs and 'real_chat_from_webview_to_qwen_to_sqlite' in ps
assert 'exeSha256' in cs and 'exeSha256' in ps
assert 'runId' in cs and 'runId' in ps
assert 'Get-Random' in ps and '--nox-runid=' in ps and '--nox-runid=' in cs
assert 'Set-StrictMode -Version Latest' in ps
assert 'fullV16Accepted = false' in cs
assert 'accepted_full_release = $false' in ps
assert 'NOX_HELION_DESKTOP_SELFTEST_R5' in app
assert 'NOX_HELION_DESKTOP_SINGLE_HOST_R5' in app
# Check proper brace nesting without interpreting braces inside comments or strings.
for path in [p/'src/MainWindow.xaml.cs',p/'src/KnowledgeStore.cs',p/'src/App.xaml.cs']:
    stack=[]
    source=path.read_text(encoding='utf-8')
    # Pygments' C# lexer predates C# 11 raw triple-quoted strings; mask them.
    source=__import__('re').sub(r'"""[\s\S]*?"""', '"masked raw string"', source)
    for tok, text in lex(source,CSharpLexer()):
        if tok in Token.Comment or tok in Token.Literal.String:continue
        if tok in Token.Punctuation:
            for ch in text:
                if ch in '{([':stack.append(ch)
                elif ch in '})]':
                    assert stack, f'unpaired closing token: {path} {ch}'
                    opench=stack.pop()
                    assert {'}':'{',')':'(',']':'['}[ch]==opench, f'bad token nesting {path}'
    assert not stack, f'unclosed tokens {path}: {stack[-8:]}'
for x in ('App.xaml','MainWindow.xaml','NOX.HELION.csproj'):
    ET.parse(p/'src'/x)
print('R5 NATIVE ACCEPTANCE CONTRACT: PASS (source only, Windows run still required)')
