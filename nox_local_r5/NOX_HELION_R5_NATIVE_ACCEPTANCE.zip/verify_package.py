#!/usr/bin/env python3
"""Offline package QA: content integrity, action-to-handler contracts, source invariants.
Not a replacement for dotnet compilation or Windows UIA/real Qwen tests.
"""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re,sys,subprocess,tempfile
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text('utf-8'))
assert manifest['schema']=='NOX_HELION_R5_SOURCE_SHA256_V1'
for name,expected in manifest['files'].items():
    path=root/name
    assert path.is_file(),f'NO_SUCH_FILE {name}'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,f'HASH_MISMATCH {name}'
cs=(root/'src/MainWindow.xaml.cs').read_text('utf-8')
html=(root/'src/index.html').read_text('utf-8')
for a in ['stop','chat','history','tasks.list','tasks.add','tasks.toggle','settings.get','settings.put','health','training','memory.search','system.status']:
    assert f'case "{a}"' in cs,f'NATIVE_HANDLER_MISSING {a}'
for a in ['consciousness','atlas','reflection','nexus','forge','core','voice','persona']:
    assert f'data-route="{a}"' in html and f'data-panel="{a}"' in html,f'ROUTE_MISSING {a}'
for marker in ['SqliteConnection','PersistChat','CancellationTokenSource','ReadHistory','GetTrainingState','ImportLegacyJsonlIfNeeded','NavigationStarting']:
    assert marker in cs,f'BACKEND_CONTRACT_MISSING {marker}'
assert 'nox-qwen-clean:latest' in cs
assert '127.0.0.1:11436' in cs
assert 'RunNativeSelfTestAsync()' in cs
assert 'native_e2e' in (root/'FINISH_NOX.ps1').read_text(encoding='utf-8')
assert '<PackageReference Include="Microsoft.Web.WebView2"' in (root/'src/NOX.HELION.csproj').read_text('utf-8')
assert '<PackageReference Include="Microsoft.Data.Sqlite"' in (root/'src/NOX.HELION.csproj').read_text('utf-8')
for forbidden in ['Tkinter','mockModelResponse','fake_PASS','Process.Start("cmd.exe"']:
    assert forbidden not in cs,f'FORBIDDEN {forbidden}'
assert (root/'src/KnowledgeStore.cs').is_file()
assert (root/'START_NOX.ps1').is_file()
assert (root/'FINISH_NOX.cmd').is_file()
script=re.search(r'<script>(.*?)</script>',html,re.S)
assert script
with tempfile.TemporaryDirectory() as tmp:
    js=Path(tmp)/'ui.js';js.write_text(script.group(1),encoding='utf-8')
    p=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
    assert p.returncode==0, p.stderr
print('SOURCE_PACKAGE_QA=PASS')
print('WINDOWS_COMPILATION=NOT_TESTED')
print('LIVE_INFERENCE=NOT_TESTED_BY_THIS_TEST')
print('WINDOWS_UI_ACCEPTANCE=NOT_TESTED')
