using System;
using System.Threading;
using System.Windows;

namespace Nox;

public partial class App : Application
{
    private Mutex? _singleInstance;
    private bool _ownsMutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        // Smoke acceptance is deliberately isolated from the owner's live NOX
        // instance. It never forces the user to close an existing application.
        bool smoke = Array.Exists(e.Args, arg => arg.Equals("--nox-selftest", StringComparison.OrdinalIgnoreCase) ||
            arg.Equals("--nox-ui-selftest", StringComparison.OrdinalIgnoreCase));
        string mutexName = smoke ? @"Local\NOX_HELION_DESKTOP_SELFTEST_R5" : @"Local\NOX_HELION_DESKTOP_SINGLE_HOST_R5";
        _singleInstance = new Mutex(true, mutexName, out var createdNew);
        _ownsMutex = createdNew;
        if (!createdNew)
        {
            MessageBox.Show("NOX HELION уже запущен. Второй процесс не создан.", "NOX HELION");
            Shutdown(0);
            return;
        }
        base.OnStartup(e);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        if (_ownsMutex) _singleInstance?.ReleaseMutex();
        _singleInstance?.Dispose();
        base.OnExit(e);
    }
}
