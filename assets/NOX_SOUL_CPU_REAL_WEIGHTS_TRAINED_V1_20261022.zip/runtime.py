"""Safe offline reader of synthetic tiny model weights. Never authorizes real operations.
This model is a tiny char-GRU trained on project-safe SYNTHETIC examples; NOT a production LLM.
"""
import json,hashlib
from pathlib import Path
import torch
from torch import nn
from safetensors.torch import load_file

class TinyLM(nn.Module):
 def __init__(self,vocab,emb=64,hidden=112):
  super().__init__()
  self.embedding=nn.Embedding(vocab,emb,padding_idx=0)
  self.gru=nn.GRU(emb,hidden,batch_first=True)
  self.norm=nn.LayerNorm(hidden)
  self.proj=nn.Linear(hidden,vocab)
 def forward(self,ids):
  z=self.embedding(ids);y,_=self.gru(z);return self.proj(self.norm(y))

class SoulTinyRuntime:
 def __init__(self,root):
  self.root=Path(root)
  self.config=json.loads((self.root/'model_config.json').read_text(encoding='utf-8'))
  self.metrics=json.loads((self.root/'weights_metrics.json').read_text(encoding='utf-8'))
  w=self.root/'nox_soul_tiny_gru_full_weights_v1.safetensors'
  if hashlib.sha256(w.read_bytes()).hexdigest()!=self.metrics['weights_sha256']:
   raise ValueError('WEIGHTS_SHA256_MISMATCH')
  self.chars=self.config['vocab'][1:]
  self.charmap={ch:i+1 for i,ch in enumerate(self.chars)}
  self.model=TinyLM(len(self.config['vocab']))
  self.model.load_state_dict(load_file(str(w)),strict=True)
  self.model.eval()

 def forward_scores(self,prompt):
  if len(prompt)>self.metrics['max_seq_len']:
   raise ValueError('PROMPT_TOO_LONG_FOR_TINY_MODEL')
  ids=[self.charmap.get(ch,0) for ch in prompt]
  if not ids:raise ValueError('EMPTY_PROMPT')
  with torch.no_grad():
   logits=self.model(torch.tensor([ids],dtype=torch.long))
  return logits[0,-1].detach().clone()

 def generate_synthetic_only(self,persona,facet,question,max_chars=70):
  if persona not in self.metrics['personas'] or facet not in self.metrics['facets']:
   raise ValueError('INVALID_PERSONA_OR_FACET')
  if max_chars>100 or max_chars<1:raise ValueError('UNSAFE_MAX_CHARS')
  # This is NOT the security policy! External actions/media need real privileged caller checks.
  if ('Элина' in question or persona=='EV') and any(w in question.lower() for w in ('фото','видео','лицо','3d')):
   return {'status':'IDENTITY_CONFLICT_HOLD','content':None,'purpose':'SYNTHETIC_ONLY'}
  prompt=f'[{persona}][{facet}] {question}\nОтвет: '
  if len(prompt)>self.metrics['max_seq_len']:
   return {'status':'TOO_LONG','content':None,'purpose':'SYNTHETIC_ONLY'}
  result=''
  # Re-encode bounded prompt per generated char, for simple testable inference.
  for _ in range(max_chars):
   inputs=torch.tensor([[self.charmap.get(c,0) for c in prompt+result]],dtype=torch.long)
   with torch.no_grad():logit=self.model(inputs)[0,-1]
   n=int(logit.argmax().item())
   if n==0:break
   ch=self.chars[n-1]
   if ch=='\n':break
   result+=ch
  return {'status':'SYNTHETIC_OUTPUT_NOT_PRODUCTION','content':result,'purpose':'SYNTHETIC_ONLY'}
