#!/usr/bin/env python3
"""Train a small *real* char-level GRU language model from scratch on new synthetic persona-learning examples.
This is a sandbox proof of physical neural weights, NOT ChatGPT/Qwen/LoRA, not approved canonical traits.
No Drive records, books, S04 datasets, or private data are loaded.
"""
import os,json,random,hashlib,math,copy
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
from safetensors.torch import save_file,load_file

ROOT=Path(__file__).resolve().parent
SEED=20261022
random.seed(SEED);np.random.seed(SEED);torch.manual_seed(SEED)
torch.set_num_threads(2)

PERSONAS={
 'KV':('Кайрен Восс','планирование и последствия'),
 'AM':('Адриан Мерроу','проверка доказательств'),
 'LA':('Леон Ардис','проектирование решений'),
 'EV':('Элина Вейл','редактура и границы общения'),
 'KW':('Кассиен Вейр','критический разбор рисков')}
FACETS={
 'HF01':('Как осмыслить решение?', 'Сверю факты, собственную неопределённость и последствия.'),
 'HF02':('Как ответить на эмоцию собеседника?', 'Отражу настроение бережно; это модель реакции, не переживание.'),
 'HF03':('Как сохранить характер?', 'Учитываю устойчивый стиль, решения владельца и историю.'),
 'HF04':('Как восстановить память?', 'Сверю эпизод с источником и не смешаю частные записи.'),
 'HF05':('Как проверить знание?', 'Назову источник и отмечу непроверенный вывод.'),
 'HF06':('Как стать лучше?', 'Сравню тест до и после, без прогресса верну прежнюю версию.'),
 'HF07':('Как выполнить рабочую задачу?', 'Построю проверяемый план и сохраню результат, а не обещание.'),
 'HF08':('Как вести диалог?', 'Отвечу по существу, уточню только необходимое.')}
TOPICS=['сегодня','на встрече','в беседе','после ошибки','в новом проекте','при споре','для команды','при сомнении','для друга','в необычной ситуации','после перезапуска','на прогулке']
TEMPLATES=[
 'Ситуация: {topic}. Вопрос: {question}',
 'Представь {topic}; объясни: {question}',
 'У меня задача {topic}. {question}',
 'Подскажи {topic}: {question}'
]
STYLE=['Начну с главного: {focus}.','Учитываю {focus}.','Полезный акцент: {focus}.','Мой фокус здесь — {focus}.']
rows=[]
for persona,(name,focus) in PERSONAS.items():
 for facet,(question,rule) in FACETS.items():
  for i,topic in enumerate(TOPICS):
   question_text=TEMPLATES[i%len(TEMPLATES)].format(topic=topic,question=question)
   answer=STYLE[(i+list(PERSONAS).index(persona))%len(STYLE)].format(focus=focus)+' '+rule
   prompt=f'[{persona}][{facet}] {question_text}\nОтвет: '
   text=prompt+answer+'\n'
   rows.append({'id':f'{persona}_{facet}_{i:02d}','persona':persona,'facet':facet,'topic_group':i,'prompt':prompt,'completion':answer+'\n','text':text,'origin':'NEW_SYNTHETIC_PRIVATE_FREE','approved_persona_traits':False,'training_permission':'SYNTHETIC_SELF_CONTAINED_ONLY','split':'test' if i in (9,11) else ('validation' if i==10 else 'train')})
train=[x for x in rows if x['split']=='train'];valid=[x for x in rows if x['split']=='validation'];held=[x for x in rows if x['split']=='test']
assert len(train)==360 and len(valid)==40 and len(held)==80
assert not ({x['topic_group'] for x in train}&{x['topic_group'] for x in valid+held})
with (ROOT/'dataset_manifest.jsonl').open('w',encoding='utf-8') as f:
 for x in rows:
  y={k:v for k,v in x.items() if k not in ('text',)}
  y['sha256']=hashlib.sha256(x['text'].encode()).hexdigest()
  f.write(json.dumps(y,ensure_ascii=False)+'\n')
# All text is newly synthesized. No training on proprietary material or canonical sensitive data.
chars=sorted(set(''.join(x['text'] for x in rows)))
vocab=['<PAD>']+chars
char2id={ch:i+1 for i,ch in enumerate(chars)}
V=len(vocab);MAXLEN=max(len(x['text']) for x in rows)
assert MAXLEN<260,(MAXLEN,V)

def batch(samples):
 # Token 0 = pad; model sees prompt AND answer; loss is evaluated only on completion tokens.
 X=torch.zeros((len(samples),MAXLEN-1),dtype=torch.long)
 Y=torch.zeros_like(X)
 MASK=torch.zeros_like(X,dtype=torch.float32)
 for i,row in enumerate(samples):
  ids=[char2id[z] for z in row['text']]
  n=len(ids)
  X[i,:n-1]=torch.tensor(ids[:-1]);Y[i,:n-1]=torch.tensor(ids[1:]);
  # shifted next char index >= length(prompt) is response
  MASK[i,len(row['prompt'])-1:n-1]=1
 return X,Y,MASK
tr=batch(train);va=batch(valid);te=batch(held)
class TinyLM(nn.Module):
 def __init__(self,vocab,emb=64,hidden=112):
  super().__init__()
  self.embedding=nn.Embedding(vocab,emb,padding_idx=0)
  self.gru=nn.GRU(emb,hidden,batch_first=True)
  self.norm=nn.LayerNorm(hidden)
  self.proj=nn.Linear(hidden,vocab)
 def forward(self,ids):
  z=self.embedding(ids);y,_=self.gru(z);return self.proj(self.norm(y))
model=TinyLM(V)
optim=torch.optim.AdamW(model.parameters(),lr=0.003,weight_decay=0.005)
def loss(data,eval_mode=False):
 x,y,mask=data
 out=model(x)
 raw=nn.functional.cross_entropy(out.reshape(-1,V),y.reshape(-1),reduction='none').reshape_as(y)
 return (raw*mask).sum()/mask.sum()
with torch.no_grad():
 model.eval();before_valid=float(loss(va));before_held=float(loss(te));model.train()
steps=300
history=[];best=float('inf');best_weights=None;best_optimizer=None;best_step=0
for step in range(1,steps+1):
 indices=torch.randint(0,len(train),(24,))
 data=tuple(t[indices] for t in tr)
 optim.zero_grad(set_to_none=True)
 l=loss(data);l.backward()
 nn.utils.clip_grad_norm_(model.parameters(),max_norm=1.0)
 optim.step()
 if step%30==0 or step==1:
  model.eval()
  with torch.no_grad():lv=float(loss(va))
  model.train();history.append({'step':step,'train_batch_loss':round(float(l.detach()),5),'validation_loss':round(lv,5)})
  if lv+0.0001<best:
   best=lv;best_step=step;best_weights={k:v.detach().cpu().contiguous().clone() for k,v in model.state_dict().items()}
   best_optimizer={name:{field:(value.detach().cpu().clone() if torch.is_tensor(value) else value) for field,value in optim.state[p].items()} for name,p in model.named_parameters()}
model.load_state_dict(best_weights);model.eval()
with torch.no_grad():after_valid=float(loss(va));after_held=float(loss(te))
assert math.isfinite(after_valid) and math.isfinite(after_held)
assert after_valid<before_valid and after_held<before_held,('MODEL_NO_GAIN',before_valid,after_valid,before_held,after_held)
path=ROOT/'nox_soul_tiny_gru_full_weights_v1.safetensors'
save_file({k:v.cpu().contiguous() for k,v in model.state_dict().items()},str(path))
optimizer_path=ROOT/'nox_soul_optimizer_state_v1.safetensors'
optimizer_tensors={}
for name,rec in best_optimizer.items():
 for field,value in rec.items():
  optimizer_tensors[f'{name}|{field}']=(value.contiguous() if isinstance(value,torch.Tensor) else torch.tensor(value))
save_file(optimizer_tensors,str(optimizer_path))
loaded=TinyLM(V)
loaded.load_state_dict(load_file(str(path)),strict=True)
loaded.eval()
with torch.no_grad():
 a=model(te[0]);b=loaded(te[0]);assert torch.allclose(a,b,atol=1e-7)
 nre=float(loss(te))
# Loss on raw test is a teacher-forced synthetic character metric, not independent blind human quality.
metrics={
 'task':'CHARACTER_LEVEL_NEXT_TOKEN_SYNTHETIC_PERSONA_POLICY_NOT_CHATGPT_NOT_LLM_EQUIVALENT',
 'physical_weights_trained':True,'is_fully_finetuned_tiny_model':True,'trained_base_model':'OWN_RANDOM_INIT_CPU_TINY_GRU',
 'external_model_weights_used':False,'lora_training':False,'verified_real_world_skill_gain':False,
 'model_structure':'nn.Embedding + nn.GRU + LayerNorm + Linear','trainable_parameter_count':sum(p.numel() for p in model.parameters()),
 'personas':list(PERSONAS),'facets':list(FACETS),'train_examples':len(train),'validation_examples':len(valid),'frozen_test_examples':len(held),
 'dataset_origin':'FRESH_SYNTHETIC_SAFE_GENERIC_ONLY','blocked_source_ingestion':True,
 'grouping':'TOPIC_GROUP_STRICT_SPLIT_WITHHELD_GROUPS_9_AND_11_TEST','training_steps':steps,'selected_checkpoint_step':best_step,
 'loss_before_validation':before_valid,'loss_after_validation':after_valid,
 'loss_before_test':before_held,'loss_after_test':after_held,
 'validation_improvement_pct':(before_valid-after_valid)/before_valid*100,
 'test_improvement_pct':(before_held-after_held)/before_held*100,
 'test_perplexity_before':math.exp(before_held),'test_perplexity_after':math.exp(after_held),
 'weights_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
 'dataset_manifest_sha256':hashlib.sha256((ROOT/'dataset_manifest.jsonl').read_bytes()).hexdigest(),
 'optimizer_state_saved':True,'optimizer_sha256':hashlib.sha256(optimizer_path.read_bytes()).hexdigest(),'full_training_resume':'OPTIMIZER_RESTORABLE_WITH_SAME_BASE_CONFIG_AND_DATA_SPLIT','random_seed':SEED,
 'max_seq_len':MAXLEN,'vocab_size':V,'runtime':'CPU','approved_model_for_release':False,
 'frozen_source_changed':False,'holdout_touched_for_training':False,
 'important_limit':'Tiny language model learned synthetic Russian response patterns. No independent open-ended inference acceptance, no Qwen/ChatGPT weight updates, no owner persona profile updates.'}
(ROOT/'model_config.json').write_text(json.dumps({'model':'TinyLM','emb':64,'hidden':112,'vocab':vocab,'dataset_license':'newly authored synthetic, sandbox only','unsafe_pickle':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'weights_metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'train_trace.json').write_text(json.dumps(history,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'params':metrics['trainable_parameter_count'],'loss_test_before':round(before_held,3),'loss_test_after':round(after_held,3),'steps':steps,'best_step':best_step,'train':len(train),'validation':len(valid),'test':len(held),'weights_sha':metrics['weights_sha256']},ensure_ascii=False))
