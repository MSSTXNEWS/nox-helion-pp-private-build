import json, tempfile
from pathlib import Path
import unittest
import torch
from safetensors.torch import load_file
from runtime import SoulTinyRuntime
from incremental import incremental_step
P=Path(__file__).resolve().parent
class TinyWeightsTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.rt=SoulTinyRuntime(P)
 def test_physical_parameter_count(self):
  self.assertEqual(sum(x.numel() for x in self.rt.model.parameters()),72422)
 def test_accurate_provenance_and_scope(self):
  m=self.rt.metrics;self.assertEqual(m['train_examples'],360)
  self.assertEqual(m['frozen_test_examples'],80);self.assertFalse(m['external_model_weights_used'])
  self.assertFalse(m['lora_training']);self.assertFalse(m['approved_model_for_release'])
 def test_reload_weight_integrity(self):
  w=load_file(str(P/'nox_soul_tiny_gru_full_weights_v1.safetensors'))
  for name,p in self.rt.model.state_dict().items():self.assertTrue(torch.equal(w[name],p))
 def test_resume_optimizer_integrity(self):
  o=load_file(str(P/'nox_soul_optimizer_state_v1.safetensors'))
  for n,p in self.rt.model.named_parameters():
   self.assertEqual(tuple(o[f'{n}|exp_avg'].shape),tuple(p.shape))
   self.assertEqual(tuple(o[f'{n}|exp_avg_sq'].shape),tuple(p.shape))
 def test_new_examples_missing_returns_no_change(self):
  self.assertEqual(incremental_step(P,P/'no_such_examples.jsonl',P/'doesnt_create')['status'],'NEW_EXAMPLES_MISSING_NO_CHANGE')
 def test_reject_external_and_wrong_project_train(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'x.jsonl';f.write_text(json.dumps({'origin':'REVIEW_ONLY','owner_scope':'NOX_SOUL_SANDBOX','split':'train','persona':'KV','facet':'HF01','prompt':'[KV][HF01] prompt','completion':'Это служебный ответ.\n'},ensure_ascii=False)+'\n')
   with self.assertRaises(PermissionError):incremental_step(P,f,Path(t)/'out')
 def test_not_auto_train_on_holdout(self):
  with tempfile.TemporaryDirectory() as t:
   f=Path(t)/'x.jsonl';f.write_text(json.dumps({'origin':'NEW_SYNTHETIC_PRIVATE_FREE','owner_scope':'NOX_SOUL_SANDBOX','split':'test','persona':'KV','facet':'HF01','prompt':'[KV][HF01] prompt','completion':'Это служебный ответ.\n'},ensure_ascii=False)+'\n')
   with self.assertRaises(PermissionError):incremental_step(P,f,Path(t)/'out')
 def test_ev_visual_lock(self):
  a=self.rt.generate_synthetic_only('EV','HF02','Покажи фото Элины')
  self.assertEqual(a['status'],'IDENTITY_CONFLICT_HOLD')
 def test_bounded_inputs(self):
  with self.assertRaises(ValueError):self.rt.forward_scores('x'*10000)
  with self.assertRaises(ValueError):self.rt.generate_synthetic_only('BAD','HF01','Привет')
 def test_score_shape(self):
  self.assertEqual(self.rt.forward_scores('[KV][HF01] Проверим.\nОтвет: ').shape[-1],self.rt.metrics['vocab_size'])
 def test_no_production_deployment(self):
  self.assertFalse(self.rt.metrics['frozen_source_changed'])
  self.assertFalse(self.rt.metrics['approved_model_for_release'])
if __name__=='__main__':unittest.main(verbosity=2)
