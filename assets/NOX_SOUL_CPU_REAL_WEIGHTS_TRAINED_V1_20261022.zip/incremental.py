#!/usr/bin/env python3
"""Conservative staged continuation training. Never auto-writes production or MAIN.
Caller must provide *new*, sanitized, self-authored synthetic examples with explicit sandbox scope.
Keep validation/test frozen; promote only inside an isolated candidate directory and after regression.
"""
import argparse,json,hashlib,random,copy,math,difflib
from pathlib import Path
import torch
from safetensors.torch import load_file,save_file
from runtime import SoulTinyRuntime, TinyLM


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def incremental_step(root,new_file,output):
 root=Path(root);new_file=Path(new_file);output=Path(output)
 if not new_file.is_file():return {'status':'NEW_EXAMPLES_MISSING_NO_CHANGE'}
 rows=[json.loads(x) for x in new_file.read_text(encoding='utf-8').splitlines() if x.strip()]
 if not rows:return {'status':'NO_CHANGE','new_unique':0}
 source_manifest=[json.loads(x) for x in (root/'dataset_manifest.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
 previous={x['sha256'] for x in source_manifest}
 # Prevent wasteful retraining on near-identical rephrasings of the same synthetic sample.
 prior_training=[x for x in source_manifest if x.get('split')=='train']
 dedup=set();validated=[]
 for x in rows:
  if x.get('origin')!='NEW_SYNTHETIC_PRIVATE_FREE' or x.get('owner_scope')!='NOX_SOUL_SANDBOX' or x.get('split')!='train':
   raise PermissionError('TRAIN_SOURCE_NOT_AUTHORIZED_OR_WRONG_SPLIT')
  if x.get('persona') not in ('KV','AM','LA','EV','KW') or x.get('facet') not in tuple(f'HF{i:02d}' for i in range(1,9)):
   raise ValueError('PERSONA_FACET_INVALID')
  prompt=x.get('prompt');completion=x.get('completion')
  if not isinstance(prompt,str) or not isinstance(completion,str) or not prompt.startswith('['+x['persona']+']['+x['facet']+'] '):
   raise ValueError('INVALID_FORMAT')
  if not completion.endswith('\n') or len(prompt+completion)>255 or not (10<len(completion)<190):
   raise ValueError('INVALID_LENGTH')
  # These text tests are defense in depth, NOT a full private-data scrubber.
  lowered=(prompt+completion).lower()
  if any(s in lowered for s in ('@gmail','@outlook','passport number','token=','api_key','credit card')):
   raise PermissionError('POSSIBLE_PRIVATE_OR_SECRET_DATA')
  h=hashlib.sha256((prompt+completion).encode()).hexdigest()
  if h in previous or h in dedup:continue
  near_same=any((q['persona']==x['persona'] and q['facet']==x['facet'] and q['completion']==x['completion'] and difflib.SequenceMatcher(None,q['prompt'],x['prompt']).ratio()>=0.80) for q in prior_training)
  if near_same:continue
  dedup.add(h);validated.append(x)
 if not validated:return {'status':'NO_CHANGE_SEMANTIC_DEDUP','new_unique':0,'skipped_existing_or_nearduplicate':len(rows),'new_checkpoint':False}
 rt=SoulTinyRuntime(root);model=rt.model;model.train()
 old_cfg=rt.config;charmap={z:i+1 for i,z in enumerate(old_cfg['vocab'][1:])}
 unknown=set(c for x in validated for c in x['prompt']+x['completion'] if c not in charmap)
 if unknown:raise ValueError('TOKENIZER_CHANGE_REQUIRES_NEW_VERSION')
 opt=torch.optim.AdamW(model.parameters(),lr=0.0005,weight_decay=0.005)
 optdata=load_file(str(root/'nox_soul_optimizer_state_v1.safetensors'))
 for name,p in model.named_parameters():
  rec=opt.state[p]
  for k in ('step','exp_avg','exp_avg_sq'):
   rec[k]=optdata[f'{name}|{k}'].clone()

 def tobatch(items):
  X=[];Y=[];M=[];mx=max(rt.metrics['max_seq_len'],max(len(x['prompt']+x['completion']) for x in items))
  for x in items:
   prompt,comp=x['prompt'],x['completion'];seq=prompt+comp
   z=[charmap[c] for c in seq];ii=z[:-1];yy=z[1:];mm=[float(q>=len(prompt)-1) for q in range(len(ii))]
   X.append(ii+[0]*(mx-1-len(ii)));Y.append(yy+[0]*(mx-1-len(yy)));M.append(mm+[0.]*(mx-1-len(mm)))
  return torch.tensor(X,dtype=torch.long),torch.tensor(Y,dtype=torch.long),torch.tensor(M,dtype=torch.float32)

 def score(items):
  model.eval();x,y,m=tobatch(items)
  with torch.no_grad():
   out=model(x)
   loss=torch.nn.functional.cross_entropy(out.reshape(-1,out.shape[-1]),y.reshape(-1),reduction='none').reshape_as(y)
   res=float((loss*m).sum()/m.sum())
  model.train();return res
 val=[x for x in source_manifest if x.get('split')=='validation']
 test=[x for x in source_manifest if x.get('split')=='test']
 before_val=score(val)
 weights_orig={k:v.clone() for k,v in model.state_dict().items()}
 for k in range(60):
  idx=[(k*7+j)%len(validated) for j in range(min(12,len(validated)))]
  x,y,m=tobatch([validated[j] for j in idx])
  opt.zero_grad(set_to_none=True);logits=model(x)
  l=(torch.nn.functional.cross_entropy(logits.reshape(-1,logits.shape[-1]),y.reshape(-1),reduction='none').reshape_as(y)*m).sum()/m.sum()
  l.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.0);opt.step()
 after_val=score(val)
 # NO_GAIN / no real new corpus benefits is not a reason to publish worse weights.
 if after_val>before_val+0.001:
  model.load_state_dict(weights_orig)
  return {'status':'NO_GAIN_ROLLBACK','new_unique':len(validated),'before_validation':before_val,'after_validation':after_val,'checkpoint_promoted':False}
 # Test used one time after validation gate.
 before=score(test)
 # "before" here already trained, use separate comparison model to compute baseline test from original state.
 current={k:v.clone() for k,v in model.state_dict().items()};model.load_state_dict(weights_orig)
 baseline_test=score(test);model.load_state_dict(current)
 if before>baseline_test+0.001:
  model.load_state_dict(weights_orig)
  return {'status':'TEST_REGRESSION_ROLLBACK','new_unique':len(validated),'before_test':baseline_test,'after_test':before,'checkpoint_promoted':False}
 output.mkdir(parents=True,exist_ok=True)
 w=output/'candidate_weights.safetensors';save_file({k:v.contiguous() for k,v in model.state_dict().items()},str(w))
 rec={'status':'CANDIDATE_WEIGHTS_ONLY_NOT_RELEASE','new_unique':len(validated),'validated_examples_sha256':sha(new_file),'parent_weights_sha256':rt.metrics['weights_sha256'],'candidate_sha256':sha(w),'before_val':before_val,'after_val':after_val,'before_test':baseline_test,'after_test':before,'checkpoint_promoted_in_main':False,'no_external_actions':True}
 (output/'delta_receipt.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return rec

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',default=str(Path(__file__).resolve().parent));p.add_argument('--new-examples',required=True);p.add_argument('--output',required=True)
 a=p.parse_args();print(json.dumps(incremental_step(a.root,a.new_examples,a.output),ensure_ascii=False))
