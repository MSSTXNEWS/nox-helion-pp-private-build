"""Independent behavioural probes. Synthetic accuracy is NOT persona conversational ability."""
import json
from pathlib import Path
from runtime import SoulTinyRuntime

def audit(root):
 root=Path(root);rt=SoulTinyRuntime(root)
 rows=[json.loads(x) for x in (root/'dataset_manifest.jsonl').read_text(encoding='utf-8').splitlines()]
 probes=[r for r in rows if r['split']=='test' and r['topic_group']==9]
 seen=[]
 for p in probes:
  # question from frozen test, not used in training; this is an evaluation, not a feedback loop.
  question=p['prompt'].split('] ',1)[1].replace('\nОтвет: ','')
  result=rt.generate_synthetic_only(p['persona'],p['facet'],question,110 if False else 96)
  text=result.get('content') or ''
  # Hard requirement: required persona focus occurs in generated text (not merely style similarity).
  marker={'KV':'планирование и последствия','AM':'проверка доказательств','LA':'проектирование решений','EV':'редактура и границы общения','KW':'критический разбор рисков'}[p['persona']]
  seen.append({'persona':p['persona'],'facet':p['facet'],'persona_focus_present':marker in text,'text_preview':text[:70]})
 passes=sum(x['persona_focus_present'] for x in seen)
 report={'schema':'NOX.SOUL.BEHAVIORAL_AUDIT.V1','test_method':'UNSEEN_HELDOUT_FREE_GREEDY_GENERATION_PERSONA_FOCUS','heldout_probe_count':len(seen),'persona_focus_passes':passes,'persona_focus_accuracy':round(passes/len(seen),4),'sample_probe_results':seen[:15], 'release_gate':'HOLD_IF_ANY_PERSONA_MISMATCH','release_admissible':passes==len(seen),'notes':'This test may fail despite very low teacher-forced loss; model output must not be used as reliable character dialogue.'}
 (root/'behavior_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return report
if __name__=='__main__':
 x=audit(Path(__file__).resolve().parent);print(json.dumps({k:v for k,v in x.items() if k not in ('sample_probe_results',)},ensure_ascii=False))
