"""Offline source-only D02 liquid GPU/2D fallback contract. Not a Windows runtime claim."""
from pathlib import Path
from html.parser import HTMLParser
from subprocess import run
from tempfile import TemporaryDirectory
import re
root=Path(__file__).resolve().parent
s=(root/'src/index.html').read_text(encoding='utf8')
assert s.count('id="helionFx"')==1
assert 'data-route="consciousness"' in s and s.count('class="core c')==8
assert 'webgl2' in s and "getContext('2d'" in s
assert 'window.noxVisual' in s and "setEnergy(v==='GENERATING')" in s
assert 'prefers-reduced-motion: reduce' in s
assert "powerPreference:'high-performance'" in s
assert 'https://cdn.' not in s and '<script src=' not in s
assert len(re.findall(r'<script(?:[^>]*)>',s))==2
with TemporaryDirectory() as temp:
    for i,code in enumerate(re.findall(r'<script(?:[^>]*)>(.*?)</script>',s,re.S)):
        js=Path(temp)/f'{i}.js';js.write_text(code,encoding='utf8')
        p=run(['node','--check',str(js)],capture_output=True,text=True)
        assert p.returncode==0,p.stderr
cs=(root/'src/MainWindow.xaml.cs').read_text(encoding='utf8')
assert 'pendingEmbeddedNavigation' in cs
assert 'cancellation.Token.ThrowIfCancellationRequested();' in cs and 'PersistChat(prompt, answer.ToString());' in cs
assert 'lastGenerationCompleted = true;' in cs
print('R8 OFFLINE GPU + 2D FALLBACK, ACCESSIBILITY, NAV, STOP CONTRACT: PASS (source only)')
