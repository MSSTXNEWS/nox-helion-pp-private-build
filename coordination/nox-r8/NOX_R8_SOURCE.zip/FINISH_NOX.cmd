@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FINISH_NOX.ps1"
exit /b %ERRORLEVEL%
