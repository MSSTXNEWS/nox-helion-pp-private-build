"""Test SQLite FTS5 RAG SQL against the runtime schema without simulating inference."""
from pathlib import Path
import re, sqlite3, tempfile, hashlib
source=(Path(__file__).parent/'src'/'KnowledgeStore.cs').read_text()
block=re.search(r'public void Initialize\(\).*?cmd.CommandText = """(.*?)""";',source,re.S)
assert block, 'Knowledge schema missing'
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'memory.sqlite3'
 db=sqlite3.connect(p)
 db.executescript(block.group(1))
 assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 docs=[('NOX.md','Локальная память NOX HELION на компьютере.','2f'),('QWEN.md','Qwen работает локально и потоково.','3f')]
 for title,content,sha in docs:
  db.execute('INSERT INTO knowledge_documents(imported_utc,title,source_name,sha256,chunk_count) VALUES(?,?,?,?,?)',('2026-11-06',title,title,sha,1))
  docid=db.execute('SELECT last_insert_rowid()').fetchone()[0]
  db.execute('INSERT INTO knowledge_chunks(document_id,chunk_index,content) VALUES(?,?,?)',(docid,0,content))
  chunkid=db.execute('SELECT last_insert_rowid()').fetchone()[0]
  db.execute('INSERT INTO knowledge_fts(title,content,chunk_id) VALUES(?,?,?)',(title,content,chunkid))
 db.commit()
 q='"память" OR "NOX"'
 rows=db.execute('''SELECT d.title, snippet(knowledge_fts,1,'','','…',38)
 FROM knowledge_fts JOIN knowledge_chunks c ON c.id=knowledge_fts.chunk_id
 JOIN knowledge_documents d ON d.id=c.document_id
 WHERE knowledge_fts MATCH ? ORDER BY bm25(knowledge_fts) LIMIT 8''',(q,)).fetchall()
 assert rows[0][0]=='NOX.md', rows
 assert 'NOX' in rows[0][1]
 assert db.execute('SELECT COUNT(*) FROM knowledge_chunks').fetchone()[0]==2
 try:
  db.execute('INSERT INTO knowledge_documents(imported_utc,title,source_name,sha256,chunk_count) VALUES(?,?,?,?,?)',('2026-11-06','duplicate','duplicate','2f',1))
  raise AssertionError('Duplicate SHA must be rejected')
 except sqlite3.IntegrityError: pass
 db.close()
print('LOCAL RAG SQL: PASS — FTS5 Russian tokens, chunk join, source names, dedup, integrity')
