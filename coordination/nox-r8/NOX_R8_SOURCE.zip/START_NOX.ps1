[CmdletBinding()]
param([string]$ExePath = '', [switch]$NoStartOllama)
$ErrorActionPreference='Stop'
$models='C:\NOX_OLLAMA_CLEAN\models'
$endpoint='http://127.0.0.1:11436'
$model='nox-qwen-clean:latest'
if (!(Test-Path -LiteralPath $models -PathType Container)) { throw 'NOX_QWEN_MODEL_STORE_NOT_FOUND: clean model store must already exist' }
if ([string]::IsNullOrWhiteSpace($ExePath)) {
  $ExePath=Join-Path $PSScriptRoot 'NOX.HELION.exe'
}
if (!(Test-Path -LiteralPath $ExePath -PathType Leaf)) { throw "NOX_EXECUTABLE_NOT_FOUND: $ExePath" }
function Test-Engine {
 try {
  $result=Invoke-RestMethod "$endpoint/api/tags" -TimeoutSec 3
  return $result
 } catch { return $null }
}
$state=Test-Engine
if ($null -eq $state -and !$NoStartOllama) {
 $listener=Get-NetTCPConnection -LocalPort 11436 -State Listen -ErrorAction SilentlyContinue
 if ($null -ne $listener) { throw 'PORT_11436_OCCUPIED_BY_UNKNOWN_SERVICE' }
 $cmd=Get-Command ollama -ErrorAction Stop
 $priorHost=$env:OLLAMA_HOST; $priorModels=$env:OLLAMA_MODELS
 try {
   $env:OLLAMA_HOST='127.0.0.1:11436'; $env:OLLAMA_MODELS=$models
   Start-Process -FilePath $cmd.Source -ArgumentList @('serve') -WindowStyle Minimized | Out-Null
 } finally { $env:OLLAMA_HOST=$priorHost; $env:OLLAMA_MODELS=$priorModels }
 for ($i=0; $i -lt 25; $i++) { Start-Sleep -Milliseconds 800; $state=Test-Engine; if ($null -ne $state) { break } }
}
if ($null -eq $state) { throw 'NOX_QWEN_API_OFFLINE' }
if (@($state.models | ForEach-Object { $_.name }) -notcontains $model) { throw 'NOX_QWEN_MODEL_NOT_REGISTERED' }
Write-Host "NOX QWEN READY: $endpoint" -ForegroundColor Green
Start-Process -FilePath $ExePath -WorkingDirectory (Split-Path $ExePath -Parent) | Out-Null
Write-Host "NOX EXE START REQUESTED: $ExePath" -ForegroundColor Green
