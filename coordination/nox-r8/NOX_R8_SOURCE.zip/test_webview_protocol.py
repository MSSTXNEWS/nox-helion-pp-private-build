import asyncio
import re
from pathlib import Path
from playwright.async_api import async_playwright

HTML=Path(__file__).with_name('src').joinpath('index.html').read_text()

async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
        page=await browser.new_page(viewport={'width':1440,'height':900})
        errors=[]
        page.on('pageerror',lambda e: errors.append(str(e)))
        await page.add_init_script('''window.__nativeMessages=[];window.__nativeHandlers=[];window.chrome={webview:{postMessage(x){window.__nativeMessages.push(x)},addEventListener(type,handler){if(type==='message')window.__nativeHandlers.push(handler)}}};window.__nativeReceive=(type,value)=>window.__nativeHandlers.forEach(h=>h({data:{type,value}}));''')
        await page.goto('about:blank')
        await page.set_content(HTML,wait_until='domcontentloaded')
        
        assert await page.locator('button.core').count()==8
        assert await page.locator('.helion').count()==1
        for key in ('core','atlas','reflection','nexus','forge','voice','persona','consciousness'):
            await page.locator(f'button.core[data-route="{key}"]').click()
            assert await page.locator('.panel.active').get_attribute('data-panel')==key
        await page.locator('button#startEngine').click()
        assert any(m['type']=='engine.start' for m in await page.evaluate('window.__nativeMessages'))
        await page.evaluate('window.__nativeReceive("health",{online:true,model:"nox-qwen-clean:latest",modelVisible:true,models:["nox-qwen-clean:latest"],endpoint:"http://127.0.0.1:11436"})')
        assert await page.locator('#hudEngine').inner_text()=='ONLINE'
        assert await page.locator('#modelPicker option').count()==1
        await page.locator('button.core[data-route="nexus"]').click()
        page.on('dialog',lambda dialog: asyncio.create_task(dialog.accept()))
        await page.locator('#modelToDownload').fill('qwen2.5-coder:7b')
        await page.locator('#pullModel').click()
        assert any(m['type']=='model.pull' and m['model']=='qwen2.5-coder:7b' for m in await page.evaluate('window.__nativeMessages'))
        await page.evaluate('window.__nativeReceive("download",{model:"qwen2.5-coder:7b",status:"pulling",percent:36.5})')
        assert '36.5%' in await page.locator('#downloadStatus').inner_text()
        await page.locator('#cancelPull').click()
        assert any(m['type']=='model.cancel' for m in await page.evaluate('window.__nativeMessages'))
        await page.locator('button.core[data-route="core"]').click()
        await page.locator('#prompt').fill('Привет, NOX!')
        await page.locator('#send').click()
        assert any(m['type']=='chat' and m['text']=='Привет, NOX!' for m in await page.evaluate('window.__nativeMessages'))
        await page.evaluate('window.__nativeReceive("status","GENERATING")')
        await page.evaluate('window.__nativeReceive("token","Привет!")')
        await page.evaluate('window.__nativeReceive("token"," Готов работать.")')
        assert 'Привет! Готов работать.' in await page.locator('#messages').inner_text()
        await page.evaluate('window.__nativeReceive("metrics",{measured:true,outputTokens:24,tokensPerSecond:11.7,promptTokens:33})')
        assert '11.7' in await page.locator('#inferenceMetrics').inner_text()
        await page.locator('#stop').click()
        assert any(m['type']=='stop' for m in await page.evaluate('window.__nativeMessages'))
        await page.evaluate('window.__nativeReceive("complete",{ok:false,stopped:true})')
        assert 'не сохранён' in await page.locator('#streamHint').inner_text()
        await page.locator('button.core[data-route="atlas"]').click()
        await page.evaluate('window.__nativeReceive("tasks",[{id:1,title:"Задача NOX",complete:false}])')
        assert await page.locator('#tasks input[type="checkbox"]').count()==1
        await page.locator('#tasks input[type="checkbox"]').click()
        assert any(m['type']=='tasks.toggle' and m['id']==1 for m in await page.evaluate('window.__nativeMessages'))
        await page.locator('button.core[data-route="reflection"]').click()
        await page.evaluate('window.__nativeReceive("notes",[{id:3,title:"Локальное знание",content:"Проверенный факт",timestamp:"2026-11-06"}])')
        assert 'Проверенный факт' in await page.locator('#notes').inner_text()
        await page.locator('#knowledgeImport').click()
        assert any(m['type']=='knowledge.import' for m in await page.evaluate('window.__nativeMessages'))
        await page.evaluate('window.__nativeReceive("knowledge.imported",{documents:2,skipped:1,chunks:8})')
        await page.evaluate('window.__nativeReceive("knowledge.stats",{documents:2,chunks:8,localOnly:true})')
        assert '2 документов' in await page.locator('#knowledgeStats').inner_text()
        await page.locator('#knowledgeQuery').fill('локальная память')
        await page.locator('#knowledgeSearch').click()
        assert any(m['type']=='knowledge.search' and m['query']=='локальная память' for m in await page.evaluate('window.__nativeMessages'))
        await page.evaluate('window.__nativeReceive("knowledge.results",[{title:"NOX.md",source:"NOX.md",excerpt:"Локальная память NOX"}])')
        assert 'Локальная память NOX' in await page.locator('#knowledgeResults').inner_text()
        await page.locator('#memoryQuery').fill('тест')
        await page.locator('#memorySearch').click()
        assert any(m['type']=='memory.search' and m['query']=='тест' for m in await page.evaluate('window.__nativeMessages'))
        await page.locator('button.core[data-route="persona"]').click()
        await page.locator('#performance').select_option('ECO')
        await page.locator('#savePerformance').click()
        assert any(m['type']=='settings.put' and m['key']=='performance' and m['value']=='ECO' for m in await page.evaluate('window.__nativeMessages'))
        await page.locator('#reduceMotion').check()
        await page.locator('#saveMotion').click()
        assert any(m['type']=='settings.put' and m['key']=='motion' and m['value']=='off' for m in await page.evaluate('window.__nativeMessages'))
        await page.evaluate('window.__nativeReceive("settings",{motion:"off",persona:"KV",performance:"ECO",context:"off"})')
        assert await page.evaluate("document.body.classList.contains('reduced')")
        for w,h in [(390,844),(800,480),(1440,900),(1920,1080)]:
            await page.set_viewport_size({'width':w,'height':h})
            assert await page.locator('button.core').count()==8
            if w >= 1250:
                assert await page.locator('.visual').is_visible()
        assert not errors, errors
        await browser.close()
        print('PASS: 8 CORE ROUTES, MODEL, LIVE CHAT, STREAM TOKENS, STOP, TASKS, SQLITE EVENTS, NOTES, MEMORY SEARCH, SETTINGS, REDUCED MOTION, RESPONSIVE SIZES')

asyncio.run(main())
