# NOX HELION R8 · SINGLE WINDOWS INTEGRATION CANDIDATE

## Scope

An existing WPF/WebView2 Windows desktop with original offline HTML/JS, eight functional CoreID routes, local Ollama `nox-qwen-clean:latest` at `http://127.0.0.1:11436`, stream/STOP, SQLite chat/tasks/notes/preferences, file-based local RAG and owner-consented VUNEO import. Full V16 autonomous self-evolution, canonical visual QA and final Windows end-to-end have *not* been certified merely by source tests.

## R8 real changes

- True offline WebGL2 animated liquid Helion surface with procedurally varying wave/energy fields, live inference activity and spherical glow. No CDN or web requests. An animated Canvas2D engine is used when WebGL2 is unavailable.
- One complete system of nine spheres; eight real buttons open functional panels. Reduced Motion, background throttling and MAX/BALANCED/ECO frame budgets.
- WPF trusted embedded navigation fix retains external URL blocking. Final STOP cancellation is checked before SQLite commit, and `lastGenerationCompleted` only flips after a successful transaction.
- Source hashing is bound to this archive. `FINISH_NOX.cmd` stages isolated Win64 builds; does not delete old binaries or model weights.

## Required runtime verification

One Windows build from this exact source archive must pass: .NET publish, in-process WPF/WebView2 UI smoke with eight routes and isolated SQLite; on the *owner's Windows device* native E2E with the already installed Ollama and real Qwen. This distinction is enforced; cloud runner without Qwen cannot claim native model PASS.

## No-loss rules

Do not overwrite `C:\NOX_HELION\NOX_NEW\release` or live `chat.sqlite3`. Do not duplicate or re-download model weights. Backups are retained. The archive is a complete candidate, but not permission to claim the entire NOX V16 is implemented.
