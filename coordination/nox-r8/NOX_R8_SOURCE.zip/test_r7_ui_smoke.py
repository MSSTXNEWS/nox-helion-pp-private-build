"""Strict source contract for R7 UI-only Windows smoke; not Windows proof."""
from pathlib import Path
p=Path(__file__).parent
cs=(p/'src/MainWindow.xaml.cs').read_text(encoding='utf8')
app=(p/'src/App.xaml.cs').read_text(encoding='utf8')
ps=(p/'FINISH_NOX.ps1').read_text(encoding='utf8')
assert '--nox-ui-smoke' in cs and '--nox-ui-smoke' in app and '--nox-ui-smoke' in ps
assert 'RunUiSmokeAsync' in cs and 'NOX_WPF_UI_SMOKE_R7_V1' in cs and 'NOX_WPF_UI_SMOKE_R7_V1' in ps
assert 'webview2-selftest-r7-' in cs
assert 'selftest_r7_' in cs
assert 'local_qwen_e2e=\'NOT_TESTED\'' in ps
assert 'canonical_d02_visual=\'NOT_TESTED\'' in ps
assert 'accepted_full_release=$false' in ps
assert 'NOX_WINDOWS_WPF_WEBVIEW2_UI_SMOKE_PASS; QWEN_E2E_NOT_TESTED' in ps
assert 'stopMarker = "NOX_STOP_"' in cs and 'real_webview_stop_cancel_no_partial_persistence' in cs
assert 'NoLaunch -and $UiSmokeOnly' in ps
assert 'source_manifest=\'MANIFEST_SHA256.json\'' in ps
print('R7 UI smoke strict contract PASS (source only; Windows runtime not claimed)')
