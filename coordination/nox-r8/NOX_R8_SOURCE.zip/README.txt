NOX HELION R5 · Windows WPF/WebView2 source release (NOT full V16 acceptance)

Single Windows integration: run FINISH_NOX.cmd once after extracting the archive.
No older NOX files, models, databases, checkpoints, or learning sessions are deleted.
Existing Ollama model: nox-qwen-clean:latest on 127.0.0.1:11436.

The program provides eight navigable CoreID sections, streaming local Qwen,
a real user STOP command, SQLite history and local knowledge, tasks, notes,
settings, training readouts and Windows speech synthesis. The D02 scene has
nine spheres but is not independently certified against the original design.

The build runner verifies source SHA256, publishes a distinct NOX_R5 release,
executes a native WebView2->WPF->Qwen->SQLite smoke chat and STOP test, checks
runtime PID and EXE SHA256 in a dedicated test receipt, then launches the
normal window. If a stage fails, it reports HOLD, does not overwrite the last
known working executable, and preserves the source and model data.

This package is NOT a proven autonomous AI developer, a fully accepted V16,
or a Windows-built EXE. Actual Windows compilation and physical runtime
acceptance must occur in the target environment. Source-only tests do not
substitute for that evidence.
