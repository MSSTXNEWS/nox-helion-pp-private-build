# NOX V16 P03 C38 – Reused original ModelCenter

Base: C37 sha256 `b45968ed6da9b557764d30aa6e0cb4df339cf77485092f3da95df1da473c08b9`.

This isolated candidate preserves the 30 family catalog and existing Ollama Pull/GGUF transport. Changes: strict independent GGUF evidence; JSON corruption fail-closed; bounded same-folder atomic queue writes and .bak; monotonic byte progress; cancellation terminal guards; exact local Ollama loopback validation and `/api/tags` digest readback; parallel bounded Windows prerequisite probes; 15 checked official family URLs with REVIEW_REQUIRED for artifact metadata. No new host, no live downloader duplication, no inferred licenses.

Run on Windows/.NET 8 SDK: `dotnet run --project P03.ModelCenter.Smoke/P03.ModelCenter.Smoke.csproj` and `dotnet build P03.ModelCenter/P03.ModelCenter.csproj -c Release`. Smoke uses fake HTTP response, NOT real model transfer. After compile success, #6 should run actual authorized small pull and GGUF import against loopback Ollama and independently bind receipts/SourceLock.

LIMITATION: at time of authoring, environment has no .NET SDK and Windows is unavailable, thus these commands have not yet run. An E07 independent same BuildID/EXE SHA verification is outstanding; RELEASE BLOCKED.
