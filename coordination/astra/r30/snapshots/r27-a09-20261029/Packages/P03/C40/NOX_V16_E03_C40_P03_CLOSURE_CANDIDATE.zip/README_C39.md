# NOX V16 · P03 MICRO-WOW C39

Original source preimage: `NOX_V16_E03_C38_P03_SOURCE_CANDIDATE.zip`.
This patch **only adds** secondary UI assets and a host-neutral .NET 8 bridge serializer.
It modifies no pre-existing C38 source file, no HOME/MENU/CORE and no `MainWindow.xaml.cs`.

New WOW: energy ring, MODEL DNA, quick control, Microsoft Fluent local SVG icons (MIT),
Quantum Filters, Twin Scan, Event Pulse, Hardware Harmony, Pre-flight Radar.

Read `P03.ModelCenter.Wow/README.md` for source-lock and integration steps.
The 15 exact artifact sources, model revisions/licenses/hashes, real Windows host wiring,
Ollama runtime, and E07 acceptance are NOT complete. STATUS=SOURCE_CANDIDATE/HOLD.

Build target (on Windows with .NET 8): `dotnet build P03.ModelCenter/P03.ModelCenter.csproj -c Release`
The UI may be mounted by existing WebView2 instance after #6 origin/ACL review.
No new NuGet, JS frameworks, API keys, or internet calls are required at runtime.
