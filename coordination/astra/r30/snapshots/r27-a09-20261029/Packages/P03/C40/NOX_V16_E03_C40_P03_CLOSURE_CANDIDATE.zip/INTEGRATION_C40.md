# NOX FIN ZAGR V16 · Executor 3 · P03 C40 critical-path candidate

- Starting source: exact C39 26-file ZIP; original ten-file ModelCenter preserved; nine MICRO-WOW functions retained.
- One queue/worker/adapter: P03.ModelCenter. PR #8 remains a candidate for feature-level extraction by #6, not a second active store.
- New fail-closed enqueue: EnqueueVerifiedPullAsync(ModelCatalogEntry, true). Legacy EnqueueAsync creates queued discovery-only work but PullAsync rejects it until the immutable digest/revision is supplied via reviewed evidence. Host MUST use the approved registry and user ACL.
- Model artifact SHA-256 and Ollama manifest SHA-256 are distinct fields; never compare unrelated digests. ExpectedManifestDigestSha256 is a separately independently reviewed pin, compared to /api/tags after terminal Ollama success. Source URL alone never proves rights, SHA or compatibility. Unknown exact artifacts stay REVIEW_REQUIRED.
- Worker prevents resurrection of cancelled queued jobs and isolates event sink failures from model-install result. STOP is client-side and may not hard-abort shared Ollama work.
- Queue rejects invalid enum/status/digest/provenance, retains rollback snapshot, explicit retry preserves ancestry.
- Tests: run `dotnet run --project P03.ModelCenter.Smoke/P03.ModelCenter.Smoke.csproj` on Windows agent with .NET SDK 8. Additional live authorized small-model pull, GGUF import, STOP, retry, recovery and rollback required before acceptance.
- #6 must unpack source_00/01/02, verify SHA, freeze SourceLock, bind exact path and pre/post/patch receipts, add P03 projects once to source tree, and route WebView2 via trusted origin/ACL only. DO NOT patch foreign MainWindow/host from this package. #7 independent same BuildID/EXE SHA QA.
- Six internal quality roles (not independent subagents), seven criteria E03-01…E03-07. PRODUCT ACCEPTANCE=N/D until full component evidence and Windows runtime.
- No new external runtime dependency or API; MICRO-WOW icon attribution preserved. No full rewrite of unverified master journal.
