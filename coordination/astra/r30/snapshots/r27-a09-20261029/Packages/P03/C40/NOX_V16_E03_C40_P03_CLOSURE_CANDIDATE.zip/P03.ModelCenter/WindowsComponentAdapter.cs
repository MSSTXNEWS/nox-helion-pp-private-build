using System.Diagnostics;

namespace Nox.P03;

public sealed record ComponentStatus(string Name, bool Available, string? Version, string? Error = null);

public sealed class WindowsComponentAdapter
{
    private static readonly IReadOnlyDictionary<string, string> WingetPackages = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        ["Ollama"] = "Ollama.Ollama", ["Python"] = "Python.Python.3.12", ["Git"] = "Git.Git"
    };

    // Run independent probes concurrently, without racing writes to shared state.
    public async Task<IReadOnlyList<ComponentStatus>> DetectAsync(CancellationToken ct = default) =>
        await Task.WhenAll(new[]
        {
            ProbeAsync("winget", new[] { "--version" }, ct),
            ProbeAsync("ollama", new[] { "--version" }, ct),
            ProbeAsync("python", new[] { "--version" }, ct),
            ProbeAsync("git", new[] { "--version" }, ct),
            ProbeAsync("nvidia-smi", new[] { "--query-gpu=name,memory.total,memory.free,temperature.gpu",
                "--format=csv,noheader,nounits" }, ct)
        });

    public async Task InstallWithWingetAsync(string component, bool explicitlyConfirmed, CancellationToken ct = default)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("WinGet integration is Windows-only.");
        if (!explicitlyConfirmed) throw new InvalidOperationException("Explicit confirmation is required before installing software.");
        if (!WingetPackages.TryGetValue(component, out var package)) throw new ArgumentOutOfRangeException(nameof(component));
        var psi = new ProcessStartInfo("winget") { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
        foreach (var arg in new[] { "install", "--id", package, "--exact", "--source", "winget", "--accept-source-agreements", "--accept-package-agreements" })
            psi.ArgumentList.Add(arg);
        psi.CreateNoWindow = true;
        using var process = Process.Start(psi) ?? throw new InvalidOperationException("Could not start WinGet.");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromMinutes(20));
        try
        {
            var stdout = process.StandardOutput.ReadToEndAsync(timeout.Token);
            var stderr = process.StandardError.ReadToEndAsync(timeout.Token);
            await process.WaitForExitAsync(timeout.Token);
            await Task.WhenAll(stdout, stderr);
            if (process.ExitCode != 0)
                throw new InvalidOperationException($"WinGet exited with {process.ExitCode}: {stderr.Result[..Math.Min(600, stderr.Result.Length)]}");
        }
        catch (OperationCanceledException)
        {
            if (!process.HasExited) process.Kill(entireProcessTree: true);
            throw;
        }
    }

    private static async Task<ComponentStatus> ProbeAsync(string name, string[] args, CancellationToken ct)
    {
        try
        {
            var psi = new ProcessStartInfo(name)
            {
                UseShellExecute = false, RedirectStandardOutput = true,
                RedirectStandardError = true, CreateNoWindow = true
            };
            foreach (var arg in args) psi.ArgumentList.Add(arg);
            using var process = Process.Start(psi);
            if (process is null) return new(name, false, null, "Process did not start");
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(TimeSpan.FromSeconds(8));
            try
            {
                // Drain both pipes concurrently to avoid a full-pipe deadlock.
                var stdout = process.StandardOutput.ReadToEndAsync(timeout.Token);
                var stderr = process.StandardError.ReadToEndAsync(timeout.Token);
                await process.WaitForExitAsync(timeout.Token);
                await Task.WhenAll(stdout, stderr);
                var output = string.IsNullOrWhiteSpace(stdout.Result) ? stderr.Result : stdout.Result;
                return new(name, process.ExitCode == 0, output.Trim()[..Math.Min(output.Trim().Length, 400)]);
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                if (!process.HasExited) process.Kill(entireProcessTree: true);
                return new(name, false, null, "Timed out after 8s");
            }
            catch (OperationCanceledException)
            {
                if (!process.HasExited) process.Kill(entireProcessTree: true);
                throw;
            }
        }
        catch (System.ComponentModel.Win32Exception ex)
        { return new(name, false, null, ex.Message); }
    }
}
