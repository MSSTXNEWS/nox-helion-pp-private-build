# NOX HELION P03 candidate

This directory is an isolated, source-only candidate because the visible workspace contains no admitted application tree. It is not integrated into the Windows candidate and does not alter its SourceLock.

## Implemented seam

- Official Ollama API adapter for streamed `/api/pull`, cancel through request cancellation, GGUF import through local SHA-256 → `/api/blobs/:digest` → `/api/create`, and local model digest readback.
- Durable single-worker queue with queued/running/cancelling/completed/cancelled/failed states, progress snapshots, retry, atomic JSON writes, and explicit license acknowledgement/source URL.
- Immutable lifecycle events intended for both P01 and P05 adapters.
- 30 official Ollama Library family discovery records. They intentionally have no inferred tag, license, version, size, hardware requirement, or expected hash; they are not one-click-downloadable until those exact facts are reviewed.
- Windows component probes and allowlisted, explicitly confirmed WinGet install entry point.

## Integration gate

The Windows app tree, owner receipts, canonical archive preimage, current SourceLock serializer/manifest, and P01/P05 event contract are not present in this workspace. Bind this candidate into the admitted app tree only after those inputs are supplied or restored. No test, build, model pull, model download, or installation was run here.

## Official sources

- Ollama Library: https://ollama.com/library
- Ollama API (pull, tags/show, blobs, create): https://github.com/ollama/ollama/blob/main/docs/api.md
