"""Usage: python verify_real_setuptools.py BUILDER_ROOT SETUPTOOLS_WHEEL"""
from pathlib import Path
import sys,zipfile,tempfile
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from offline_wheelhouse_lock import inspect_wheel,WheelHold
from audit_build_inputs import wheel_metadata
p=Path(sys.argv[2]).resolve()
r=inspect_wheel(p,wheel_root=p.parent);a=wheel_metadata(p)
assert r['distribution']=='setuptools' and a['name']=='setuptools'
assert r['version']==a['version']=='80.9.0'
print('PASS real setuptools80.9.0 outer identity, license metadata, RECORD')
for label,name,reason in [('duplicate_top','other-1.dist-info/METADATA','WHEEL_DIST_INFO_INVALID'),('unrecorded_vendor','setuptools/_vendor/evil-1.dist-info/METADATA','RECORD_DOES_NOT_COVER_ALL_MEMBERS')]:
 with tempfile.TemporaryDirectory() as td:
  q=Path(td)/p.name
  with zipfile.ZipFile(p) as src,zipfile.ZipFile(q,'w') as out:
   for info in src.infolist():out.writestr(info,src.read(info.filename))
   out.writestr(name,'Name: evil\nVersion: 1\n')
  try:inspect_wheel(q,wheel_root=q.parent);raise AssertionError('unexpected acceptance')
  except WheelHold as e:assert str(e)==reason;print('PASS rejected',label,reason)
  if label=='duplicate_top':
   try:wheel_metadata(q);raise AssertionError('unexpected audit acceptance')
   except ValueError as e:assert str(e)=='WHEEL_DIST_INFO_METADATA_MISSING_OR_MULTIPLE';print('PASS audit rejected duplicate top-level')
