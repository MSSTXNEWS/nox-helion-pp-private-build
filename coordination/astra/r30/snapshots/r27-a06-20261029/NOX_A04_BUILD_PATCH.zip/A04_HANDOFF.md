# A04 R1 build-input repairs — C1 INCOMPLETE

Apply A04_BUILD_REPAIRS_EXACT_PARENT.patch only to exact parent TREE1454257c66d5107b12091b8e81706e51b0cfb672 through canonical writer A11. Isolated support TREE d16663f9fd26aa0eab90270fff1bb65bc3f805e6 is not canonical or a built EXE. STOP patch remains independently apply-check compatible; it is not counted again.

Corrected wheelhouse replaces exactly cffi2.1.1 with2.0.0 and pycparser3.12 with2.23; nine other wheels unchanged. Use wheels/ as wheel directory; hashlock and notices sit outside. These are staged bytes, not installed locks. Use new extracted notices, not old notices hash, for this set.

A06: authorized native Win64 is still absent. Existing C_RELEASE_SPRINT_BUILD.ps1 can build early private GUI+worker with existing source assets; provision its additional pytest/trimesh separately with pinned inputs. Do not wait full173media for that private early build. Full R1 needs actual schema_version1 ProductInventory+bytes, installed model and5profiles. Existing canonical manifest is a handoff document, not valid ProductInventory; its notices link also remains stale. A12 owns correction.

Checks: root actual11wheel strict gate PASS, portable4/4 PASS with Windows path emulation, real setuptools plus negative tamper tests PASS. Wheel module18/19; symlink exception-message assertion fails unchanged on original source. Native Windows NOT_RUN. Seven real workers participated, but measured common overlap=0; C1 cannot close, C2/C3 not started. See receipt for timestamps and blockers.
