from pathlib import Path
import re,xml.etree.ElementTree as ET,sqlite3,tempfile,json,hashlib,subprocess
p=Path(__file__).parent
src=p/'src'
html=(src/'index.html').read_text(encoding='utf8')
cs=(src/'MainWindow.xaml.cs').read_text(encoding='utf8')
project=(src/'NOX.HELION.csproj').read_text(encoding='utf8')
assert len(re.findall(r'<button\b[^>]*class="core\b',html))==8, 'eight CoreID buttons required'
assert len(re.findall('class="helion"',html))==1, 'one central HELION sphere required'
assert 'System.Windows' in cs and 'CoreWebView2' in cs
ET.parse(src/'App.xaml');ET.parse(src/'MainWindow.xaml');ET.parse(src/'NOX.HELION.csproj')
ids=re.findall(r'\bid="([^"]+)"',html)
assert len(ids)==len(set(ids)), 'duplicate HTML IDs'
js_ids=set(re.findall(r"\$\('([^']+)'\)",html))
missing=js_ids-set(ids)
assert not missing, f'Missing referenced DOM IDs: {missing}'
for operation in ('chat','stop','notes.add','notes.delete','memory.search','tasks.add','tasks.toggle','settings.put','model.select','engine.start','system.status','knowledge.import','knowledge.search','knowledge.stats'):
    assert f'case "{operation}"' in cs, f'Native handler missing: {operation}'
for token in ('NOX_HELION_R5_FUNCTIONAL_BUILD','SQLite','STREAM','WebView2'):
    assert token.lower() in (html+cs).lower(), token
raw=re.search(r'command\.CommandText = """\s*(.*?)\s*""";',cs,re.S)
assert raw, 'SQLite schema not found'
with tempfile.TemporaryDirectory() as temp:
    f=Path(temp)/'smoke.sqlite3'; db=sqlite3.connect(f)
    db.executescript(raw.group(1))
    names={name for (name,) in db.execute('SELECT name FROM sqlite_master WHERE type="table"')}
    required={'chat_history','tasks','memory_notes','feedback','preferences','imported_sources'}
    assert required <= names, f'Missing SQLite tables: {required-names}'
    db.execute("INSERT INTO chat_history(timestamp,prompt,answer) VALUES(?,?,?)",('2026-11-06','Привет','Ответ'))
    db.execute("INSERT INTO tasks(created_at,title) VALUES (?,?)",('2026-11-06','NOX'))
    db.execute("INSERT INTO memory_notes(created_at,title,content) VALUES(?,?,?)",('2026-11-06','Знание','Тест'))
    db.execute("INSERT INTO preferences(key,value) VALUES(?,?)",('performance','ECO'))
    db.commit(); db.close()
    db=sqlite3.connect(f)
    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert db.execute('SELECT answer FROM chat_history').fetchone()[0]=='Ответ'
    assert db.execute('SELECT content FROM memory_notes').fetchone()[0]=='Тест'
    assert db.execute('SELECT value FROM preferences WHERE key="performance"').fetchone()[0]=='ECO'
    db.close()
assert (src/'KnowledgeStore.cs').exists()
assert 'CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts' in (src/'KnowledgeStore.cs').read_text(encoding='utf-8')
assert 'new ProcessStartInfo(executable, "serve")' in cs, 'Ollama owner startup missing'
assert 'WriteRuntimeReadyReceipt();' in cs, 'WebView2 runtime receipt missing'
assert 'webview2_runtime_receipt' in (p/'FINISH_NOX.ps1').read_text(encoding='utf-8'), 'Builder must inspect runtime receipt'
assert 'RunNativeSelfTestAsync()' in cs and 'real_webview_stop_cancel_no_partial_persistence' in cs
assert 'native_e2e' in (p/'FINISH_NOX.ps1').read_text(encoding='utf-8')
assert 'nox-runid' in cs and 'nox-runid' in (p/'FINISH_NOX.ps1').read_text(encoding='utf-8')
assert 'nativeCoreAccepted' in cs and 'nativeCoreAccepted' in (p/'FINISH_NOX.ps1').read_text(encoding='utf-8')
script=re.search(r'<script>(.*?)</script>',html,re.S)
assert script
r=subprocess.run(['node','--check'],input=script.group(1),text=True,capture_output=True)
assert r.returncode==0, r.stderr
print('SOURCE QA: PASS; XML, JS, HTML DOM IDs, IPC handlers, SQLite schema/transactions, WebView2 runtime receipt.')
