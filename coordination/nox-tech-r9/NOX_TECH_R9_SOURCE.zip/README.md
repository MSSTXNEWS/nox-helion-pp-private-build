# NOX HELION TECH R9 — technical core first

Preserves the existing WPF/WebView2 interface and native commands. This is a technical integration candidate, NOT the completed V16, and not a canonical visual D02 release.

## R9 actual change

* NOX now checks its existing localhost Ollama at startup and automatically starts the already installed `ollama.exe serve` with `OLLAMA_MODELS=C:\NOX_OLLAMA_CLEAN\models` on `127.0.0.1:11436` when the port is free.
* The same guarded start path recovers a stopped Qwen provider before `CHAT` generation, with a single async gate to prevent duplicate server launches. Existing local model `nox-qwen-clean:latest` must be registered. There are no pulls or re-downloads.
* Three-second bounded model inventory calls, clear missing-model/offline state, no stopping existing processes, no external network calls. Owner STOP can cancel a generation waiting for engine recovery.
* Acceptance-only processes **do not auto-launch Ollama** and use isolated SQLite/WebView2 profile paths; native inference remains a separate test on a computer with the real model installed.

## Proven versus pending

Source protocol tests: available cross-platform. Windows .NET compilation and native WebView2 smoke: tested in CI when matching build receipt is present. Owner's local Qwen CHAT/STOP/SQLite on this exact binary: NOT VERIFIED until `FINISH_NOX.cmd` returns a matching native receipt.

No D02 visual overhaul occurs in this stage. Existing releases, stored weights, and user chat databases are not overwritten by the packaged builder.
