import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
HTML=Path(__file__).with_name('src').joinpath('index.html').read_text(encoding='utf-8')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
  page=await browser.new_page(viewport={'width':1440,'height':900})
  await page.set_content(HTML,wait_until='domcontentloaded')
  assert await page.title()=='NOX HELION'
  assert await page.locator('button.core').count()==8
  assert await page.locator('.helion').count()==1
  for name,title in [('core','CORE / LIVE CHAT'),('atlas','ATLAS / TASKS'),('reflection','REFLECTION / HISTORY'),('nexus','NEXUS / MODELS'),('forge','FORGE / TRAINING'),('voice','VOICE'),('persona','PERSONA'),('consciousness','CONSCIOUSNESS')]:
   await page.locator('button[data-route="'+name+'"]').click()
   assert await page.locator('#routeTitle').inner_text()==title, name
   assert await page.locator('.panel.active').get_attribute('data-panel')==name
  await page.locator('button[data-open="core"]').first.click()
  assert await page.locator('#routeTitle').inner_text()=='CORE / LIVE CHAT'
  await page.locator('button#maxMode').click()
  assert await page.locator('#performance').input_value()=='MAX'
  assert await page.locator('#routeTitle').inner_text()=='PERSONA'
  await page.set_viewport_size({'width':800,'height':480})
  await page.screenshot(path='/mnt/data/nox_r1_800x480.png')
  await page.set_viewport_size({'width':390,'height':844})
  await page.screenshot(path='/mnt/data/nox_r1_390x844.png')
  print('UI 8 routes, focus actions, responsive screenshots: PASS')
  await browser.close()
asyncio.run(main())
