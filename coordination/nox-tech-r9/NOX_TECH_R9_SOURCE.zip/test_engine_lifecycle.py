"""NOX technical engine lifecycle source guard; real-Qwen runtime tested separately."""
from pathlib import Path
s=(Path(__file__).parent/'src/MainWindow.xaml.cs').read_text(encoding='utf8')
assert 'if (!selfTestRequested) _ = EnsureProviderAtStartupAsync();' in s
assert 'Interlocked.Exchange(ref startupEngineCheckStarted, 1)' in s
assert 'await engineStartGate.WaitAsync(cancellationToken);' in s
assert 'finally { engineStartGate.Release(); }' in s
assert 'using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(3));' in s
assert 'http.GetAsync(Api + "/api/tags", timeout.Token)' in s
assert 'ps.Environment["OLLAMA_HOST"] = "127.0.0.1:11436";' in s
assert 'ps.Environment["OLLAMA_MODELS"] = modelDir;' in s
assert 'Path.Combine(modelDir, "manifests-v2")' in s
assert 'Path.Combine(modelDir, "blobs")' in s
assert 'cancellation.Token.ThrowIfCancellationRequested();' in s
assert 'await StartLocalEngine(cancellation.Token);' in s
assert 'if (registered == null || !registered.Contains(model, StringComparer.Ordinal))' in s
assert 'if (!await engineStartGate.WaitAsync(0)) return' not in s
assert s.count('Process.Start(ps)') == 1
assert 'Stop-Process' not in s and 'ollama pull' not in s.lower()
assert 'if (!selfTestRequested)' in s
assert 'if (!UiSmokeRequested) _ = CheckProvider();' not in s
print('ENGINE LIFECYCLE SOURCE CONTRACT: PASS (not real model acceptance)')
