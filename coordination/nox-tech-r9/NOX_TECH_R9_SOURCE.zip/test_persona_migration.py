"""Regression of additive persona segregation from existing local databases.
Source-only SQL simulation; not a substitute for native Windows migration QA.
"""
from pathlib import Path
import sqlite3,tempfile
cs=(Path(__file__).parent/'src/MainWindow.xaml.cs').read_text(encoding='utf8')
required=(
    "ALTER TABLE \" + table + \" ADD COLUMN persona_id TEXT NOT NULL DEFAULT 'KV'",
    "CREATE INDEX IF NOT EXISTS idx_chat_persona ON chat_history(persona_id,id)",
    "CREATE INDEX IF NOT EXISTS idx_note_persona ON memory_notes(persona_id,id)",
    "SELECT timestamp,prompt,answer FROM chat_history WHERE persona_id=$persona",
    "SELECT id,created_at,title,content FROM memory_notes WHERE persona_id=$persona",
    "DELETE FROM memory_notes WHERE id=$id AND persona_id=$persona",
    "PersistChat(prompt, answer.ToString(), persona)",
    'active?.Cancel();',
    'Send("history", ReadHistory()); Send("notes", ReadNotes());',
)
for item in required: assert item in cs,item
with tempfile.TemporaryDirectory() as directory:
 db=sqlite3.connect(str(Path(directory)/'original.sqlite'))
 db.executescript('''CREATE TABLE chat_history(id INTEGER PRIMARY KEY,timestamp TEXT NOT NULL,prompt TEXT NOT NULL,answer TEXT NOT NULL);
 CREATE TABLE memory_notes(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL);''')
 db.execute('INSERT INTO chat_history VALUES(1,"prior","KV legacy", "answer")')
 db.execute('INSERT INTO memory_notes VALUES(2,"prior","KV legacy note","text")')
 db.commit()
 for iteration in range(2):
  db.execute('BEGIN')
  for table in ('chat_history','memory_notes'):
   names=[row[1] for row in db.execute('PRAGMA table_info('+table+')')]
   if 'persona_id' not in names: db.execute("ALTER TABLE "+table+" ADD COLUMN persona_id TEXT NOT NULL DEFAULT 'KV'")
  db.commit()
 db.execute("INSERT INTO chat_history(timestamp,prompt,answer,persona_id) VALUES('now','LA','answer','LA')")
 db.execute("INSERT INTO memory_notes(created_at,title,content,persona_id) VALUES('now','LA','text','LA')")
 assert db.execute('SELECT COUNT(*) FROM chat_history WHERE persona_id=?',('KV',)).fetchone()[0]==1
 assert db.execute('SELECT COUNT(*) FROM chat_history WHERE persona_id=?',('LA',)).fetchone()[0]==1
 assert db.execute('SELECT COUNT(*) FROM memory_notes WHERE persona_id=?',('KV',)).fetchone()[0]==1
 assert db.execute('SELECT COUNT(*) FROM memory_notes WHERE persona_id=?',('LA',)).fetchone()[0]==1
 assert db.execute('SELECT COUNT(*) FROM chat_history').fetchone()[0]==2
 assert db.execute('SELECT COUNT(*) FROM memory_notes').fetchone()[0]==2
 db.close()
print('PERSONA MIGRATION CONTRACT: PASS (source SQL simulation; native Windows pending)')
