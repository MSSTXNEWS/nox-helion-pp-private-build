# SKILL CAPSULE {{SkillID}}
SourceLock: {{SourceSHA}}
Model/provider: {{PinnedModel}} (NOT_INSTALLED until verified)
Tools/ACL: {{LeastPrivilegePermissions}}
Input schema: {{InputSchema}}
Output/acceptance: {{OutputSchema}} + {{IndependentTest}}
Operational cost: UNKNOWN until measured
Lifecycle: DRAFT→TESTED→APPROVED→ROLLED_BACK
