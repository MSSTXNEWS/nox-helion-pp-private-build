# Weekly Opportunity Portfolio
New candidates: {{RealNumber}}
Evidence-validated candidates: {{RealNumber}}
Interviews completed: {{RealNumber}}
Pilots launched with signed permission: {{RealNumber}}
Results accepted independently: {{RealNumber}}
Killed hypotheses & preserved lessons: {{RealNumber}}
Actual spend and receipts: {{RealCost}}
Next 3 candidates with source and counterargument: {{RankedIdeas}}
No metrics claimed if NOT_RUN.
