# PRIOR ART: {{IdeaID}}
As-of date: {{Date}}
Competitors (source URLs, exact offer, regions, pricing observed): UNKNOWN
Existing substitute/do-nothing baseline: UNKNOWN
Differentiating measurable user outcome: {{Hypothesis}}
Claim novelty: NOT VERIFIED
Reviewer: PENDING
