# INDEPENDENT SKEPTIC / KILL REVIEW
IdeaID: {{IdeaID}}
Weakest assumption: {{Assumption}}
What competitor already does better: {{Counterexample}}
Legal veto: UNKNOWN / PASS / FAIL
Economic veto: UNKNOWN / PASS / FAIL
Evidence robustness: UNKNOWN
If experiment fails, salvageable Skill/Media/Source: {{Reuse}}
Verdict: HOLD — requires human signoff
