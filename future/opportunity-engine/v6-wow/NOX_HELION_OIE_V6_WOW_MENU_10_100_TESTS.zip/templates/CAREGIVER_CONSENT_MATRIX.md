# NOX CARE TRUST GRAPH (illustrative, NOT granted)
Data owner: {{SeniorUser}}
Caregiver: {{TrustedPerson}}
Data category: {{Checkins/Wearable/Reminders/Notes}}
Scope, purpose, expiration: {{ExplicitPermission}}
Access log: mandatory
Revocation: immediate, propagates to all remote sessions
Family payer != data owner
Emergency escalation: cannot be promised as 24/7 without partner SLA
