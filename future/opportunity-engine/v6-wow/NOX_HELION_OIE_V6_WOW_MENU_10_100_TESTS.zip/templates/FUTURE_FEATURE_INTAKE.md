# NOX NEXT RELEASE INTAKE
IdeaID: {{IdeaID}}
Requested release: FUTURE only
R1 SourceLock/D02/8 CoreID/5 Persona: IMMUTABLE
Owner of code changes: {{Owner}}
Exact preimage SHA and paths: UNKNOWN
Reuse-first options: {{ExistingModule}}
One user-visible vertical slice: {{VerticalSlice}}
STOP/ACL/Consent/test: {{Checklist}}
BuildID and installed QA: NOT_RUN
No automatic app deployment from this template.
