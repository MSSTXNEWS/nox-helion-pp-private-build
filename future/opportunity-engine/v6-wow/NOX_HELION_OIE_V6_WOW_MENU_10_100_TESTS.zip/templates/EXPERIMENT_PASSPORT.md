# TEST RUN {{ExperimentID}}
Frozen hypothesis: {{Hypothesis}}
Owner grant: {{OwnerGrantID}} or HOLD
Pre-registered measurement: {{Metric}}
Sample & expected effect: {{Design}}
Stop budget: {{BudgetCap}}
Safety/rights veto: {{RightsReceipt}}
Baseline: {{Baseline}}
Date/source revisions: {{Sources}}
Result: NOT_RUN
Decision: HOLD until independent QA
