# NOX IDEA PASSPORT — {{IdeaID}} / {{Version}}
**Status:** IDEA_UNVERIFIED  | **Scope:** FUTURE  | **Owner:** {{Owner}}
## Пользовательская проблема
- Кто реально страдает: {{Beneficiary}}
- Проверяемая проблема / обходной процесс: {{Problem}}
- Наблюдаемые доказательства / даты / первичные источники: {{EvidenceLinksOrUNKNOWN}}
## Продукт
- First 5 minutes / конкретная польза: {{FirstFiveMinutes}}
- Что уже существует / сравнение с лучшей альтернативой: {{CompetitorPriorArt}}
- Контракт первого полного результата: {{OutputArtifact}}
- Что переиспользуем из NOX: {{ReuseVerified}}; чего пока нет: {{Missing}}
## Бизнес и право
- Кто оплачивает и почему: {{Payer}}
- Сценарный тариф (НЕ факт): {{PriceHypothesis}}
- Cost assumptions, fixed vs variable: {{CostModel}}
- Права, дети, здоровье, приватность, страна: {{RightsGate}}
- Причины отказа / KILL: {{RedFlags}}
## Эксперимент
- Проверка на ограниченном бюджете, без авто-публикации: {{Pilot}}
- Критерий PASS / KILL: {{Thresholds}}
- Фактический результат: NOT_RUN
- Owner grant / independent QA: NOT_GRANTED / NOT_RUN
