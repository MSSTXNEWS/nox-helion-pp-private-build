@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 -m engine.cli studio --port 8765 & goto end)
where python >nul 2>nul
if not errorlevel 1 (python -m engine.cli studio --port 8765 & goto end)
echo [NOX OIE] Python 3.10+ is required and was not found. No software will be silently installed.
:end
if errorlevel 1 echo [NOX OIE] Error. Read README.md for details.
pause
