"""Optional actual Chromium interactive visual QA, separate from headless source unit tests."""
import sys,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from engine.studio import Server,make_handler
from playwright.sync_api import sync_playwright
out=ROOT/'output'/'OIE_V4_studio_live_screenshot.png'
server=Server(('127.0.0.1',0),make_handler('test-secret-token'))
url=f'http://127.0.0.1:{server.server_port}/'
t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--no-proxy-server','--proxy-bypass-list=*'])
  page=browser.new_page(viewport={'width':1440,'height':1040},device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(url)
  page.locator('article.idea').first.wait_for(timeout=15000)
  assert page.locator('article.idea').count()==60
  page.locator('#generate').click()
  page.locator('#result article.idea').first.wait_for(timeout=10000)
  assert page.locator('#result article.idea').count()==3
  page.locator('#catalog article.idea').first.click()
  page.locator('#inspector').get_by_text('NEED_TRUSTED_EXTERNAL_AUTHORITY').wait_for(timeout=10000)
  page.screenshot(path=str(out),full_page=False)
  print({'browser':'chromium','ideas':60,'proposals':3,'host_policy':'PASS','inspector':'PASS','errors':errors,'screenshot':str(out)})
  assert not errors
  mobile=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  mobile.goto(url)
  mobile.locator('article.idea').first.wait_for()
  mobile.screenshot(path=str(ROOT/'output'/'OIE_V4_studio_mobile.png'),full_page=False)
  print({'mobile':'PASS','width':390})
  browser.close()
finally:
 server.shutdown();server.server_close();t.join(timeout=2)
