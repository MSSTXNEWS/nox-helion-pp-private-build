import sys,unittest,json,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from engine.gates import validate,evidence_ready,can_enter_pilot,score_exploratory_only
from engine.cli import main
class EngineContractTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.ideas=json.loads((ROOT/'catalog/ideas_60.json').read_text('utf-8'))
 def test_catalog_count(self):self.assertEqual(len(self.ideas),60)
 def test_unique(self):self.assertEqual(len({x['id'] for x in self.ideas}),60)
 def test_all_source_only(self):self.assertTrue(all(x['status']=='IDEA_UNVERIFIED' for x in self.ideas))
 def test_valid(self):self.assertTrue(all(not validate(x) for x in self.ideas))
 def test_no_fake_market_evidence(self):self.assertTrue(all(evidence_ready(x) for x in self.ideas))
 def test_no_unauthorized_pilot(self):self.assertTrue(all(can_enter_pilot(x) for x in self.ideas))
 def test_no_fabricated_scores(self):self.assertTrue(all(score_exploratory_only(x) is None for x in self.ideas))
 def test_no_auto_publish(self):self.assertTrue(all(not x['publication_authorized'] for x in self.ideas))
 def test_guard_no_single_source(self):
  x=copy.deepcopy(self.ideas[0]);x['external_demand_evidence']=[{'url':'https://example.org/1','date':'2026-10-31','claim':'interview'},{'url':'https://example.org/2','date':'2026-10-31','claim':'survey'}];x['competitor_evidence']=[{'url':'https://example.org/3','date':'2026-10-31','competitor':'Known'}]
  self.assertIn('NEED_2_INDEPENDENT_DEMAND_HOSTS',evidence_ready(x))
 def test_sensitive_no_rights_review(self):
  x=copy.deepcopy(self.ideas[0]);x['owner_approved_to_build']=True;x['pilot_protocol_sha256']='a'*64
  self.assertIn('NEED_INDEPENDENT_RIGHTS_REVIEW',can_enter_pilot(x))
 def test_owner_permission(self):
  x=copy.deepcopy(self.ideas[0]);x['publication_authorized']=True
  self.assertIn('PUBLISH_WITHOUT_OWNER_GRANT',validate(x))
 def test_cli_verify(self):self.assertEqual(main(['verify']),0)
if __name__=='__main__':unittest.main()
