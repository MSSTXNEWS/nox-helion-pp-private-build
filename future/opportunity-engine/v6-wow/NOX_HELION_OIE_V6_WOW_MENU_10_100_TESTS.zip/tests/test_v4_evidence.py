import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine.evidence import compile_research_packet,load_research_packet
ROOT=Path(__file__).resolve().parents[1]

class EvidenceTests(unittest.TestCase):
 def setUp(self):self.source=json.loads((ROOT/'examples'/'care_source_notes.json').read_text())
 def test_care_packet(self):
  p=compile_research_packet(self.source['idea_id'],self.source['notes'])
  self.assertEqual(p['source_count'],3);self.assertFalse(p['market_demand_verified']);self.assertEqual(len(p['sha256']),64)
 def test_replay_same_hash(self):
  p=compile_research_packet(self.source['idea_id'],self.source['notes'])
  q=compile_research_packet(self.source['idea_id'],self.source['notes'])
  self.assertEqual(p,q)
 def test_source_no_local(self):
  a=self.source['notes'];a[0]['url']='https://127.0.0.1/private'
  with self.assertRaisesRegex(ValueError,'INVALID_SOURCE_URL'):compile_research_packet('OI-001',a)
 def test_date_no_future(self):
  a=self.source['notes'];a[1]['published']='2030-01-01'
  with self.assertRaisesRegex(ValueError,'INVALID_DATE'):compile_research_packet('OI-001',a)
 def test_user_suspicious_notes_not_authority(self):
  a=self.source['notes'];a[0]['owner_grant_receipt']={'status':'VERIFIED_BY_EXTERNAL_OWNER_AUTH'}
  packet=compile_research_packet('OI-001',a)
  self.assertFalse(packet['owner_grant_present']);self.assertFalse(packet['market_demand_verified'])
 def test_packet_from_file(self):
  p=load_research_packet(ROOT/'examples'/'care_source_notes.json')
  self.assertEqual(p['status'],'CONTEXT_REQUIRES_INDEPENDENT_REVIEW')
 def test_not_classify_unknown(self):
  a=self.source['notes'];a[0]['category']='PROVEN_PAYING_CUSTOMER'
  with self.assertRaisesRegex(ValueError,'UNKNOWN_CATEGORY'):compile_research_packet('OI-001',a)
if __name__=='__main__':unittest.main()
