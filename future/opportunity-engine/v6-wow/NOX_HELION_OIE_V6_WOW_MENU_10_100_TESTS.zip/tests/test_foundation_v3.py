"""Negative contract tests: cannot convert paper evidence into real-world truth."""
import unittest,sys,json,copy,sqlite3,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from engine.gates import source_host,valid_iso_date,evidence_ready,can_enter_pilot,score_exploratory_only,audit
from engine.discovery import propose,load_seeds
from engine.journal import append,verify
from engine.cli import main

class V3Contracts(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.data=json.loads((ROOT/'catalog/ideas_60.json').read_text('utf-8'))
 def test_real_sources_avoid_local_fake(self):
  for v in ['http://real.com','https://127.0.0.1/x','https://localhost/a','https://demo.invalid/a','https://x.test/a','https://someone@google.com/x','https://name:pass@google.com/x','https://host.com:444/a']:
   self.assertIsNone(source_host(v),v)
 def test_subdomains_not_independent(self):
  self.assertEqual(source_host('https://a.example.com/a'),source_host('https://b.example.com/b'))
  self.assertEqual(source_host('https://www.oxford.co.uk/a'),source_host('https://news.oxford.co.uk/b'))
 def test_evidence_must_have_real_date_and_claim(self):
  x=copy.deepcopy(self.data[0]);x['external_demand_evidence']=[{'url':'https://alpha.org/x','claim':'valid descriptive claim of 20 chars','date':'2050-01-01'}, {'url':'https://beta.net/x','claim':'valid second claim for audit','date':'2026-10-31'}]
  self.assertIn('NEED_2_INDEPENDENT_DEMAND_HOSTS',evidence_ready(x))
 def test_no_grant_from_boolean_and_sha(self):
  x=copy.deepcopy(self.data[0]);x['owner_approved_to_build']=True;x['pilot_protocol_sha256']='a'*64
  x['external_evidence_verified']=True
  self.assertIn('NEED_AUTHENTICATED_OWNER_GRANT',can_enter_pilot(x))
 def test_forced_receipts_still_research_not_market_verified(self):
  x=copy.deepcopy(self.data[0]);x['owner_grant_receipt']={'action':'pilot','status':'FAKE','receipt_id':'123456789012'}
  x['external_evidence_verified']=True
  self.assertIn('NEED_AUTHENTICATED_OWNER_GRANT',can_enter_pilot(x))
 def test_forged_json_receipts_never_grant_pilot_offline(self):
  x=copy.deepcopy(self.data[0]);x['owner_approved_to_build']=True;x['pilot_protocol_sha256']='a'*64
  x['external_demand_evidence']=[{'url':'https://source-one.org/a','date':'2026-10-31','claim':'A full evidence claim 20+ chars'},{'url':'https://source-two.net/a','date':'2026-10-31','claim':'Another full claimed data source'}]
  x['competitor_evidence']=[{'url':'https://existing-product.com','date':'2026-10-31','competitor':'An incumbent'}]
  x['owner_grant_receipt']={'action':'pilot','status':'VERIFIED_BY_EXTERNAL_OWNER_AUTH','receipt_id':'fake_reception_123456'}
  x['independent_rights_review_receipt']={'verdict':'APPROVED','status':'VERIFIED_BY_INDEPENDENT_REVIEWER'}
  x['external_evidence_verified']=True
  self.assertEqual(can_enter_pilot(x),['NEED_TRUSTED_EXTERNAL_AUTHORITY'])
 def test_sensitive_requires_real_rights(self):
  self.assertIn('NEED_INDEPENDENT_RIGHTS_REVIEW',can_enter_pilot(self.data[0]))
 def test_deterministic_drafts(self):
  a=propose(self.data,limit=4,seed=1);b=propose(self.data,limit=4,seed=1)
  self.assertEqual(a,b);self.assertEqual(a['count'],4)
 def test_diverse_streams(self):
  z=propose(self.data,limit=5,seed=5)['candidates']
  self.assertEqual(len({x['stream'] for x in z}),5)
 def test_no_fake_market_claim(self):
  self.assertTrue(all(x['market_demand']=='UNKNOWN' and x['pilot_run'] is False and x['actual_revenue'] is None for x in propose(self.data,limit=12)['candidates']))
 def test_limit_and_theme(self):
  with self.assertRaises(ValueError):propose(self.data,limit=13)
  self.assertEqual(propose(self.data,theme='impossible-never-matches')['count'],0)
 def test_no_auto_status_approval(self):
  x=audit(self.data[0]);self.assertFalse(x['release_ready']);self.assertTrue(x['pilot_blockers'])
 def test_journal_append_and_verify(self):
  with tempfile.TemporaryDirectory() as tmp:
   db=Path(tmp)/'x.db'
   a=append(db,'CANDIDATE_DRAFTED',{'candidate':'OC-1'})
   b=append(db,'RESEARCH_FLAGGED',{'note':'not ready'})
   self.assertEqual(a['seq'],1);self.assertEqual(b['seq'],2)
   self.assertEqual(verify(db)['events'],2)
 def test_journal_tamper_fails(self):
  with tempfile.TemporaryDirectory() as tmp:
   db=Path(tmp)/'x.db';append(db,'CANDIDATE_DRAFTED',{'candidate':'OC-1'})
   with sqlite3.connect(db) as cx:cx.execute("UPDATE events SET payload='{}' WHERE seq=1")
   self.assertFalse(verify(db)['valid'])
 def test_journal_disallows_actions(self):
  with tempfile.TemporaryDirectory() as tmp:
   with self.assertRaises(ValueError):append(Path(tmp)/'x.db','PAYMENT_PROCESSED',{})
 def test_verify_command(self):self.assertEqual(main(['verify']),0)
 def test_cli_discover(self):self.assertEqual(main(['discover','--count','3']),0)
 def test_journal_empty(self):
  with tempfile.TemporaryDirectory() as tmp:self.assertTrue(verify(Path(tmp)/'x.db')['valid'])
if __name__=='__main__':unittest.main()

class WorkflowMoreTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.idea=json.loads((ROOT/'catalog/ideas_60.json').read_text('utf-8'))[0]
 def test_can_plan_research(self):
  from engine.workflow import plan_transition
  self.assertTrue(plan_transition(self.idea,'RESEARCHING')['permitted_by_evidence'])
 def test_no_jump_to_pilot(self):
  from engine.workflow import plan_transition
  x=plan_transition(self.idea,'PILOT_APPROVED')
  self.assertIn('ILLEGAL_TRANSITION',x['blockers'])
 def test_no_unverified_research_evidence_stage(self):
  from engine.workflow import plan_transition
  x=copy.deepcopy(self.idea);x['status']='RESEARCHING'
  self.assertIn('NEED_INDEPENDENT_SOURCE_READBACK',plan_transition(x,'EVIDENCE_READY')['blockers'])
 def test_no_kill_without_reason(self):
  from engine.workflow import plan_transition
  self.assertIn('NEED_RECORDED_KILL_REASON',plan_transition(self.idea,'KILL')['blockers'])
