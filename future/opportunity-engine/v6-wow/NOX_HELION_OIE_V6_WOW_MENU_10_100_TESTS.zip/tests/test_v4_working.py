"""Integrated V4 tests, including true localhost HTTP and mock provider reads."""
import contextlib,io,json,os,re,sys,tempfile,threading,unittest
from pathlib import Path
from urllib.request import urlopen,Request
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine.research import query_crossref,query_openalex,secure_get_json,SourceError
from engine.llm import propose_local,LocalModelError
from engine.pipeline import run_mission,save_json_atomic
from engine.integration import run_job
from engine.studio import Server,make_handler
from engine.cli import main
ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'catalog/ideas_60.json').read_text('utf-8'))

class MemoryResponse:
 def __init__(self,data,ct='application/json',status=200):
  self.data=data if isinstance(data,bytes) else json.dumps(data).encode();self.headers={'Content-Type':ct};self.status=status
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def read(self,limit=-1):return self.data[:limit] if limit!=-1 else self.data

def fake_crossref(url,timeout):
 assert url.startswith('https://api.crossref.org/works?')
 return MemoryResponse({'message':{'items':[{'title':['Relevant research only'],'DOI':'10.1234/study1','published':{'date-parts':[[2023,6,1]]},'URL':'https://doi.org/10.1234/study1'}]}})
def fake_openalex(url,timeout):
 assert url.startswith('https://api.openalex.org/works?')
 return MemoryResponse({'results':[{'id':'https://openalex.org/W987654','title':'Care research','publication_year':2024}]})

class OIEV4Tests(unittest.TestCase):
 def test_readonly_mission_three(self):
  a=run_mission(DATA,count=3,seed=17)
  self.assertEqual(a['candidate_count'],3)
  self.assertFalse(a['pilot_approved']);self.assertEqual(a['businesses_launched'],0)
  self.assertTrue(all(x['acceptance']=='RESEARCH_REQUIRED' for x in a['results']))
  self.assertEqual(len({x['candidate']['stream'] for x in a['results']}),3)
 def test_determinism(self):
  self.assertEqual(run_mission(DATA,seed=2),run_mission(DATA,seed=2))
 def test_network_denied_by_default(self):
  with self.assertRaisesRegex(ValueError,'NETWORK_NOT_AUTHORIZED'):run_mission(DATA,research='crossref')
  with self.assertRaisesRegex(SourceError,'NETWORK_NOT_AUTHORIZED'):query_crossref('problem')
 def test_mock_public_research_context(self):
  m=run_mission(DATA,count=1,research='crossref',network=True,research_transport=fake_crossref)
  hit=m['results'][0]['context']['hits'][0]
  self.assertEqual(hit['classification'],'SCHOLARLY_CONTEXT_NOT_MARKET_DEMAND')
  self.assertFalse(m['market_demand_verified']);self.assertFalse(m['pilot_approved'])
 def test_scholarly_hit_not_demand(self):
  r=query_crossref('test',network=True,transport=fake_crossref)
  self.assertEqual(r['count'],1);self.assertFalse(r['prior_art_complete']);self.assertFalse(r['verified_demand'])
 def test_openalex(self):
  r=query_openalex('test',network=True,transport=fake_openalex)
  self.assertEqual(r['count'],1);self.assertEqual(r['hits'][0]['provider'],'OpenAlex')
 def test_no_unknown_hosts(self):
  for u in ['https://127.0.0.1/works','http://api.crossref.org/works','https://evil.example/works',
            'https://u:pass@api.crossref.org/works','https://api.crossref.org:81/works']:
   with self.assertRaisesRegex(SourceError,'SOURCE_NOT_ALLOWLISTED'):secure_get_json(u)
 def test_reject_redirect(self):
  with self.assertRaisesRegex(SourceError,'REDIRECT_BLOCKED'):
   raise SourceError('REDIRECT_BLOCKED')
 def test_oversized_response(self):
  with self.assertRaisesRegex(SourceError,'RESPONSE_TOO_LARGE'):
   secure_get_json('https://api.crossref.org/works',transport=lambda u,t:MemoryResponse(b'x'*(1024*1024+2)))
 def test_wrong_content_type(self):
  with self.assertRaisesRegex(SourceError,'UNEXPECTED_CONTENT_TYPE'):
   secure_get_json('https://api.crossref.org/works',transport=lambda u,t:MemoryResponse(b'{}',ct='text/html'))
 def test_broken_provider(self):
  with self.assertRaisesRegex(SourceError,'INVALID_ITEMS'):
   query_crossref('test',network=True,transport=lambda u,t:MemoryResponse({'message':{'items':'not array'}}))
 def test_provider_query_validation(self):
  with self.assertRaisesRegex(SourceError,'INVALID_QUERY'):query_crossref('x',network=True)
  with self.assertRaisesRegex(SourceError,'ROW_LIMIT'):query_crossref('valid',network=True,rows=100)
 def test_no_openalex_key_in_url(self):
  with self.assertRaisesRegex(SourceError,'CREDENTIALS_REQUIRE_HOST_ADAPTER'):
   query_openalex('research',network=True,api_key='secret')
 def test_llm_no_auto(self):
  with self.assertRaisesRegex(LocalModelError,'LOCAL_MODEL_NOT_AUTHORIZED'):propose_local('sample question',model='small')
 def test_llm_invalid_model(self):
  with self.assertRaisesRegex(LocalModelError,'MODEL_NAME_INVALID'):propose_local('sample question',model='http://evil/a',enabled=True)
 def test_mock_llm_schema(self):
  payload={k:'A tentative idea for humans' for k in ('title','problem','first_value','payer_hypothesis','alternatives_to_check','pilot_to_falsify','risks')}
  def fake(body):return MemoryResponse({'response':json.dumps(payload)})
  r=propose_local('A question about families',model='llama3.2:3b',enabled=True,transport=fake)
  self.assertEqual(r['status'],'IDEA_UNVERIFIED');self.assertIsNone(r['verified_revenue']);self.assertFalse(r['prior_art_complete'])
 def test_llm_malformed(self):
  with self.assertRaisesRegex(LocalModelError,'MODEL_JSON_SCHEMA_MISMATCH'):
   propose_local('sample question',model='test:3b',enabled=True,transport=lambda body:MemoryResponse({'response':'{"title":"x"}'}))
 def test_ollama_pipeline_one(self):
  values={k:'Long enough hypothetical content' for k in ('title','problem','first_value','payer_hypothesis','alternatives_to_check','pilot_to_falsify','risks')}
  m=run_mission(DATA,count=1,provider='ollama',model='llama3.2:3b',theme='need',llm_transport=lambda b:MemoryResponse({'response':json.dumps(values)}))
  self.assertEqual(m['candidate_count'],1);self.assertFalse(m['market_demand_verified'])
 def test_local_adapter_readonly(self):
  request={'contract':'nox.oie.job.v1','action':'mission.run','parameters':{'count':3,'theme':''}}
  output=run_job(request)
  self.assertTrue(output['ok']);self.assertFalse(output['result']['pilot_approved'])
 def test_local_adapter_refuse_external(self):
  for action in ['publish','pilot.approve','grant','create.task','charge','deploy']:
   self.assertEqual(run_job({'contract':'nox.oie.job.v1','action':action})['error'],'ACTION_DENIED')
 def test_bad_contract(self):
  self.assertEqual(run_job({'action':'idea.list'})['error'],'CONTRACT_UNSUPPORTED')
 def test_lookup_real_catalog(self):
  self.assertEqual(run_job({'contract':'nox.oie.job.v1','action':'idea.list'})['result']['count'],60)
  self.assertFalse(run_job({'contract':'nox.oie.job.v1','action':'idea.inspect','idea_id':'OI-001'})['result']['audit']['release_ready'])
 def test_save_exclusive(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'nested'/'a.json'
   r=save_json_atomic(path,{'status':'IDEA_UNVERIFIED'})
   self.assertEqual(len(r['sha256']),64)
   with self.assertRaisesRegex(FileExistsError,'REFUSE_OVERWRITE_RESULT'):save_json_atomic(path,{'status':'PILOT_APPROVED'})
 def test_journal_mission(self):
  from engine.journal import verify
  with tempfile.TemporaryDirectory() as d:
   file=Path(d)/'events.db'
   r=run_mission(DATA,count=2,journal=file)
   self.assertEqual(r['journal_receipt']['seq'],1)
   self.assertEqual(verify(file)['events'],1)
 def test_cli_mission_and_file(self):
  with tempfile.TemporaryDirectory() as d:
   with contextlib.redirect_stdout(io.StringIO()):
    self.assertEqual(main(['mission','--count','2','--output',str(Path(d)/'out.json')]),0)
   self.assertFalse(json.loads((Path(d)/'out.json').read_text())['pilot_approved'])
 def test_cli_network_denied(self):
  with contextlib.redirect_stderr(io.StringIO()):self.assertEqual(main(['mission','--research','crossref']),2)
 def test_http_ui_security_and_read(self):
  server=Server(('127.0.0.1',0),make_handler('super-secret-token'))
  port=server.server_port;thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  base=f'http://127.0.0.1:{port}'
  try:
   with urlopen(base+'/') as r:self.assertIn(b'OPPORTUNITY INVENTION LAB',r.read())
   with urlopen(base+'/api/ideas') as r:self.assertEqual(json.load(r)['result']['count'],60)
   with urlopen(base+'/api/inspect?id=OI-001') as r:self.assertEqual(json.load(r)['result']['idea']['id'],'OI-001')
   with self.assertRaises(HTTPError) as cm:urlopen(Request(base+'/api/mission',data=b'{}',method='POST'))
   self.assertEqual(cm.exception.code,403)
   body=json.dumps({'theme':'','count':2}).encode()
   request=Request(base+'/api/mission',data=body,method='POST',headers={'X-NOX-OIE-Token':'super-secret-token','Content-Type':'application/json'})
   with urlopen(request) as r:self.assertEqual(json.load(r)['result']['candidate_count'],2)
  finally:
   server.shutdown();server.server_close();thread.join(timeout=2)

if __name__=='__main__':unittest.main()
