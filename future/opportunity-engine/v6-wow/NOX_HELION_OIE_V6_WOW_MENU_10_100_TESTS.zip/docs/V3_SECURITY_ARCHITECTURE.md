# NOX OIE V3 — trustworthy foundation, not a launched autonomous company

## Provenance and guardrails

- All 60 old passports are unchanged concept hypotheses. Ten seed problem descriptions are manually curated **creative seeds**, not collected from the web, not research evidence.
- `engine/discovery.py`: deterministic offline conceptual recombination, human-readable output; novelty only relative to existing catalog titles and NOT legal/public novelty.
- `engine/gates.py`: URL syntax, dated sources, conservative root-domain dedup. **Neither a URL nor a date proves a claim**. Actual live retrieval, independent source readback, medical review, and verified owner grants require separate authenticated connector access.
- `can_enter_pilot(..., trusted_authority=None)` **ALWAYS denies production admission offline**; an untrusted JSON `owner_grant_receipt` cannot grant authority. Only a separately authenticated real backend may provide that callable with out-of-band validated grant/evidence. NO trusted backend is included in V3.
- `engine/workflow.py`: stage transition advice only; cannot promote real catalog state.
- `engine/journal.py`: SQLite append-only SHA chain helps detect accidental modifications, not cryptographic nonrepudiation (a DB owner could rewrite all rows). No payments, messages, publication, child/medical record access, or external effects.
- Data source policy: use approved public data and consented sources, never users' private contents to identify generalized business opportunities. Use dated citations for any actual market claim. GDPR/medical/child safety veto is mandatory.

## Integration interface when future release is authorized

Existing NOX core / Mission Commander → OIE adapter with narrow `discover`, `research`, `audit`, `draft_passport` functions → existing ACL/STOP/Consent → independent evidence reviewer and owner-grant verifier → Outcome Engine. Not a second runtime, not a new CoreID/Persona, not a competing Windows process or paid API.

`DiscoveryProposal` status is **IDEA_UNVERIFIED**; `EvidenceReview` is ADVISORY; `OutcomeReceipt` is produced only from externally observable actions with actual independent proof. Never auto-merge source modifications or auto-purchase resources.

## First remote evidence adapter contract (future)

`research(id, source_url, read_at, source_extract, content_hash, provider, rights_basis)` with immutable source content hash and retrieved timestamp. Requires **two genuinely independent sources**, a competitor/prior-art check, validation of each real fact, and separate review by a different agent/person. The local gate only recognizes structured fields; it cannot perform online verification.

`grant(owner_identity, scope, action, expiry, nonce)` must come from authenticated host API, checked at execution time; no user-editable JSON boolean substitutes for the grant. Strict task/tenant isolation and revocation.

## Release 1 Function Lock

NOX Windows R66/R1, 729 SourceLock, original D02/HOME/MENU/WORK, 8 CoreID/5 PersonaID and already accepted source media are OUT OF SCOPE. This source kit runs exclusively offline on its own directory.
