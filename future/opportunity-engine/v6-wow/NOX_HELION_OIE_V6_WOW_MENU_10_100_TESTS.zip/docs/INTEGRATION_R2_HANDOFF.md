# NOX OIE V4 → future R2 host intake

**No source modifications of active R1.** Integrator can stage this folder as a future isolated plugin only after owner scope approval.

## Ingress

`engine.integration.run_job({"contract":"nox.oie.job.v1","action":"mission.run","parameters":{"count":3,"seed":0,"theme":""}})`

Other actions: `capabilities`, `idea.list`, `idea.inspect`.

## Egress

`{"ok":true,"contract":"nox.oie.result.v1","result":{ ... }}`. All generated candidates have status IDEA_UNVERIFIED. Observational research is never granted authority to publish, spend or enroll user.

## AuthZ contract

The integration deliberately rejects `pilot.approve`, `publish`, `grant`, `charge`, `create.task` and similar actions. A future authorized R2 host should independently verify principal identity, tenant, scope, budget, time limits, sensitive-data classification, rights review, and independent QA, then build and sign an external permit. This V4 module cannot issue one.

## Runtime

Python 3.10+ standard library, no heavy automatic dependencies. Ollama only if independently installed/consented. Browser preview remains optional; desktop UI remains existing owner WPF/WebView2 with immutable approved media.

## Integration tests required when admitted

1. R1 SourceLock tree unchanged and separate R2 source branch.
2. One host, not duplicate Python host / PersonaID / CoreID.
3. `mission.run` returns three hypotheses, no external actions, no hidden source reads.
4. Deny injection, forged permissions and forbidden actions at host boundary.
5. Explicit user STOP cancels any R2 research worker and releases memory.
6. Ability to test one authorized provider with true HTTP, source provenance and rate-limit behavior.
7. Independent evaluator judges at least 10 held-out problems and competitor detection.
8. Same-BuildID installed Windows QA before promoting to a future release.
