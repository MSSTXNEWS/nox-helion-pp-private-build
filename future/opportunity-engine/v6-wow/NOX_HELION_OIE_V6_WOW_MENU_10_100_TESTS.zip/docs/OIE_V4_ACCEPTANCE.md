# OIE V4 · Release Gate · 2026-10-31

| Scope | Status | Evidence | Caveat |
|---|---|---|---|
| V3 historical catalog | PASS | 60 markdown passports byte-exact vs original V3 ZIP | Ideas not market-tested |
| V4 offline pipeline | PASS | test suite + real mission JSON artifact | Curated seeds, not autonomous web discovery |
| V4 read-only future NOX host bridge | PASS | direct contract integration tests | NOT loaded into R1 |
| Crossref/OpenAlex adapters | PASS source | mock transport and safety tests | Live external API not exercised here |
| Optional local Ollama adapter | PASS source | mock Ollama response and schema tests | Real LLM not connected here |
| UI HTTP catalog/action endpoints | PASS | Python localhost HTTP tests | Browser Chromium blocked by admin |
| V4 evidence note compiler | PASS | contextual provenance tests | Does not prove demand or validate competitors |
| Permissions / grants | PASS fail-closed | forged grant tests / no PILOT_APPROVED | Host-signed grants unavailable |
| Local audit ledger | PASS | hash-chain tests | Not cryptographically signed |
| Independent physical market experiments | HOLD | No users / external pilot | Requires owner authorization |
| Real monetization and business creation | HOLD | No revenue / no company | Requires market proof & legal review |
| NOX Windows R1 integration | HOLD | SourceLock / host unmodified | R1 release path must remain untouched |
| Installed Windows E07/G5 acceptance | HOLD | No Windows same-SHA setup | Separate Windows executor |

**Never use one global “100%” indicator for all scopes.** Report per-scope physical evidence, one RunID/SHA, strict block statuses, and next viable action.
