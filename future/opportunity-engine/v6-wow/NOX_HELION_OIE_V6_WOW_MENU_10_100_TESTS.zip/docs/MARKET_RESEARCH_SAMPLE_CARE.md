# Public contextual leads · OI-001 NOX CARE

Retrieved and manually discussed on 2026-10-31. These are pointers to public context, not an independent market-demand validation, user interview, willingness-to-pay test, or legal authorization.

1. [Technology Use Among Family Caregivers](https://www.caregivingintheus.org/reports/technology-use-among-family-caregivers-2/) — published February 2026: among respondents to 2025 US caregiving research, remote monitoring tools used by 25%, versus 13% in 2020. **Does not prove demand for this NOX product.**
2. [Caregiving in the US 2025](https://www.aarp.org/pri/topics/ltss/family-caregiving/caregiving-in-the-us-2025/) — AARP, 2025-07-24, describes extensive real caregiving responsibilities. **Macro-context only.**
3. [Apple HealthKit Privacy](https://developer.apple.com/documentation/HealthKit/protecting-user-privacy) — user permissions are per-category; no advertising based on HealthKit data and narrow limits on third-party sharing. **Provider policy, not demand.**
4. [ElliQ](https://elliq.com/pages/caregivers) — existing adjacent companion/caregiver product. **Re-verify its current offering and regional availability before a competitive claim.**

The corresponding `examples/care_source_notes.json` is intentionally flagged CONTEXT_REQUIRES_INDEPENDENT_REVIEW, and is not inserted into the user's personal/medical data.
