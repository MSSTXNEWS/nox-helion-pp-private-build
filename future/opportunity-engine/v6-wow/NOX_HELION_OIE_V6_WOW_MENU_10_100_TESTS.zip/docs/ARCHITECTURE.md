# NOX Opportunity Invention Engine V2 — Future architecture
## Mandate
Invent and pressure-test new startups from human needs, non-consumption, cross-domain combinatorics, life transitions and existing verified NOX capabilities. This is a future-module source/data donor. **It is not deployed, not running autonomous background agents, not integrated into R1, and does not claim 60 validated markets**.
## One existing engine / one owner
`Existing NOX TTVE / Venture Foundry` → `Opportunity job` → `E01..E12 candidate discovery` → `R01..R12 role orchestration` → `ProblemGraph` → `IdeaPassport` → `Independent skeptic / veto` → `Pilot design` → `Human approval` → `Outcome Engine receipt`. No new LLM backend, persona or CoreID, no app publication.
## Core entities
ProblemNode, NeedEvidence, PriorArt, CapabilitySource, IdeaCandidate, PersonaBeneficiary, PayerProfile, RightsVeto, PilotProtocol, ExperimentReceipt, OutcomePassport, RejectedIdea, SourceLock. Tables/scopes are FUTURE schema design; existing SQLite not modified.
## Pipeline
1) Scout: dated demand source + actual user workaround; 2) invent 3 independent categories (avoid anchoring) 3) resolve existing alternatives and actual users 4) generate first-five-minutes value 5) technical reuse & license check 6) rights/legal/health/minor/privacy veto 7) cost scenarios with UNKNOWN 8) human-authorized small pilot 9) independent outcome 10) KEEP/HOLD/KILL and update procedural knowledge.
## Safeguards
Default all candidates IDEA_UNVERIFIED, no estimated fake revenue, no web/LLM calls by this kit. A high heuristic score cannot bypass evidence or owner gate. No automatic purchases, messages, accounts, paid APIs, legal filings, app installs, cloud access, external production writes or patient monitoring. No personalized medical advice or emergency SLA.
## Built-in anti-anchoring
Each research batch includes at least one category not recently discussed; deduplicate by problem/beneficiary/user experience instead of superficial name; include do-nothing alternative; maintain rejected hypotheses as part of knowledge.
## Source lock
This directory may be applied only after current R1 release and a separate owner integration authorization. All code here operates offline under the standard library and never changes `ci/nox-r66*`, `.circleci`, D02, original media, 8 CoreIDs or five PersonaIDs.
