# NOX OIE V3 · Release integration acceptance (FUTURE R2+)

## What is physically done now
- [x] Previous 60 unverified idea passports retained without data claims.
- [x] Offline problem-combination proposer; result status remains `IDEA_UNVERIFIED`.
- [x] Controlled source/date/domain format checks; source HTML/article contents are **not fetched**.
- [x] Competitor, demand, sensitive rights and authenticated owner grants deny pilot when unverified.
- [x] Advisory phase transition matrix, and an SQLite SHA-chained event log.
- [x] 34 unit tests. The test count is not a percentage of scientific/business effectiveness.
- [x] 3 sample hypothetical idea proposals from `--seed 11`; no claims of external validation.
- [x] No changes to Windows R1/D02/SourceLock/host/main branch.

## Explicitly NOT done / gates remaining
- [ ] Integrate into running NOX local agent runtime; V3 is a standalone offline **source donor**.
- [ ] Real connector source fetching with publication date and content hash; respect site/data rights.
- [ ] Independent demand/competitor validation from actual sources.
- [ ] Genuine novel-value measurement against comparable existing products.
- [ ] Owner-authenticated grant and per-tenant authorization system.
- [ ] 3 prospective unrelated-problem research evaluations evaluated by a blinded human.
- [ ] Real pilot, user interviews, bills/consent, measured outcome.
- [ ] Independent product acceptance/installed Windows QA.

## 8 permanent invariants
1. No false demand, sales, academic novelty or installed capability claims.
2. User and third-party privacy isolation.
3. No medical monitoring/disease diagnosis without regulatory review and appropriate hardware validation.
4. Children have separate rights and age-appropriate rules.
5. No research write/publish/spend without granted authorization.
6. STOP, revoke, auditable receipts, rollback, single owner writer.
7. Each new idea must explain existing alternatives and a falsifiable first pilot.
8. Current NOX R1 remains intact until independent release acceptance.
