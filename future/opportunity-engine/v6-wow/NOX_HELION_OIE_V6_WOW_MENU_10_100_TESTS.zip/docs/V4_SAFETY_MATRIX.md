# Non-negotiable safety and correctness boundaries

- No API calls without explicit `--network`; fixed provider hostnames and no redirects.
- No retrieval from arbitrary URL, localhost or metadata IPs via research provider.
- No operation can promote a future startup hypothesis into verified market demand or commercial launch.
- Local Ollama outputs never issue grants, legal/medical judgments, or verified evidence.
- Prior-art bibliographic hits cannot serve as multiple independent market-demand sources.
- No reading health, children, financial, family, or company files without owner consent and a domain-specific purpose.
- No new model downloads, weights, training jobs, shell execution, purchases, marketing campaigns or email outreach.
- All source code and user-visible draft statuses remain future-only and do not impact R1.
- Do not show 34/34 or 68/68 source tests as independent Windows QA, market proof, or a safe clinical solution.
