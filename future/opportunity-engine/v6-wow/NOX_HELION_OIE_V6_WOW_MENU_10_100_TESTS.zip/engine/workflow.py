"""Advisory stage machine. No automatic deployment or external authorization."""
from __future__ import annotations
from .gates import audit,can_enter_pilot

STEPS={'IDEA_UNVERIFIED':{'RESEARCHING','HOLD','KILL'},
       'RESEARCHING':{'EVIDENCE_READY','HOLD','KILL'},
       'EVIDENCE_READY':{'PILOT_APPROVED','HOLD','KILL'},
       'PILOT_APPROVED':{'PILOT_DONE','PILOT_FAILED','HOLD'},
       'PILOT_DONE':{'SCALE_REVIEW','HOLD','KILL'},
       'PILOT_FAILED':{'KILL','RESEARCHING','HOLD'},
       'SCALE_REVIEW':{'KILL','HOLD'},'HOLD':{'RESEARCHING','KILL'},'KILL':set()}

def plan_transition(idea,target):
    """Planning only; never mutates catalog or supplies a permit."""
    source=idea.get('status')
    blockers=[]
    if target not in STEPS.get(source,set()):blockers.append('ILLEGAL_TRANSITION')
    if target=='EVIDENCE_READY':blockers.extend(audit(idea)['research_review_blockers']);blockers.append('NEED_INDEPENDENT_SOURCE_READBACK')
    if target in {'PILOT_APPROVED','PILOT_DONE','SCALE_REVIEW'}:blockers.extend(can_enter_pilot(idea))
    if target=='SCALE_REVIEW':blockers.append('NEED_EXTERNAL_MEASURED_OUTCOME_RECEIPT')
    if target=='KILL' and not idea.get('kill_reason'):blockers.append('NEED_RECORDED_KILL_REASON')
    # Even RESEARCHING is an advisory state unless actually authorized in owner system.
    return {'idea_id':idea.get('id'),'from':source,'to':target,'action':'ADVISORY_ONLY',
            'permitted_by_evidence':not blockers,'blockers':sorted(set(blockers))}
