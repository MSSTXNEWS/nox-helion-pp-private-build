"""Fail-closed portfolio and source/evidence controls. No external actions."""
from __future__ import annotations
from datetime import date
from ipaddress import ip_address
from urllib.parse import urlsplit
import re

STATUSES={"IDEA_UNVERIFIED","RESEARCHING","EVIDENCE_READY","PILOT_APPROVED","PILOT_DONE","PILOT_FAILED","SCALE_REVIEW","KILL","HOLD"}
REQUIRED={"id","name","category","stream","problem_hypothesis","payer_hypothesis","beneficiary","first_5min_value","reuse_components","regulatory_risk","pilot_experiment","status"}
SENSITIVE={"MEDICAL_REGULATED","CHILD_DATA","CHILD_IP","MEDICAL_PRIVACY","PRIVACY_SECURITY","HEALTH_PRIVACY"}
AXES=("need","feasibility","distribution","repeat_value","economics","reuse","pilot_cost","safety")
# Conservative offline eTLD+1 approximation; no claim of global PSL coverage.
MULTI_SUFFIXES={"co.uk","org.uk","ac.uk","com.au","com.br","co.jp","co.nz","com.mx","com.tr","co.in","com.cn"}

def source_host(url):
    if not isinstance(url,str) or any(c.isspace() for c in url): return None
    try:
        parsed=urlsplit(url)
        if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None,443):return None
        host=parsed.hostname.lower().rstrip('.')
        if host=='localhost' or host.endswith(('.local','.internal','.invalid','.test','.example')):return None
        try: ip_address(host); return None
        except ValueError:pass
        bits=host.split('.')
        if len(bits)<2 or any(not re.fullmatch('[a-z0-9-]+',x) or x.startswith('-') or x.endswith('-') for x in bits): return None
        if bits[-1] in ('localhost','invalid','test','example') or len(bits[-1])<2:return None
        if '.'.join(bits[-2:]) in MULTI_SUFFIXES and len(bits)>=3:return '.'.join(bits[-3:])
        return '.'.join(bits[-2:])
    except (ValueError,TypeError):return None

def valid_iso_date(s):
    try:
        if not isinstance(s,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',s):return False
        return date(2020,1,1)<=date.fromisoformat(s)<=date.today()
    except ValueError:return False

def validate(idea):
    if not isinstance(idea,dict):return ['NOT_AN_OBJECT']
    errors=[]
    for key in sorted(REQUIRED):
        if not isinstance(idea.get(key),str) or not idea[key].strip():errors.append('MISSING_'+key)
    if not re.fullmatch('OI-[0-9]{3}',str(idea.get('id',''))):errors.append('INVALID_ID')
    if idea.get('status') not in STATUSES:errors.append('INVALID_STATUS')
    if idea.get('publication_authorized') is True and idea.get('owner_approved_to_build') is not True:errors.append('PUBLISH_WITHOUT_OWNER_GRANT')
    if type(idea.get('owner_approved_to_build')) is not bool:errors.append('INVALID_OWNER_FIELD')
    return errors

def evidence_ready(idea):
    """Dated domain-diverse leads are ONLY research review candidates, not verified demand."""
    rows=idea.get('external_demand_evidence')
    if not isinstance(rows,list):rows=[]
    domains={source_host(x.get('url')) for x in rows if isinstance(x,dict) and valid_iso_date(x.get('date')) and isinstance(x.get('claim'),str) and len(x['claim'].strip())>=12}
    domains.discard(None)
    comp=idea.get('competitor_evidence')
    if not isinstance(comp,list):comp=[]
    has_comp=any(isinstance(x,dict) and source_host(x.get('url')) and valid_iso_date(x.get('date')) and isinstance(x.get('competitor'),str) and len(x['competitor'].strip())>=2 for x in comp)
    blockers=[]
    if len(domains)<2:blockers.append('NEED_2_INDEPENDENT_DEMAND_HOSTS')
    if not has_comp:blockers.append('NEED_COMPETITOR_PRIOR_ART')
    return blockers

def can_enter_pilot(idea, trusted_authority=None):
    b=validate(idea)+evidence_ready(idea)
    # True in a JSON file is NOT a verified consent or a real grant.
    grant=idea.get('owner_grant_receipt')
    if not (isinstance(grant,dict) and grant.get('action')=='pilot' and grant.get('status')=='VERIFIED_BY_EXTERNAL_OWNER_AUTH' and isinstance(grant.get('receipt_id'),str) and len(grant['receipt_id'])>=12):b.append('NEED_AUTHENTICATED_OWNER_GRANT')
    if idea.get('regulatory_risk') in SENSITIVE:
        right=idea.get('independent_rights_review_receipt')
        if not (isinstance(right,dict) and right.get('verdict')=='APPROVED' and right.get('status')=='VERIFIED_BY_INDEPENDENT_REVIEWER'):b.append('NEED_INDEPENDENT_RIGHTS_REVIEW')
    sha=idea.get('pilot_protocol_sha256')
    if not isinstance(sha,str) or not re.fullmatch('[a-f0-9]{64}',sha):b.append('NEED_FROZEN_PILOT_PROTOCOL')
    # Research sources and owner records stored as untrusted JSON are proposals only.
    if idea.get('external_evidence_verified') is not True:b.append('NEED_INDEPENDENT_EVIDENCE_VALIDATION')
    # No offline JSON field grants real-world authority; host must validate out-of-band.
    if trusted_authority is None or not callable(trusted_authority) or trusted_authority(idea) is not True:
        b.append('NEED_TRUSTED_EXTERNAL_AUTHORITY')
    return sorted(set(b))

def score_exploratory_only(idea):
    values=idea.get('owner_assessment')
    if not isinstance(values,dict) or evidence_ready(idea):return None
    if set(values)!=set(AXES) or any(type(values[k]) not in (int,float) or not 0<=values[k]<=5 for k in AXES):return None
    return round(sum(values.values())/len(AXES),2)

def audit(idea):
    return {'id':idea.get('id'), 'status':idea.get('status'), 'schema_errors':validate(idea),
            'research_review_blockers':evidence_ready(idea),'pilot_blockers':can_enter_pilot(idea),
            'exploratory_score_not_success_probability':score_exploratory_only(idea),
            'verified_demand':False if idea.get('external_evidence_verified') is not True else 'REQUIRES_AUTHENTICATED_READBACK',
            'release_ready':False}
