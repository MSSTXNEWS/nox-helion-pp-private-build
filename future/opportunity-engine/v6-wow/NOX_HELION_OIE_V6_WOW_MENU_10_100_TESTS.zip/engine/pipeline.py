"""One real local mission: discover -> optional research -> critique -> evidence gates -> artifact.
NEVER drives paid services, jobs, grants, publication, deployment, models/weights, or health action.
"""
from __future__ import annotations
import json,hashlib
from pathlib import Path
from .discovery import propose
from .gates import evidence_ready
from .research import query_crossref,query_openalex,SourceError
from .llm import propose_local,LocalModelError

STAGES=('DISCOVER','CONTEXT','SKEPTIC','PASSPORT','QA')

def run_mission(catalog, *, count=3, seed=0, theme='', provider='offline',
                research='none', network=False, model=None, llm_transport=None,
                research_transport=None, journal=None, max_context_queries=1):
    if research not in ('none','crossref','openalex'):raise ValueError('UNSUPPORTED_RESEARCH_PROVIDER')
    if provider not in ('offline','ollama'):raise ValueError('UNSUPPORTED_IDEATION_PROVIDER')
    if research!='none' and not network:raise ValueError('NETWORK_NOT_AUTHORIZED')
    if max_context_queries not in (0,1,2):raise ValueError('CONTEXT_QUERY_LIMIT')
    if provider=='offline':
        result=propose(catalog,limit=count,seed=seed,theme=theme)
        candidates=result['candidates']
    else:
        if count!=1:raise ValueError('LOCAL_MODEL_ONE_CANDIDATE_PER_MISSION')
        candidates=[propose_local(theme or 'Find one useful unmet human need and safe startup concept',
                       model=model,enabled=True,transport=llm_transport)]
    findings=[]
    for n,c in enumerate(candidates):
        context={'provider':research,'status':'NOT_REQUESTED','hits':[]}
        if research!='none' and n<max_context_queries:
            try:
                query=' '.join(str(c.get('problem',c.get('content',{}).get('problem',''))).split())[:120]
                func=query_crossref if research=='crossref' else query_openalex
                context=func(query,network=True,transport=research_transport)
                context['status']='SCHOLARLY_CONTEXT_ONLY'
            except SourceError as ex:context={'provider':research,'status':'UNAVAILABLE','reason':str(ex),'hits':[]}
        # Scholarly hits are for prior research and cannot be mis-classified as two demand sources.
        critique={'alternatives_to_research':[c.get('existing_alternative_to_check','UNKNOWN')],
                  'market_demand':'UNKNOWN','market_validated':False,
                  'assumptions_to_falsify':[c.get('first_falsification_test',c.get('content',{}).get('pilot_to_falsify','UNKNOWN'))],
                  'confidence':'HYPOTHESIS_ONLY',
                  'why_not_ready':['TWO_INDEPENDENT_MARKET_DEMAND_SOURCES_NOT_VERIFIED',
                                   'COMPETITOR_REVIEW_PENDING','OWNER_AUTHORIZATION_NOT_PRESENT',
                                   'EXTERNAL_PILOT_NOT_RUN']}
        findings.append({'candidate':c,'context':context,'critic':critique,
            'passports':{'idea_id':c['candidate_id'],'name':c['name'],'status':'IDEA_UNVERIFIED',
                         'user_benefit':c.get('first_5min_value',c.get('content',{}).get('first_value','UNKNOWN')),
                         'payer_hypothesis':c.get('payer_hypothesis',c.get('content',{}).get('payer_hypothesis')),
                         'safety_and_rights':'REVIEW_REQUIRED',
                         'pilot':'NOT_RUN'},'acceptance':'RESEARCH_REQUIRED'})
    out={'schema':'NOX_OIE_V4_MISSION_V1','mode':'READ_ONLY_RESEARCH' if network else 'OFFLINE',
         'steps':list(STAGES),'candidate_count':len(findings),'results':findings,
         'outcome':'IDEA_DRAFTS_ONLY','market_demand_verified':False,'pilot_approved':False,
         'businesses_launched':0,'r1_touched':False}
    if journal is not None:
        from .journal import append
        out['journal_receipt']=append(journal,'EXPERIMENT_DESIGNED',{
          'kind':'OFFLINE_RESEARCH_MISSION','candidate_ids':[x['candidate']['candidate_id'] for x in findings],
          'verified_demand':False,'fingerprint':hashlib.sha256(json.dumps(out,ensure_ascii=False,sort_keys=True).encode()).hexdigest()})
    return out

def save_json_atomic(path,payload):
    file=Path(path)
    file.parent.mkdir(parents=True,exist_ok=True)
    content=json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2).encode('utf-8')
    # Avoid overwriting an existing accepted source or another worker's result.
    if file.exists():raise FileExistsError('REFUSE_OVERWRITE_RESULT')
    import os,tempfile
    fd,temp=tempfile.mkstemp(prefix='.oie-',suffix='.tmp',dir=file.parent)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(content);stream.flush();os.fsync(stream.fileno())
        # Use hard link for exclusive finalization; no overwrite race.
        os.link(temp,file)
    finally:
        if os.path.exists(temp):os.unlink(temp)
    return {'path':str(file),'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)}
