"""Offline ideation. Combinatorial *hypotheses*, not market research or LLM inference."""
from __future__ import annotations
from hashlib import sha256
import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def load_seeds():
    return json.loads((ROOT/'catalog'/'problem_seeds.json').read_text(encoding='utf-8'))

def _tokens(s):
    return set(re.findall(r'[\w]+',s.casefold())) - {'for','and','the','with','для','или','and','nox','ai','ии'}

def novelty_candidate(new_title,existing_titles):
    target=_tokens(new_title)
    if not target: return False
    for title in existing_titles:
        other=_tokens(title)
        if other and len(target&other)/len(target|other)>.70:return False
    return True

def propose(existing, limit=3, theme='', seed=0):
    """Deterministic independent idea drafts across different domains.

    *Never* presents hypotheses as verified market signals. Does not call network,
    store user data, use provider credentials or produce deployment scripts.
    """
    if not isinstance(limit,int) or not 1<=limit<=12: raise ValueError('count 1..12')
    problems=load_seeds()
    theme=theme.strip().casefold()
    known=[x['name'] for x in existing]
    candidates=[]
    for problem in problems:
        if theme and theme not in ' '.join(map(str,problem.values())).casefold():continue
        for tool in problem['pairing_options']:
            title=f"{problem['product_root']} + {tool['name']}"
            if not novelty_candidate(title,known):continue
            uid=sha256(f"{problem['key']}|{tool['name']}".encode()).hexdigest()[:12]
            candidates.append({'candidate_id':f'OC-{uid}', 'name':title,
                 'source':'CURATED_OFFLINE_HYPOTHESIS_ONLY', 'status':'IDEA_UNVERIFIED',
                 'problem':problem['unmet_need_hypothesis'], 'beneficiary':problem['beneficiary'],
                 'payer_hypothesis':problem['payer_hypothesis'], 'stream':problem['stream'],
                 'first_5min_value':f"{problem['user_action']}; затем {tool['experience']}",
                 'technical_reuse_hypothesis':tool['components'],
                 'existing_alternative_to_check':problem['alternative'],
                 'first_falsification_test':problem['pilot'],
                 'requires': ['external_prior_art','2_independent_demand_sources', 'permissions', 'owner_grant'],
                 'market_demand':'UNKNOWN', 'pilot_run':False, 'actual_revenue':None})
    # Stable seeded sort gives different bounded shortlists; diversity before final cut.
    candidates.sort(key=lambda x:sha256(f"{seed}|{x['candidate_id']}".encode()).hexdigest())
    result=[];seen=set()
    for c in candidates:
        if c['stream'] in seen:continue
        result.append(c);seen.add(c['stream'])
        if len(result)==limit:return {'count':len(result),'requested':limit,'mode':'OFFLINE_CREATIVE_HYPOTHESES','candidates':result}
    for c in candidates:
        if c not in result:result.append(c)
        if len(result)==limit:break
    return {'count':len(result),'requested':limit,'mode':'OFFLINE_CREATIVE_HYPOTHESES','candidates':result}
