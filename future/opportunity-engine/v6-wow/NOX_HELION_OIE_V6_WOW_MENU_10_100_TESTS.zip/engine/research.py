"""Read-only, allowlisted bibliographic research. A hit is NOT demand or novelty evidence.

Crossref API official docs: https://www.crossref.org/documentation/retrieve-metadata/rest-api/
OpenAlex official docs: https://help.openalex.org/api/
No unknown URL, redirects, credentials, file/localhost fetch, or arbitrary web scraping.
Default: OFFLINE; every network call requires the caller's explicit opt-in.
"""
from __future__ import annotations
import hashlib
import json
import re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import URLError, HTTPError

ALLOWED={'api.crossref.org','api.openalex.org'}
MAX_RESPONSE=1024*1024
USER_AGENT='NOX-OIE-Research/4.0 (read-only, contact configurable; no scraping)'

class SourceError(RuntimeError):
    pass

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise SourceError('REDIRECT_BLOCKED')

def secure_get_json(url, *, timeout=7, transport=None):
    u=urlsplit(url)
    if u.scheme!='https' or u.hostname not in ALLOWED or u.username or u.password or u.port not in (None,443) or u.fragment:
        raise SourceError('SOURCE_NOT_ALLOWLISTED')
    if transport is None:
        opener=build_opener(NoRedirect())
        def transport(target,timeout):
            req=Request(target,headers={'User-Agent':USER_AGENT,'Accept':'application/json'})
            return opener.open(req,timeout=timeout)
    try:
        with transport(url,timeout) as res:
            if getattr(res,'status',200)!=200:raise SourceError('UNEXPECTED_HTTP_STATUS')
            content_type=res.headers.get('Content-Type','application/json').lower()
            if 'json' not in content_type:raise SourceError('UNEXPECTED_CONTENT_TYPE')
            blob=res.read(MAX_RESPONSE+1)
            if len(blob)>MAX_RESPONSE:raise SourceError('RESPONSE_TOO_LARGE')
        out=json.loads(blob.decode('utf-8'))
        if not isinstance(out,dict):raise SourceError('INVALID_RESPONSE')
        return out,hashlib.sha256(blob).hexdigest()
    except (HTTPError,URLError,TimeoutError,UnicodeError,json.JSONDecodeError,ValueError) as exc:
        raise SourceError(f'SOURCE_FETCH_ERROR:{type(exc).__name__}') from exc

@dataclass(frozen=True)
class ResearchHit:
    provider:str
    title:str
    url:str
    date:str
    summary:str
    sha256:str
    classification:str='SCHOLARLY_CONTEXT_NOT_MARKET_DEMAND'

def query_crossref(term,*,network=False,transport=None,rows=4):
    if not network:raise SourceError('NETWORK_NOT_AUTHORIZED')
    if not isinstance(term,str) or not 2<=len(term.strip())<=140:raise SourceError('INVALID_QUERY')
    if not isinstance(rows,int) or not 1<=rows<=5:raise SourceError('ROW_LIMIT')
    url='https://api.crossref.org/works?'+urlencode({'query':term,'rows':rows,'select':'DOI,title,published,URL,container-title'})
    response,digest=secure_get_json(url,transport=transport)
    items=response.get('message',{}).get('items',[])
    if not isinstance(items,list):raise SourceError('INVALID_ITEMS')
    now=datetime.now(timezone.utc).date().isoformat()
    hits=[]
    for item in items[:rows]:
        if not isinstance(item,dict):continue
        raw_title=item.get('title',[])
        title=(raw_title[0] if isinstance(raw_title,list) and raw_title else '')
        doi=str(item.get('DOI','')).strip()
        if not title or not re.fullmatch(r'10\.\d{4,9}/\S+',doi):continue
        pub=item.get('published',{}).get('date-parts',[])
        year=str(pub[0][0]) if pub and isinstance(pub[0],list) and pub[0] else 'UNKNOWN'
        hits.append(asdict(ResearchHit('Crossref',str(title)[:300],f'https://doi.org/{doi}',year,
             'Bibliographic metadata only; not evidence of market demand or technical novelty',digest)))
    return {'provider':'crossref','query':term,'fetched_at':now,'source_endpoint':'https://api.crossref.org/works',
            'response_sha256':digest,'hits':hits,'count':len(hits),'verified_demand':False,'prior_art_complete':False}

def query_openalex(term,*,network=False,transport=None,rows=4,api_key=None):
    if not network:raise SourceError('NETWORK_NOT_AUTHORIZED')
    if not isinstance(term,str) or not 2<=len(term.strip())<=140:raise SourceError('INVALID_QUERY')
    if not isinstance(rows,int) or not 1<=rows<=5:raise SourceError('ROW_LIMIT')
    # A private API key goes in an Authorization header only when the host is integrated;
    # this offline adapter intentionally rejects client keys to avoid logging secret URLs.
    if api_key is not None:raise SourceError('CREDENTIALS_REQUIRE_HOST_ADAPTER')
    url='https://api.openalex.org/works?'+urlencode({'search':term,'per_page':rows})
    result,digest=secure_get_json(url,transport=transport)
    works=result.get('results',[])
    if not isinstance(works,list):raise SourceError('INVALID_ITEMS')
    hits=[]
    for work in works[:rows]:
        if not isinstance(work,dict):continue
        ident=str(work.get('id',''))
        if not ident.startswith('https://openalex.org/W'):continue
        hits.append(asdict(ResearchHit('OpenAlex',str(work.get('title',''))[:300],ident,
                    str(work.get('publication_year') or 'UNKNOWN'),
                    'OpenAlex indexed scholarly metadata; not independent proof of market demand',digest)))
    return {'provider':'openalex','query':term,'fetched_at':datetime.now(timezone.utc).date().isoformat(),
            'source_endpoint':'https://api.openalex.org/works','response_sha256':digest,
            'hits':hits,'count':len(hits),'verified_demand':False,'prior_art_complete':False}
