"""Review packet compiler: public source notes, NEVER authentication or verified market demand.
Independent user interviews and live customer receipts must be attached outside this component.
"""
from __future__ import annotations
from datetime import date
from hashlib import sha256
import json
from pathlib import Path
from .gates import source_host,valid_iso_date

CATEGORIES={'PUBLIC_CONTEXT','EXISTING_SOLUTION','PROVIDER_POLICY','INTERVIEW_TO_VALIDATE'}

def compile_research_packet(idea_id,source_notes):
    if not isinstance(idea_id,str) or not idea_id.startswith('OI-') or not idea_id[3:].isdigit():raise ValueError('INVALID_ID')
    if not isinstance(source_notes,list) or not 1<=len(source_notes)<=20:raise ValueError('BAD_NOTE_COUNT')
    out=[]
    for idx,n in enumerate(source_notes):
        if not isinstance(n,dict):raise ValueError('INVALID_NOTE')
        url=n.get('url')
        if source_host(url) is None:raise ValueError('INVALID_SOURCE_URL')
        title=n.get('title'); claim=n.get('claim'); category=n.get('category'); published=n.get('published')
        if not isinstance(title,str) or not 6<=len(title)<=300:raise ValueError('INVALID_TITLE')
        if not isinstance(claim,str) or not 16<=len(claim)<=1000:raise ValueError('INVALID_CLAIM')
        if category not in CATEGORIES:raise ValueError('UNKNOWN_CATEGORY')
        if not valid_iso_date(published):raise ValueError('INVALID_DATE')
        out.append({'note_id':f'{idea_id}-S{idx+1:02d}','url':url,'title':title,'claim':claim,'published':published,
                    'category':category,'source_domain_group':source_host(url),'source_content_verified_by_adapter':False,
                    'evidence_type':'PUBLIC_RESEARCH_LEAD_UNVERIFIED_BY_INDEPENDENT_REVIEWER'})
    # Even 2 domain groups cannot prove demand; no validated evidence flag.
    result={'schema':'NOX_OIE_PUBLIC_CONTEXT_V1','idea_id':idea_id,'source_count':len(out),
            'domain_groups':sorted(set(n['source_domain_group'] for n in out)),
            'notes':out,'market_demand_verified':False,'competitor_analysis_complete':False,
            'owner_grant_present':False,'status':'CONTEXT_REQUIRES_INDEPENDENT_REVIEW'}
    result['sha256']=sha256(json.dumps(result,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return result

def load_research_packet(path):
    p=Path(path)
    if not p.is_file() or p.stat().st_size>100000:raise ValueError('RESEARCH_PACKET_INVALID')
    obj=json.loads(p.read_text('utf-8'))
    if not isinstance(obj,dict):raise ValueError('RESEARCH_PACKET_INVALID')
    return compile_research_packet(obj['idea_id'],obj['notes'])
