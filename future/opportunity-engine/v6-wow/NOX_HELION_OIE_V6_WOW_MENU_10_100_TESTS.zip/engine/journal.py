"""Local append-only SQLite event chain, tamper-evident against accidental edits.

Not a cryptographic signature. A DB owner can rewrite history, so this is only
an integrity aid and must NOT be treated as legal/audit-grade attestation.
"""
from __future__ import annotations
from contextlib import closing
from datetime import datetime, timezone
from hashlib import sha256
import json, sqlite3
from pathlib import Path

def canonical(event):return json.dumps(event,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def _conn(path):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(str(p),timeout=10,isolation_level=None)
    c.execute('PRAGMA busy_timeout=10000')
    c.execute('CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL, prev_hash TEXT NOT NULL, entry_hash TEXT NOT NULL UNIQUE)')
    return c

def append(path,kind,payload):
    if kind not in {'CANDIDATE_DRAFTED','RESEARCH_FLAGGED','EXPERIMENT_DESIGNED','OUTCOME_RECORDED','KILL_RECOMMENDED'}:raise ValueError('Unsupported event kind')
    if not isinstance(payload,dict):raise TypeError('payload object required')
    with closing(_conn(path)) as c:
        c.execute('BEGIN IMMEDIATE')
        try:
            last=c.execute('SELECT seq,entry_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
            prev=last[1] if last else '0'*64
            ts=datetime.now(timezone.utc).replace(microsecond=0).isoformat()
            data=canonical({'ts':ts,'kind':kind,'payload':payload,'prev_hash':prev})
            digest=sha256(data.encode('utf-8')).hexdigest()
            c.execute('INSERT INTO events(ts,kind,payload,prev_hash,entry_hash) VALUES(?,?,?,?,?)',(ts,kind,canonical(payload),prev,digest))
            seq=c.execute('SELECT last_insert_rowid()').fetchone()[0]
            c.commit();return {'seq':seq,'entry_hash':digest}
        except Exception:
            c.rollback();raise

def verify(path):
    if not Path(path).is_file():return {'events':0,'valid':True,'note':'NO_JOURNAL_YET'}
    with closing(_conn(path)) as c:
        prev='0'*64;num=0
        for seq,ts,kind,payload,old,h in c.execute('SELECT seq,ts,kind,payload,prev_hash,entry_hash FROM events ORDER BY seq'):
            num+=1
            if old!=prev:return {'events':num,'valid':False,'error':'BROKEN_PREVIOUS_LINK','seq':seq}
            digest=sha256(canonical({'ts':ts,'kind':kind,'payload':json.loads(payload),'prev_hash':old}).encode()).hexdigest()
            if digest!=h:return {'events':num,'valid':False,'error':'ENTRY_CHANGED','seq':seq}
            prev=h
        return {'events':num,'valid':True,'last_hash':prev}
